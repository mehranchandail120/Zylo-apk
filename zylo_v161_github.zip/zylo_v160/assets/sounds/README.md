# Zylo Sound Assets

Place these audio files in this directory:

- `ringtone.mp3`   — Incoming call ringtone (loops until answered/declined, max 45s)
- `outgoing.mp3`   — Outgoing call dialing tone (loops until answered/timeout)

You can use any royalty-free MP3 tones.
Recommended: Download from Zedge, Pixabay, or Mixkit.
