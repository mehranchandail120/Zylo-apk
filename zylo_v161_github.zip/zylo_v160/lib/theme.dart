import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// ─────────────────────────────────────────────────────────────────────────────
// Zylo Design System
// Single source of truth for all colors, spacing, radius, and button styles.
// ─────────────────────────────────────────────────────────────────────────────

class AppColors {
  AppColors._();

  // ── Brand ─────────────────────────────────────────────────────────────────
  static const primary    = Color(0xFF0284C7); // Sky-600
  static const primaryDark = Color(0xFF0369A1); // Sky-700
  static const primaryLight = Color(0xFFE0F2FE); // Sky-100

  // ── Neutrals ──────────────────────────────────────────────────────────────
  static const ink        = Color(0xFF060E1C); // near-black (deeper)
  static const surface    = Color(0xFFFFFFFF); // page background (white)
  static const card       = Color(0xFFFAFBFC); // slightly off-white cards
  static const divider    = Color(0xFFD4DAE4);
  static const placeholder = Color(0xFFE8ECF1);

  // ── Semantic ──────────────────────────────────────────────────────────────
  static const success    = Color(0xFF059669);
  static const successBg  = Color(0xFFF0FDF4);
  static const danger     = Color(0xFFDC2626);
  static const dangerBg   = Color(0xFFFEF2F2);
  static const warning    = Color(0xFFD97706);
  static const warningBg  = Color(0xFFFFFBEB);
  static const info       = primary;
  static const infoBg     = primaryLight;

  // ── Text ──────────────────────────────────────────────────────────────────
  static const textPrimary   = ink;
  static const textSecondary = Color(0xFF3D5068); // darker secondary text
  static const textHint      = Color(0xFF6B7A8D); // darker hints
  static const textOnPrimary = Colors.white;
}

class AppSpacing {
  AppSpacing._();

  static const double xs  = 4.0;
  static const double sm  = 8.0;
  static const double md  = 12.0;
  static const double base = 16.0;
  static const double lg  = 20.0;
  static const double xl  = 24.0;
  static const double xxl = 32.0;

  // ── Standard padding presets ──────────────────────────────────────────────
  static const EdgeInsets pagePadding = EdgeInsets.symmetric(horizontal: base);
  static const EdgeInsets cardPadding = EdgeInsets.all(base);
  static const EdgeInsets buttonPaddingV = EdgeInsets.symmetric(vertical: 14);
  static const EdgeInsets buttonPaddingH = EdgeInsets.symmetric(horizontal: base, vertical: 14);
  static const EdgeInsets chipPadding = EdgeInsets.symmetric(horizontal: md, vertical: 6);
  static const EdgeInsets inputPadding = EdgeInsets.symmetric(horizontal: md, vertical: md);
}

class AppRadius {
  AppRadius._();

  static const double sm   = 8.0;
  static const double md   = 12.0;
  static const double base = 14.0;
  static const double lg   = 16.0;
  static const double xl   = 20.0;
  static const double xxl  = 24.0;
  static const double full = 999.0;

  static BorderRadius get card    => BorderRadius.circular(lg);
  static BorderRadius get button  => BorderRadius.circular(lg);
  static BorderRadius get input   => BorderRadius.circular(md);
  static BorderRadius get chip    => BorderRadius.circular(full);
  static BorderRadius get modal   => const BorderRadius.vertical(top: Radius.circular(xxl));
  static BorderRadius get badge   => BorderRadius.circular(full);
}

class AppTextStyles {
  AppTextStyles._();

  static const TextStyle h1 = TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppColors.primary, letterSpacing: -0.5);
  static const TextStyle h2 = TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.ink);
  static const TextStyle h3 = TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.ink);
  static const TextStyle body = TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: AppColors.ink);
  static const TextStyle bodySm = TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: AppColors.textSecondary);
  static const TextStyle caption = TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.textHint);
  static const TextStyle label = TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.ink);
  static const TextStyle buttonLabel = TextStyle(fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 0.4, color: AppColors.textOnPrimary);
}

// ─────────────────────────────────────────────────────────────────────────────
// Reusable Button Styles
// ─────────────────────────────────────────────────────────────────────────────

class AppButtonStyles {
  AppButtonStyles._();

  /// Primary filled blue button — main CTA
  static ButtonStyle primary({double? width}) => ElevatedButton.styleFrom(
    backgroundColor: AppColors.primary,
    foregroundColor: AppColors.textOnPrimary,
    elevation: 0,
    shadowColor: Colors.transparent,
    shape: RoundedRectangleBorder(borderRadius: AppRadius.button),
    padding: AppSpacing.buttonPaddingV,
    textStyle: AppTextStyles.buttonLabel,
    minimumSize: width != null ? Size(width, 48) : const Size(double.infinity, 48),
  );

  /// Outlined (secondary) button
  static ButtonStyle outlined({Color? color}) => OutlinedButton.styleFrom(
    foregroundColor: color ?? AppColors.primary,
    side: BorderSide(color: color ?? AppColors.primary, width: 1.5),
    shape: RoundedRectangleBorder(borderRadius: AppRadius.button),
    padding: AppSpacing.buttonPaddingV,
    textStyle: AppTextStyles.buttonLabel.copyWith(color: color ?? AppColors.primary),
    minimumSize: const Size(double.infinity, 48),
  );

  /// Ghost (text) button
  static ButtonStyle ghost({Color? color}) => TextButton.styleFrom(
    foregroundColor: color ?? AppColors.primary,
    shape: RoundedRectangleBorder(borderRadius: AppRadius.button),
    padding: AppSpacing.chipPadding,
    textStyle: AppTextStyles.buttonLabel.copyWith(color: color ?? AppColors.primary, letterSpacing: 0),
  );

  /// Danger filled button
  static ButtonStyle danger() => ElevatedButton.styleFrom(
    backgroundColor: AppColors.danger,
    foregroundColor: AppColors.textOnPrimary,
    elevation: 0,
    shape: RoundedRectangleBorder(borderRadius: AppRadius.button),
    padding: AppSpacing.buttonPaddingV,
    textStyle: AppTextStyles.buttonLabel,
    minimumSize: const Size(double.infinity, 48),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Input Decoration
// ─────────────────────────────────────────────────────────────────────────────

class AppInputDecoration {
  AppInputDecoration._();

  static InputDecoration standard({
    String? hint,
    String? label,
    Widget? prefix,
    Widget? suffix,
    Widget? prefixIcon,
    Widget? suffixIcon,
  }) => InputDecoration(
    hintText: hint,
    labelText: label,
    prefix: prefix,
    suffix: suffix,
    prefixIcon: prefixIcon,
    suffixIcon: suffixIcon,
    hintStyle: AppTextStyles.bodySm.copyWith(color: AppColors.textHint),
    filled: true,
    fillColor: AppColors.placeholder,
    contentPadding: AppSpacing.inputPadding,
    border: OutlineInputBorder(borderRadius: AppRadius.input, borderSide: BorderSide.none),
    enabledBorder: OutlineInputBorder(borderRadius: AppRadius.input, borderSide: BorderSide.none),
    focusedBorder: OutlineInputBorder(borderRadius: AppRadius.input, borderSide: const BorderSide(color: AppColors.primary, width: 1.5)),
    errorBorder: OutlineInputBorder(borderRadius: AppRadius.input, borderSide: const BorderSide(color: AppColors.danger, width: 1.5)),
    focusedErrorBorder: OutlineInputBorder(borderRadius: AppRadius.input, borderSide: const BorderSide(color: AppColors.danger, width: 2)),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// App Theme
// ─────────────────────────────────────────────────────────────────────────────

class AppTheme {
  // Legacy color references — kept for backward compatibility
  static const Color lightBlue   = AppColors.primaryLight;
  static const Color darkBlue    = AppColors.primary;
  static const Color black       = AppColors.ink;
  static const Color background  = AppColors.surface;
  static const Color primaryColor = AppColors.primary;

  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: false,
      brightness: Brightness.dark,
      primaryColor: AppColors.primary,
      scaffoldBackgroundColor: const Color(0xFF0D1117),
      dividerColor: const Color(0xFF2A3340),
      colorScheme: ColorScheme.dark(
        primary: AppColors.primary,
        secondary: AppColors.primary,
        surface: const Color(0xFF161B22),
        background: const Color(0xFF0D1117),
        error: AppColors.danger,
      ),
      textTheme: GoogleFonts.poppinsTextTheme(ThemeData.dark().textTheme).apply(
        bodyColor: Colors.white,
        displayColor: Colors.white,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF161B22),
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.white),
        titleTextStyle: TextStyle(
          color: AppColors.primary,
          fontSize: 22,
          fontWeight: FontWeight.w900,
          fontFamily: 'Poppins',
        ),
        surfaceTintColor: Colors.transparent,
      ),
      cardColor: const Color(0xFF161B22),
      cardTheme: CardThemeData(
        color: const Color(0xFF161B22),
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: AppRadius.card),
        margin: const EdgeInsets.symmetric(vertical: AppSpacing.xs),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: AppButtonStyles.primary(),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: AppButtonStyles.outlined(),
      ),
      textButtonTheme: TextButtonThemeData(
        style: AppButtonStyles.ghost(),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFF1E2530),
        hintStyle: AppTextStyles.bodySm.copyWith(color: const Color(0xFF6B7280)),
        contentPadding: AppSpacing.inputPadding,
        border: OutlineInputBorder(borderRadius: AppRadius.input, borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: AppRadius.input, borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(borderRadius: AppRadius.input, borderSide: const BorderSide(color: AppColors.primary, width: 1.5)),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: const Color(0xFF1E2530),
        selectedColor: AppColors.primaryDark,
        labelStyle: AppTextStyles.label.copyWith(color: Colors.white),
        padding: AppSpacing.chipPadding,
        shape: RoundedRectangleBorder(borderRadius: AppRadius.chip),
        side: BorderSide.none,
      ),
      snackBarTheme: const SnackBarThemeData(
        backgroundColor: Color(0xFF1E2530),
        contentTextStyle: TextStyle(color: Colors.white, fontSize: 13),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(AppRadius.md))),
        behavior: SnackBarBehavior.floating,
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: Color(0xFF161B22),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.xxl)),
        ),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: const Color(0xFF161B22),
        shape: RoundedRectangleBorder(borderRadius: AppRadius.card),
        titleTextStyle: AppTextStyles.h2.copyWith(color: Colors.white),
        contentTextStyle: AppTextStyles.body.copyWith(color: Colors.white70),
      ),
    );
  }

  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: false,
      primaryColor: AppColors.primary,
      scaffoldBackgroundColor: AppColors.surface,
      dividerColor: AppColors.divider,
      colorScheme: ColorScheme.light(
        primary: AppColors.primary,
        secondary: AppColors.primary,
        surface: AppColors.card,
        background: AppColors.surface,
        error: AppColors.danger,
      ),
      textTheme: GoogleFonts.poppinsTextTheme().apply(
        bodyColor: AppColors.ink,
        displayColor: AppColors.ink,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.card,
        elevation: 0,
        iconTheme: IconThemeData(color: AppColors.ink),
        titleTextStyle: TextStyle(
          color: AppColors.primary,
          fontSize: 22,
          fontWeight: FontWeight.w900,
          fontFamily: 'Poppins',
        ),
        surfaceTintColor: Colors.transparent,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: AppButtonStyles.primary(),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: AppButtonStyles.outlined(),
      ),
      textButtonTheme: TextButtonThemeData(
        style: AppButtonStyles.ghost(),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.placeholder,
        hintStyle: AppTextStyles.bodySm.copyWith(color: AppColors.textHint),
        contentPadding: AppSpacing.inputPadding,
        border: OutlineInputBorder(borderRadius: AppRadius.input, borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: AppRadius.input, borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(borderRadius: AppRadius.input, borderSide: const BorderSide(color: AppColors.primary, width: 1.5)),
      ),
      cardTheme: CardThemeData(
        color: AppColors.card,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: AppRadius.card),
        margin: const EdgeInsets.symmetric(vertical: AppSpacing.xs),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: AppColors.placeholder,
        selectedColor: AppColors.primaryLight,
        labelStyle: AppTextStyles.label,
        padding: AppSpacing.chipPadding,
        shape: RoundedRectangleBorder(borderRadius: AppRadius.chip),
        side: BorderSide.none,
      ),
      snackBarTheme: const SnackBarThemeData(
        backgroundColor: AppColors.ink,
        contentTextStyle: TextStyle(color: Colors.white, fontSize: 13),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(AppRadius.md))),
        behavior: SnackBarBehavior.floating,
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: AppColors.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.xxl)),
        ),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: AppColors.card,
        shape: RoundedRectangleBorder(borderRadius: AppRadius.card),
        titleTextStyle: AppTextStyles.h2,
        contentTextStyle: AppTextStyles.body,
      ),
    );
  }
}
