import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'zylo_avatar.dart';

// ── Contact Card Message Bubble ───────────────────────────────────────────────
class ContactCardBubble extends StatelessWidget {
  final String contactUid;
  final String contactName;
  final String contactPhoto;
  final String contactUsername;
  final bool isMe;
  final VoidCallback? onViewProfile;

  const ContactCardBubble({
    super.key,
    required this.contactUid,
    required this.contactName,
    required this.contactPhoto,
    required this.contactUsername,
    required this.isMe,
    this.onViewProfile,
  });

  @override
  Widget build(BuildContext context) {
    const blue = Color(0xFF0284C7);
    final bg = isMe ? blue.withValues(alpha: 0.08) : Colors.grey[100]!;
    final borderColor = isMe ? blue.withValues(alpha: 0.25) : Colors.grey[300]!;

    return GestureDetector(
      onTap: onViewProfile,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 220),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: borderColor),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              CircleAvatar(
                radius: 22,
                backgroundColor: blue,
                backgroundImage: contactPhoto.isNotEmpty
                    ? NetworkImage(contactPhoto)
                    : null,
                child: contactPhoto.isEmpty
                    ? Text(
                        contactName.isNotEmpty
                            ? contactName[0].toUpperCase()
                            : '?',
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 18))
                    : null,
              ),
              const SizedBox(width: 10),
              Flexible(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      contactName,
                      style: const TextStyle(
                          fontWeight: FontWeight.w800, fontSize: 14),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      '@$contactUsername',
                      style: TextStyle(
                          fontSize: 11,
                          color: Colors.grey[500],
                          fontWeight: FontWeight.w500),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ]),
            const SizedBox(height: 10),
            const Divider(height: 1),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: TextButton.icon(
                onPressed: onViewProfile,
                icon: const Icon(Icons.person_outline, size: 16),
                label: const Text('View Profile',
                    style:
                        TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                style: TextButton.styleFrom(
                  foregroundColor: blue,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8)),
                  backgroundColor: blue.withValues(alpha: 0.08),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Share Contact Sheet ────────────────────────────────────────────────────────
class ShareContactSheet extends StatefulWidget {
  final String myUid;
  final Future<void> Function(Map<String, dynamic> contact) onShare;

  const ShareContactSheet(
      {super.key, required this.myUid, required this.onShare});

  @override
  State<ShareContactSheet> createState() => _ShareContactSheetState();
}

class _ShareContactSheetState extends State<ShareContactSheet> {
  final _search = TextEditingController();
  String _query = '';
  static const _blue = Color(0xFF0284C7);

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.75,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(children: [
        Container(
          margin: const EdgeInsets.only(top: 10, bottom: 4),
          width: 40,
          height: 4,
          decoration: BoxDecoration(
              color: Colors.grey[300],
              borderRadius: BorderRadius.circular(10)),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(20, 10, 20, 8),
          child: Row(children: [
            Icon(Icons.contact_page_outlined, color: _blue),
            SizedBox(width: 8),
            Text('Share Contact',
                style:
                    TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: TextField(
            controller: _search,
            decoration: InputDecoration(
              hintText: 'Search users...',
              prefixIcon:
                  const Icon(Icons.search, color: Colors.grey, size: 20),
              filled: true,
              fillColor: Colors.grey[100],
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none),
              contentPadding: const EdgeInsets.symmetric(vertical: 10),
            ),
            onChanged: (v) => setState(() => _query = v.toLowerCase().trim()),
          ),
        ),
        const Divider(height: 1),
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('users')
                .orderBy('username')
                .snapshots(),
            builder: (ctx, snap) {
              if (!snap.hasData) {
                return const Center(
                    child:
                        CircularProgressIndicator(color: _blue));
              }
              final docs = snap.data!.docs
                  .where((d) => d.id != widget.myUid)
                  .where((d) {
                final data = d.data() as Map<String, dynamic>;
                final uname =
                    (data['username'] ?? '').toString().toLowerCase();
                return _query.isEmpty || uname.contains(_query);
              }).toList();

              if (docs.isEmpty) {
                return const Center(
                    child: Text('No users found',
                        style: TextStyle(color: Colors.grey)));
              }

              return ListView.builder(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                itemCount: docs.length,
                itemBuilder: (_, i) {
                  final data =
                      docs[i].data() as Map<String, dynamic>;
                  final uid = docs[i].id;
                  final name = data['username'] ?? 'User';
                  final photo = data['photoURL'] ?? '';
                  final bio = data['bio'] ?? '';

                  return ListTile(
                    leading: CircleAvatar(
                      radius: 22,
                      backgroundColor: _blue,
                      backgroundImage:
                          photo.isNotEmpty ? NetworkImage(photo) : null,
                      child: photo.isEmpty
                          ? Text(name[0].toUpperCase(),
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w700))
                          : null,
                    ),
                    title: Text(name,
                        style: const TextStyle(
                            fontWeight: FontWeight.w700, fontSize: 14)),
                    subtitle: bio.isNotEmpty
                        ? Text(bio,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                fontSize: 11, color: Colors.grey[500]))
                        : null,
                    trailing: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        widget.onShare({
                          'contactUid': uid,
                          'contactName': name,
                          'contactPhoto': photo,
                          'contactUsername': name,
                        });
                      },
                      style: TextButton.styleFrom(
                        foregroundColor: _blue,
                        backgroundColor: _blue.withValues(alpha: 0.08),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 8),
                      ),
                      child: const Text('Share',
                          style: TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 12)),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ]),
    );
  }
}
