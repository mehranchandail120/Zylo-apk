import 'package:flutter/material.dart';
import '../services/translation_service.dart';

/// Shows a dialog asking the user to download an ML Kit translation model.
///
/// Usage — from any widget that has access to [TranslationService]:
/// ```dart
/// final result = await translationService.translate(message);
/// if (result == TranslationResult.modelNotDownloaded && context.mounted) {
///   await TranslationDownloadDialog.show(
///     context: context,
///     service: translationService,
///     langTag: translationService.inLang,
///   );
/// }
/// ```
class TranslationDownloadDialog extends StatefulWidget {
  final TranslationService service;
  final String langTag;

  const TranslationDownloadDialog({
    super.key,
    required this.service,
    required this.langTag,
  });

  /// Convenience method — shows dialog and awaits result.
  /// Returns true if model was successfully downloaded.
  static Future<bool> show({
    required BuildContext context,
    required TranslationService service,
    required String langTag,
  }) async {
    final result = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => TranslationDownloadDialog(service: service, langTag: langTag),
    );
    return result ?? false;
  }

  @override
  State<TranslationDownloadDialog> createState() => _TranslationDownloadDialogState();
}

class _TranslationDownloadDialogState extends State<TranslationDownloadDialog> {
  _Phase _phase = _Phase.asking;
  double _progress = 0.0;
  String? _error;

  String get _langName =>
      TranslationService.supportedLanguages[widget.langTag] ?? widget.langTag;

  Future<void> _startDownload() async {
    setState(() => _phase = _Phase.downloading);

    final ok = await widget.service.downloadModel(
      widget.langTag,
      onProgress: (p) {
        if (mounted) setState(() => _progress = p);
      },
    );

    if (!mounted) return;

    if (ok) {
      Navigator.of(context).pop(true);
    } else {
      setState(() {
        _phase = _Phase.error;
        _error = widget.service.downloadError ?? 'Download failed. Please try again.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return switch (_phase) {
      _Phase.asking   => _AskDialog(langName: _langName, onAccept: _startDownload,
                                     onDecline: () => Navigator.of(context).pop(false)),
      _Phase.downloading => _ProgressDialog(langName: _langName, progress: _progress),
      _Phase.error    => _ErrorDialog(error: _error!, onRetry: _startDownload,
                                      onCancel: () => Navigator.of(context).pop(false)),
    };
  }
}

enum _Phase { asking, downloading, error }

// ── Ask permission ────────────────────────────────────────────────────────────
class _AskDialog extends StatelessWidget {
  final String langName;
  final VoidCallback onAccept;
  final VoidCallback onDecline;

  const _AskDialog({required this.langName, required this.onAccept, required this.onDecline});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Row(children: [
        const Icon(Icons.translate, size: 22),
        const SizedBox(width: 8),
        const Text('Download Translation Model'),
      ]),
      content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(
          'To translate messages to $langName, Zylo needs to download a '
          'language model (~30 MB).',
        ),
        const SizedBox(height: 8),
        const Text(
          'This is a one-time download and works offline afterwards.',
          style: TextStyle(fontSize: 13, color: Colors.grey),
        ),
      ]),
      actions: [
        TextButton(onPressed: onDecline, child: const Text('Not Now')),
        FilledButton.icon(
          onPressed: onAccept,
          icon: const Icon(Icons.download, size: 18),
          label: const Text('Download'),
        ),
      ],
    );
  }
}

// ── Downloading progress ──────────────────────────────────────────────────────
class _ProgressDialog extends StatelessWidget {
  final String langName;
  final double progress;

  const _ProgressDialog({required this.langName, required this.progress});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Text('Downloading $langName model…'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        LinearProgressIndicator(value: progress > 0 ? progress : null),
        const SizedBox(height: 12),
        Text(
          progress > 0 ? '${(progress * 100).toStringAsFixed(0)}%' : 'Starting…',
          style: const TextStyle(fontSize: 13),
        ),
      ]),
    );
  }
}

// ── Error ─────────────────────────────────────────────────────────────────────
class _ErrorDialog extends StatelessWidget {
  final String error;
  final VoidCallback onRetry;
  final VoidCallback onCancel;

  const _ErrorDialog({required this.error, required this.onRetry, required this.onCancel});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: const Row(children: [
        Icon(Icons.error_outline, color: Colors.red, size: 22),
        SizedBox(width: 8),
        Text('Download Failed'),
      ]),
      content: Text(error),
      actions: [
        TextButton(onPressed: onCancel, child: const Text('Cancel')),
        FilledButton(onPressed: onRetry, child: const Text('Retry')),
      ],
    );
  }
}
