// ═══════════════════════════════════════════════════════════════════════════════
// zylo_chat_design.dart — Zylo Chat UI Design Components  v128
// All bubbles LEFT-aligned. Received: avatar inside bubble row. Sent: plain left.
// Background: smooth linen/geometric pattern. White clean bubbles.
// ═══════════════════════════════════════════════════════════════════════════════

import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';

// ── Brand tokens ─────────────────────────────────────────────────────────────
const kBrand       = Color(0xFF0284C7);
const kBrandLight  = Color(0xFF0EA5E9);
const kBrandGlow   = Color(0x300284C7);
const kBgPage      = Color(0xFFF0F5FA);
const kBgList      = Color(0xFFF8FAFC);
const kBubbleSent1 = Color(0xFF0284C7);
const kBubbleSent2 = Color(0xFF38BDF8);
const kBubbleRecv  = Color(0xFFFFFFFF);
const kOnlineDot   = Color(0xFF10B981);

// ═══════════════════════════════════════════════════════════════════════════════
// 1.  Dashed Animated Ring Avatar
// ═══════════════════════════════════════════════════════════════════════════════

class ZyloDashedRingAvatar extends StatefulWidget {
  final Widget child;
  final double size;
  final Color color;
  final bool animate;
  final bool showRing;

  const ZyloDashedRingAvatar({
    super.key,
    required this.child,
    required this.size,
    this.color = kBrand,
    this.animate = true,
    this.showRing = true,
  });

  @override
  State<ZyloDashedRingAvatar> createState() => _ZyloDashedRingAvatarState();
}

class _ZyloDashedRingAvatarState extends State<ZyloDashedRingAvatar>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 10));
    if (widget.animate) _ctrl.repeat();
  }

  @override
  void didUpdateWidget(ZyloDashedRingAvatar old) {
    super.didUpdateWidget(old);
    if (widget.animate && !old.animate) _ctrl.repeat();
    if (!widget.animate && old.animate) _ctrl.stop();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    if (!widget.showRing) {
      return SizedBox(width: widget.size, height: widget.size, child: widget.child);
    }
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, child) => CustomPaint(
        painter: _DashedRingPainter(progress: _ctrl.value, color: widget.color, gap: widget.size * 0.04),
        child: child,
      ),
      child: Padding(
        padding: EdgeInsets.all(widget.size * 0.07),
        child: ClipOval(
          child: SizedBox(width: widget.size * 0.86, height: widget.size * 0.86, child: widget.child),
        ),
      ),
    );
  }
}

class _DashedRingPainter extends CustomPainter {
  final double progress;
  final Color color;
  final double gap;
  const _DashedRingPainter({required this.progress, required this.color, required this.gap});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round;
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 1.2;
    const int dashCount = 14;
    const double dashFraction = 0.45;
    const double tau = math.pi * 2;
    final double segAngle = tau / dashCount;
    final double dashAngle = segAngle * dashFraction;
    final double rotOffset = progress * tau;
    for (int i = 0; i < dashCount; i++) {
      final startAngle = i * segAngle - (tau / 4) + rotOffset;
      canvas.drawArc(Rect.fromCircle(center: center, radius: radius), startAngle, dashAngle, false, paint);
    }
  }

  @override
  bool shouldRepaint(_DashedRingPainter old) => old.progress != progress || old.color != color;
}

// ═══════════════════════════════════════════════════════════════════════════════
// 2.  Bubble Decorations — WHITE clean bubbles, both sides
//     Sent: white with subtle blue tint border + soft shadow
//     Recv: pure white with light grey border
//     Shape: pill-like, smooth — left tail for recv (top-left sharp), 
//            sent: top-right sharp
// ═══════════════════════════════════════════════════════════════════════════════

BoxDecoration sentBubbleDecoration({bool isPinned = false}) {
  return BoxDecoration(
    color: const Color(0xFFFFF8F2), // warm off-white for sent messages
    borderRadius: const BorderRadius.only(
      topLeft: Radius.circular(20),
      topRight: Radius.circular(6),   // sharp corner = "tail" side
      bottomLeft: Radius.circular(20),
      bottomRight: Radius.circular(20),
    ),
    border: Border.all(color: const Color(0xFFE8D5C0), width: 1.0),
    boxShadow: [
      BoxShadow(
        color: const Color(0xFF0284C7).withValues(alpha: 0.10),
        blurRadius: 12,
        spreadRadius: 0,
        offset: const Offset(0, 3),
      ),
      BoxShadow(
        color: Colors.black.withValues(alpha: 0.04),
        blurRadius: 4,
        offset: const Offset(0, 1),
      ),
      if (isPinned)
        const BoxShadow(color: Color(0x55FFA500), blurRadius: 8, spreadRadius: 1),
    ],
  );
}

BoxDecoration recvBubbleDecoration({bool isPinned = false}) {
  return BoxDecoration(
    color: Colors.white,
    borderRadius: const BorderRadius.only(
      topLeft: Radius.circular(6),    // sharp = "tail" side
      topRight: Radius.circular(20),
      bottomLeft: Radius.circular(20),
      bottomRight: Radius.circular(20),
    ),
    border: Border.all(color: const Color(0xFFE2E8F0), width: 1.0),
    boxShadow: [
      BoxShadow(
        color: Colors.black.withValues(alpha: 0.07),
        blurRadius: 10,
        spreadRadius: 0,
        offset: const Offset(0, 3),
      ),
      BoxShadow(
        color: Colors.black.withValues(alpha: 0.03),
        blurRadius: 3,
        offset: const Offset(0, 1),
      ),
      if (isPinned)
        const BoxShadow(color: Color(0x55FFA500), blurRadius: 8, spreadRadius: 1),
    ],
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// 3.  Glass Input Bar
// ═══════════════════════════════════════════════════════════════════════════════

class ZyloGlassInputBar extends StatelessWidget {
  final Widget child;
  const ZyloGlassInputBar({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 2, 8, 4),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(32),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.97),
              borderRadius: BorderRadius.circular(32),
              boxShadow: [
                BoxShadow(color: Colors.black.withValues(alpha: 0.06), blurRadius: 8, offset: const Offset(0, 2)),
              ],
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 4.  Glass Search Bar
// ═══════════════════════════════════════════════════════════════════════════════

class ZyloGlassSearchBar extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final VoidCallback? onClear;

  const ZyloGlassSearchBar({super.key, required this.controller, this.hint = 'Search...', this.onClear});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: Container(
          height: 42,
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.72),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white.withValues(alpha: 0.6), width: 0.8),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 6, offset: const Offset(0, 2))],
          ),
          child: TextField(
            controller: controller,
            style: const TextStyle(fontSize: 13.5, color: Color(0xFF1E293B)),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(color: Color(0xFF94A3B8), fontSize: 13.5),
              prefixIcon: const Icon(Icons.search_rounded, color: Color(0xFF94A3B8), size: 19),
              suffixIcon: ValueListenableBuilder<TextEditingValue>(
                valueListenable: controller,
                builder: (_, val, __) => val.text.isNotEmpty
                    ? GestureDetector(
                        onTap: () { controller.clear(); onClear?.call(); },
                        child: const Icon(Icons.close_rounded, color: Color(0xFFCBD5E1), size: 17))
                    : const SizedBox.shrink(),
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(vertical: 11),
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 5.  Chat list tile
// ═══════════════════════════════════════════════════════════════════════════════

class ZyloChatTile extends StatelessWidget {
  final String name;
  final String photoUrl;
  final String lastMsg;
  final String timeStr;
  final int unread;
  final bool isOnline;
  final bool isLocked;
  final bool isTyping;
  final bool notFollowing;
  final Widget? typingWidget;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  final VoidCallback onAvatarTap;
  final Widget avatarFallback;

  const ZyloChatTile({
    super.key,
    required this.name,
    required this.photoUrl,
    required this.lastMsg,
    required this.timeStr,
    required this.unread,
    required this.isOnline,
    required this.isLocked,
    required this.isTyping,
    required this.notFollowing,
    required this.onTap,
    required this.onLongPress,
    required this.onAvatarTap,
    required this.avatarFallback,
    this.typingWidget,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 3),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.045), blurRadius: 8, offset: const Offset(0, 2))],
        ),
        child: Row(children: [
          GestureDetector(
            onTap: onAvatarTap,
            behavior: HitTestBehavior.translucent,
            child: Stack(children: [
              ZyloDashedRingAvatar(
                size: 56,
                color: isOnline ? kOnlineDot : kBrand.withValues(alpha: 0.45),
                animate: isOnline,
                showRing: true,
                child: avatarFallback,
              ),
              if (isLocked)
                Positioned(top: 0, right: 0,
                  child: Container(width: 17, height: 17,
                    decoration: BoxDecoration(color: kBrand, shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 1.5)),
                    child: const Icon(Icons.lock_rounded, size: 9, color: Colors.white))),
            ]),
          ),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            Row(children: [
              Expanded(child: Row(children: [
                Flexible(child: Text(name, style: TextStyle(
                  fontWeight: unread > 0 ? FontWeight.w800 : FontWeight.w600,
                  fontSize: 14.5, color: const Color(0xFF0F172A), letterSpacing: -0.2),
                  overflow: TextOverflow.ellipsis)),
                if (notFollowing) ...[ const SizedBox(width: 5),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
                    decoration: BoxDecoration(color: const Color(0xFFF1F5F9), borderRadius: BorderRadius.circular(5),
                      border: Border.all(color: const Color(0xFFCBD5E1), width: 0.5)),
                    child: const Text('Not Following', style: TextStyle(color: Color(0xFF94A3B8), fontSize: 8, fontWeight: FontWeight.w700)))],
              ])),
              Text(timeStr, style: TextStyle(fontSize: 11,
                color: unread > 0 ? kBrand : const Color(0xFF94A3B8),
                fontWeight: unread > 0 ? FontWeight.w700 : FontWeight.normal)),
            ]),
            const SizedBox(height: 3),
            Row(children: [
              Expanded(child: isTyping && typingWidget != null
                  ? Row(children: [Container(
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                      decoration: BoxDecoration(color: kBrand.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(8)),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        typingWidget!, const SizedBox(width: 5),
                        const Text('typing...', style: TextStyle(fontSize: 11, color: kBrand, fontWeight: FontWeight.w600, fontStyle: FontStyle.italic)),
                      ]))])
                  : Text(lastMsg, style: TextStyle(fontSize: 12.5,
                      color: unread > 0 ? const Color(0xFF475569) : const Color(0xFF94A3B8),
                      fontWeight: unread > 0 ? FontWeight.w500 : FontWeight.normal),
                    maxLines: 1, overflow: TextOverflow.ellipsis)),
              if (unread > 0)
                Container(constraints: const BoxConstraints(minWidth: 20, minHeight: 20),
                  padding: const EdgeInsets.symmetric(horizontal: 5),
                  decoration: const BoxDecoration(color: kBrand, shape: BoxShape.circle),
                  child: Center(child: Text(unread > 99 ? '99+' : '$unread',
                    style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w900)))),
            ]),
          ])),
        ]),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 6.  Chat Room – Translucent AppBar background
// ═══════════════════════════════════════════════════════════════════════════════

class ZyloGlassAppBarBackground extends StatelessWidget implements PreferredSizeWidget {
  final Widget child;
  final double height;
  const ZyloGlassAppBarBackground({super.key, required this.child, this.height = kToolbarHeight});

  @override
  Size get preferredSize => Size.fromHeight(height);

  @override
  Widget build(BuildContext context) {
    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          height: height + MediaQuery.of(context).padding.top,
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.82),
            border: const Border(bottom: BorderSide(color: Color(0x18000000), width: 0.5)),
          ),
          child: child,
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 7.  Chat Room Background — smooth geometric honeycomb/wave pattern
// ═══════════════════════════════════════════════════════════════════════════════

class ZyloChatBackground extends StatelessWidget {
  final Widget child;
  const ZyloChatBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        // Warm white base
        Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFFF7FBFF),
                Color(0xFFF0F6FC),
                Color(0xFFEBF4FB),
                Color(0xFFF4F8FD),
              ],
              stops: [0.0, 0.35, 0.65, 1.0],
            ),
          ),
        ),
        // Smooth diamond/rhombus pattern
        CustomPaint(painter: _DiamondPatternPainter()),
        // Soft top glow
        Positioned(
          top: -80, left: -60,
          child: Container(
            width: 320, height: 320,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(colors: [
                const Color(0xFF0284C7).withValues(alpha: 0.08),
                Colors.transparent,
              ]),
            ),
          ),
        ),
        // Bottom right accent
        Positioned(
          bottom: -60, right: -40,
          child: Container(
            width: 240, height: 240,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(colors: [
                const Color(0xFF38BDF8).withValues(alpha: 0.06),
                Colors.transparent,
              ]),
            ),
          ),
        ),
        child,
      ],
    );
  }
}

class _DiamondPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF0284C7).withValues(alpha: 0.045)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.7;

    const double cellW = 32.0;
    const double cellH = 32.0;

    // Draw rotated grid (diamond pattern)
    for (double row = -cellH; row < size.height + cellH * 2; row += cellH) {
      for (double col = -cellW; col < size.width + cellW * 2; col += cellW) {
        final offset = ((row / cellH).round() % 2 == 0) ? 0.0 : cellW / 2;
        final cx = col + offset;
        final cy = row;
        final half = cellW * 0.42;
        final path = Path()
          ..moveTo(cx, cy - half)
          ..lineTo(cx + half, cy)
          ..lineTo(cx, cy + half)
          ..lineTo(cx - half, cy)
          ..close();
        canvas.drawPath(path, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_DiamondPatternPainter old) => false;
}

// ═══════════════════════════════════════════════════════════════════════════════
// 8.  Reply bar (glass style)
// ═══════════════════════════════════════════════════════════════════════════════

class ZyloGlassReplyBar extends StatelessWidget {
  final String senderLabel;
  final String preview;
  final VoidCallback onDismiss;

  const ZyloGlassReplyBar({super.key, required this.senderLabel, required this.preview, required this.onDismiss});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 0, 10, 4),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.85),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.white.withValues(alpha: 0.6), width: 0.8),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 6)],
            ),
            child: Row(children: [
              Container(width: 3, height: 34, decoration: BoxDecoration(color: kBrand, borderRadius: BorderRadius.circular(4))),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(senderLabel, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: kBrand)),
                Text(preview, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12, color: Color(0xFF64748B))),
              ])),
              GestureDetector(onTap: onDismiss, child: const Icon(Icons.close_rounded, size: 18, color: Color(0xFF94A3B8))),
            ]),
          ),
        ),
      ),
    );
  }
}
