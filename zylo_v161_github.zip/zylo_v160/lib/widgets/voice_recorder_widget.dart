import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:just_audio/just_audio.dart';

// ── Voice Recorder Widget (Hold to Record) ────────────────────────────────────
// Uses just_audio for playback. Recording is simulated — integrate your
// preferred recording package (record / flutter_sound) in _startRecording.

class VoiceRecorderWidget extends StatefulWidget {
  final Future<String?> Function(File audioFile) onSend;
  final VoidCallback onCancel;

  const VoiceRecorderWidget({
    super.key,
    required this.onSend,
    required this.onCancel,
  });

  @override
  State<VoiceRecorderWidget> createState() => _VoiceRecorderWidgetState();
}

class _VoiceRecorderWidgetState extends State<VoiceRecorderWidget>
    with SingleTickerProviderStateMixin {
  bool _isRecording = false;
  bool _isSending = false;
  bool _isCancelled = false;
  Duration _elapsed = Duration.zero;
  Timer? _timer;
  File? _recordedFile;
  String? _recordedPath;

  // Waveform bars
  final List<double> _bars = List.generate(40, (_) => 0.1);
  int _barIndex = 0;
  final _random = Random();

  // Amplitude simulation (replace with real recorder amplitude)
  late AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600))
      ..repeat(reverse: true);
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pulseCtrl.dispose();
    super.dispose();
  }

  Future<void> _startRecording() async {
    HapticFeedback.heavyImpact();
    final dir = await getTemporaryDirectory();
    _recordedPath =
        '${dir.path}/zylo_voice_${DateTime.now().millisecondsSinceEpoch}.m4a';

    // Real recording using `record` package
    // Uncomment when `record: ^5.x` is added to pubspec.yaml:
    // try {
    //   final recorder = AudioRecorder();
    //   final hasPermission = await recorder.hasPermission();
    //   if (!hasPermission) { widget.onCancel(); return; }
    //   await recorder.start(
    //     RecordConfig(encoder: AudioEncoder.aacLc, bitRate: 128000, sampleRate: 44100),
    //     path: _recordedPath!,
    //   );
    //   _audioRecorder = recorder;
    // } catch (e) { widget.onCancel(); return; }

    setState(() {
      _isRecording = true;
      _isCancelled = false;
      _elapsed = Duration.zero;
    });

    _timer = Timer.periodic(const Duration(milliseconds: 100), (_) {
      if (!mounted) return;
      setState(() {
        _elapsed += const Duration(milliseconds: 100);
        _bars[_barIndex % _bars.length] =
            0.15 + _random.nextDouble() * 0.85;
        _barIndex++;
      });
    });
  }

  Future<void> _stopRecording({bool send = true}) async {
    _timer?.cancel();

    // Real recording stop:
    // if (_audioRecorder != null) {
    //   await _audioRecorder!.stop();
    //   _audioRecorder!.dispose();
    //   _audioRecorder = null;
    // }

    if (!send || _isCancelled || _elapsed.inSeconds < 1) {
      widget.onCancel();
      return;
    }

    setState(() => _isSending = true);

    _recordedFile = File(_recordedPath!);
    if (!await _recordedFile!.exists()) {
      await _recordedFile!.create(recursive: true);
    }

    await widget.onSend(_recordedFile!);
    if (mounted) setState(() => _isSending = false);
  }

  String _formatDuration(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    const blue = Color(0xFF0284C7);

    return GestureDetector(
      // Tap: toggle recording (start or stop+send)
      onTap: () {
        if (_isRecording) {
          _stopRecording(send: true);
        } else {
          _startRecording();
        }
      },
      // Long press: hold-to-record (release sends)
      onLongPressStart: (_) {
        if (!_isRecording) _startRecording();
      },
      onLongPressEnd: (_) {
        if (_isRecording) _stopRecording(send: true);
      },
      onLongPressMoveUpdate: (details) {
        // Swipe left to cancel
        if (details.offsetFromOrigin.dx < -60 && !_isCancelled) {
          setState(() => _isCancelled = true);
          HapticFeedback.lightImpact();
        } else if (details.offsetFromOrigin.dx >= -60 && _isCancelled) {
          setState(() => _isCancelled = false);
        }
      },
      child: _isRecording
          ? _buildRecordingUI(blue)
          : _buildMicButton(blue),
    );
  }

  Widget _buildMicButton(Color blue) {
    return Container(
      width: 46,
      height: 46,
      decoration: const BoxDecoration(
        color: Color(0xFF0284C7),
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
              color: Color(0x200284C7), blurRadius: 8, offset: Offset(0, 3))
        ],
      ),
      child: const Icon(Icons.mic, color: Colors.white, size: 22),
    );
  }

  Widget _buildRecordingUI(Color blue) {
    return Container(
      height: 56,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.08),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: Row(
        children: [
          // Cancel slide indicator
          Padding(
            padding: const EdgeInsets.only(left: 12),
            child: AnimatedOpacity(
              opacity: _isCancelled ? 1.0 : 0.5,
              duration: const Duration(milliseconds: 200),
              child: Row(children: [
                Icon(Icons.chevron_left,
                    color: _isCancelled ? Colors.red : Colors.grey, size: 18),
                Text(
                  _isCancelled ? '  Release to cancel' : '  Slide to cancel',
                  style: TextStyle(
                    fontSize: 12,
                    color: _isCancelled ? Colors.red : Colors.grey[500],
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ]),
            ),
          ),

          const Spacer(),

          // Waveform
          SizedBox(
            width: 80,
            height: 36,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: List.generate(20, (i) {
                final barH =
                    (_bars[(i + _barIndex) % _bars.length] * 28).clamp(3.0, 28.0);
                return Container(
                  width: 2.5,
                  height: barH,
                  margin: const EdgeInsets.symmetric(horizontal: 1),
                  decoration: BoxDecoration(
                    color: _isCancelled
                        ? Colors.red.withValues(alpha: 0.7)
                        : blue.withValues(alpha: 0.85),
                    borderRadius: BorderRadius.circular(2),
                  ),
                );
              }),
            ),
          ),

          const SizedBox(width: 8),

          // Timer
          Text(
            _formatDuration(_elapsed),
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: _isCancelled ? Colors.red : Colors.black87,
            ),
          ),

          const SizedBox(width: 8),

          // Mic icon with pulse
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) {
              return Container(
                width: 40,
                height: 40,
                margin: const EdgeInsets.only(right: 8),
                decoration: BoxDecoration(
                  color: _isCancelled
                      ? Colors.red
                      : Color.lerp(blue, Colors.red, _pulseCtrl.value * 0.3)!,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.mic, color: Colors.white, size: 20),
              );
            },
          ),
        ],
      ),
    );
  }
}

// ── Waveform Audio Bubble (for received/sent voice messages) ─────────────────

class WaveformAudioBubble extends StatefulWidget {
  final String audioUrl;
  final String? name;
  final bool isMe;
  final Duration? totalDuration;

  const WaveformAudioBubble({
    super.key,
    required this.audioUrl,
    this.name,
    required this.isMe,
    this.totalDuration,
  });

  @override
  State<WaveformAudioBubble> createState() => _WaveformAudioBubbleState();
}

class _WaveformAudioBubbleState extends State<WaveformAudioBubble> {
  final _player = AudioPlayer();
  bool _playing = false;
  Duration _position = Duration.zero;
  Duration _total = Duration.zero;
  StreamSubscription? _posSub;
  StreamSubscription? _stateSub;

  // Simulated waveform bars for visual
  final List<double> _bars =
      List.generate(30, (i) => 0.2 + (i % 3) * 0.25 + (i % 7) * 0.08);

  @override
  void initState() {
    super.initState();
    _initPlayer();
  }

  Future<void> _initPlayer() async {
    try {
      await _player.setUrl(widget.audioUrl);
      _total = widget.totalDuration ??
          _player.duration ??
          const Duration(seconds: 0);
      _posSub = _player.positionStream.listen((pos) {
        if (mounted) setState(() => _position = pos);
      });
      _stateSub = _player.playerStateStream.listen((state) {
        if (mounted) {
          setState(() => _playing = state.playing);
          if (state.processingState == ProcessingState.completed) {
            _player.seek(Duration.zero);
            setState(() { _playing = false; _position = Duration.zero; });
          }
        }
      });
      if (mounted) setState(() => _total = _player.duration ?? _total);
    } catch (_) {}
  }

  @override
  void dispose() {
    _posSub?.cancel();
    _stateSub?.cancel();
    _player.dispose();
    super.dispose();
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    const blue = Color(0xFF0284C7);
    final bubbleColor = widget.isMe ? blue : Colors.white;
    final iconColor = widget.isMe ? Colors.white : blue;
    final waveColor = widget.isMe ? Colors.white70 : blue.withValues(alpha: 0.7);
    final waveActiveColor = widget.isMe ? Colors.white : blue;
    final textColor = widget.isMe ? Colors.white70 : Colors.black54;

    final progress = _total.inMilliseconds > 0
        ? (_position.inMilliseconds / _total.inMilliseconds).clamp(0.0, 1.0)
        : 0.0;
    final activeCount = (progress * _bars.length).round();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      constraints: const BoxConstraints(maxWidth: 240),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Play/Pause
          GestureDetector(
            onTap: () async {
              if (_playing) {
                await _player.pause();
              } else {
                await _player.play();
              }
            },
            child: Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: widget.isMe
                    ? Colors.white.withValues(alpha: 0.2)
                    : blue.withValues(alpha: 0.12),
                shape: BoxShape.circle,
              ),
              child: Icon(
                _playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                color: iconColor,
                size: 22,
              ),
            ),
          ),

          const SizedBox(width: 8),

          // Waveform + timer
          Flexible(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Waveform bars
                SizedBox(
                  height: 28,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: List.generate(_bars.length, (i) {
                      final h = (_bars[i] * 24).clamp(4.0, 24.0);
                      final isActive = i < activeCount;
                      return GestureDetector(
                        onTapDown: (d) {
                          final frac = i / _bars.length;
                          _player.seek(Duration(
                              milliseconds:
                                  (frac * _total.inMilliseconds).round()));
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 80),
                          width: 3,
                          height: h,
                          margin: const EdgeInsets.symmetric(horizontal: 1),
                          decoration: BoxDecoration(
                            color: isActive ? waveActiveColor : waveColor,
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                      );
                    }),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  _playing || _position > Duration.zero
                      ? _fmt(_position)
                      : _fmt(_total),
                  style: TextStyle(
                      fontSize: 10,
                      color: textColor,
                      fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
