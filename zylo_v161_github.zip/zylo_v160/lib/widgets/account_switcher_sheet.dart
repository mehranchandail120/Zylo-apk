import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:provider/provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'zylo_cached_image.dart';
import '../services/account_switcher_service.dart';
import '../services/auth_service.dart';
import '../services/notification_service.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';

const _kBlue = Color(0xFF0284C7);

/// Call this to show the account switcher bottom sheet.
Future<void> showAccountSwitcher(BuildContext context) async {
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => const _AccountSwitcherSheet(),
  );
}

class _AccountSwitcherSheet extends StatefulWidget {
  const _AccountSwitcherSheet();
  @override State<_AccountSwitcherSheet> createState() => _AccountSwitcherSheetState();
}

class _AccountSwitcherSheetState extends State<_AccountSwitcherSheet> {
  List<SavedAccount> _accounts = [];
  bool _loading = true;
  String? _switchingUid; // uid currently being switched to

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final list = await AccountSwitcherService.loadAccounts();
    if (mounted) setState(() { _accounts = list; _loading = false; });
  }

  String get _currentUid => FirebaseAuth.instance.currentUser?.uid ?? '';

  Future<void> _switchTo(SavedAccount account) async {
    if (account.uid == _currentUid) {
      Navigator.pop(context);
      return;
    }

    setState(() => _switchingUid = account.uid);

    final creds = await AccountSwitcherService.loadCreds(account.uid);
    if (creds == null) {
      if (mounted) {
        setState(() => _switchingUid = null);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Credentials not found. Please log in again.')));
      }
      return;
    }

    try {
      final auth = Provider.of<AuthService>(context, listen: false);
      await auth.signOut();

      final error = await auth.login(creds.email, creds.password);
      if (error != null) throw Exception(error);

      // Update OneSignal player id for new account
      final playerId = OneSignal.User.pushSubscription.id;
      if (playerId != null && playerId.isNotEmpty) {
        NotificationService().savePlayerId(playerId).catchError((_) {});
      }

      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        setState(() => _switchingUid = null);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Switch failed: $e')));
      }
    }
  }

  Future<void> _removeAccount(SavedAccount account) async {
    await AccountSwitcherService.removeAccount(account.uid);
    await _load();
  }

  void _addAccount() {
    Navigator.pop(context);
    // Navigate to login screen — import and push LoginScreen
    // We use the navigator from context (already on HomeScreen stack)
    Navigator.of(context, rootNavigator: true).pushNamed('/login');
  }

  @override
  Widget build(BuildContext context) {
    final bottomPad = MediaQuery.of(context).viewInsets.bottom + MediaQuery.of(context).padding.bottom;

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: EdgeInsets.fromLTRB(20, 12, 20, 20 + bottomPad),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle
          Container(width: 40, height: 4,
            margin: const EdgeInsets.only(bottom: 16),
            decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2))),

          // Title
          Row(children: [
            const Icon(Icons.switch_account_rounded, color: _kBlue, size: 22),
            const SizedBox(width: 8),
            const Text('Switch Account',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Color(0xFF0C4A6E))),
            const Spacer(),
            if (_accounts.length < AccountSwitcherService.maxAccounts)
              TextButton.icon(
                onPressed: _addAccount,
                icon: const Icon(Icons.add_rounded, size: 18),
                label: const Text('Add'),
                style: TextButton.styleFrom(foregroundColor: _kBlue,
                  textStyle: const TextStyle(fontWeight: FontWeight.w700)),
              ),
          ]),

          const SizedBox(height: 4),
          Text('Up to ${AccountSwitcherService.maxAccounts} accounts · tap to switch',
            style: TextStyle(fontSize: 12, color: Colors.grey[500])),
          const SizedBox(height: 16),

          if (_loading)
            const Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator(color: _kBlue))
          else if (_accounts.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 24),
              child: Column(children: [
                Icon(Icons.person_add_alt_1_rounded, size: 48, color: Colors.grey[300]),
                const SizedBox(height: 8),
                Text('No saved accounts', style: TextStyle(color: Colors.grey[500])),
              ]),
            )
          else
            ...(_accounts.map((acc) => _AccountTile(
              account: acc,
              isCurrent: acc.uid == _currentUid,
              isSwitching: _switchingUid == acc.uid,
              onTap: () => _switchTo(acc),
              onRemove: acc.uid == _currentUid ? null : () => _removeAccount(acc),
            ))),
        ],
      ),
    );
  }
}

class _AccountTile extends StatelessWidget {
  final SavedAccount account;
  final bool isCurrent;
  final bool isSwitching;
  final VoidCallback onTap;
  final VoidCallback? onRemove;

  const _AccountTile({
    required this.account,
    required this.isCurrent,
    required this.isSwitching,
    required this.onTap,
    this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: isCurrent ? const Color(0xFFE0F2FE) : const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isCurrent ? _kBlue.withValues(alpha: 0.4) : Colors.grey.withValues(alpha: 0.15)),
      ),
      child: ListTile(
        onTap: isSwitching ? null : onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
        leading: _Avatar(photoURL: account.photoURL, username: account.username),
        title: Text(account.displayName.isNotEmpty ? account.displayName : account.username,
          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
        subtitle: Text('@${account.username}',
          style: TextStyle(fontSize: 12, color: Colors.grey[600])),
        trailing: isSwitching
          ? const SizedBox(width: 22, height: 22,
              child: CircularProgressIndicator(strokeWidth: 2, color: _kBlue))
          : isCurrent
            ? Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _kBlue, borderRadius: BorderRadius.circular(20)),
                child: const Text('Active',
                  style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)))
            : Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.swap_horiz_rounded, color: Colors.grey[400], size: 20),
                if (onRemove != null) ...[
                  const SizedBox(width: 4),
                  GestureDetector(
                    onTap: onRemove,
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      child: Icon(Icons.close_rounded, size: 16, color: Colors.grey[400]))),
                ],
              ]),
      ),
    );
  }
}

class _Avatar extends StatelessWidget {
  final String? photoURL;
  final String username;
  const _Avatar({this.photoURL, required this.username});

  @override
  Widget build(BuildContext context) {
    if (photoURL != null && photoURL!.isNotEmpty) {
      return ClipOval(child: ZyloCachedImage(
        url: photoURL!,
        width: 42, height: 42, fit: BoxFit.cover,
        errorWidget: _initials(),
      ));
    }
    return _initials();
  }

  Widget _initials() => CircleAvatar(
    radius: 21,
    backgroundColor: _kBlue.withValues(alpha: 0.15),
    child: Text(
      username.isNotEmpty ? username[0].toUpperCase() : '?',
      style: const TextStyle(fontWeight: FontWeight.w800, color: _kBlue, fontSize: 16),
    ),
  );
}
