import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

class LinkPreviewCard extends StatefulWidget {
  final String url;
  final bool isMe;

  const LinkPreviewCard({super.key, required this.url, required this.isMe});

  @override
  State<LinkPreviewCard> createState() => _LinkPreviewCardState();
}

class _LinkPreviewCardState extends State<LinkPreviewCard> {
  static final Map<String, Map<String, String>?> _cache = {};
  Map<String, String>? _meta;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _fetchMeta();
  }

  Future<void> _fetchMeta() async {
    if (_cache.containsKey(widget.url)) {
      if (mounted) setState(() { _meta = _cache[widget.url]; _loading = false; });
      return;
    }

    try {
      // Use Open Graph parser via a simple HTML fetch
      final response = await http
          .get(Uri.parse(widget.url),
              headers: {'User-Agent': 'ZyloBot/1.0 (link preview)'})
          .timeout(const Duration(seconds: 6));

      if (response.statusCode == 200) {
        final body = response.body;
        final meta = _parseOG(body, widget.url);
        _cache[widget.url] = meta;
        if (mounted) setState(() { _meta = meta; _loading = false; });
        return;
      }
    } catch (_) {}

    _cache[widget.url] = null;
    if (mounted) setState(() => _loading = false);
  }

  Map<String, String> _parseOG(String html, String url) {
    String _tag(String name) {
      // og: meta tags
      final ogReg = RegExp(
          '<meta[^>]*property=["\']og:$name["\'][^>]*content=["\']([^"\']*)["\']',
          caseSensitive: false);
      final m = ogReg.firstMatch(html);
      if (m != null) return m.group(1) ?? '';
      // name= tags
      final nameReg = RegExp(
          '<meta[^>]*name=["\']$name["\'][^>]*content=["\']([^"\']*)["\']',
          caseSensitive: false);
      final m2 = nameReg.firstMatch(html);
      if (m2 != null) return m2.group(1) ?? '';
      return '';
    }

    String title = _tag('title');
    if (title.isEmpty) {
      final t = RegExp('<title[^>]*>([^<]*)</title>', caseSensitive: false)
          .firstMatch(html);
      if (t != null) title = t.group(1) ?? '';
    }

    final domain = Uri.tryParse(url)?.host ?? url;

    return {
      'title': _htmlDecode(title.trim()),
      'description': _htmlDecode(_tag('description').trim()),
      'image': _tag('image').trim(),
      'domain': domain,
    };
  }

  String _htmlDecode(String input) {
    return input
        .replaceAll('&amp;', '&')
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&quot;', '"')
        .replaceAll('&#39;', "'")
        .replaceAll('&nbsp;', ' ');
  }

  @override
  Widget build(BuildContext context) {
    const blue = Color(0xFF0284C7);

    if (_loading) {
      return Container(
        height: 60,
        alignment: Alignment.centerLeft,
        padding: const EdgeInsets.only(left: 4),
        child: const SizedBox(
          width: 16,
          height: 16,
          child: CircularProgressIndicator(strokeWidth: 2, color: blue),
        ),
      );
    }

    if (_meta == null) return const SizedBox.shrink();

    final title = _meta!['title'] ?? '';
    final desc = _meta!['description'] ?? '';
    final image = _meta!['image'] ?? '';
    final domain = _meta!['domain'] ?? '';

    if (title.isEmpty && image.isEmpty) return const SizedBox.shrink();

    return GestureDetector(
      onTap: () async {
        final uri = Uri.tryParse(widget.url);
        if (uri != null) await launchUrl(uri, mode: LaunchMode.externalApplication);
      },
      child: Container(
        margin: const EdgeInsets.only(top: 6),
        decoration: BoxDecoration(
          color: widget.isMe
              ? Colors.white.withValues(alpha: 0.15)
              : const Color(0xFFF0F8FF),
          borderRadius: BorderRadius.circular(10),
          border: Border(
            left: BorderSide(color: blue, width: 3),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (image.isNotEmpty)
              ClipRRect(
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(8),
                  topRight: Radius.circular(8),
                ),
                child: Image.network(
                  image,
                  height: 120,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                ),
              ),
            Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    const Icon(Icons.link, size: 12, color: Colors.blue),
                    const SizedBox(width: 4),
                    Flexible(
                      child: Text(
                        domain,
                        style: TextStyle(
                          fontSize: 10,
                          color: widget.isMe ? Colors.white70 : Colors.blue,
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ]),
                  if (title.isNotEmpty) ...[
                    const SizedBox(height: 3),
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: widget.isMe ? Colors.white : Colors.black87,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                  if (desc.isNotEmpty) ...[
                    const SizedBox(height: 2),
                    Text(
                      desc,
                      style: TextStyle(
                        fontSize: 11,
                        color: widget.isMe ? Colors.white70 : Colors.black54,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// URL detection helper
final _urlRegex = RegExp(
  r'https?://[^\s<>"{}|\\^`\[\]]+',
  caseSensitive: false,
);

String? extractFirstUrl(String text) {
  final match = _urlRegex.firstMatch(text);
  return match?.group(0);
}
