// ═══════════════════════════════════════════════════════════════════════════
// ShareToZyloSheet — "Send to..." bottom sheet for incoming share intents
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:receive_sharing_intent/receive_sharing_intent.dart';
import 'package:path/path.dart' as p;
import '../services/firestore_service.dart';
import '../services/cloudflare_service.dart';
import '../services/share_intent_service.dart';
import '../screens/chat/chat_room_screen.dart';
import 'zylo_avatar.dart';

class ShareToZyloSheet extends StatefulWidget {
  final SharedMediaInfo info;
  const ShareToZyloSheet({super.key, required this.info});
  @override
  State<ShareToZyloSheet> createState() => _ShareToZyloSheetState();
}

class _ShareToZyloSheetState extends State<ShareToZyloSheet> {
  final FirestoreService _fs = FirestoreService();
  final TextEditingController _search = TextEditingController();
  String _query = '';
  String? _sendingTo;
  static const _blue = Color(0xFF0284C7);

  @override
  void initState() {
    super.initState();
    _search.addListener(
        () => setState(() => _query = _search.text.toLowerCase().trim()));
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _sendTo(Map<String, dynamic> friend) async {
    final uid = friend['uid'] as String? ?? '';
    final name = friend['displayName'] as String? ?? 'User';
    if (uid.isEmpty || _sendingTo != null) return;
    setState(() => _sendingTo = uid);

    try {
      final info = widget.info;

      if (info.hasText && !info.hasFiles) {
        await _fs.sendMessage(otherUid: uid, text: info.text, mediaType: 'text');
      } else {
        for (final sharedFile in info.files) {
          final file = File(sharedFile.path);
          if (!file.existsSync()) continue;

          final result = await CloudflareService.uploadFile(file);
          if (!result.isSuccess) continue;

          final fileId = result.fileId;
          final fileName = result.fileName.isNotEmpty
              ? result.fileName
              : p.basename(file.path);

          if (sharedFile.type == SharedMediaType.image) {
            await _fs.sendMessage(otherUid: uid, imageUrl: fileId, mediaType: 'image');
          } else if (sharedFile.type == SharedMediaType.video) {
            await _fs.sendMessage(otherUid: uid, videoUrl: fileId, mediaType: 'video');
          } else {
            await _fs.sendMessage(
              otherUid: uid,
              docUrl: fileId,
              docName: fileName,
              mediaType: 'doc',
            );
          }
        }
      }

      if (!mounted) return;
      ShareIntentService.instance.reset();
      Navigator.pop(context);
      Navigator.push(context, MaterialPageRoute(
        builder: (_) => ChatRoomScreen(targetId: uid, targetName: name),
      ));
    } catch (e) {
      if (mounted) {
        setState(() => _sendingTo = null);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Send failed: $e'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
        ));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        // Handle
        Container(
          margin: const EdgeInsets.only(top: 12, bottom: 4),
          width: 40, height: 4,
          decoration: BoxDecoration(
              color: Colors.grey[300], borderRadius: BorderRadius.circular(10)),
        ),
        // Header
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
          child: Row(children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                  color: _blue.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12)),
              child: Icon(widget.info.icon, color: _blue, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Send ${widget.info.label} to...',
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
              Text(
                widget.info.hasText && !widget.info.hasFiles
                    ? _trunc(widget.info.text ?? '', 60)
                    : '${widget.info.files.length} item(s) via Zylo',
                style: TextStyle(fontSize: 12, color: Colors.grey[500]),
                maxLines: 1, overflow: TextOverflow.ellipsis,
              ),
            ])),
            IconButton(
              onPressed: () {
                ShareIntentService.instance.reset();
                Navigator.pop(context);
              },
              icon: const Icon(Icons.close_rounded, color: Colors.grey),
            ),
          ]),
        ),
        const SizedBox(height: 12),
        // Search
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: TextField(
            controller: _search,
            decoration: InputDecoration(
              hintText: 'Search following...',
              hintStyle: TextStyle(color: Colors.grey[400], fontSize: 14),
              prefixIcon: Icon(Icons.search_rounded, color: Colors.grey[400], size: 20),
              filled: true,
              fillColor: Colors.grey[100],
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
              contentPadding: const EdgeInsets.symmetric(vertical: 10),
            ),
          ),
        ),
        const SizedBox(height: 8),
        // Friends list
        _FriendsList(query: _query, sendingTo: _sendingTo, onTap: _sendTo),
        const SizedBox(height: 16),
      ]),
    );
  }

  String _trunc(String s, int max) => s.length > max ? '${s.substring(0, max)}...' : s;
}

// ─────────────────────────────────────────────────────────────────────────────
// Following list for share sheet
class _FriendsList extends StatelessWidget {
  final String query;
  final String? sendingTo;
  final Future<void> Function(Map<String, dynamic>) onTap;

  const _FriendsList({
    required this.query,
    required this.sendingTo,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final myUid = FirebaseAuth.instance.currentUser?.uid ?? '';

    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('users')
          .doc(myUid)
          .collection('following')
          .orderBy('followedAt', descending: false)
          .snapshots(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Padding(
              padding: EdgeInsets.all(32),
              child: Center(child: CircularProgressIndicator()));
        }

        final docs = snap.data?.docs ?? [];

        if (docs.isEmpty) {
          return Padding(
            padding: const EdgeInsets.all(32),
            child: Column(children: [
              Icon(Icons.person_search_rounded, size: 48, color: Colors.grey[300]),
              const SizedBox(height: 12),
              Text(
                'Not following anyone yet',
                style: TextStyle(color: Colors.grey[400], fontSize: 14,
                    fontWeight: FontWeight.w600)),
              const SizedBox(height: 6),
              Text('Follow someone to send them files directly.',
                style: TextStyle(color: Colors.grey[400], fontSize: 12),
                textAlign: TextAlign.center),
            ]),
          );
        }

        final uids = docs.map((d) => d.id).toList();

        return FutureBuilder<QuerySnapshot>(
          future: FirebaseFirestore.instance
              .collection('users')
              .where(FieldPath.documentId, whereIn: uids)
              .get(),
          builder: (context, userSnap) {
            if (!userSnap.hasData) {
              return const Padding(
                  padding: EdgeInsets.all(32),
                  child: Center(child: CircularProgressIndicator()));
            }

            final userMap = {
              for (final d in userSnap.data!.docs)
                d.id: d.data() as Map<String, dynamic>
            };

            final members = uids.map((uid) {
              final u = userMap[uid] ?? {};
              return {
                'uid': uid,
                'displayName': u['displayName'] as String? ??
                    u['username'] as String? ?? 'User',
                'username': u['username'] as String? ?? '',
                'photoURL': u['photoURL'] as String? ?? '',
              };
            }).where((m) {
              if (query.isEmpty) return true;
              final n = (m['displayName'] as String).toLowerCase();
              final u = (m['username'] as String).toLowerCase();
              return n.contains(query) || u.contains(query);
            }).toList();

            if (members.isEmpty) {
              return Padding(
                padding: const EdgeInsets.all(32),
                child: Column(children: [
                  Icon(Icons.search_off_rounded, size: 48, color: Colors.grey[300]),
                  const SizedBox(height: 12),
                  Text('No results for "$query"',
                      style: TextStyle(color: Colors.grey[400], fontSize: 14)),
                ]),
              );
            }

            return ConstrainedBox(
              constraints: BoxConstraints(
                  maxHeight: MediaQuery.of(context).size.height * 0.45),
              child: ListView.builder(
                shrinkWrap: true,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                itemCount: members.length,
                itemBuilder: (ctx, i) {
                  final f = members[i];
                  final uid = f['uid'] as String;
                  final name = f['displayName'] as String;
                  final username = f['username'] as String;
                  final photo = f['photoURL'] as String;
                  final isSending = sendingTo == uid;

                  return ListTile(
                    onTap: isSending || sendingTo != null ? null : () => onTap(f),
                    contentPadding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                    leading: Stack(children: [
                      ZyloAvatar(
                        photoUrl: photo.isNotEmpty ? photo : null,
                        radius: 24,
                      ),

                    ]),
                    title: Text(name,
                        style: const TextStyle(
                            fontWeight: FontWeight.w700, fontSize: 15)),
                    subtitle: username.isNotEmpty
                        ? Text('@$username',
                            style: TextStyle(color: Colors.grey[500], fontSize: 12))
                        : null,
                    trailing: isSending
                        ? const SizedBox(
                            width: 22, height: 22,
                            child: CircularProgressIndicator(strokeWidth: 2.5))
                        : Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 7),
                            decoration: BoxDecoration(
                                color: const Color(0xFF0284C7),
                                borderRadius: BorderRadius.circular(20)),
                            child: const Text('Send',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 13)),
                          ),
                  );
                },
              ),
            );
          },
        );
      },
    );
  }
}
// ─────────────────────────────────────────────────────────────────────────────
Future<void> showShareToZyloSheet(BuildContext context, SharedMediaInfo info) async {
  if (info.isEmpty) return;
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => ShareToZyloSheet(info: info),
  );
}
