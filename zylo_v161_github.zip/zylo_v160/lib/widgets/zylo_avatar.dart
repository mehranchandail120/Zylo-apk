// ── ZyloAvatar — universal avatar widget with initials fallback ──
// Usage: ZyloAvatar(photoUrl: user['photoURL'], radius: 22)
//        ZyloAvatar(photoUrl: null, radius: 18, name: 'Ali')

import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'zylo_cached_image.dart';

class ZyloAvatar extends StatelessWidget {
  final String? photoUrl;
  final String? name;
  final double radius;
  final VoidCallback? onTap;

  const ZyloAvatar({
    super.key,
    required this.photoUrl,
    this.name,
    this.radius = 22,
    this.onTap,
  });

  Color get _bgColor {
    final colors = [
      const Color(0xFF0284C7), const Color(0xFF7C3AED), const Color(0xFF059669),
      const Color(0xFFD97706), const Color(0xFFDC2626), const Color(0xFF0891B2),
      const Color(0xFF9333EA), const Color(0xFF065F46), const Color(0xFFB45309),
    ];
    final seed = (name ?? photoUrl ?? '').isNotEmpty ? (name ?? photoUrl ?? '')[0].codeUnitAt(0) : 0;
    return colors[seed % colors.length];
  }

  String get _initials {
    final n = (name ?? '').trim();
    if (n.isEmpty) return '?';
    final parts = n.split(RegExp(r'\s+'));
    if (parts.length >= 2) return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    return n[0].toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    final hasPhoto = photoUrl != null && photoUrl!.isNotEmpty;

    Widget avatar = CircleAvatar(
      radius: radius,
      backgroundColor: _bgColor,
      child: hasPhoto
          ? ClipOval(
              child: ZyloCachedImage(
                url: photoUrl!,
                width: radius * 2,
                height: radius * 2,
                fit: BoxFit.cover,
                placeholder: (_, __) => _placeholder(),
                errorWidget: _placeholder(),
              ),
            )
          : _placeholder(),
    );

    if (onTap != null) {
      return GestureDetector(onTap: onTap, child: avatar);
    }
    return avatar;
  }

  Widget _placeholder() {
    return Container(
      width: radius * 2,
      height: radius * 2,
      decoration: BoxDecoration(color: _bgColor, shape: BoxShape.circle),
      alignment: Alignment.center,
      child: Text(
        _initials,
        style: TextStyle(
          color: Colors.white,
          fontSize: radius * 0.75,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.5,
        ),
      ),
    );
  }
}

// ── ZyloLoader — zylo logo spinner used app-wide ──────────────────────────────
// Usage: const ZyloLoader()   or   ZyloLoader(size: 48)
class ZyloLoader extends StatefulWidget {
  final double size;
  const ZyloLoader({super.key, this.size = 56});

  @override
  State<ZyloLoader> createState() => _ZyloLoaderState();
}

class _ZyloLoaderState extends State<ZyloLoader> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _scale;
  late final Animation<double> _opacity;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
    _scale   = Tween(begin: 0.85, end: 1.0).chain(CurveTween(curve: Curves.easeInOut)).animate(_ctrl);
    _opacity = Tween(begin: 0.5,  end: 1.0).chain(CurveTween(curve: Curves.easeInOut)).animate(_ctrl);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) => Opacity(
        opacity: _opacity.value,
        child: Transform.scale(
          scale: _scale.value,
          child: Image.asset(
            'assets/images/zylo_logo.png',
            width: widget.size,
            height: widget.size,
            fit: BoxFit.contain,
          ),
        ),
      ),
    );
  }
}

// ── ZyloLoadingPage — full screen loader ─────────────────────────────────────
class ZyloLoadingPage extends StatelessWidget {
  const ZyloLoadingPage({super.key});
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Colors.white,
      body: Center(child: ZyloLoader()),
    );
  }
}
