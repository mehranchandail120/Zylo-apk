// lib/widgets/zylo_cached_image.dart
// ─────────────────────────────────────────────────────────────────────────────
// Zylo v151 — Optimised image loading widget.
// Wraps CachedNetworkImage with:
//   • Blurhash placeholder (Instagram-style soft blur while loading)
//   • Shimmer fallback (jab blurhash na ho)
//   • Automatic Cloudinary transform params (resize to displayed size)
//   • Fade-in animation
//   • Broken image fallback
//   • Configurable fit / radius / aspect ratio
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:typed_data';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:shimmer/shimmer.dart';
import 'package:blurhash_dart/blurhash_dart.dart';
import 'package:image/image.dart' as img;

// ══════════════════════════════════════════════════════════════
//  URL optimiser — appends Cloudinary transform params
// ══════════════════════════════════════════════════════════════

String optimizeImageUrl(
  String url, {
  int? width,
  int? height,
  int quality = 80,
}) {
  if (url.isEmpty) return url;
  if (!url.contains('res.cloudinary.com')) return url;
  if (url.contains('/upload/') && url.contains('/c_')) return url;

  try {
    final parts = url.split('/upload/');
    if (parts.length != 2) return url;
    final transforms = <String>[];
    if (width != null) transforms.add('w_$width');
    if (height != null) transforms.add('h_$height');
    transforms.add('q_$quality');
    transforms.add('f_auto');
    if (width != null || height != null) transforms.add('c_fill');
    return '${parts[0]}/upload/${transforms.join(",")}/${parts[1]}';
  } catch (_) {
    return url;
  }
}

// ══════════════════════════════════════════════════════════════
//  Blurhash decoder — RGBA bytes → Flutter Image widget
// ══════════════════════════════════════════════════════════════

/// Decode a blurhash string into a small flutter Image widget.
/// [punch] controls contrast (default 1.0).
/// Returns null silently if hash is invalid.
Widget? buildBlurhashWidget(
  String? hash, {
  double? width,
  double? height,
  double punch = 1.0,
  BoxFit fit = BoxFit.cover,
}) {
  if (hash == null || hash.isEmpty || hash.length < 6) return null;
  try {
    // Decode at a tiny resolution — 32×32 is enough for a blur
    final int w = math.max(4, math.min(32, (width ?? 32).round()));
    final int h = math.max(4, math.min(32, (height ?? 32).round()));

    final img.Image decoded = BlurHash.decode(hash, punch: punch).toImage(w, h);
    final Uint8List rgba = decoded.getBytes(order: img.ChannelOrder.rgba);

    return SizedBox(
      width: width,
      height: height,
      child: Image.memory(
        _rgbaToRawPng(rgba, w, h),
        width: width,
        height: height,
        fit: fit,
        gaplessPlayback: true,
      ),
    );
  } catch (_) {
    return null;
  }
}

/// Convert raw RGBA bytes to a PNG Uint8List that Image.memory accepts.
Uint8List _rgbaToRawPng(Uint8List rgba, int w, int h) {
  final image = img.Image.fromBytes(
    width: w,
    height: h,
    bytes: rgba.buffer,
    numChannels: 4,
  );
  return Uint8List.fromList(img.encodePng(image));
}

// ══════════════════════════════════════════════════════════════
//  ZyloCachedImage
// ══════════════════════════════════════════════════════════════

class ZyloCachedImage extends StatelessWidget {
  final String url;
  final double? width;
  final double? height;
  final BoxFit fit;
  final double radius;
  final Widget? errorWidget;
  final bool autoOptimize;
  final int optimizeQuality;
  final Widget Function(BuildContext, String)? placeholder;
  final Widget Function(BuildContext, ImageProvider)? imageBuilder;

  /// Optional blurhash string (e.g. stored in Firestore with post/profile doc).\
  /// If provided, a decoded blur preview shows instead of shimmer.
  final String? blurhash;

  const ZyloCachedImage({
    super.key,
    required this.url,
    this.width,
    this.height,
    this.fit = BoxFit.cover,
    this.radius = 0,
    this.errorWidget,
    this.autoOptimize = true,
    this.optimizeQuality = 80,
    this.blurhash,
    this.placeholder,
    this.imageBuilder,
  });

  String get _optimizedUrl {
    if (!autoOptimize) return url;
    // Guard against double.infinity — would produce "w_Infinity" → invalid URL
    final w = (width != null && width!.isFinite) ? width!.round() : null;
    final h = (height != null && height!.isFinite) ? height!.round() : null;
    return optimizeImageUrl(url, width: w, height: h, quality: optimizeQuality);
  }

  @override
  Widget build(BuildContext context) {
    if (url.isEmpty) return _placeholder();

    final img = CachedNetworkImage(
      imageUrl: _optimizedUrl,
      width: width,
      height: height,
      fit: fit,
      fadeInDuration: const Duration(milliseconds: 300),
      fadeOutDuration: const Duration(milliseconds: 150),
      memCacheWidth: width?.round(),
      memCacheHeight: height?.round(),
      placeholder: (ctx, url) => placeholder != null
          ? placeholder!(ctx, url)
          : _buildPlaceholder(),
      errorWidget: (ctx, url, err) => errorWidget ?? _errorPlaceholder(),
      imageBuilder: imageBuilder,
    );

    if (radius > 0) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: img,
      );
    }
    return img;
  }

  Widget _buildPlaceholder() {
    // Blurhash first — shimmer fallback
    final blurWidget = buildBlurhashWidget(
      blurhash,
      width: width,
      height: height,
      fit: fit,
    );
    if (blurWidget != null) {
      return radius > 0
          ? ClipRRect(
              borderRadius: BorderRadius.circular(radius),
              child: blurWidget,
            )
          : blurWidget;
    }
    return _shimmerPlaceholder();
  }

  Widget _shimmerPlaceholder() => Shimmer.fromColors(
        baseColor: const Color(0xFFEEEEEE),
        highlightColor: const Color(0xFFF8F8F8),
        child: Container(
          width: width,
          height: height,
          color: Colors.white,
        ),
      );

  Widget _placeholder() => Container(
        width: width,
        height: height,
        color: const Color(0xFFEEEEEE),
      );

  Widget _errorPlaceholder() => Container(
        width: width,
        height: height,
        color: const Color(0xFFEEEEEE),
        child: const Icon(Icons.broken_image_rounded,
            color: Colors.grey, size: 32),
      );
}

// ══════════════════════════════════════════════════════════════
//  ZyloCircleImage — avatar variant
// ══════════════════════════════════════════════════════════════

class ZyloCircleImage extends StatelessWidget {
  final String url;
  final double radius;
  final Color? fallbackColor;
  final String? fallbackInitial;

  /// Optional blurhash for avatar placeholder
  final String? blurhash;

  const ZyloCircleImage({
    super.key,
    required this.url,
    required this.radius,
    this.fallbackColor,
    this.fallbackInitial,
    this.blurhash,
  });

  @override
  Widget build(BuildContext context) {
    final size = radius * 2;
    return ClipOval(
      child: url.isNotEmpty
          ? CachedNetworkImage(
              imageUrl: optimizeImageUrl(url,
                  width: size.round(), height: size.round(), quality: 70),
              width: size,
              height: size,
              fit: BoxFit.cover,
              memCacheWidth: size.round(),
              memCacheHeight: size.round(),
              fadeInDuration: const Duration(milliseconds: 200),
              placeholder: (_, __) {
                final blurWidget = buildBlurhashWidget(
                  blurhash,
                  width: size,
                  height: size,
                  fit: BoxFit.cover,
                );
                if (blurWidget != null) return blurWidget;
                return Shimmer.fromColors(
                  baseColor: const Color(0xFFEEEEEE),
                  highlightColor: const Color(0xFFF8F8F8),
                  child: Container(
                      width: size, height: size, color: Colors.white),
                );
              },
              errorWidget: (_, __, ___) => _fallback(size),
            )
          : _fallback(size),
    );
  }

  Widget _fallback(double size) => Container(
        width: size,
        height: size,
        color: fallbackColor ?? const Color(0xFF0284C7).withValues(alpha: 0.15),
        child: Center(
          child: Text(
            fallbackInitial ?? '?',
            style: TextStyle(
              fontWeight: FontWeight.w900,
              fontSize: size * 0.35,
              color: fallbackColor != null
                  ? Colors.white
                  : const Color(0xFF0284C7),
            ),
          ),
        ),
      );
}
