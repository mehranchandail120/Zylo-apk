import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/translation_service.dart';

/// Two-tab bottom sheet:
///  • Incoming — translate received messages into chosen language
///  • Outgoing — translate your typed messages before sending
class LanguagePickerSheet extends StatefulWidget {
  const LanguagePickerSheet({super.key, this.initialTab = 0});
  final int initialTab;

  static Future<void> show(BuildContext context, {int initialTab = 0}) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => LanguagePickerSheet(initialTab: initialTab),
    );
  }

  @override
  State<LanguagePickerSheet> createState() => _LanguagePickerSheetState();
}

class _LanguagePickerSheetState extends State<LanguagePickerSheet>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs;
  final Map<String, bool> _downloaded = {};
  final Map<String, double> _downloading = {};
  String _search = '';

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this, initialIndex: widget.initialTab);
    // Only check already-downloaded models (no network, just local storage check)
    _checkDownloaded();
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  /// Only checks which models are ALREADY downloaded on device.
  /// Does NOT trigger any download. Fast — just reads local model registry.
  Future<void> _checkDownloaded() async {
    final svc = context.read<TranslationService>();
    for (final tag in TranslationService.supportedLanguages.keys) {
      final ok = await svc.isModelDownloaded(tag);
      if (mounted) setState(() => _downloaded[tag] = ok);
    }
  }

  Future<void> _selectLanguage(String tag, bool isOutgoing) async {
    final svc = context.read<TranslationService>();
    final alreadyHave = _downloaded[tag] ?? false;

    if (!alreadyHave) {
      final confirmed = await _showDownloadDialog(tag);
      if (!confirmed) return;
      setState(() => _downloading[tag] = 0.0);
      final ok = await svc.downloadModel(tag, onProgress: (p) {
        if (mounted) setState(() => _downloading[tag] = p);
      });
      if (mounted) setState(() { _downloading.remove(tag); _downloaded[tag] = ok; });
      if (!ok) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('⚠️ Model download failed. Check internet.'),
          backgroundColor: Colors.red, behavior: SnackBarBehavior.floating));
        return;
      }
    }

    if (isOutgoing) {
      await svc.setOutgoingLanguage(tag);
      await svc.setOutgoingEnabled(true);
    } else {
      await svc.setIncomingLanguage(tag);
      await svc.setIncomingEnabled(true);
    }
    if (mounted) Navigator.pop(context);
  }

  Future<bool> _showDownloadDialog(String tag) async {
    final name = TranslationService.supportedLanguages[tag] ?? tag;
    return await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Row(children: [
          Icon(Icons.download_rounded, color: Color(0xFF0284C7), size: 22),
          SizedBox(width: 8),
          Text('Download Language Model', style: TextStyle(fontWeight: FontWeight.w800)),
        ]),
        content: Text(
          'To translate "$name", a language pack (~15–30 MB) needs to be downloaded and saved on your device.\n\n'
          '✅ Works offline after download\n'
          '📦 Stored on your device only\n'
          '🚫 Never downloaded automatically',
          style: const TextStyle(fontSize: 13, height: 1.5)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          ElevatedButton.icon(
            icon: const Icon(Icons.download_rounded, size: 16),
            label: const Text('Download Now'),
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0284C7),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () => Navigator.pop(context, true)),
        ],
      ),
    ) ?? false;
  }

  @override
  Widget build(BuildContext context) {
    final svc = context.watch<TranslationService>();

    return Container(
      height: MediaQuery.of(context).size.height * 0.80,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      child: Column(children: [
        // Handle
        Container(margin: const EdgeInsets.only(top: 12, bottom: 4),
          width: 36, height: 4,
          decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
        // Header
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 6, 20, 0),
          child: Row(children: [
            const Icon(Icons.translate_rounded, color: Color(0xFF0284C7), size: 22),
            const SizedBox(width: 10),
            const Expanded(child: Text('Chat Translation',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800))),
          ])),
        const SizedBox(height: 10),
        // Tabs
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: const Color(0xFFF1F5F9),
            borderRadius: BorderRadius.circular(12)),
          child: TabBar(
            controller: _tabs,
            indicator: BoxDecoration(
              color: const Color(0xFF0284C7),
              borderRadius: BorderRadius.circular(10)),
            indicatorSize: TabBarIndicatorSize.tab,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.grey[600],
            labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
            tabs: [
              Tab(
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Icon(Icons.download_rounded, size: 15),
                  const SizedBox(width: 5),
                  const Text('Incoming'),
                  if (svc.inEnabled) ...[
                    const SizedBox(width: 4),
                    Container(width: 7, height: 7,
                      decoration: const BoxDecoration(color: Colors.greenAccent, shape: BoxShape.circle)),
                  ],
                ])),
              Tab(
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Icon(Icons.upload_rounded, size: 15),
                  const SizedBox(width: 5),
                  const Text('Outgoing'),
                  if (svc.outEnabled) ...[
                    const SizedBox(width: 4),
                    Container(width: 7, height: 7,
                      decoration: const BoxDecoration(color: Colors.orangeAccent, shape: BoxShape.circle)),
                  ],
                ])),
            ]),
        ),
        const SizedBox(height: 8),
        // Tab content
        Expanded(
          child: TabBarView(
            controller: _tabs,
            children: [
              _LangList(
                isOutgoing: false,
                activeLang: svc.inEnabled ? svc.inLang : null,
                accentColor: const Color(0xFF0284C7),
                description: 'Received messages are auto-translated to your language. ✨ Hinglish messages (Roman Hindi/Urdu) are handled by Zylo AI. Other languages use on-device ML Kit.',
                onDisable: () async { await svc.setIncomingEnabled(false); if (mounted) Navigator.pop(context); },
                downloaded: _downloaded,
                downloading: _downloading,
                onSelect: (tag) => _selectLanguage(tag, false),
              ),
              _LangList(
                isOutgoing: true,
                activeLang: svc.outEnabled ? svc.outLang : null,
                accentColor: const Color(0xFFF97316),
                description: 'Your messages will be auto-translated before sending. ✨ Hinglish (Roman Hindi/Urdu) is detected automatically and translated via Zylo AI. Other languages use on-device ML Kit.',
                onDisable: () async { await svc.setOutgoingEnabled(false); if (mounted) Navigator.pop(context); },
                downloaded: _downloaded,
                downloading: _downloading,
                onSelect: (tag) => _selectLanguage(tag, true),
              ),
            ]),
        ),
      ]),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _LangList extends StatefulWidget {
  final bool isOutgoing;
  final String? activeLang;
  final Color accentColor;
  final String description;
  final VoidCallback onDisable;
  final Map<String, bool> downloaded;
  final Map<String, double> downloading;
  final void Function(String tag) onSelect;

  const _LangList({
    required this.isOutgoing,
    required this.activeLang,
    required this.accentColor,
    required this.description,
    required this.onDisable,
    required this.downloaded,
    required this.downloading,
    required this.onSelect,
  });

  @override
  State<_LangList> createState() => _LangListState();
}

class _LangListState extends State<_LangList> {
  String _search = '';

  @override
  Widget build(BuildContext context) {
    final isActive = widget.activeLang != null;
    final filtered = TranslationService.supportedLanguages.entries
        .where((e) => _search.isEmpty ||
            e.value.toLowerCase().contains(_search.toLowerCase()) ||
            e.key.toLowerCase().contains(_search.toLowerCase()))
        .toList();

    return Column(children: [
      // Description + status bar
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
        child: Column(children: [
          // Info text
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: widget.accentColor.withValues(alpha: 0.07),
              borderRadius: BorderRadius.circular(10)),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(widget.isOutgoing ? Icons.send_rounded : Icons.chat_bubble_outline_rounded,
                size: 14, color: widget.accentColor),
              const SizedBox(width: 8),
              Expanded(child: Text(widget.description,
                style: TextStyle(fontSize: 12, color: Colors.grey[700], height: 1.4))),
            ])),
          // Active language badge
          if (isActive) ...[
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: widget.accentColor.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: widget.accentColor.withValues(alpha: 0.3))),
                child: Row(children: [
                  Icon(Icons.check_circle_rounded, color: widget.accentColor, size: 16),
                  const SizedBox(width: 8),
                  Text(widget.isOutgoing ? 'Sending as: ' : 'Translating to: ',
                    style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                  Text(TranslationService.supportedLanguages[widget.activeLang] ?? widget.activeLang!,
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: widget.accentColor)),
                ]))),
              const SizedBox(width: 8),
              TextButton.icon(
                onPressed: widget.onDisable,
                icon: const Icon(Icons.close, size: 14),
                label: const Text('Off', style: TextStyle(fontSize: 12)),
                style: TextButton.styleFrom(
                  foregroundColor: Colors.red,
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  minimumSize: Size.zero)),
            ]),
          ],
        ])),
      // Search
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
        child: TextField(
          onChanged: (v) => setState(() => _search = v),
          decoration: InputDecoration(
            hintText: 'Search language...',
            prefixIcon: const Icon(Icons.search, size: 18),
            filled: true, fillColor: Colors.grey[100],
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            contentPadding: const EdgeInsets.symmetric(vertical: 6)),
        )),
      const Divider(height: 1),
      // List
      Expanded(
        child: ListView.builder(
          padding: const EdgeInsets.symmetric(vertical: 4),
          itemCount: filtered.length,
          itemBuilder: (ctx, i) {
            final tag = filtered[i].key;
            final name = filtered[i].value;
            final isSelected = widget.activeLang == tag;
            final isDownloaded = widget.downloaded[tag] ?? false;
            final dlProgress = widget.downloading[tag];
            final isDownloading = dlProgress != null;

            return InkWell(
              onTap: isDownloading ? null : () => widget.onSelect(tag),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 11),
                color: isSelected ? widget.accentColor.withValues(alpha: 0.07) : Colors.transparent,
                child: Row(children: [
                  // Lang tag badge
                  Container(
                    width: 38, height: 38,
                    decoration: BoxDecoration(
                      color: isSelected ? widget.accentColor.withValues(alpha: 0.15) : Colors.grey[100],
                      shape: BoxShape.circle),
                    child: Center(child: Text(tag.toUpperCase(),
                      style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800,
                        color: isSelected ? widget.accentColor : Colors.grey[600])))),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(name, style: TextStyle(fontSize: 15,
                      fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                      color: isSelected ? widget.accentColor : Colors.black87)),
                    if (isDownloading) ...[
                      const SizedBox(height: 4),
                      LinearProgressIndicator(
                        value: dlProgress == 0.0 ? null : dlProgress,
                        backgroundColor: Colors.grey[200], color: widget.accentColor,
                        minHeight: 3, borderRadius: BorderRadius.circular(2)),
                      const SizedBox(height: 2),
                      const Text('Downloading model...', style: TextStyle(fontSize: 10, color: Colors.grey)),
                    ],
                  ])),
                  // Status icon
                  if (isDownloading)
                    SizedBox(width: 20, height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: widget.accentColor))
                  else if (isSelected)
                    Icon(Icons.check_circle_rounded, color: widget.accentColor, size: 22)
                  else if (isDownloaded)
                    const Icon(Icons.check_rounded, color: Colors.green, size: 18)
                  else
                    Icon(Icons.download_rounded, color: Colors.grey[400], size: 20),
                ]),
              ),
            );
          }),
      ),
    ]);
  }
}
