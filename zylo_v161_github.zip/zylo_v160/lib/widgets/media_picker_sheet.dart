import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:file_picker/file_picker.dart';
import '../services/cloudflare_service.dart';
import 'cloud_upload_tile.dart';
import 'package:video_player/video_player.dart';
import 'package:geolocator/geolocator.dart';
import 'package:crop_your_image/crop_your_image.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'dart:typed_data';
import 'dart:math' as math;

// ═══════════════════════════════════════════════════════════════════════
// MediaPickerSheet  —  WhatsApp-style in-app media picker
// Tabs: Gallery | File | Contact
// ═══════════════════════════════════════════════════════════════════════
class MediaPickerSheet extends StatefulWidget {
  final Function(List<File> files, bool isVideo) onMediaSelected;
  final Function(File file)? onDocumentSelected;
  final Function(File file)? onAudioSelected;
  final VoidCallback? onContactSelected;
  final Function(double lat, double lng)? onLocationSelected;
  final String? opponentId;
  final String? opponentName;

  const MediaPickerSheet({
    super.key,
    required this.onMediaSelected,
    this.onDocumentSelected,
    this.onAudioSelected,
    this.onContactSelected,
    this.onLocationSelected,
    this.opponentId,
    this.opponentName,
  });

  @override
  State<MediaPickerSheet> createState() => _MediaPickerSheetState();
}

class _MediaPickerSheetState extends State<MediaPickerSheet>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;

  static const _blue  = Color(0xFF0284C7);
  static const _green = Color(0xFF10B981);

  // ── Gallery state ──────────────────────────────────────────────────
  List<AssetPathEntity>  _albums      = [];
  AssetPathEntity?       _curAlbum;
  List<AssetEntity>      _assets      = [];
  final Set<AssetEntity> _selected    = {};
  bool   _galleryLoading  = true;
  bool   _permDenied      = false;
  bool   _partialAccess   = false;   // Android 13+: user chose limited
  int    _page            = 0;
  static const _pageSize  = 80;
  bool   _hasMore         = true;

  // ── Scroll controller for lazy loading ────────────────────────────
  final ScrollController _scrollCtrl = ScrollController();

  // Build available tabs based on callbacks
  List<Map<String, dynamic>> get _availableTabs {
    final tabs = <Map<String, dynamic>>[
      {'label': 'Gallery', 'icon': Icons.photo_library_rounded, 'color': _blue},
    ];
    if (widget.onDocumentSelected != null || widget.onAudioSelected != null) {
      tabs.add({'label': 'File', 'icon': Icons.insert_drive_file_rounded, 'color': const Color(0xFF6366F1)});
    }
    if (widget.onContactSelected != null) {
      tabs.add({'label': 'Contact', 'icon': Icons.contacts_rounded, 'color': const Color(0xFF0EA5E9)});
    }
    // Cloud upload tab — always visible
    tabs.add({'label': 'Cloud', 'icon': Icons.cloud_upload_rounded, 'color': const Color(0xFF7C3AED)});
    return tabs;
  }

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: _availableTabs.length, vsync: this);
    _scrollCtrl.addListener(_onScroll);
    _initGallery();
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  // GALLERY — permission + load
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _initGallery() async {
    setState(() { _galleryLoading = true; _permDenied = false; _partialAccess = false; });

    final ps = await PhotoManager.requestPermissionExtend();

    if (ps == PermissionState.authorized) {
      // Full access
      _partialAccess = false;
      await _loadAlbums();
    } else if (ps == PermissionState.limited) {
      // Partial access (Android 13+) — still show what's available
      _partialAccess = true;
      await _loadAlbums();
    } else {
      // Denied
      setState(() { _galleryLoading = false; _permDenied = true; });
    }
  }

  Future<void> _loadAlbums() async {
    final albums = await PhotoManager.getAssetPathList(
      type: RequestType.common,
      filterOption: FilterOptionGroup(
        orders: [const OrderOption(type: OrderOptionType.createDate, asc: false)],
      ),
    );
    if (!mounted) return;
    setState(() {
      _albums = albums;
      _curAlbum = albums.isNotEmpty ? albums.first : null;
      _galleryLoading = false;
    });
    if (_curAlbum != null) _loadPage(reset: true);
  }

  Future<void> _loadPage({bool reset = false}) async {
    if (reset) {
      _page = 0;
      _hasMore = true;
      _assets.clear();
    }
    if (!_hasMore || _curAlbum == null) return;

    final batch = await _curAlbum!.getAssetListPaged(page: _page, size: _pageSize);
    if (!mounted) return;
    setState(() {
      _assets.addAll(batch);
      if (batch.length < _pageSize) _hasMore = false;
      _page++;
    });
  }

  void _onScroll() {
    if (_scrollCtrl.position.pixels >= _scrollCtrl.position.maxScrollExtent - 400) {
      _loadPage();
    }
  }

  // ── Select / deselect ─────────────────────────────────────────────
  void _toggleSelect(AssetEntity a) => setState(() {
    _selected.contains(a) ? _selected.remove(a) : _selected.add(a);
  });

  // ── Send selected ─────────────────────────────────────────────────
  Future<void> _sendSelected() async {
    if (_selected.isEmpty) return;
    final files = <File>[];
    bool hasVideo = false;
    for (final a in _selected) {
      final f = await a.originFile;
      if (f != null) {
        files.add(f);
        if (a.type == AssetType.video) hasVideo = true;
      }
    }
    if (!mounted) return;
    if (!hasVideo) {
      // Always open edit screen — shows multi-image bubbles preview if >1
      final result = await Navigator.push<_EditResult>(
        context,
        MaterialPageRoute(builder: (_) => _ImageEditScreen(file: files.first, allFiles: files)),
      );
      if (result != null && mounted) {
        Navigator.pop(context);
        // Send all (possibly edited) files
        widget.onMediaSelected(result.allFiles ?? [result.file], false);
      }
    } else {
      Navigator.pop(context);
      widget.onMediaSelected(files, hasVideo);
    }
  }

  // ── Quick-tap single image ─────────────────────────────────────────
  Future<void> _openSingleImage(AssetEntity asset) async {
    final f = await asset.originFile;
    if (f == null || !mounted) return;
    final result = await Navigator.push<_EditResult>(
      context,
      MaterialPageRoute(builder: (_) => _ImageEditScreen(file: f, allFiles: [f])),
    );
    if (result != null && mounted) {
      Navigator.pop(context);
      widget.onMediaSelected(result.allFiles ?? [result.file], false);
    }
  }

  Future<void> _openSingleVideo(AssetEntity asset) async {
    final f = await asset.originFile;
    if (f == null || !mounted) return;
    final rootCtx = Navigator.of(context, rootNavigator: true).context;
    Navigator.pop(context);
    final result = await Navigator.push<_EditResult>(
      rootCtx,
      MaterialPageRoute(builder: (_) => _VideoPreviewScreen(file: f)),
    );
    if (result != null) widget.onMediaSelected([result.file], true);
  }

  // ── Camera ─────────────────────────────────────────────────────────
  Future<void> _openCamera() async {
    final s = await Permission.camera.request();
    if (!s.isGranted) { _snack('Camera permission required'); return; }
    final rootCtx = Navigator.of(context, rootNavigator: true).context;
    if (mounted) Navigator.pop(context);
    await Future.delayed(const Duration(milliseconds: 200));
    final f = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 90);
    if (f != null && rootCtx.mounted) {
      final result = await Navigator.push<_EditResult>(
        rootCtx, MaterialPageRoute(builder: (_) => _ImageEditScreen(file: File(f.path), allFiles: [File(f.path)])));
      if (result != null) widget.onMediaSelected(result.allFiles ?? [result.file], false);
    }
  }

  Future<void> _openVideoCamera() async {
    final s = await Permission.camera.request();
    if (!s.isGranted) { _snack('Camera permission required'); return; }
    final rootCtx = Navigator.of(context, rootNavigator: true).context;
    if (mounted) Navigator.pop(context);
    await Future.delayed(const Duration(milliseconds: 200));
    final f = await ImagePicker().pickVideo(source: ImageSource.camera,
        maxDuration: const Duration(minutes: 5));
    if (f != null && rootCtx.mounted) {
      final result = await Navigator.push<_EditResult>(
        rootCtx, MaterialPageRoute(builder: (_) => _VideoPreviewScreen(file: File(f.path))));
      if (result != null) widget.onMediaSelected([result.file], true);
    }
  }

  // ── Document / Audio pickers ───────────────────────────────────────
  Future<void> _pickDocument() async {
    if (mounted) Navigator.pop(context);
    try {
      final r = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf','doc','docx','txt','xls','xlsx','ppt','pptx','zip'],
      );
      if (r?.files.single.path != null) {
        widget.onDocumentSelected?.call(File(r!.files.single.path!));
      }
    } catch (_) {}
  }

  Future<void> _pickAudio() async {
    if (mounted) Navigator.pop(context);
    try {
      final r = await FilePicker.platform.pickFiles(type: FileType.audio);
      if (r?.files.single.path != null) {
        widget.onAudioSelected?.call(File(r!.files.single.path!));
      }
    } catch (_) {}
  }

  // ── Scan document (camera → edit → send as doc) ───────────────────
  Future<void> _scanDocument() async {
    final s = await Permission.camera.request();
    if (!s.isGranted) { _snack('Camera permission required'); return; }
    final rootCtx = Navigator.of(context, rootNavigator: true).context;
    if (mounted) Navigator.pop(context);
    await Future.delayed(const Duration(milliseconds: 200));
    final f = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 95);
    if (f != null && rootCtx.mounted) {
      widget.onDocumentSelected?.call(File(f.path));
    }
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(msg),
        action: SnackBarAction(label: 'Settings', onPressed: openAppSettings)));
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.80,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      child: Column(children: [
        // Drag handle
        Container(margin: const EdgeInsets.only(top: 10, bottom: 2),
            width: 40, height: 4,
            decoration: BoxDecoration(color: Colors.grey[300],
                borderRadius: BorderRadius.circular(10))),

        // Send bar (gallery only)
        AnimatedBuilder(
          animation: _tabCtrl,
          builder: (_, __) {
            if (_tabCtrl.index != 0 || _selected.isEmpty) return const SizedBox.shrink();
            return Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              child: Row(children: [
                Text('${_selected.length} selected',
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                const Spacer(),
                GestureDetector(
                  onTap: _sendSelected,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                    decoration: BoxDecoration(color: _blue, borderRadius: BorderRadius.circular(20)),
                    child: Text('Send (${_selected.length})',
                        style: const TextStyle(color: Colors.white,
                            fontWeight: FontWeight.w800, fontSize: 13)),
                  ),
                ),
              ]),
            );
          },
        ),

        // Tab content
        Expanded(
          child: TabBarView(
            controller: _tabCtrl,
            physics: const NeverScrollableScrollPhysics(),
            children: _availableTabs.map<Widget>((t) {
              final label = t['label'] as String;
              if (label == 'Gallery')  return _buildGalleryTab();
              if (label == 'File')     return _buildFileTab();
              if (label == 'Contact')  return _buildContactTab();
              if (label == 'Cloud')    return _buildCloudTab();
              return const SizedBox.shrink();
            }).toList(),
          ),
        ),

        // Bottom tab bar
        _buildTabBar(),
        SizedBox(height: MediaQuery.of(context).padding.bottom),
      ]),
    );
  }

  // ── Bottom tab bar ─────────────────────────────────────────────────
  Widget _buildTabBar() => AnimatedBuilder(
    animation: _tabCtrl,
    builder: (_, __) => Container(
      decoration: BoxDecoration(color: Colors.white,
          border: Border(top: BorderSide(color: Colors.grey[200]!, width: 1))),
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: List.generate(_availableTabs.length, (i) {
          final active = _tabCtrl.index == i;
          final color  = _availableTabs[i]['color'] as Color;
          return GestureDetector(
            onTap: () => setState(() => _tabCtrl.animateTo(i)),
            behavior: HitTestBehavior.opaque,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                  color: active ? color.withValues(alpha: 0.12) : Colors.transparent,
                  borderRadius: BorderRadius.circular(14)),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Icon(_availableTabs[i]['icon'] as IconData,
                    color: active ? color : Colors.grey[400], size: 26),
                const SizedBox(height: 3),
                Text(_availableTabs[i]['label'] as String,
                    style: TextStyle(fontSize: 10,
                        fontWeight: active ? FontWeight.w800 : FontWeight.w500,
                        color: active ? color : Colors.grey[400])),
              ]),
            ),
          );
        }),
      ),
    ),
  );

  // ═══════════════════════════════════════════════════════════════════
  // GALLERY TAB  —  WhatsApp style in-app grid
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildGalleryTab() {
    return Column(children: [
      // ── Camera + album selector row ──
      SizedBox(
        height: 72,
        child: Row(children: [
          // Camera quick btn
          Padding(
            padding: const EdgeInsets.only(left: 10, right: 6),
            child: _CameraBtn(onPhotoTap: _openCamera, onVideoTap: _openVideoCamera),
          ),
          // Album dropdown
          Expanded(
            child: _albums.isEmpty
                ? const SizedBox.shrink()
                : _AlbumDropdown(
                    albums: _albums,
                    selected: _curAlbum,
                    onChanged: (a) {
                      setState(() { _curAlbum = a; _selected.clear(); });
                      _loadPage(reset: true);
                    },
                  ),
          ),
          // Partial access badge
          if (_partialAccess)
            TextButton(
              onPressed: () async {
                await PhotoManager.presentLimited();
                _initGallery();
              },
              child: const Text('Add more', style: TextStyle(fontSize: 12, color: _blue)),
            ),
        ]),
      ),

      const Divider(height: 1),

      // ── Grid ──
      Expanded(child: _buildGrid()),
    ]);
  }

  Widget _buildGrid() {
    if (_galleryLoading) {
      return const Center(child: CircularProgressIndicator(color: _blue));
    }
    if (_permDenied) {
      return _PermissionDeniedView(onSettings: () async {
        await openAppSettings();
        await Future.delayed(const Duration(seconds: 1));
        _initGallery();
      });
    }
    if (_assets.isEmpty) {
      return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(Icons.photo_library_outlined, size: 64, color: Colors.grey[300]),
        const SizedBox(height: 10),
        Text('No media found', style: TextStyle(color: Colors.grey[400])),
      ]));
    }

    return GridView.builder(
      controller: _scrollCtrl,
      padding: EdgeInsets.zero,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3, crossAxisSpacing: 1.5, mainAxisSpacing: 1.5),
      itemCount: _assets.length + (_hasMore ? 1 : 0),
      itemBuilder: (ctx, i) {
        if (i == _assets.length) {
          return const Center(
              child: Padding(padding: EdgeInsets.all(8),
                  child: CircularProgressIndicator(color: _blue, strokeWidth: 2)));
        }
        final asset    = _assets[i];
        final selected = _selected.contains(asset);
        final selIdx   = _selected.toList().indexOf(asset) + 1;

        return GestureDetector(
          onTap: () {
            if (_selected.isNotEmpty) {
              // Multi-select mode: toggle
              _toggleSelect(asset);
            } else {
              // Single tap: open edit / video preview
              if (asset.type == AssetType.video) {
                _openSingleVideo(asset);
              } else {
                _openSingleImage(asset);
              }
            }
          },
          onLongPress: () => _toggleSelect(asset),
          child: Stack(fit: StackFit.expand, children: [
            // Thumbnail
            _AssetThumbnail(asset: asset),

            // Video duration badge
            if (asset.type == AssetType.video)
              Positioned(bottom: 4, left: 4,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                  decoration: BoxDecoration(color: Colors.black54,
                      borderRadius: BorderRadius.circular(5)),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.videocam, color: Colors.white, size: 10),
                    const SizedBox(width: 2),
                    Text(_fmtDur(asset.videoDuration),
                        style: const TextStyle(color: Colors.white,
                            fontSize: 9, fontWeight: FontWeight.bold)),
                  ]),
                )),

            // Selection overlay
            if (selected)
              Container(color: _blue.withValues(alpha: 0.30)),

            // Selection circle
            Positioned(
              top: 5, right: 5,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                width: 24, height: 24,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: selected ? _blue : Colors.transparent,
                  border: Border.all(
                      color: selected ? _blue : Colors.white.withValues(alpha: 0.85),
                      width: 2),
                ),
                child: selected
                    ? Center(child: Text('$selIdx',
                        style: const TextStyle(color: Colors.white,
                            fontSize: 11, fontWeight: FontWeight.w900)))
                    : null,
              ),
            ),
          ]),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ═══════════════════════════════════════════════════════════════════
  // FILE TAB  (WhatsApp Documents style)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildFileTab() {
    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
      children: [
        // Header
        const Padding(
          padding: EdgeInsets.fromLTRB(20, 20, 20, 12),
          child: Text('Share File',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: Colors.black87)),
        ),
        _DocTile(
          icon: Icons.folder_rounded,
          label: 'Browse documents',
          sub: 'Select files up to 2 GB in size',
          color: const Color(0xFF10B981),
          onTap: _pickDocument,
        ),
        _DocTile(
          icon: Icons.photo_library_rounded,
          label: 'Choose from gallery',
          sub: 'Select original quality photos or videos',
          color: const Color(0xFF0284C7),
          onTap: () {
            setState(() => _tabCtrl.animateTo(0));
          },
        ),
        _DocTile(
          icon: Icons.document_scanner_rounded,
          label: 'Scan document',
          sub: 'Take photos of a document',
          color: const Color(0xFF6366F1),
          onTap: _scanDocument,
        ),
        _DocTile(
          icon: Icons.music_note_rounded,
          label: 'Audio file',
          sub: 'MP3, WAV, M4A...',
          color: const Color(0xFFF59E0B),
          onTap: _pickAudio,
        ),

        // Recents header
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
          child: Text('Recents',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13,
                  color: Colors.grey[600])),
        ),

        // Recent gallery images (last 6)
        if (_assets.isNotEmpty)
          SizedBox(
            height: 90,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _assets.take(6).length,
              itemBuilder: (_, i) {
                final asset = _assets[i];
                return GestureDetector(
                  onTap: () async {
                    final f = await asset.originFile;
                    if (f != null && mounted) {
                      Navigator.pop(context);
                      widget.onDocumentSelected?.call(f);
                    }
                  },
                  child: Container(
                    width: 80, height: 80,
                    margin: const EdgeInsets.only(right: 8),
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),
                        color: Colors.grey[100]),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: _AssetThumbnail(asset: asset),
                    ),
                  ),
                );
              },
            ),
          ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // LOCATION TAB
  // ═══════════════════════════════════════════════════════════════════
  // CONTACT TAB
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildContactTab() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Share Contact',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: Colors.black87)),
        const SizedBox(height: 20),
        _DocTile(icon: Icons.contacts_rounded, label: 'Share Contact',
            sub: 'From your phone contacts', color: const Color(0xFF0EA5E9),
            onTap: () { Navigator.pop(context); widget.onContactSelected?.call(); }),
      ]),
    );
  }

  String _fmtDur(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  // ─── Cloud Upload Tab ────────────────────────────────────────────────────
  Widget _buildCloudTab() {
    const purple = Color(0xFF7C3AED);
    const blue   = Color(0xFF0284C7);
    const green  = Color(0xFF10B981);
    const kSub   = Color(0xFF888888);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: purple.withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: purple.withValues(alpha: 0.2)),
          ),
          child: Row(children: [
            Container(
              width: 38, height: 38,
              decoration: BoxDecoration(color: purple.withValues(alpha: 0.15), shape: BoxShape.circle),
              child: const Icon(Icons.cloud_upload_rounded, color: purple, size: 20),
            ),
            const SizedBox(width: 12),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Zylo Storage', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13)),
              SizedBox(height: 2),
              Text('Upload big files via E2E encrypted Telegram CDN', style: TextStyle(color: kSub, fontSize: 11)),
            ])),
          ]),
        ),
        const SizedBox(height: 14),
        const Text('SHARE IN CHAT', style: TextStyle(color: kSub, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1)),
        const SizedBox(height: 8),
        CloudUploadTile(
          label: 'Upload Any File',
          color: purple,
          onUploaded: (result) {
            Navigator.pop(context, {'type': 'cloud_file', 'file_id': result.fileId, 'file_name': result.fileName});
          },
        ),
        const SizedBox(height: 8),
        CloudUploadTile(
          label: 'Upload APK / App',
          color: const Color(0xFFF59E0B),
          onUploaded: (result) {
            Navigator.pop(context, {'type': 'cloud_file', 'file_id': result.fileId, 'file_name': result.fileName});
          },
        ),
        const SizedBox(height: 20),
        const Text('SECURITY', style: TextStyle(color: kSub, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1)),
        const SizedBox(height: 8),
        _securityRow(Icons.lock_rounded, blue, 'End-to-End Encrypted', 'MTProto 2.0 + AES-256'),
        const SizedBox(height: 6),
        _securityRow(Icons.cloud_done_rounded, green, 'Telegram CDN Storage', 'Files stored on Telegram servers'),
        const SizedBox(height: 6),
        _securityRow(Icons.visibility_off_rounded, purple, 'Zero-Knowledge Relay', 'Cloudflare Worker never reads your files'),
        const SizedBox(height: 20),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: () => Navigator.pop(context, {'type': 'open_file_manager'}),
            style: OutlinedButton.styleFrom(
              foregroundColor: purple,
              side: BorderSide(color: purple.withValues(alpha: 0.4)),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
            icon: const Icon(Icons.open_in_new_rounded, size: 16),
            label: const Text('Open Full File Manager', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
          ),
        ),
      ]),
    );
  }

  Widget _securityRow(IconData icon, Color color, String title, String subtitle) {
    return Row(children: [
      Container(
        width: 34, height: 34,
        decoration: BoxDecoration(color: color.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
        child: Icon(icon, color: color, size: 17),
      ),
      const SizedBox(width: 10),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12)),
        Text(subtitle, style: const TextStyle(color: Color(0xFF888888), fontSize: 10)),
      ]),
    ]);
  }
}

// ═══════════════════════════════════════════════════════════════════════
// Helper widgets
// ═══════════════════════════════════════════════════════════════════════

// ── Camera quick-access button ──────────────────────────────────────
class _CameraBtn extends StatelessWidget {
  final VoidCallback onPhotoTap;
  final VoidCallback onVideoTap;
  const _CameraBtn({required this.onPhotoTap, required this.onVideoTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPhotoTap,
      onLongPress: onVideoTap,
      child: Container(
        width: 60, height: 60,
        decoration: BoxDecoration(
          color: Colors.grey[900],
          borderRadius: BorderRadius.circular(10),
        ),
        child: const Icon(Icons.camera_alt, color: Colors.white, size: 28),
      ),
    );
  }
}

// ── Album dropdown ───────────────────────────────────────────────────
class _AlbumDropdown extends StatelessWidget {
  final List<AssetPathEntity> albums;
  final AssetPathEntity? selected;
  final ValueChanged<AssetPathEntity> onChanged;
  const _AlbumDropdown({required this.albums, required this.selected, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _showSheet(context),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Row(children: [
          Flexible(
            child: Text(selected?.name ?? 'Recents',
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                overflow: TextOverflow.ellipsis),
          ),
          const Icon(Icons.arrow_drop_down, size: 22),
        ]),
      ),
    );
  }

  void _showSheet(BuildContext ctx) {
    showModalBottomSheet(
      context: ctx,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.5,
        minChildSize: 0.3,
        maxChildSize: 0.85,
        expand: false,
        builder: (_, ctrl) => ListView.builder(
          controller: ctrl,
          itemCount: albums.length + 1,
          itemBuilder: (_, i) {
            if (i == 0) {
              return const Padding(
                padding: EdgeInsets.fromLTRB(20, 16, 20, 8),
                child: Text('Albums', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              );
            }
            final album = albums[i - 1];
            final isSelected = album.id == selected?.id;
            return ListTile(
              leading: Container(width: 44, height: 44,
                decoration: BoxDecoration(color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(8)),
                child: const Icon(Icons.photo_library, color: Colors.grey)),
              title: Text(album.name,
                  style: TextStyle(fontWeight:
                    isSelected ? FontWeight.w700 : FontWeight.w500)),
              trailing: isSelected
                  ? const Icon(Icons.check_circle, color: Color(0xFF0284C7))
                  : null,
              onTap: () { Navigator.pop(_); onChanged(album); },
            );
          },
        ),
      ),
    );
  }
}

// ── Asset thumbnail ──────────────────────────────────────────────────
class _AssetThumbnail extends StatefulWidget {
  final AssetEntity asset;
  const _AssetThumbnail({required this.asset});
  @override State<_AssetThumbnail> createState() => _AssetThumbnailState();
}

class _AssetThumbnailState extends State<_AssetThumbnail> {
  Uint8List? _data;
  @override
  void initState() {
    super.initState();
    widget.asset.thumbnailDataWithSize(const ThumbnailSize(300, 300))
        .then((d) { if (mounted && d != null) setState(() => _data = d); });
  }
  @override
  Widget build(BuildContext context) {
    if (_data == null) {
      return Container(color: const Color(0xFFF1F5F9),
          child: const Center(child: Icon(Icons.image_outlined, color: Colors.grey, size: 22)));
    }
    return Image.memory(_data!, fit: BoxFit.cover);
  }
}

// ── Document-style list tile ─────────────────────────────────────────
class _DocTile extends StatelessWidget {
  final IconData icon;
  final String label, sub;
  final Color color;
  final VoidCallback onTap;
  const _DocTile({required this.icon, required this.label, required this.sub,
      required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 13),
        child: Row(children: [
          Container(width: 44, height: 44,
            decoration: BoxDecoration(color: color.withValues(alpha: 0.12), shape: BoxShape.circle),
            child: Icon(icon, color: color, size: 22)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
            const SizedBox(height: 1),
            Text(sub, style: TextStyle(fontSize: 12, color: Colors.grey[500])),
          ])),
        ]),
      ),
    );
  }
}

// ── Permission denied view ──────────────────────────────────────────
class _PermissionDeniedView extends StatelessWidget {
  final VoidCallback onSettings;
  const _PermissionDeniedView({required this.onSettings});
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(width: 80, height: 80,
            decoration: BoxDecoration(color: const Color(0xFF0284C7).withValues(alpha: 0.1),
                shape: BoxShape.circle),
            child: const Icon(Icons.photo_library_rounded,
                size: 40, color: Color(0xFF0284C7))),
          const SizedBox(height: 18),
          const Text('Gallery Access Needed',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          const SizedBox(height: 8),
          Text('Allow Zylo to access your photos and videos to share them in chats.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13, color: Colors.grey[500], height: 1.45)),
          const SizedBox(height: 26),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: onSettings,
              icon: const Icon(Icons.settings_outlined, size: 18, color: Colors.white),
              label: const Text('Open Settings',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0284C7), elevation: 0,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
            ),
          ),
          const SizedBox(height: 10),
          TextButton(onPressed: onSettings,
              child: const Text('Try Again',
                  style: TextStyle(color: Color(0xFF0284C7), fontWeight: FontWeight.w600))),
        ]),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
// Public helper
// ═══════════════════════════════════════════════════════════════════════
void showMediaPicker(
  BuildContext context, {
  required Function(List<File> files, bool isVideo) onMediaSelected,
  Function(File file)? onDocumentSelected,
  Function(File file)? onAudioSelected,
  VoidCallback? onContactSelected,
  Function(double lat, double lng)? onLocationSelected,
  String? opponentId,
  String? opponentName,
}) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => MediaPickerSheet(
      onMediaSelected: onMediaSelected,
      onDocumentSelected: onDocumentSelected,
      onAudioSelected: onAudioSelected,
      onContactSelected: onContactSelected,
      onLocationSelected: onLocationSelected,
      opponentId: opponentId,
      opponentName: opponentName,
    ),
  );
}

// ═══════════════════════════════════════════════════════════════════════
// _EditResult
// ═══════════════════════════════════════════════════════════════════════
class _EditResult {
  final File file;
  final Duration? timer;
  final List<File>? allFiles;
  _EditResult({required this.file, this.timer, this.allFiles});
}

// ═══════════════════════════════════════════════════════════════════════
// _ImageEditScreen  — real gesture crop + rotate + flip + timer
// ═══════════════════════════════════════════════════════════════════════
class _ImageEditScreen extends StatefulWidget {
  final File file;
  final List<File>? allFiles;
  const _ImageEditScreen({required this.file, this.allFiles});
  @override State<_ImageEditScreen> createState() => _ImageEditScreenState();
}

class _ImageEditScreenState extends State<_ImageEditScreen> {
  static const _blue = Color(0xFF0284C7);
  double _rotation = 0;
  bool   _flipH    = false;
  Duration? _timer;
  String _timerLabel = 'No Timer';
  bool _isCropping = false;
  bool _isCropLoading = false;
  final CropController _cropCtrl = CropController();

  // Multiple-image preview bubbles
  List<File> _previewFiles = [];
  int _currentIdx = 0;

  @override
  void initState() {
    super.initState();
    _previewFiles = widget.allFiles != null && widget.allFiles!.isNotEmpty
        ? List<File>.from(widget.allFiles!)
        : [widget.file];
  }

  // ── Send / Crop ────────────────────────────────────────────────────────
  void _send() => Navigator.pop(context, _EditResult(
      file: _previewFiles[_currentIdx],
      timer: _timer,
      allFiles: _previewFiles));

  void _applyCrop() {
    setState(() => _isCropLoading = true);
    _cropCtrl.crop();
  }

  // ── Timer sheet ────────────────────────────────────────────────────────
  void _showTimerSheet() {
    showModalBottomSheet(
      context: context, backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) {
        final opts = [
          (null,                         'No Timer',   Icons.timer_off_outlined, Colors.grey),
          (const Duration(seconds: 1),   '1 Second',   Icons.flash_on,           Colors.red),
          (const Duration(seconds: 4),   '4 Seconds',  Icons.timer,              Colors.orange),
          (const Duration(seconds: 10),  '10 Seconds', Icons.timer_10_select,    _blue),
          (const Duration(minutes: 1),   '1 Minute',   Icons.schedule,           Colors.purple),
        ];
        return SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(margin: const EdgeInsets.only(top: 10, bottom: 10), width: 40, height: 4,
              decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
          const Padding(padding: EdgeInsets.fromLTRB(20, 0, 20, 10),
              child: Row(children: [
                Icon(Icons.timer_rounded, color: _blue, size: 20), SizedBox(width: 8),
                Text('Image Timer', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              ])),
          ...opts.map((o) {
            final selected = _timer == o.$1;
            return ListTile(
              leading: Container(padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(color: o.$4.withValues(alpha: 0.1), shape: BoxShape.circle),
                  child: Icon(o.$3, color: o.$4, size: 20)),
              title: Text(o.$2, style: TextStyle(fontWeight: selected ? FontWeight.w800 : FontWeight.w600)),
              trailing: selected ? const Icon(Icons.check_circle, color: _blue) : null,
              onTap: () {
                setState(() { _timer = o.$1; _timerLabel = o.$2; });
                Navigator.pop(ctx);
              },
            );
          }),
          const SizedBox(height: 8),
        ]));
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final currentFile = _previewFiles[_currentIdx];
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: _isCropping
            ? IconButton(
                icon: const Icon(Icons.close, color: Colors.white),
                onPressed: () => setState(() => _isCropping = false))
            : IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => Navigator.pop(context)),
        title: Text(_isCropping ? 'Drag to Crop' : 'Edit Photo',
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
        actions: _isCropping
            ? [
                if (_isCropLoading)
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    child: Center(child: SizedBox(width: 20, height: 20,
                        child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))),
                  )
                else
                  TextButton(
                    onPressed: _applyCrop,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                      decoration: BoxDecoration(color: _blue, borderRadius: BorderRadius.circular(20)),
                      child: const Text('Crop',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14)),
                    )),
                const SizedBox(width: 8),
              ]
            : [
                TextButton(
                  onPressed: _send,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                    decoration: BoxDecoration(color: _blue, borderRadius: BorderRadius.circular(20)),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.send, color: Colors.white, size: 16),
                      const SizedBox(width: 6),
                      Text('Send${_previewFiles.length > 1 ? " (${_previewFiles.length})" : ""}',
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14)),
                    ]),
                  )),
                const SizedBox(width: 8),
              ],
      ),
      body: Column(children: [
        // ── Main image area ──────────────────────────────────────────────
        Expanded(
          child: _isCropping
              ? Crop(
                  controller: _cropCtrl,
                  image: currentFile.readAsBytesSync(),
                  onCropped: (croppedData) async {
                    try {
                      final tmpDir = await getTemporaryDirectory();
                      final outFile = File('${tmpDir.path}/cropped_${DateTime.now().millisecondsSinceEpoch}.jpg');
                      await outFile.writeAsBytes(croppedData);
                      if (mounted) {
                        final updated = List<File>.from(_previewFiles);
                        updated[_currentIdx] = outFile;
                        setState(() {
                          _previewFiles = updated;
                          _isCropping = false;
                          _isCropLoading = false;
                        });
                      }
                    } catch (_) {
                      if (mounted) setState(() => _isCropLoading = false);
                    }
                  },
                  aspectRatio: null, // free crop
                  withCircleUi: false,
                  baseColor: Colors.black,
                  maskColor: Colors.black.withValues(alpha: 0.55),
                  cornerDotBuilder: (size, edgeAlignment) => DotControl(color: _blue),
                  initialSize: 0.85,
                )
              : Center(
                  child: Transform(
                    alignment: Alignment.center,
                    transform: Matrix4.identity()
                      ..rotateZ(_rotation * 3.14159 / 180)
                      ..scale(_flipH ? -1.0 : 1.0, 1.0),
                    child: Image.file(currentFile, fit: BoxFit.contain),
                  ),
                ),
        ),

        // ── Multiple image bubbles row ───────────────────────────────────
        if (_previewFiles.length > 1 && !_isCropping)
          Container(
            color: const Color(0xFF111111),
            height: 72,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              itemCount: _previewFiles.length,
              itemBuilder: (ctx, i) {
                final isActive = i == _currentIdx;
                return GestureDetector(
                  onTap: () => setState(() => _currentIdx = i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    margin: const EdgeInsets.only(right: 8),
                    width: 54,
                    height: 54,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: isActive ? _blue : Colors.white30,
                        width: isActive ? 2.5 : 1,
                      ),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.file(_previewFiles[i], fit: BoxFit.cover),
                    ),
                  ),
                );
              },
            ),
          ),

        // ── Tool bar ─────────────────────────────────────────────────────
        if (!_isCropping) Container(
          color: const Color(0xFF1A1A1A),
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            _toolBtn(Icons.crop_rounded, 'Crop',
                () => setState(() => _isCropping = true), Colors.white),
            _toolBtn(Icons.rotate_90_degrees_cw_rounded, 'Rotate',
                () => setState(() => _rotation = (_rotation + 90) % 360), Colors.white),
            _toolBtn(Icons.flip_rounded, 'Flip',
                () => setState(() => _flipH = !_flipH), Colors.white),
            GestureDetector(
              onTap: _showTimerSheet,
              child: Column(children: [
                Container(padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: _timer != null ? _blue.withValues(alpha: 0.2) : Colors.white.withValues(alpha: 0.08),
                    shape: BoxShape.circle),
                  child: Icon(_timer != null ? Icons.timer : Icons.timer_outlined,
                      color: _timer != null ? _blue : Colors.grey, size: 24)),
                const SizedBox(height: 4),
                Text(_timerLabel, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600,
                    color: _timer != null ? _blue : Colors.grey)),
              ]),
            ),
          ]),
        ),
        SizedBox(height: MediaQuery.of(context).padding.bottom),
      ]),
    );
  }

  Widget _toolBtn(IconData icon, String label, VoidCallback onTap, Color color) =>
      GestureDetector(onTap: onTap, child: Column(children: [
        Container(padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.08), shape: BoxShape.circle),
            child: Icon(icon, color: color, size: 24)),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: Colors.grey)),
      ]));
}

// ═══════════════════════════════════════════════════════════════════════
// _VideoPreviewScreen
// ═══════════════════════════════════════════════════════════════════════
class _VideoPreviewScreen extends StatefulWidget {
  final File file;
  const _VideoPreviewScreen({required this.file});
  @override State<_VideoPreviewScreen> createState() => _VideoPreviewScreenState();
}

class _VideoPreviewScreenState extends State<_VideoPreviewScreen> {
  late VideoPlayerController _ctrl;
  bool _ready   = false;
  bool _playing = false;
  double _trimS = 0, _trimE = 1;
  static const _blue = Color(0xFF0284C7);

  @override
  void initState() {
    super.initState();
    _ctrl = VideoPlayerController.file(widget.file)
      ..initialize().then((_) { if (mounted) setState(() => _ready = true); _ctrl.setLooping(false); });
    _ctrl.addListener(() { if (mounted) setState(() => _playing = _ctrl.value.isPlaying); });
  }

  @override void dispose() { _ctrl.dispose(); super.dispose(); }

  String _fmt(Duration d) =>
      '${d.inMinutes.remainder(60).toString().padLeft(2,'0')}:${d.inSeconds.remainder(60).toString().padLeft(2,'0')}';

  @override
  Widget build(BuildContext context) {
    final total = _ready ? _ctrl.value.duration : Duration.zero;
    final pos   = _ready ? _ctrl.value.position  : Duration.zero;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: IconButton(icon: const Icon(Icons.close, color: Colors.white),
            onPressed: () => Navigator.pop(context)),
        title: const Text('Video Preview', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, _EditResult(file: widget.file)),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
              decoration: BoxDecoration(color: _blue, borderRadius: BorderRadius.circular(20)),
              child: const Text('Send', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14)))),
          const SizedBox(width: 8),
        ],
      ),
      body: Column(children: [
        Expanded(child: GestureDetector(
          onTap: () { _ctrl.value.isPlaying ? _ctrl.pause() : _ctrl.play(); },
          child: Container(color: Colors.black, child: Center(
            child: _ready
                ? AspectRatio(aspectRatio: _ctrl.value.aspectRatio, child: VideoPlayer(_ctrl))
                : const CircularProgressIndicator(color: _blue),
          )),
        )),
        if (_ready) Container(color: const Color(0xFF111111),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(children: [
            GestureDetector(
              onTap: () { _ctrl.value.isPlaying ? _ctrl.pause() : _ctrl.play(); },
              child: Container(width: 40, height: 40,
                  decoration: const BoxDecoration(color: _blue, shape: BoxShape.circle),
                  child: Icon(_playing ? Icons.pause : Icons.play_arrow, color: Colors.white, size: 22))),
            const SizedBox(width: 12),
            Expanded(child: VideoProgressIndicator(_ctrl, allowScrubbing: true,
                colors: const VideoProgressColors(
                    playedColor: _blue, bufferedColor: Colors.white24, backgroundColor: Colors.white12))),
            const SizedBox(width: 10),
            Text('${_fmt(pos)} / ${_fmt(total)}',
                style: const TextStyle(color: Colors.white60, fontSize: 11)),
          ]),
        ),
        if (_ready && total.inSeconds > 0) Container(color: const Color(0xFF1A1A1A),
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('TRIM', style: TextStyle(color: Colors.grey, fontSize: 10,
                fontWeight: FontWeight.w700, letterSpacing: 0.8)),
            const SizedBox(height: 6),
            RangeSlider(
              values: RangeValues(_trimS, _trimE), min: 0, max: 1,
              activeColor: _blue, inactiveColor: Colors.white12,
              onChanged: (v) {
                setState(() { _trimS = v.start; _trimE = v.end; });
                _ctrl.seekTo(Duration(milliseconds: (v.start * total.inMilliseconds).round()));
              },
            ),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text(_fmt(Duration(milliseconds: (_trimS * total.inMilliseconds).round())),
                  style: const TextStyle(color: Colors.white54, fontSize: 10)),
              Text(_fmt(Duration(milliseconds: (_trimE * total.inMilliseconds).round())),
                  style: const TextStyle(color: Colors.white54, fontSize: 10)),
            ]),
          ]),
        ),
        SizedBox(height: MediaQuery.of(context).padding.bottom),
      ]),
    );
  }
}
