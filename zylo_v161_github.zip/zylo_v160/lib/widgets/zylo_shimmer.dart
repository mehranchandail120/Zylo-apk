// lib/widgets/zylo_shimmer.dart
// ─────────────────────────────────────────────────────────────────────────────
// Zylo v121 — Shimmer skeleton widgets using the shimmer package.
// Replace all CircularProgressIndicator "loading" states with these.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

const _kBase      = Color(0xFFEEEEEE);
const _kHighlight = Color(0xFFF8F8F8);

// ── Rounded box helper ────────────────────────────────────────────────────────
class _SBox extends StatelessWidget {
  final double? width, height;
  final double radius;
  const _SBox({this.width, this.height, this.radius = 8});
  @override
  Widget build(BuildContext context) => Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(radius),
        ),
      );
}

// ══════════════════════════════════════════════════════════════
//  POST CARD SHIMMER — feed list item
// ══════════════════════════════════════════════════════════════
class PostCardShimmer extends StatelessWidget {
  const PostCardShimmer({super.key});

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: _kBase,
      highlightColor: _kHighlight,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
            child: Row(
              children: [
                const _SBox(width: 36, height: 36, radius: 18),
                const SizedBox(width: 10),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  _SBox(width: 120, height: 13),
                  const SizedBox(height: 5),
                  _SBox(width: 80, height: 10),
                ]),
                const Spacer(),
                _SBox(width: 56, height: 24, radius: 12),
              ],
            ),
          ),
          // Text lines
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _SBox(width: double.infinity, height: 13),
              const SizedBox(height: 7),
              _SBox(width: double.infinity, height: 13),
              const SizedBox(height: 7),
              _SBox(width: 200, height: 13),
            ]),
          ),
          // Image placeholder
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: _SBox(
              width: double.infinity, height: 200, radius: 0,
            ),
          ),
          // Action bar
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
            child: Row(children: [
              _SBox(width: 60, height: 28, radius: 8),
              const SizedBox(width: 10),
              _SBox(width: 60, height: 28, radius: 8),
              const SizedBox(width: 10),
              _SBox(width: 40, height: 28, radius: 8),
            ]),
          ),
          Divider(height: 1, thickness: 1, color: Colors.grey[100]),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
//  FEED LIST SHIMMER — N card stubs
// ══════════════════════════════════════════════════════════════
class FeedShimmerList extends StatelessWidget {
  final int count;
  const FeedShimmerList({super.key, this.count = 4});

  @override
  Widget build(BuildContext context) => ListView(
        physics: const NeverScrollableScrollPhysics(),
        padding: const EdgeInsets.only(top: 4),
        children: List.generate(count, (_) => const PostCardShimmer()),
      );
}

// ══════════════════════════════════════════════════════════════
//  PROFILE SHIMMER — view_profile_screen header
// ══════════════════════════════════════════════════════════════
class ProfileShimmer extends StatelessWidget {
  const ProfileShimmer({super.key});

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: _kBase,
      highlightColor: _kHighlight,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Avatar
            const _SBox(width: 84, height: 84, radius: 42),
            const SizedBox(height: 12),
            _SBox(width: 140, height: 18, radius: 9),
            const SizedBox(height: 8),
            _SBox(width: 100, height: 13, radius: 6),
            const SizedBox(height: 20),
            // Stats row
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              _SBox(width: 70, height: 48, radius: 12),
              const SizedBox(width: 16),
              _SBox(width: 70, height: 48, radius: 12),
              const SizedBox(width: 16),
              _SBox(width: 70, height: 48, radius: 12),
            ]),
            const SizedBox(height: 20),
            // Button row
            Row(children: [
              Expanded(child: _SBox(height: 42, radius: 21)),
              const SizedBox(width: 10),
              Expanded(child: _SBox(height: 42, radius: 21)),
            ]),
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
//  CHAT LIST SHIMMER
// ══════════════════════════════════════════════════════════════
class ChatListShimmer extends StatelessWidget {
  final int count;
  const ChatListShimmer({super.key, this.count = 6});

  Widget _tile() => Shimmer.fromColors(
        baseColor: _kBase,
        highlightColor: _kHighlight,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Row(children: [
            const _SBox(width: 50, height: 50, radius: 25),
            const SizedBox(width: 12),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _SBox(width: 130, height: 14, radius: 7),
              const SizedBox(height: 7),
              _SBox(width: 200, height: 11, radius: 5),
            ]),
            const Spacer(),
            _SBox(width: 36, height: 11, radius: 5),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) => ListView(
        physics: const NeverScrollableScrollPhysics(),
        children: List.generate(count, (_) => _tile()),
      );
}

// ══════════════════════════════════════════════════════════════
//  NOTIFICATION SHIMMER
// ══════════════════════════════════════════════════════════════
class NotifShimmer extends StatelessWidget {
  final int count;
  const NotifShimmer({super.key, this.count = 5});

  Widget _tile() => Shimmer.fromColors(
        baseColor: _kBase,
        highlightColor: _kHighlight,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Row(children: [
            const _SBox(width: 44, height: 44, radius: 22),
            const SizedBox(width: 12),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _SBox(width: 220, height: 13, radius: 6),
              const SizedBox(height: 6),
              _SBox(width: 80, height: 10, radius: 5),
            ]),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) => ListView(
        physics: const NeverScrollableScrollPhysics(),
        children: List.generate(count, (_) => _tile()),
      );
}

// ══════════════════════════════════════════════════════════════
//  SEARCH SHIMMER
// ══════════════════════════════════════════════════════════════
class SearchResultShimmer extends StatelessWidget {
  final int count;
  const SearchResultShimmer({super.key, this.count = 5});

  Widget _tile() => Shimmer.fromColors(
        baseColor: _kBase,
        highlightColor: _kHighlight,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(children: [
            const _SBox(width: 46, height: 46, radius: 23),
            const SizedBox(width: 12),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _SBox(width: 120, height: 14, radius: 7),
              const SizedBox(height: 6),
              _SBox(width: 180, height: 11, radius: 5),
            ]),
            const Spacer(),
            _SBox(width: 70, height: 30, radius: 15),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) => ListView(
        physics: const NeverScrollableScrollPhysics(),
        children: List.generate(count, (_) => _tile()),
      );
}

// ══════════════════════════════════════════════════════════════
//  GENERIC INLINE SHIMMER BOX — use anywhere
// ══════════════════════════════════════════════════════════════
class ZyloShimmerBox extends StatelessWidget {
  final double width, height, radius;
  const ZyloShimmerBox({
    super.key,
    required this.width,
    required this.height,
    this.radius = 8,
  });

  @override
  Widget build(BuildContext context) => Shimmer.fromColors(
        baseColor: _kBase,
        highlightColor: _kHighlight,
        child: _SBox(width: width, height: height, radius: radius),
      );
}
