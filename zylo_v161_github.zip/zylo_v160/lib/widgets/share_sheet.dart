import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../services/auth_service.dart';
import '../services/file_service.dart';
import '../services/firestore_service.dart';

// ─────────────────────────────────────────────────────────────────────────────
// ShareSheet — share documents, photos, video (≤500 MB), audio, PDF, links,
// text inside the app (friends only, realtime) or externally via share_plus.
// ─────────────────────────────────────────────────────────────────────────────

class ShareItem {
  final String type; // 'file' | 'text' | 'link' | 'photo' | 'video' | 'audio' | 'pdf'
  final File? file;
  final String? text;
  final String? url;
  final String? fileName;
  final int? fileSize; // bytes

  const ShareItem({
    required this.type,
    this.file,
    this.text,
    this.url,
    this.fileName,
    this.fileSize,
  });

  String get displayName => fileName ?? (file?.path.split('/').last ?? text ?? url ?? 'Unknown');
  bool get isOversized => (fileSize ?? 0) > 500 * 1024 * 1024; // 500 MB
  String get sizeLabel {
    if (fileSize == null) return '';
    final mb = fileSize! / (1024 * 1024);
    if (mb < 1) return '${(fileSize! / 1024).toStringAsFixed(0)} KB';
    return '${mb.toStringAsFixed(1)} MB';
  }

  IconData get icon {
    switch (type) {
      case 'photo': return Icons.image_rounded;
      case 'video': return Icons.videocam_rounded;
      case 'audio': return Icons.music_note_rounded;
      case 'pdf':   return Icons.picture_as_pdf_rounded;
      case 'link':  return Icons.link_rounded;
      case 'text':  return Icons.text_fields_rounded;
      default:      return Icons.insert_drive_file_rounded;
    }
  }

  Color get color {
    switch (type) {
      case 'photo':  return const Color(0xFF0EA5E9);
      case 'video':  return const Color(0xFFEF4444);
      case 'audio':  return const Color(0xFF8B5CF6);
      case 'pdf':    return const Color(0xFFDC2626);
      case 'link':   return const Color(0xFF10B981);
      case 'text':   return const Color(0xFF6366F1);
      default:       return const Color(0xFFF59E0B);
    }
  }
}

class AppShareSheet extends StatefulWidget {
  /// Pre-loaded item to share (optional). If null, user picks from UI.
  final ShareItem? initialItem;
  /// Called with (item, recipientUid, recipientName)
  final Future<void> Function(ShareItem item, String uid, String name) onShare;

  const AppShareSheet({super.key, this.initialItem, required this.onShare});

  @override
  State<AppShareSheet> createState() => _AppShareSheetState();
}

class _AppShareSheetState extends State<AppShareSheet>
    with SingleTickerProviderStateMixin {
  ShareItem? _item;
  final Set<String> _selectedUids = {};
  bool _isSending = false;
  final TextEditingController _searchCtrl = TextEditingController();
  String _searchQ = '';
  String? _caption;
  static const _blue = Color(0xFF0284C7);
  static const _bg = Color(0xFFF8FAFC);
  late TabController _tabs;
  final _captionCtrl = TextEditingController();
  Stream<List<Map<String, dynamic>>>? _friendsStream;

  @override
  void initState() {
    super.initState();
    _item = widget.initialItem;
    _tabs = TabController(length: 2, vsync: this);
    // Load realtime friends stream
    WidgetsBinding.instance.addPostFrameCallback((_) {
      setState(() {
        _friendsStream = FirestoreService().myFriendsStream();
      });
    });
  }

  @override
  void dispose() {
    _tabs.dispose();
    _searchCtrl.dispose();
    _captionCtrl.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> _filterFriends(List<Map<String, dynamic>> friends) {
    if (_searchQ.isEmpty) return friends;
    return friends.where((c) {
      final n = (c['name'] ?? c['displayName'] ?? '').toString().toLowerCase();
      return n.contains(_searchQ.toLowerCase());
    }).toList();
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'zip'],
      allowMultiple: false,
    );
    if (result == null || result.files.isEmpty) return;
    final f = result.files.first;
    if (f.path == null) return;
    final file = File(f.path!);
    final size = await file.length();
    final ext = f.extension?.toLowerCase() ?? '';
    setState(() {
      _item = ShareItem(
        type: ext == 'pdf' ? 'pdf' : 'file',
        file: file,
        fileName: f.name,
        fileSize: size,
      );
    });
  }

  Future<void> _pickPhoto() async {
    final picker = ImagePicker();
    final xf = await picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
    if (xf == null) return;
    final file = File(xf.path);
    final size = await file.length();
    setState(() {
      _item = ShareItem(type: 'photo', file: file, fileName: xf.name, fileSize: size);
    });
  }

  Future<void> _pickVideo() async {
    final picker = ImagePicker();
    final xf = await picker.pickVideo(source: ImageSource.gallery, maxDuration: const Duration(minutes: 15));
    if (xf == null) return;
    final file = File(xf.path);
    final size = await file.length();
    if (size > 500 * 1024 * 1024) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Video exceeds 500 MB limit'), backgroundColor: Colors.red),
        );
      }
      return;
    }
    setState(() {
      _item = ShareItem(type: 'video', file: file, fileName: xf.name, fileSize: size);
    });
  }

  Future<void> _pickAudio() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.audio, allowMultiple: false,
    );
    if (result == null || result.files.isEmpty) return;
    final f = result.files.first;
    if (f.path == null) return;
    final file = File(f.path!);
    final size = await file.length();
    setState(() {
      _item = ShareItem(type: 'audio', file: file, fileName: f.name, fileSize: size);
    });
  }

  void _shareLink() {
    showDialog(
      context: context,
      builder: (_) {
        final ctrl = TextEditingController();
        return AlertDialog(
          title: const Text('Share Link'),
          content: TextField(
            controller: ctrl,
            decoration: const InputDecoration(hintText: 'Paste URL here...', prefixIcon: Icon(Icons.link)),
            keyboardType: TextInputType.url,
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: _blue),
              onPressed: () {
                final url = ctrl.text.trim();
                if (url.isEmpty) return;
                setState(() => _item = ShareItem(type: 'link', url: url, text: url));
                Navigator.pop(context);
              },
              child: const Text('Add'),
            ),
          ],
        );
      },
    );
  }

  void _shareText() {
    showDialog(
      context: context,
      builder: (_) {
        final ctrl = TextEditingController();
        return AlertDialog(
          title: const Text('Share Text'),
          content: TextField(
            controller: ctrl,
            maxLines: 5,
            decoration: const InputDecoration(hintText: 'Type your message...', border: OutlineInputBorder()),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: _blue),
              onPressed: () {
                final txt = ctrl.text.trim();
                if (txt.isEmpty) return;
                setState(() => _item = ShareItem(type: 'text', text: txt));
                Navigator.pop(context);
              },
              child: const Text('Add'),
            ),
          ],
        );
      },
    );
  }

  // ── External share via share_plus ─────────────────────────────────────
  Future<void> _shareExternal() async {
    final item = _item;
    if (item == null) return;
    try {
      if (item.file != null) {
        await Share.shareXFiles(
          [XFile(item.file!.path)],
          text: _caption,
          subject: item.fileName,
        );
      } else if (item.url != null) {
        await Share.share(item.url!, subject: item.fileName);
      } else if (item.text != null) {
        await Share.share(item.text!);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Share failed: \$e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  // ── In-app send ───────────────────────────────────────────────────────
  Future<void> _send(List<Map<String, dynamic>> allFriends) async {
    if (_item == null || _selectedUids.isEmpty || _isSending) return;
    if (_item!.isOversized) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('File exceeds 500 MB limit'), backgroundColor: Colors.red),
      );
      return;
    }
    setState(() => _isSending = true);
    try {
      for (final uid in _selectedUids) {
        final contact = allFriends.firstWhere(
          (c) => c['uid'] == uid, orElse: () => {'uid': uid, 'name': 'User'});
        final name = contact['name'] ?? contact['displayName'] ?? 'User';
        ShareItem itemToSend = _item!;
        if (_caption != null && _caption!.isNotEmpty && itemToSend.type != 'text') {
          itemToSend = ShareItem(
            type: itemToSend.type,
            file: itemToSend.file,
            text: _caption,
            url: itemToSend.url,
            fileName: itemToSend.fileName,
            fileSize: itemToSend.fileSize,
          );
        }
        await widget.onShare(itemToSend, uid, name.toString());
      }
      if (mounted) {
        HapticFeedback.mediumImpact();
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Sent to ${_selectedUids.length} friend${_selectedUids.length > 1 ? "s" : ""}'),
            backgroundColor: const Color(0xFF10B981),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to send: \$e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.90,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: StreamBuilder<List<Map<String, dynamic>>>(
        stream: _friendsStream,
        builder: (context, snapshot) {
          final allFriends = snapshot.data ?? [];
          final filtered = _filterFriends(allFriends);
          final isLoading = snapshot.connectionState == ConnectionState.waiting && allFriends.isEmpty;

          return Column(children: [
            // Handle
            Container(
              margin: const EdgeInsets.only(top: 10, bottom: 6),
              width: 36, height: 4,
              decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2)),
            ),

            // Header
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
              child: Row(children: [
                const Text('Share', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(width: 8),
                // Realtime friends count badge
                if (allFriends.isNotEmpty)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: _blue.withValues(alpha: 0.10),
                      borderRadius: BorderRadius.circular(20)),
                    child: Text('${allFriends.length} friends',
                      style: const TextStyle(fontSize: 11, color: _blue, fontWeight: FontWeight.w600))),
                const Spacer(),
                // External share button
                if (_item != null)
                  GestureDetector(
                    onTap: _shareExternal,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.grey[100],
                        borderRadius: BorderRadius.circular(20)),
                      child: const Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.ios_share_rounded, size: 15, color: Colors.black87),
                        SizedBox(width: 5),
                        Text('External',
                          style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.black87)),
                      ]),
                    ),
                  ),
                if (_item != null) const SizedBox(width: 8),
                // In-app send button
                if (_selectedUids.isNotEmpty)
                  GestureDetector(
                    onTap: _isSending ? null : () => _send(allFriends),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: _isSending ? Colors.grey[200] : _blue,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: _isSending
                          ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                          : Text('Send (${_selectedUids.length})',
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
                    ),
                  ),
              ]),
            ),

            // Preview section
            if (_item != null) _buildPreview(),

            // Content type picker
            if (_item == null) _buildTypePicker(),

            const Divider(height: 1),

            // Search friends
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
              child: TextField(
                controller: _searchCtrl,
                decoration: InputDecoration(
                  hintText: 'Search friends...',
                  prefixIcon: const Icon(Icons.search, size: 20),
                  filled: true, fillColor: Colors.grey[100],
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                ),
                onChanged: (v) => setState(() => _searchQ = v),
              ),
            ),

            // Friends list (realtime)
            Expanded(child: isLoading
              ? const Center(child: CircularProgressIndicator())
              : allFriends.isEmpty
                  ? _emptyFriends()
                  : filtered.isEmpty
                      ? Center(child: Text('No friend found', style: TextStyle(color: Colors.grey[400])))
                      : ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          itemCount: filtered.length,
                          itemBuilder: (_, i) => _buildFriendTile(filtered[i]),
                        )),
          ]);
        },
      ),
    );
  }

  Widget _emptyFriends() => Center(
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.people_outline_rounded, size: 48, color: Colors.grey[300]),
      const SizedBox(height: 12),
      Text('No friends yet', style: TextStyle(color: Colors.grey[400], fontWeight: FontWeight.w600)),
      const SizedBox(height: 4),
      Text('Add friends to share with them', style: TextStyle(color: Colors.grey[300], fontSize: 12)),
    ]),
  );

  Widget _buildPreview() {
    final item = _item!;
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: item.color.withValues(alpha: 0.07),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: item.color.withValues(alpha: 0.2)),
      ),
      child: Row(children: [
        Container(
          width: 52, height: 52,
          decoration: BoxDecoration(
            color: item.color.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(10),
          ),
          child: item.type == 'photo' && item.file != null
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.file(item.file!, fit: BoxFit.cover))
              : Icon(item.icon, color: item.color, size: 28),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(item.displayName,
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
              maxLines: 1, overflow: TextOverflow.ellipsis),
          if (item.sizeLabel.isNotEmpty) ...[
            const SizedBox(height: 2),
            Text(item.sizeLabel, style: TextStyle(fontSize: 11, color: Colors.grey[500])),
          ],
          if (_caption != null && _caption!.isNotEmpty) ...[
            const SizedBox(height: 2),
            Text('Caption: \$_caption', style: const TextStyle(fontSize: 11, color: _blue),
              maxLines: 1, overflow: TextOverflow.ellipsis),
          ],
          if (item.isOversized) ...[
            const SizedBox(height: 4),
            const Text('Exceeds 500 MB limit', style: TextStyle(fontSize: 11, color: Colors.red, fontWeight: FontWeight.w600)),
          ],
        ])),
        if (item.type != 'text' && item.type != 'link') ...[
          IconButton(
            icon: const Icon(Icons.edit_note_rounded, size: 20),
            tooltip: 'Add caption',
            onPressed: () {
              showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text('Add Caption'),
                  content: TextField(
                    controller: _captionCtrl,
                    maxLines: 3,
                    decoration: const InputDecoration(hintText: 'Optional caption...', border: OutlineInputBorder()),
                  ),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: _blue),
                      onPressed: () {
                        setState(() => _caption = _captionCtrl.text.trim());
                        Navigator.pop(context);
                      },
                      child: const Text('Add'),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
        IconButton(
          icon: Icon(Icons.close_rounded, size: 18, color: Colors.grey[400]),
          onPressed: () => setState(() { _item = null; _caption = null; }),
        ),
      ]),
    );
  }

  Widget _buildTypePicker() {
    final types = [
      {'label': 'Photo', 'icon': Icons.image_rounded, 'color': const Color(0xFF0EA5E9), 'onTap': _pickPhoto},
      {'label': 'Video', 'icon': Icons.videocam_rounded, 'color': const Color(0xFFEF4444), 'onTap': _pickVideo},
      {'label': 'Document', 'icon': Icons.insert_drive_file_rounded, 'color': const Color(0xFFF59E0B), 'onTap': _pickFile},
      {'label': 'Audio', 'icon': Icons.music_note_rounded, 'color': const Color(0xFF8B5CF6), 'onTap': _pickAudio},
      {'label': 'PDF', 'icon': Icons.picture_as_pdf_rounded, 'color': const Color(0xFFDC2626), 'onTap': _pickFile},
      {'label': 'Link', 'icon': Icons.link_rounded, 'color': const Color(0xFF10B981), 'onTap': _shareLink},
      {'label': 'Text', 'icon': Icons.text_fields_rounded, 'color': const Color(0xFF6366F1), 'onTap': _shareText},
    ];
    return Container(
      height: 96,
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: types.length,
        itemBuilder: (_, i) {
          final t = types[i];
          return GestureDetector(
            onTap: () => (t['onTap'] as VoidCallback)(),
            child: Container(
              width: 68, margin: const EdgeInsets.only(right: 8),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Container(
                  width: 48, height: 48,
                  decoration: BoxDecoration(
                    color: (t['color'] as Color).withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(t['icon'] as IconData, color: t['color'] as Color, size: 24),
                ),
                const SizedBox(height: 5),
                Text(t['label'] as String, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
              ]),
            ),
          );
        },
      ),
    );
  }

  Widget _buildFriendTile(Map<String, dynamic> c) {
    final uid = c['uid'] as String;
    final name = c['name'] ?? c['displayName'] ?? 'User';
    final avatar = c['photoUrl'] ?? c['avatar'] ?? '';
    final selected = _selectedUids.contains(uid);

    return ListTile(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() {
          if (selected) _selectedUids.remove(uid);
          else _selectedUids.add(uid);
        });
      },
      leading: Stack(children: [
        Container(
          width: 44, height: 44,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _blue.withValues(alpha: 0.1),
            border: selected ? Border.all(color: _blue, width: 2) : null,
          ),
          child: ClipOval(
            child: avatar.isNotEmpty
                ? Image.network(avatar, fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Center(
                      child: Text(name.toString().isNotEmpty ? name.toString()[0].toUpperCase() : '?',
                        style: TextStyle(color: _blue, fontWeight: FontWeight.bold, fontSize: 16))))
                : Center(
                    child: Text(name.toString().isNotEmpty ? name.toString()[0].toUpperCase() : '?',
                      style: TextStyle(color: _blue, fontWeight: FontWeight.bold, fontSize: 16))),
          ),
        ),
        if (selected)
          Positioned(right: 0, bottom: 0,
            child: Container(
              width: 16, height: 16,
              decoration: const BoxDecoration(color: _blue, shape: BoxShape.circle),
              child: const Icon(Icons.check_rounded, color: Colors.white, size: 10),
            )),
      ]),
      title: Text(name.toString(), style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
      subtitle: Text(c['status'] ?? c['phone'] ?? 'Zylo Friend',
          style: TextStyle(fontSize: 11, color: Colors.grey[400]), maxLines: 1, overflow: TextOverflow.ellipsis),
      trailing: selected
          ? Container(
              width: 28, height: 28,
              decoration: const BoxDecoration(color: _blue, shape: BoxShape.circle),
              child: const Icon(Icons.check_rounded, color: Colors.white, size: 16))
          : Container(
              width: 28, height: 28,
              decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.grey[300]!))),
    );
  }
}

/// Helper to open the share sheet from anywhere
Future<void> showAppShareSheet(
  BuildContext context, {
  ShareItem? item,
  required Future<void> Function(ShareItem, String uid, String name) onShare,
}) {
  return showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => AppShareSheet(initialItem: item, onShare: onShare),
  );
}
