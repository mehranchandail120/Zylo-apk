import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

// ── Achievement definition ────────────────────────────────────────────────────
class _Achievement {
  final String id, emoji, title, desc;
  final Color color;
  final List<Color> gradient;
  const _Achievement({
    required this.id, required this.emoji,
    required this.title, required this.desc,
    required this.color, required this.gradient,
  });
}

const _allAchievements = [
  _Achievement(id: 'og',           emoji: '🏅', title: 'OG',           desc: 'Account 1+ year old',      color: Color(0xFFFFBB35), gradient: [Color(0xFFFFBB35), Color(0xFFFF8C00)]),
  _Achievement(id: 'rising_star',  emoji: '🌟', title: 'Rising Star',  desc: '100+ followers',            color: Color(0xFF7C3AED), gradient: [Color(0xFF7C3AED), Color(0xFFA855F7)]),
  _Achievement(id: 'popular',      emoji: '🔥', title: 'Popular',      desc: '500+ followers',            color: Color(0xFFEF4444), gradient: [Color(0xFFEF4444), Color(0xFFF97316)]),
  _Achievement(id: 'famous',       emoji: '👑', title: 'Famous',       desc: '1000+ followers',           color: Color(0xFFFFBB35), gradient: [Color(0xFFFFBB35), Color(0xFFFF6B00)]),
  _Achievement(id: 'creator',      emoji: '✍️',  title: 'Creator',     desc: '10+ posts',                 color: Color(0xFF0284C7), gradient: [Color(0xFF0284C7), Color(0xFF0EA5E9)]),
  _Achievement(id: 'prolific',     emoji: '📚', title: 'Prolific',     desc: '50+ posts',                 color: Color(0xFF0891B2), gradient: [Color(0xFF0891B2), Color(0xFF06B6D4)]),
  _Achievement(id: 'loved',        emoji: '❤️',  title: 'Loved',       desc: '500+ profile views',        color: Color(0xFFEC4899), gradient: [Color(0xFFEC4899), Color(0xFFF43F5E)]),
  _Achievement(id: 'verified_fan', emoji: '💎', title: 'Supporter',    desc: 'Donater badge holder',      color: Color(0xFF06B6D4), gradient: [Color(0xFF06B6D4), Color(0xFF0284C7)]),
  _Achievement(id: 'official',     emoji: '✅',  title: 'Official',    desc: 'Verified account',          color: Color(0xFF0284C7), gradient: [Color(0xFF0284C7), Color(0xFF7C3AED)]),
  _Achievement(id: 'social',       emoji: '💬', title: 'Socialite',    desc: '50+ following',             color: Color(0xFF10B981), gradient: [Color(0xFF10B981), Color(0xFF059669)]),
];

List<_Achievement> _computeAchievements(Map<String, dynamic> data, int followersCount, int postsCount) {
  final earned = <_Achievement>[];
  final createdAt      = (data['createdAt'] as Timestamp?)?.toDate();
  final followingCount = (data['followingCount'] as int?) ?? 0;
  final profileViews   = (data['profileViewCount'] as int?) ?? 0;
  final isOfficialTick = data['isOfficialTick'] == true;
  final isDonater      = data['isDonater'] == true;

  if (createdAt != null && DateTime.now().difference(createdAt).inDays >= 365)
    earned.add(_allAchievements.firstWhere((a) => a.id == 'og'));
  if (followersCount >= 1000)
    earned.add(_allAchievements.firstWhere((a) => a.id == 'famous'));
  else if (followersCount >= 500)
    earned.add(_allAchievements.firstWhere((a) => a.id == 'popular'));
  else if (followersCount >= 100)
    earned.add(_allAchievements.firstWhere((a) => a.id == 'rising_star'));
  if (postsCount >= 50)
    earned.add(_allAchievements.firstWhere((a) => a.id == 'prolific'));
  else if (postsCount >= 10)
    earned.add(_allAchievements.firstWhere((a) => a.id == 'creator'));
  if (profileViews >= 500)
    earned.add(_allAchievements.firstWhere((a) => a.id == 'loved'));
  if (followingCount >= 50)
    earned.add(_allAchievements.firstWhere((a) => a.id == 'social'));
  if (isOfficialTick)
    earned.add(_allAchievements.firstWhere((a) => a.id == 'official'));
  if (isDonater)
    earned.add(_allAchievements.firstWhere((a) => a.id == 'verified_fan'));
  return earned;
}

// ── Public widget ─────────────────────────────────────────────────────────────
class ZyloAchievements extends StatelessWidget {
  final Map<String, dynamic> userData;
  final int followersCount, postsCount;

  const ZyloAchievements({
    super.key,
    required this.userData,
    required this.followersCount,
    required this.postsCount,
  });

  @override
  Widget build(BuildContext context) {
    final earned = _computeAchievements(userData, followersCount, postsCount);
    if (earned.isEmpty) return _EmptyAchievements();

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Header ─────────────────────────────────────────────────────────────
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 12),
        child: Row(children: [
          Container(
            width: 32, height: 32,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFFFBB35), Color(0xFFFF8C00)],
                begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(10)),
            child: const Center(child: Text('🏆', style: TextStyle(fontSize: 16)))),
          const SizedBox(width: 10),
          const Text('Achievements',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900,
              color: Color(0xFF0D1B2A), letterSpacing: -0.3)),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF0284C7), Color(0xFF7C3AED)]),
              borderRadius: BorderRadius.circular(20)),
            child: Text('${earned.length} earned',
              style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800))),
        ]),
      ),

      // ── Horizontal scroll cards ─────────────────────────────────────────────
      SizedBox(
        height: 118,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
          itemCount: earned.length,
          separatorBuilder: (_, __) => const SizedBox(width: 10),
          itemBuilder: (ctx, i) => _AchievementCard(
            a: earned[i], onTap: () => _showDetail(ctx, earned[i])),
        ),
      ),

      const SizedBox(height: 6),

      // ── Locked preview strip ────────────────────────────────────────────────
      _LockedStrip(earned: earned),

      const SizedBox(height: 4),
    ]);
  }

  void _showDetail(BuildContext ctx, _Achievement a) {
    showGeneralDialog(
      context: ctx,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 280),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child)),
      pageBuilder: (ctx, _, __) => Center(
        child: Material(
          color: Colors.transparent,
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 40),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(28),
              boxShadow: [BoxShadow(color: a.color.withValues(alpha: 0.25), blurRadius: 40, spreadRadius: 5)]),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              // Top gradient banner
              Container(
                height: 100,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: a.gradient,
                    begin: Alignment.topLeft, end: Alignment.bottomRight),
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(28))),
                child: Center(child: Text(a.emoji, style: const TextStyle(fontSize: 52)))),

              // Content
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
                child: Column(children: [
                  Text(a.title,
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: a.color)),
                  const SizedBox(height: 6),
                  Text(a.desc,
                    style: const TextStyle(fontSize: 14, color: Color(0xFF6B7280)),
                    textAlign: TextAlign.center),
                  const SizedBox(height: 20),
                  // Shine divider
                  Container(height: 1, decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [Colors.transparent, a.color.withValues(alpha: 0.3), Colors.transparent]))),
                  const SizedBox(height: 16),
                  const Text('Keep it up! This badge shows on your profile.',
                    style: TextStyle(fontSize: 12, color: Color(0xFF9CA3AF)),
                    textAlign: TextAlign.center),
                  const SizedBox(height: 18),
                  GestureDetector(
                    onTap: () => Navigator.pop(ctx),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: a.gradient),
                        borderRadius: BorderRadius.circular(30),
                        boxShadow: [BoxShadow(color: a.color.withValues(alpha: 0.35), blurRadius: 12, offset: const Offset(0, 4))]),
                      child: const Text('Awesome! 🎉',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14)))),
                ])),
            ])))));
  }
}

// ── Individual Card ───────────────────────────────────────────────────────────
class _AchievementCard extends StatelessWidget {
  final _Achievement a;
  final VoidCallback onTap;
  const _AchievementCard({required this.a, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 88,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(color: a.color.withValues(alpha: 0.18), blurRadius: 14, offset: const Offset(0, 4)),
            BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 4),
          ],
          border: Border.all(color: a.color.withValues(alpha: 0.15), width: 1)),
        child: Column(children: [
          // Top gradient bar
          Container(
            height: 5,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: a.gradient),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)))),
          const SizedBox(height: 10),
          // Emoji circle
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: a.gradient.map((c) => c.withValues(alpha: 0.13)).toList(),
                begin: Alignment.topLeft, end: Alignment.bottomRight),
              border: Border.all(color: a.color.withValues(alpha: 0.2), width: 1.5)),
            child: Center(child: Text(a.emoji, style: const TextStyle(fontSize: 22)))),
          const SizedBox(height: 8),
          // Title
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 6),
            child: Text(a.title,
              style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: a.color),
              textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis)),
          const SizedBox(height: 6),
        ]),
      ),
    );
  }
}

// ── Locked preview strip ──────────────────────────────────────────────────────
class _LockedStrip extends StatelessWidget {
  final List<_Achievement> earned;
  const _LockedStrip({required this.earned});

  @override
  Widget build(BuildContext context) {
    final earnedIds = earned.map((a) => a.id).toSet();
    final locked = _allAchievements.where((a) => !earnedIds.contains(a.id)).toList();
    if (locked.isEmpty) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: const Color(0xFFF8FAFC),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFE2E8F0))),
        child: Row(children: [
          const Icon(Icons.lock_outline_rounded, size: 15, color: Color(0xFF94A3B8)),
          const SizedBox(width: 8),
          Text('${locked.length} more to unlock',
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Color(0xFF94A3B8))),
          const Spacer(),
          Row(children: locked.take(5).map((a) =>
            Padding(
              padding: const EdgeInsets.only(left: 4),
              child: Container(
                width: 28, height: 28,
                decoration: BoxDecoration(
                  color: const Color(0xFFE2E8F0),
                  shape: BoxShape.circle),
                child: Center(child: ColorFiltered(
                  colorFilter: const ColorFilter.matrix([
                    0.2126, 0.7152, 0.0722, 0, 0,
                    0.2126, 0.7152, 0.0722, 0, 0,
                    0.2126, 0.7152, 0.0722, 0, 0,
                    0,      0,      0,      1, 0,
                  ]),
                  child: Text(a.emoji, style: const TextStyle(fontSize: 14)))))),
          ).toList()),
        ]),
      ),
    );
  }
}

// ── Empty state ───────────────────────────────────────────────────────────────
class _EmptyAchievements extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFFF0F9FF), Color(0xFFF5F3FF)],
            begin: Alignment.topLeft, end: Alignment.bottomRight),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFE0E7FF))),
        child: Row(children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.06), blurRadius: 8)]),
            child: const Center(child: Text('🎯', style: TextStyle(fontSize: 22)))),
          const SizedBox(width: 14),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('No Achievements Yet',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: Color(0xFF0D1B2A))),
            SizedBox(height: 4),
            Text('Post more, grow followers & stay active\nto earn your first badge!',
              style: TextStyle(fontSize: 12, color: Color(0xFF64748B), height: 1.4)),
          ])),
        ]),
      ),
    );
  }
}
