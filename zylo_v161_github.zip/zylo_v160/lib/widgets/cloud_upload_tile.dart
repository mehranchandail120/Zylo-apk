// ═══════════════════════════════════════════════════════════════════════════
// CloudUploadTile  —  Compact upload button that fits inside MediaPickerSheet
// and ShareSheet. Picks a file, uploads it, returns file_id to parent.
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import '../../services/cloudflare_service.dart';

class CloudUploadTile extends StatefulWidget {
  final void Function(UploadResult result)? onUploaded;
  final String label;
  final Color color;

  const CloudUploadTile({
    super.key,
    this.onUploaded,
    this.label = 'Upload Big File',
    this.color = const Color(0xFF0284C7),
  });

  @override
  State<CloudUploadTile> createState() => _CloudUploadTileState();
}

class _CloudUploadTileState extends State<CloudUploadTile> {
  bool _picking = false;
  bool _uploading = false;
  double _progress = 0;
  UploadResult? _result;
  String? _error;
  String? _pickedName;

  static const _kCard = Color(0xFF1E1E1E);
  static const _kSub  = Color(0xFF888888);

  Future<void> _pick() async {
    if (_picking || _uploading) return;
    setState(() { _picking = true; _result = null; _error = null; });
    try {
      final res = await FilePicker.platform.pickFiles(type: FileType.any);
      if (res == null || res.files.isEmpty) {
        setState(() => _picking = false);
        return;
      }
      final pf = res.files.first;
      if (pf.path == null) { setState(() => _picking = false); return; }

      setState(() {
        _picking     = false;
        _uploading   = true;
        _progress    = 0;
        _pickedName  = pf.name;
      });

      final uploadResult = await CloudflareService.uploadFile(
        File(pf.path!),
        onProgress: (prog) {
          if (mounted) setState(() => _progress = prog);
        },
      );
      if (mounted) {
        setState(() { _uploading = false; _result = uploadResult; });
        widget.onUploaded?.call(uploadResult);
      }
    } catch (e) {
      if (mounted) {
        setState(() { _picking = false; _uploading = false; _error = e.toString(); });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _pick,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: _kCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: _result != null
                ? const Color(0xFF10B981).withValues(alpha: 0.4)
                : widget.color.withValues(alpha: 0.2),
          ),
        ),
        child: _uploading
            ? _buildUploading()
            : _result != null
                ? _buildDone()
                : _buildIdle(),
      ),
    );
  }

  Widget _buildIdle() {
    return Row(children: [
      Container(
        width: 42, height: 42,
        decoration: BoxDecoration(
          color: widget.color.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(Icons.cloud_upload_rounded, color: widget.color, size: 22),
      ),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(widget.label,
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
        const SizedBox(height: 2),
        Text('Any file type • Secure Telegram storage',
          style: TextStyle(color: _kSub, fontSize: 11)),
        if (_error != null)
          Text('Error: $_error',
            style: const TextStyle(color: Colors.red, fontSize: 11),
            maxLines: 2, overflow: TextOverflow.ellipsis),
      ])),
      Icon(Icons.add_rounded, color: widget.color, size: 22),
    ]);
  }

  Widget _buildUploading() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        SizedBox(
          width: 18, height: 18,
          child: CircularProgressIndicator(
            value: _progress,
            strokeWidth: 2.5,
            color: widget.color,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(child: Text(
          _pickedName != null ? 'Uploading $_pickedName...' : 'Uploading...',
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12),
          maxLines: 1, overflow: TextOverflow.ellipsis,
        )),
        Text('${(_progress * 100).toStringAsFixed(0)}%',
          style: TextStyle(color: widget.color, fontWeight: FontWeight.w800, fontSize: 12)),
      ]),
      const SizedBox(height: 8),
      ClipRRect(
        borderRadius: BorderRadius.circular(4),
        child: LinearProgressIndicator(
          value: _progress,
          minHeight: 4,
          backgroundColor: Colors.white.withValues(alpha: 0.06),
          valueColor: AlwaysStoppedAnimation<Color>(widget.color),
        ),
      ),
    ]);
  }

  Widget _buildDone() {
    const green = Color(0xFF10B981);
    return Row(children: [
      Container(
        width: 42, height: 42,
        decoration: BoxDecoration(
          color: green.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Icon(Icons.check_circle_rounded, color: green, size: 22),
      ),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Upload Complete!',
          style: TextStyle(color: green, fontWeight: FontWeight.w800, fontSize: 13)),
        const SizedBox(height: 2),
        Text(_result!.fileName,
          style: TextStyle(color: _kSub, fontSize: 11),
          maxLines: 1, overflow: TextOverflow.ellipsis),
      ])),
      GestureDetector(
        onTap: () {
          setState(() { _result = null; _pickedName = null; _progress = 0; });
        },
        child: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.06),
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Icon(Icons.close_rounded, color: Colors.white54, size: 16),
        ),
      ),
    ]);
  }
}
