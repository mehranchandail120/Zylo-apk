// ── ZyloPeopleSuggestion — optimized, minimal Firebase calls ─────────────────
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../screens/profile/view_profile_screen.dart';

class ZyloPeopleSuggestion extends StatefulWidget {
  final String myUid;
  final bool compact;
  const ZyloPeopleSuggestion({super.key, required this.myUid, this.compact = false});
  @override State<ZyloPeopleSuggestion> createState() => _ZyloPeopleSuggestionState();
}

class _ZyloPeopleSuggestionState extends State<ZyloPeopleSuggestion> {
  static const _blue   = Color(0xFF0284C7);
  static const _indigo = Color(0xFF6366F1);

  // ── In-memory cache — survives widget rebuilds, cleared on refresh ──────────
  static final Map<String, List<Map<String, dynamic>>> _cache = {};
  static final Map<String, DateTime> _cacheTime = {};
  static const _cacheTTL = Duration(minutes: 10);

  List<Map<String, dynamic>> _suggestions = [];
  bool _loading = true;
  bool _dismissed = false;

  @override
  void initState() { super.initState(); _load(forceRefresh: false); }

  Future<void> _load({bool forceRefresh = false}) async {
    if (widget.myUid.isEmpty) { if (mounted) setState(() => _loading = false); return; }
    if (!mounted) return;
    setState(() => _loading = true);

    // ── Return cached result if fresh ────────────────────────────────────────
    final cacheKey = widget.myUid;
    if (!forceRefresh) {
      final cached = _cache[cacheKey];
      final t = _cacheTime[cacheKey];
      if (cached != null && t != null && DateTime.now().difference(t) < _cacheTTL) {
        if (mounted) setState(() { _suggestions = List.from(cached); _loading = false; });
        return;
      }
    }

    try {
      final db = FirebaseFirestore.instance;

      // ── 1 read: my following list ─────────────────────────────────────────
      final followingSnap = await db.collection('users').doc(widget.myUid)
          .collection('following').limit(30).get();
      final alreadyFollowing = followingSnap.docs.map((d) => d.id).toSet()
        ..add(widget.myUid);

      // ── 1 read: my followers ──────────────────────────────────────────────
      final myFollowersSnap = await db.collection('users').doc(widget.myUid)
          .collection('followers').limit(30).get();

      final Map<String, int> scoreMap = {};

      // Score: people who follow me but I don't follow back (high priority)
      for (final doc in myFollowersSnap.docs) {
        if (!alreadyFollowing.contains(doc.id)) scoreMap[doc.id] = (scoreMap[doc.id] ?? 0) + 3;
      }

      // ── Parallel fetch: friends-of-friends (max 5 following, all parallel) ─
      if (alreadyFollowing.length > 1) {
        final fids = alreadyFollowing.where((id) => id != widget.myUid).take(5).toList();
        final results = await Future.wait(
          fids.map((fid) => db.collection('users').doc(fid)
              .collection('followers').limit(15).get()),
          eagerError: false,
        );
        for (final snap in results) {
          for (final doc in snap.docs) {
            if (!alreadyFollowing.contains(doc.id)) {
              scoreMap[doc.id] = (scoreMap[doc.id] ?? 0) + 1;
            }
          }
        }
      }

      List<Map<String, dynamic>> suggestions = [];

      // ── 1 read: fetch top scored users in one whereIn ─────────────────────
      if (scoreMap.isNotEmpty) {
        final sorted = (scoreMap.entries.toList()..sort((a, b) => b.value.compareTo(a.value)))
            .take(10).map((e) => e.key).toList();
        final snap = await db.collection('users')
            .where(FieldPath.documentId, whereIn: sorted).get();
        for (final doc in snap.docs) {
          final d = doc.data() as Map<String, dynamic>;
          if (d['isBanned'] != true) suggestions.add({...d, 'uid': doc.id, 'score': scoreMap[doc.id] ?? 0});
        }
        suggestions.sort((a, b) => (b['score'] as int).compareTo(a['score'] as int));
      }

      // ── 1 read: fallback if not enough ───────────────────────────────────
      if (suggestions.length < 5) {
        final popularSnap = await db.collection('users')
            .orderBy('followersCount', descending: true).limit(20).get();
        for (final doc in popularSnap.docs) {
          if (alreadyFollowing.contains(doc.id)) continue;
          if (suggestions.any((s) => s['uid'] == doc.id)) continue;
          final d = doc.data() as Map<String, dynamic>;
          if (d['isBanned'] != true) suggestions.add({...d, 'uid': doc.id, 'score': 0});
          if (suggestions.length >= 10) break;
        }
      }

      _cache[cacheKey] = List.from(suggestions);
      _cacheTime[cacheKey] = DateTime.now();

      if (mounted) setState(() { _suggestions = suggestions; _loading = false; });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_dismissed) return const SizedBox.shrink();
    if (_loading) return _LoadingCard(compact: widget.compact);
    if (_suggestions.isEmpty) return const SizedBox.shrink();

    return Container(
      margin: EdgeInsets.symmetric(horizontal: widget.compact ? 12 : 0, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 14, offset: const Offset(0, 3))],
        border: Border.all(color: const Color(0xFFE8EEF4))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Header
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 12, 8),
          child: Row(children: [
            Container(
              width: 30, height: 30,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [_blue, _indigo],
                  begin: Alignment.topLeft, end: Alignment.bottomRight),
                borderRadius: BorderRadius.circular(10)),
              child: const Center(child: Text('👥', style: TextStyle(fontSize: 15)))),
            const SizedBox(width: 10),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('People You May Know',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: Color(0xFF0D1B2A))),
              Text('Suggested for you', style: TextStyle(fontSize: 10, color: Color(0xFF94A3B8))),
            ])),
            GestureDetector(
              onTap: () => _load(forceRefresh: true),
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(color: const Color(0xFFF1F5F9), borderRadius: BorderRadius.circular(8)),
                child: const Icon(Icons.refresh_rounded, size: 15, color: Color(0xFF64748B)))),
            const SizedBox(width: 6),
            GestureDetector(
              onTap: () => setState(() => _dismissed = true),
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(color: const Color(0xFFF1F5F9), borderRadius: BorderRadius.circular(8)),
                child: const Icon(Icons.close_rounded, size: 15, color: Color(0xFF94A3B8)))),
          ]),
        ),
        SizedBox(
          height: 185,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
            itemCount: _suggestions.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (ctx, i) => _SuggestionCard(
              key: ValueKey(_suggestions[i]['uid']),
              user: _suggestions[i], myUid: widget.myUid,
              onFollowed: () { if (mounted) setState(() => _suggestions.removeAt(i)); },
              onRemoved:  () { if (mounted) setState(() => _suggestions.removeAt(i)); },
            ),
          ),
        ),
      ]),
    );
  }
}

class _LoadingCard extends StatelessWidget {
  final bool compact;
  const _LoadingCard({required this.compact});
  @override
  Widget build(BuildContext context) => Container(
    margin: EdgeInsets.symmetric(horizontal: compact ? 12 : 0, vertical: 8),
    height: 60,
    decoration: BoxDecoration(
      color: Colors.white, borderRadius: BorderRadius.circular(20),
      border: Border.all(color: const Color(0xFFE8EEF4))),
    child: const Center(child: Row(mainAxisSize: MainAxisSize.min, children: [
      SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF0284C7))),
      SizedBox(width: 10),
      Text('Finding people...', style: TextStyle(color: Color(0xFF94A3B8), fontSize: 12)),
    ])));
}

// ── Individual card — no Firebase reads during build ─────────────────────────
class _SuggestionCard extends StatefulWidget {
  final Map<String, dynamic> user;
  final String myUid;
  final VoidCallback onFollowed, onRemoved;
  const _SuggestionCard({super.key, required this.user, required this.myUid, required this.onFollowed, required this.onRemoved});
  @override State<_SuggestionCard> createState() => _SuggestionCardState();
}

class _SuggestionCardState extends State<_SuggestionCard> {
  static const _blue   = Color(0xFF0284C7);
  static const _indigo = Color(0xFF6366F1);
  bool _following = false, _loading = false;

  Future<void> _follow() async {
    setState(() => _loading = true);
    final uid = widget.user['uid'] as String;
    final db  = FirebaseFirestore.instance;
    // Parallel writes — 4 ops at once instead of sequential
    await Future.wait([
      db.collection('users').doc(widget.myUid).collection('following').doc(uid)
          .set({'followedAt': FieldValue.serverTimestamp()}),
      db.collection('users').doc(uid).collection('followers').doc(widget.myUid)
          .set({'followedAt': FieldValue.serverTimestamp()}),
      db.collection('users').doc(uid).update({'followersCount': FieldValue.increment(1)}),
      db.collection('users').doc(widget.myUid).update({'followingCount': FieldValue.increment(1)}),
    ]);
    if (!mounted) return;
    setState(() { _following = true; _loading = false; });
    await Future.delayed(const Duration(milliseconds: 600));
    widget.onFollowed();
  }

  @override
  Widget build(BuildContext context) {
    final name       = widget.user['username']      as String? ?? 'User';
    final photo      = widget.user['photoURL']       as String? ?? '';
    final fc         = widget.user['followersCount'] as int?    ?? 0;
    final score      = widget.user['score']          as int?    ?? 0;
    final isOfficial = widget.user['isOfficialTick'] == true;
    final bio        = widget.user['bio']            as String? ?? '';

    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(
        builder: (_) => ViewProfileScreen(targetUid: widget.user['uid'] as String))),
      child: Container(
        width: 135,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 10, offset: const Offset(0, 3))],
          border: Border.all(color: const Color(0xFFE8EEF4))),
        child: Column(children: [
          Container(height: 4, decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [_blue, _indigo]),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(18)))),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
            child: Column(children: [
              Align(alignment: Alignment.topRight,
                child: GestureDetector(
                  onTap: widget.onRemoved, behavior: HitTestBehavior.opaque,
                  child: const Icon(Icons.close_rounded, size: 14, color: Color(0xFFCBD5E1)))),
              const SizedBox(height: 2),
              Stack(alignment: Alignment.bottomRight, children: [
                CircleAvatar(
                  radius: 28, backgroundColor: _blue.withValues(alpha: 0.12),
                  backgroundImage: photo.isNotEmpty ? CachedNetworkImageProvider(photo) : null,
                  child: photo.isEmpty ? Text(name.isNotEmpty ? name[0].toUpperCase() : '?',
                    style: const TextStyle(color: _blue, fontWeight: FontWeight.w900, fontSize: 20)) : null),
                if (isOfficial) Container(
                  padding: const EdgeInsets.all(1.5),
                  decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                  child: const Icon(Icons.verified_rounded, color: _blue, size: 13)),
              ]),
              const SizedBox(height: 8),
              Text('@$name',
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12, color: Color(0xFF0D1B2A)),
                overflow: TextOverflow.ellipsis, maxLines: 1, textAlign: TextAlign.center),
              const SizedBox(height: 2),
              Text(bio.isNotEmpty ? bio : (score > 0 ? '$score mutual' : '$fc followers'),
                style: const TextStyle(fontSize: 10, color: Color(0xFF94A3B8)),
                maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center),
              const SizedBox(height: 10),
              GestureDetector(
                onTap: _loading || _following ? null : _follow,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  height: 30, width: double.infinity,
                  decoration: BoxDecoration(
                    gradient: _following ? null : const LinearGradient(colors: [_blue, _indigo]),
                    color: _following ? const Color(0xFFF1F5F9) : null,
                    borderRadius: BorderRadius.circular(20),
                    border: _following ? Border.all(color: const Color(0xFFE2E8F0)) : null),
                  child: Center(child: _loading
                    ? const SizedBox(width: 13, height: 13, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Text(_following ? '✓ Following' : '+ Follow',
                        style: TextStyle(
                          color: _following ? const Color(0xFF64748B) : Colors.white,
                          fontSize: 11, fontWeight: FontWeight.w800))))),
            ]),
          ),
        ]),
      ),
    );
  }
}
