import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart' hide ChangeNotifierProvider, Consumer;
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'theme.dart';
import 'services/auth_service.dart';
import 'services/notification_service.dart';
import 'services/file_service.dart';
import 'services/cache_service.dart';
import 'services/deep_link_service.dart';
import 'screens/splash_screen.dart';
import 'screens/chat/chat_room_screen.dart';
import 'screens/home_screen.dart';
import 'screens/profile/view_profile_screen.dart';
import 'services/share_intent_service.dart';
import 'services/translation_service.dart';
import 'screens/auth/login_screen.dart';
import 'services/accent_theme_service.dart';
import 'services/remote_config_service.dart';
import 'services/local_db_service.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Lock to portrait for faster initial render
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

  // Critical inits — sequential
  await Firebase.initializeApp();
  await FileService.init();
  await CacheService.init();
  CacheService.configureImageCache();

  // Local SQLite DB — messages, unread counts
  await LocalDbService.instance.init();

  // Remote Config — fetch fresh flags before app starts
  await RemoteConfigService.instance.init();

  // Non-critical — fire and forget (don't block startup)
  DeepLinkService.instance.init(navigatorKey).catchError((_) {});
  ShareIntentService.instance.init().catchError((_) {});

  // OneSignal — deferred slightly so UI starts first
  Future.delayed(const Duration(milliseconds: 500), () {
    OneSignal.initialize('a32ac41e-a2d8-4e48-9954-873ffe75940f');
    OneSignal.Notifications.requestPermission(false); // false = don't prompt immediately

    void _savePlayerIdIfLoggedIn() {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;
      final playerId = OneSignal.User.pushSubscription.id;
      if (playerId != null && playerId.isNotEmpty) {
        NotificationService().savePlayerId(playerId).catchError((_) {});
      }
    }

    FirebaseAuth.instance.authStateChanges().listen((user) {
      if (user != null) {
        // Link OneSignal device to Firebase UID — prevents duplicate IDs on reinstall
        OneSignal.login(user.uid);
        _savePlayerIdIfLoggedIn();
        Future.delayed(const Duration(seconds: 3), _savePlayerIdIfLoggedIn);
      } else {
        OneSignal.logout();
      }
    });

    OneSignal.User.pushSubscription.addObserver((state) {
      final newId = state.current.id;
      if (newId != null && newId.isNotEmpty) {
        final user = FirebaseAuth.instance.currentUser;
        if (user != null) {
          NotificationService().savePlayerId(newId).catchError((_) {});
        }
      }
    });

    OneSignal.Notifications.addClickListener((event) {
      final data = event.notification.additionalData;
      if (data == null) return;
      final type     = data['type']     as String?;
      final fromUid  = data['fromUid']  as String?;
      final fromName = data['fromName'] as String? ?? 'User';

      if (type == 'message' && fromUid != null) {
        navigatorKey.currentState?.push(MaterialPageRoute(
          builder: (_) => ChatRoomScreen(targetId: fromUid, targetName: fromName),
        ));
      } else if (type == 'follow' && fromUid != null) {
        // Someone followed me → open their profile
        navigatorKey.currentState?.push(MaterialPageRoute(
          builder: (_) => ViewProfileScreen(targetUid: fromUid),
        ));
      } else if (type == 'post_like' || type == 'post_comment' ||
                 type == 'comment_reply' || type == 'post_mention' ||
                 type == 'feed_post') {
        // Post interaction → go to feed tab
        navigatorKey.currentState?.pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const HomeScreen(initialTab: 1)),
          (route) => false,
        );
      }
    });
  });

  runApp(
    ProviderScope(
      child: MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (_) => AuthService()),
          ChangeNotifierProvider(create: (_) => AccentThemeService()),
          ChangeNotifierProvider(create: (_) => TranslationService()..init()),
        ],
        child: const ZyloApp(),
      ),
    ),
  );
}

class ZyloApp extends StatelessWidget {
  const ZyloApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AccentThemeService>(
      builder: (_, accentSvc, __) => MaterialApp(
        title: 'zylo.pages',
        theme: accentSvc.lightTheme(AppTheme.lightTheme),
        darkTheme: accentSvc.darkTheme(AppTheme.darkTheme),
        themeMode: ThemeMode.system,
        navigatorKey: navigatorKey,
        debugShowCheckedModeBanner: false,
        routes: {
          '/login': (_) => const LoginScreen(),
        },
        home: const SplashScreen(),
      ),
    );
  }
}
