import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/auth_service.dart';
import 'auth/login_screen.dart';
import 'get_started_screen.dart';
import 'home_screen.dart';
import 'maintenance_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with TickerProviderStateMixin {
  late final AnimationController _logoCtrl;
  late final AnimationController _taglineCtrl;
  late final Animation<double> _logoOpacity;
  late final Animation<double> _logoScale;
  late final Animation<double> _taglineOpacity;
  late final Animation<Offset> _taglineSlide;

  String _splashLogoUrl = '';
  Map<String, dynamic> _configData = {};

  bool _showMadeBy = false;

  @override
  void initState() {
    super.initState();
    _logoCtrl    = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _taglineCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));

    _logoOpacity = Tween(begin: 0.0, end: 1.0)
        .chain(CurveTween(curve: Curves.easeOut)).animate(_logoCtrl);
    _logoScale = Tween(begin: 0.75, end: 1.0)
        .chain(CurveTween(curve: Curves.easeOutBack)).animate(_logoCtrl);
    _taglineOpacity = Tween(begin: 0.0, end: 1.0).animate(_taglineCtrl);
    _taglineSlide   = Tween(begin: const Offset(0, 0.3), end: Offset.zero)
        .chain(CurveTween(curve: Curves.easeOut)).animate(_taglineCtrl);

    _runSequence();
  }

  Future<void> _runSequence() async {
    final prefs = await SharedPreferences.getInstance();
    final everOpened = prefs.getBool('ever_opened') ?? false;

    if (!everOpened) {
      await prefs.setBool('ever_opened', true);
      if (!mounted) return;
      setState(() => _showMadeBy = true);
      return;
    }

    _startNormalSplash();
  }

  void _onMadeByDone() async {
    if (!mounted) return;
    setState(() => _showMadeBy = false);
    _startNormalSplash();
  }

  void _startNormalSplash() async {
    _logoCtrl.forward();
    await Future.delayed(const Duration(milliseconds: 400));
    _taglineCtrl.forward();

    await Future.wait([
      Future.delayed(const Duration(milliseconds: 1600)),
      _fetchConfig(),
    ]);
    if (!mounted) return;
    _navigate();
  }

  Future<void> _fetchConfig() async {
    try {
      final cfg = await FirebaseFirestore.instance
          .collection('appConfig').doc('main').get()
          .timeout(const Duration(seconds: 5));
      _configData = cfg.data() ?? {};
      final logoUrl = _configData['splashLogoUrl'] as String? ?? '';
      if (logoUrl.isNotEmpty && mounted) setState(() => _splashLogoUrl = logoUrl);
    } catch (_) {}
  }

  // Fetch startup poster config
  Future<Map<String, dynamic>> _fetchPoster() async {
    try {
      final doc = await FirebaseFirestore.instance
          .collection('appConfig').doc('startupPoster').get()
          .timeout(const Duration(seconds: 4));
      return doc.data() ?? {};
    } catch (_) { return {}; }
  }

  // Slide-up page route — no black fade
  PageRouteBuilder _slideUp(Widget page) => PageRouteBuilder(
    pageBuilder: (_, __, ___) => page,
    transitionDuration: const Duration(milliseconds: 500),
    reverseTransitionDuration: const Duration(milliseconds: 300),
    transitionsBuilder: (_, anim, __, child) {
      final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutCubic);
      return SlideTransition(
        position: Tween(begin: const Offset(0, 1), end: Offset.zero).animate(curved),
        child: FadeTransition(opacity: Tween(begin: 0.0, end: 1.0).animate(curved), child: child),
      );
    },
  );

  void _navigate() async {
    if (!mounted) return;

    if (_configData['maintenanceMode'] == true) {
      Navigator.pushReplacement(context, _slideUp(MaintenanceScreen(
        message: _configData['maintenanceMessage'] as String? ?? 'We are under maintenance. Be right back!',
        apkUrl:  _configData['apkDownloadUrl']     as String? ?? '')));
      return;
    }

    final auth = Provider.of<AuthService>(context, listen: false);
    if (auth.user != null) {
      try {
        final userDoc = await FirebaseFirestore.instance
            .collection('users').doc(auth.user!.uid).get()
            .timeout(const Duration(seconds: 4));
        if (userDoc.data()?['isBanned'] == true) {
          final banReason = userDoc.data()?['banReason'] as String? ?? '';
          await auth.signOut();
          if (!mounted) return;
          _showBannedDialog(banReason);
          return;
        }
      } catch (_) {}
      if (!mounted) return;

      // Check startup poster
      final poster = await _fetchPoster();
      if (!mounted) return;
      if (poster['active'] == true) {
        Navigator.pushReplacement(context, _slideUp(
          StartupPosterScreen(posterData: poster, destination: const HomeScreen())));
      } else {
        Navigator.pushReplacement(context, _slideUp(const HomeScreen()));
      }
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    final seen = prefs.getBool('seen_onboarding') ?? false;
    if (!seen) {
      await prefs.setBool('seen_onboarding', true);
      if (!mounted) return;
      Navigator.pushReplacement(context, _slideUp(const GetStartedScreen()));
    } else {
      if (!mounted) return;
      Navigator.pushReplacement(context, _slideUp(const LoginScreen()));
    }
  }

  void _showBannedDialog(String banReason) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Row(children: [
          Icon(Icons.block, color: Colors.red, size: 22),
          SizedBox(width: 8),
          Text('Account Banned', style: TextStyle(fontWeight: FontWeight.w900, color: Colors.red)),
        ]),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Your account has been banned for violating our community guidelines.',
            style: TextStyle(fontSize: 13, height: 1.5)),
          if (banReason.isNotEmpty) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.red.withValues(alpha: 0.07),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.red.withValues(alpha: 0.2))),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Icon(Icons.info_outline, color: Colors.red, size: 14),
                const SizedBox(width: 6),
                Flexible(child: Text('Reason: $banReason',
                  style: const TextStyle(color: Colors.red, fontSize: 12))),
              ])),
          ],
          const SizedBox(height: 8),
          const Text('Contact support if this is a mistake.',
            style: TextStyle(fontSize: 12, color: Colors.grey)),
        ]),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () => Navigator.pushReplacement(ctx,
              MaterialPageRoute(builder: (_) => const LoginScreen())),
            child: const Text('OK')),
        ]));
  }

  @override
  void dispose() {
    _logoCtrl.dispose();
    _taglineCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_showMadeBy) return _MadeByScreen(onDone: _onMadeByDone);

    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: AnimatedBuilder(
          animation: _logoCtrl,
          builder: (_, __) => Opacity(
            opacity: _logoOpacity.value,
            child: Transform.scale(
              scale: _logoScale.value,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    width: 130, height: 130,
                    child: _splashLogoUrl.isNotEmpty
                        ? Image.network(_splashLogoUrl, fit: BoxFit.contain,
                            errorBuilder: (_, __, ___) => _defaultLogo())
                        : _defaultLogo(),
                  ),
                  const SizedBox(height: 20),
                  const Text('zylo.pages',
                    style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900,
                      color: Color(0xFF0284C7), letterSpacing: -0.5)),
                  const SizedBox(height: 6),
                  SlideTransition(
                    position: _taglineSlide,
                    child: FadeTransition(
                      opacity: _taglineOpacity,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                        decoration: BoxDecoration(
                          color: const Color(0xFFEFF6FF),
                          borderRadius: BorderRadius.circular(20)),
                        child: const Text('CONNECT • EXPLORE SECURELY',
                          style: TextStyle(fontSize: 9, fontWeight: FontWeight.w700,
                            color: Color(0xFF0284C7), letterSpacing: 2.2)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _defaultLogo() => Image.asset('assets/images/zylo_logo.png', fit: BoxFit.contain);
}

// ─────────────────────────────────────────────────────────────────────────────
//  Made By Mehran Chandail Screen
// ─────────────────────────────────────────────────────────────────────────────
class _MadeByScreen extends StatefulWidget {
  final VoidCallback onDone;
  const _MadeByScreen({required this.onDone});

  @override
  State<_MadeByScreen> createState() => _MadeByScreenState();
}

class _MadeByScreenState extends State<_MadeByScreen> with TickerProviderStateMixin {
  late final AnimationController _entryCtrl;
  late final AnimationController _exitCtrl;
  late final AnimationController _pulseCtrl;
  late final AnimationController _shimmerCtrl;

  late final Animation<double> _photoScale;
  late final Animation<double> _photoOpacity;
  late final Animation<Offset> _textSlide;
  late final Animation<double> _textOpacity;
  late final Animation<double> _pulse;

  @override
  void initState() {
    super.initState();

    _entryCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _exitCtrl   = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _pulseCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..repeat(reverse: true);
    _shimmerCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat();

    _photoScale   = Tween(begin: 0.5, end: 1.0).animate(CurvedAnimation(parent: _entryCtrl, curve: Curves.elasticOut));
    _photoOpacity = Tween(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _entryCtrl, curve: const Interval(0.0, 0.5)));
    _textSlide    = Tween(begin: const Offset(0, 0.5), end: Offset.zero).animate(CurvedAnimation(parent: _entryCtrl, curve: const Interval(0.4, 1.0, curve: Curves.easeOut)));
    _textOpacity  = Tween(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _entryCtrl, curve: const Interval(0.4, 1.0)));
    _pulse = Tween(begin: 1.0, end: 1.06).animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _entryCtrl.forward().then((_) async {
      await Future.delayed(const Duration(milliseconds: 2200));
      if (!mounted) return;
      await _exitCtrl.forward();
      widget.onDone();
    });
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    _exitCtrl.dispose();
    _pulseCtrl.dispose();
    _shimmerCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _exitCtrl,
      builder: (_, child) => Opacity(opacity: 1 - _exitCtrl.value, child: child),
      child: Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF0A0A1A),
                Color(0xFF0C1A2E),
                Color(0xFF0A0A1A),
              ],
            ),
          ),
          child: SafeArea(
            child: Stack(
              children: [
                // BG glow blobs
                Positioned(top: -100, left: -80,
                  child: Container(width: 300, height: 300,
                    decoration: BoxDecoration(shape: BoxShape.circle,
                      color: const Color(0xFF0284C7).withValues(alpha: 0.08)))),
                Positioned(bottom: -80, right: -60,
                  child: Container(width: 260, height: 260,
                    decoration: BoxDecoration(shape: BoxShape.circle,
                      color: const Color(0xFF7C3AED).withValues(alpha: 0.07)))),

                Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Photo with ring
                      AnimatedBuilder(
                        animation: Listenable.merge([_entryCtrl, _pulseCtrl]),
                        builder: (_, __) => Opacity(
                          opacity: _photoOpacity.value,
                          child: Transform.scale(
                            scale: _photoScale.value * _pulse.value,
                            child: Container(
                              width: 160, height: 160,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: const SweepGradient(colors: [
                                  Color(0xFF0284C7),
                                  Color(0xFF7C3AED),
                                  Color(0xFF38BDF8),
                                  Color(0xFF0284C7),
                                ]),
                                boxShadow: [
                                  BoxShadow(color: const Color(0xFF0284C7).withValues(alpha: 0.4),
                                      blurRadius: 30, spreadRadius: 4),
                                ],
                              ),
                              padding: const EdgeInsets.all(3),
                              child: Container(
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0xFF0A0A1A),
                                ),
                                padding: const EdgeInsets.all(3),
                                child: ClipOval(
                                  child: Image.asset(
                                    'assets/images/made_by_mehran.png',
                                    width: 148, height: 148,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 32),

                      // Text block
                      SlideTransition(
                        position: _textSlide,
                        child: FadeTransition(
                          opacity: _textOpacity,
                          child: Column(children: [
                            // "Made by" chip
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                              decoration: BoxDecoration(
                                color: Colors.white.withValues(alpha: 0.06),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
                              ),
                              child: Row(mainAxisSize: MainAxisSize.min, children: [
                                Container(width: 6, height: 6, decoration: const BoxDecoration(
                                  shape: BoxShape.circle, color: Color(0xFF34A853))),
                                const SizedBox(width: 7),
                                const Text('Made by', style: TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.w600,
                                  color: Colors.white60, letterSpacing: 0.5)),
                              ]),
                            ),

                            const SizedBox(height: 14),

                            // Name with shimmer
                            AnimatedBuilder(
                              animation: _shimmerCtrl,
                              builder: (_, __) => ShaderMask(
                                shaderCallback: (bounds) => LinearGradient(
                                  begin: Alignment.centerLeft,
                                  end: Alignment.centerRight,
                                  colors: const [
                                    Color(0xFF38BDF8),
                                    Colors.white,
                                    Color(0xFF7C3AED),
                                    Colors.white,
                                    Color(0xFF38BDF8),
                                  ],
                                  stops: [
                                    0.0,
                                    (_shimmerCtrl.value - 0.2).clamp(0.0, 1.0),
                                    _shimmerCtrl.value,
                                    (_shimmerCtrl.value + 0.2).clamp(0.0, 1.0),
                                    1.0,
                                  ],
                                ).createShader(bounds),
                                child: const Text(
                                  'Mehran Chandail',
                                  style: TextStyle(
                                    fontSize: 28,
                                    fontWeight: FontWeight.w900,
                                    color: Colors.white,
                                    letterSpacing: -0.5,
                                  ),
                                ),
                              ),
                            ),

                            const SizedBox(height: 8),

                            // Role badge
                            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                              _Badge(icon: Icons.phone_android_rounded, label: 'Flutter Developer'),
                              const SizedBox(width: 8),
                              _Badge(icon: Icons.design_services_rounded, label: 'UI Designer'),
                            ]),

                            const SizedBox(height: 20),

                            // Zylo tag
                            ShaderMask(
                              shaderCallback: (b) => const LinearGradient(
                                colors: [Color(0xFF0284C7), Color(0xFF38BDF8)]).createShader(b),
                              child: const Text('zylo.pages',
                                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800,
                                  color: Colors.white, letterSpacing: 0.5)),
                            ),
                          ]),
                        ),
                      ),
                    ],
                  ),
                ),

                // Tap to skip
                Positioned(
                  bottom: 24, left: 0, right: 0,
                  child: FadeTransition(
                    opacity: _textOpacity,
                    child: GestureDetector(
                      onTap: widget.onDone,
                      child: Center(child: Text('Tap to continue',
                        style: TextStyle(fontSize: 12, color: Colors.white.withValues(alpha: 0.25),
                          letterSpacing: 0.5))),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final IconData icon;
  final String label;
  const _Badge({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.07),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withValues(alpha: 0.1)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 12, color: const Color(0xFF38BDF8)),
        const SizedBox(width: 5),
        Text(label, style: const TextStyle(fontSize: 11, color: Colors.white70,
            fontWeight: FontWeight.w600)),
      ]),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Startup Poster Screen — shown to all users on app open when admin sets it
// ─────────────────────────────────────────────────────────────────────────────
class StartupPosterScreen extends StatefulWidget {
  final Map<String, dynamic> posterData;
  final Widget destination;
  const StartupPosterScreen({super.key, required this.posterData, required this.destination});
  @override State<StartupPosterScreen> createState() => _StartupPosterScreenState();
}

class _StartupPosterScreenState extends State<StartupPosterScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double>    _fade;
  late final Animation<Offset>    _slide;

  @override
  void initState() {
    super.initState();
    _ctrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fade  = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween(begin: const Offset(0, 0.06), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
    _ctrl.forward();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  void _dismiss() {
    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => widget.destination,
        transitionDuration: const Duration(milliseconds: 400),
        transitionsBuilder: (_, anim, __, child) => FadeTransition(opacity: anim, child: child),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final d          = widget.posterData;
    final type       = d['type'] as String? ?? 'image';
    final mediaUrl   = d['mediaUrl'] as String? ?? '';
    final title      = d['title'] as String? ?? '';
    final subtitle   = d['subtitle'] as String? ?? '';
    final textBody   = d['textBody'] as String? ?? '';
    final btnLabel   = d['buttonLabel'] as String? ?? '';
    final btnLink    = d['buttonLink'] as String? ?? '';

    return Scaffold(
      backgroundColor: Colors.black,
      body: FadeTransition(
        opacity: _fade,
        child: SlideTransition(
          position: _slide,
          child: Stack(fit: StackFit.expand, children: [

            // ── Background media ────────────────────────────────────────
            if (type == 'image' && mediaUrl.isNotEmpty)
              Image.network(mediaUrl, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(color: const Color(0xFF0D1B2A))),

            if (type == 'video' && mediaUrl.isNotEmpty)
              _VideoBackground(url: mediaUrl),

            if (type == 'text')
              Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                    colors: [Color(0xFF0D1B2A), Color(0xFF0284C7), Color(0xFF0D1B2A)])),
              ),

            // ── Dark gradient overlay ────────────────────────────────────
            if (type != 'text')
              Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter, end: Alignment.bottomCenter,
                    colors: [Colors.black12, Colors.black54, Colors.black87])),
              ),

            // ── Content ──────────────────────────────────────────────────
            SafeArea(
              child: Column(children: [
                // Skip button top-right
                Align(
                  alignment: Alignment.topRight,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: GestureDetector(
                      onTap: _dismiss,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.45),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: Colors.white.withValues(alpha: 0.25))),
                        child: const Text('Skip', style: TextStyle(
                          color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ),
                ),

                const Spacer(),

                // Bottom content panel
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 32),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    if (title.isNotEmpty)
                      Text(title, style: const TextStyle(
                        color: Colors.white, fontSize: 26,
                        fontWeight: FontWeight.w900, letterSpacing: -0.5, height: 1.2)),
                    if (title.isNotEmpty && subtitle.isNotEmpty)
                      const SizedBox(height: 8),
                    if (subtitle.isNotEmpty)
                      Text(subtitle, style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.75), fontSize: 14, height: 1.4)),
                    if (type == 'text' && textBody.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      Text(textBody, style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.85), fontSize: 15, height: 1.6)),
                    ],
                    if (btnLabel.isNotEmpty && btnLink.isNotEmpty) ...[
                      const SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity, height: 52,
                        child: ElevatedButton(
                          onPressed: () async {
                            final uri = Uri.tryParse(btnLink);
                            if (uri != null) {
                              await launchUrl(uri, mode: LaunchMode.externalApplication);
                            }
                            _dismiss();
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF0284C7),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                          child: Text(btnLabel, style: const TextStyle(
                            color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
                        ),
                      ),
                    ],
                    const SizedBox(height: 12),
                    // Tap anywhere to dismiss hint
                    GestureDetector(
                      onTap: _dismiss,
                      behavior: HitTestBehavior.translucent,
                      child: SizedBox(
                        width: double.infinity, height: 48,
                        child: Center(child: Text('Tap to continue →',
                          style: TextStyle(color: Colors.white.withValues(alpha: 0.5),
                            fontSize: 12, fontWeight: FontWeight.w600))),
                      ),
                    ),
                  ]),
                ),
              ]),
            ),

          ]),
        ),
      ),
    );
  }
}

// Simple video background widget (auto-plays muted)
class _VideoBackground extends StatelessWidget {
  final String url;
  const _VideoBackground({required this.url});
  @override
  Widget build(BuildContext context) {
    // Using a placeholder — integrate video_player if needed
    // video_player package se: VideoPlayerController.network(url)
    return Container(
      color: Colors.black,
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.play_circle_outline, color: Colors.white30, size: 64),
        const SizedBox(height: 8),
        Text(url.split('/').last,
          style: const TextStyle(color: Colors.white24, fontSize: 11),
          textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis),
      ]),
    );
  }
}
