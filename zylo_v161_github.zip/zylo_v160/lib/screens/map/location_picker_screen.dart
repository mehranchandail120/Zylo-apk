import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

// ══════════════════════════════════════════════════════════════════════════════
// PickedLatLng — returned from this screen
// ══════════════════════════════════════════════════════════════════════════════
class PickedLatLng {
  final double lat, lng;
  const PickedLatLng(this.lat, this.lng);
}

// ══════════════════════════════════════════════════════════════════════════════
// LocationPickerScreen
// ══════════════════════════════════════════════════════════════════════════════
class LocationPickerScreen extends StatefulWidget {
  const LocationPickerScreen({super.key});

  @override
  State<LocationPickerScreen> createState() => _LocationPickerScreenState();
}

class _LocationPickerScreenState extends State<LocationPickerScreen> {
  static const _blue = Color(0xFF0284C7);
  static const _defaultLatLng = LatLng(28.6139, 77.2090); // New Delhi default

  final MapController _mapController = MapController();

  LatLng _pickedPoint = _defaultLatLng;
  LatLng? _myLocation;
  bool _loadingGps = false;
  bool _loadingRoute = false;
  List<LatLng> _routePoints = [];
  String? _routeInfo; // "2.3 km · 8 min"
  String? _pickedAddress;
  bool _loadingAddress = false;

  @override
  void initState() {
    super.initState();
    _getMyLocation();
  }

  // ── GPS ───────────────────────────────────────────────────────────────────
  Future<void> _getMyLocation() async {
    setState(() => _loadingGps = true);
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) { setState(() => _loadingGps = false); return; }

      LocationPermission perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        setState(() => _loadingGps = false);
        return;
      }

      final pos = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high,
          timeLimit: const Duration(seconds: 10));

      if (!mounted) return;
      final myLatLng = LatLng(pos.latitude, pos.longitude);
      setState(() {
        _myLocation = myLatLng;
        _pickedPoint = myLatLng;
        _loadingGps = false;
      });
      _mapController.move(myLatLng, 15);
      _reverseGeocode(myLatLng);
    } catch (_) {
      if (mounted) setState(() => _loadingGps = false);
    }
  }

  // ── Reverse geocode (OSM Nominatim) ───────────────────────────────────────
  Future<void> _reverseGeocode(LatLng point) async {
    setState(() { _loadingAddress = true; _pickedAddress = null; });
    try {
      final url = Uri.parse(
          'https://nominatim.openstreetmap.org/reverse?format=json&lat=${point.latitude}&lon=${point.longitude}&zoom=18&addressdetails=1');
      final res = await http.get(url, headers: {'User-Agent': 'ZyloApp/1.0'});
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final display = data['display_name'] as String? ?? '';
        // Shorten address — take first 2 parts
        final parts = display.split(',');
        final short = parts.take(3).join(',').trim();
        if (mounted) setState(() { _pickedAddress = short; _loadingAddress = false; });
      } else {
        if (mounted) setState(() => _loadingAddress = false);
      }
    } catch (_) {
      if (mounted) setState(() => _loadingAddress = false);
    }
  }

  // ── Route (OSRM) ──────────────────────────────────────────────────────────
  Future<void> _fetchRoute() async {
    if (_myLocation == null) return;
    setState(() { _loadingRoute = true; _routePoints = []; _routeInfo = null; });
    try {
      final from = _myLocation!;
      final to = _pickedPoint;
      final url = Uri.parse(
          'https://router.project-osrm.org/route/v1/driving/'
          '${from.longitude},${from.latitude};${to.longitude},${to.latitude}'
          '?overview=full&geometries=geojson');
      final res = await http.get(url);
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final routes = data['routes'] as List;
        if (routes.isNotEmpty) {
          final route = routes.first;
          final coords = route['geometry']['coordinates'] as List;
          final points = coords.map((c) => LatLng(c[1] as double, c[0] as double)).toList();
          final distM = (route['distance'] as num).toDouble();
          final durS = (route['duration'] as num).toDouble();
          final distKm = (distM / 1000).toStringAsFixed(1);
          final durMin = (durS / 60).ceil();
          if (mounted) setState(() {
            _routePoints = points;
            _routeInfo = '$distKm km · $durMin min';
            _loadingRoute = false;
          });
          // Fit map to show both points
          final bounds = LatLngBounds.fromPoints([from, to, ...points]);
          _mapController.fitCamera(CameraFit.bounds(bounds: bounds, padding: const EdgeInsets.all(60)));
        } else {
          if (mounted) setState(() => _loadingRoute = false);
        }
      } else {
        if (mounted) setState(() => _loadingRoute = false);
      }
    } catch (_) {
      if (mounted) setState(() { _loadingRoute = false; _routeInfo = 'Route unavailable'; });
    }
  }

  void _onMapTap(TapPosition tap, LatLng point) {
    setState(() {
      _pickedPoint = point;
      _routePoints = [];
      _routeInfo = null;
    });
    _reverseGeocode(point);
  }

  void _confirmLocation() {
    Navigator.pop(context, PickedLatLng(_pickedPoint.latitude, _pickedPoint.longitude));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black87),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Choose Location',
            style: TextStyle(color: Colors.black87, fontWeight: FontWeight.w700, fontSize: 17)),
        actions: [
          if (_loadingGps)
            const Padding(
              padding: EdgeInsets.all(14),
              child: SizedBox(width: 18, height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2, color: _blue)),
            )
          else
            IconButton(
              icon: const Icon(Icons.my_location, color: _blue),
              tooltip: 'My Location',
              onPressed: _getMyLocation,
            ),
        ],
      ),
      body: Stack(children: [
        // ── Map ──
        FlutterMap(
          mapController: _mapController,
          options: MapOptions(
            initialCenter: _defaultLatLng,
            initialZoom: 12,
            onTap: _onMapTap,
          ),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'com.zylopages.app',
            ),

            // Route polyline
            if (_routePoints.isNotEmpty)
              PolylineLayer(polylines: [
                Polyline(points: _routePoints, color: _blue, strokeWidth: 4.5),
              ]),

            // Markers
            MarkerLayer(markers: [
              // My location
              if (_myLocation != null)
                Marker(
                  point: _myLocation!,
                  width: 36, height: 36,
                  child: Container(
                    decoration: BoxDecoration(
                      color: _blue,
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 3),
                      boxShadow: [BoxShadow(color: _blue.withValues(alpha: 0.4), blurRadius: 8)],
                    ),
                    child: const Icon(Icons.person, color: Colors.white, size: 18),
                  ),
                ),

              // Picked point
              Marker(
                point: _pickedPoint,
                width: 50, height: 60,
                alignment: const Alignment(0, -1),
                child: Column(children: [
                  Container(
                    width: 40, height: 40,
                    decoration: BoxDecoration(
                      color: const Color(0xFFEF4444),
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 3),
                      boxShadow: [BoxShadow(color: Colors.red.withValues(alpha: 0.4), blurRadius: 8)],
                    ),
                    child: const Icon(Icons.location_on, color: Colors.white, size: 20),
                  ),
                  Container(width: 3, height: 12, color: const Color(0xFFEF4444)),
                ]),
              ),
            ]),
          ],
        ),

        // ── Bottom Card ──
        Positioned(
          left: 0, right: 0, bottom: 0,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(22)),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.12), blurRadius: 20)],
            ),
            padding: EdgeInsets.fromLTRB(20, 16, 20, MediaQuery.of(context).padding.bottom + 16),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Container(width: 40, height: 4,
                  decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
              const SizedBox(height: 14),

              // Address row
              Row(children: [
                Container(width: 38, height: 38,
                  decoration: BoxDecoration(
                    color: const Color(0xFFEF4444).withValues(alpha: 0.12), shape: BoxShape.circle),
                  child: const Icon(Icons.location_on, color: Color(0xFFEF4444), size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Selected Location',
                      style: TextStyle(fontSize: 11, color: Colors.grey, fontWeight: FontWeight.w500)),
                  const SizedBox(height: 2),
                  _loadingAddress
                      ? const Text('Getting address...', style: TextStyle(fontSize: 13, color: Colors.grey))
                      : Text(
                          _pickedAddress ?? '${_pickedPoint.latitude.toStringAsFixed(5)}, ${_pickedPoint.longitude.toStringAsFixed(5)}',
                          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Colors.black87),
                          maxLines: 2, overflow: TextOverflow.ellipsis),
                ])),
              ]),

              // Route info
              if (_routeInfo != null) ...[
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: _blue.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(children: [
                    const Icon(Icons.directions_car, color: _blue, size: 18),
                    const SizedBox(width: 8),
                    Text(_routeInfo!, style: const TextStyle(
                        color: _blue, fontWeight: FontWeight.w700, fontSize: 13)),
                  ]),
                ),
              ],

              const SizedBox(height: 14),

              // Buttons
              Row(children: [
                // Route button
                if (_myLocation != null)
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _loadingRoute ? null : _fetchRoute,
                      icon: _loadingRoute
                          ? const SizedBox(width: 14, height: 14,
                              child: CircularProgressIndicator(strokeWidth: 2, color: _blue))
                          : const Icon(Icons.alt_route, color: _blue, size: 18),
                      label: Text(_loadingRoute ? 'Getting...' : 'Show Route',
                          style: const TextStyle(color: _blue, fontWeight: FontWeight.w700)),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: _blue),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                    ),
                  ),
                if (_myLocation != null) const SizedBox(width: 12),

                // Send button
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _confirmLocation,
                    icon: const Icon(Icons.send_rounded, size: 18, color: Colors.white),
                    label: const Text('Send Location',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _blue,
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                  ),
                ),
              ]),
            ]),
          ),
        ),

        // ── Tap hint ──
        Positioned(
          top: 12, left: 0, right: 0,
          child: Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.55),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Text('Tap on map to pick location',
                  style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w500)),
            ),
          ),
        ),
      ]),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// LocationMessageWidget — shown in chat bubble when a location is received
// ══════════════════════════════════════════════════════════════════════════════
class LocationMessageWidget extends StatelessWidget {
  final double lat, lng;
  final bool isMe;

  const LocationMessageWidget({
    super.key,
    required this.lat,
    required this.lng,
    required this.isMe,
  });

  static const _blue = Color(0xFF0284C7);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context,
            MaterialPageRoute(builder: (_) => _LocationViewScreen(lat: lat, lng: lng)));
      },
      child: Container(
        width: 240,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.grey[200]!),
        ),
        child: Column(children: [
          // Mini map preview (static image via OSM)
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
            child: SizedBox(
              height: 140,
              child: FlutterMap(
                options: MapOptions(
                  initialCenter: LatLng(lat, lng),
                  initialZoom: 14,
                  interactionOptions: const InteractionOptions(
                    flags: InteractiveFlag.none, // non-interactive thumbnail
                  ),
                ),
                children: [
                  TileLayer(
                    urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                    userAgentPackageName: 'com.zylopages.app',
                  ),
                  MarkerLayer(markers: [
                    Marker(
                      point: LatLng(lat, lng),
                      width: 36, height: 44,
                      alignment: const Alignment(0, -1),
                      child: const Column(children: [
                        Icon(Icons.location_on, color: Color(0xFFEF4444), size: 32),
                      ]),
                    ),
                  ]),
                ],
              ),
            ),
          ),
          // Bottom bar
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: isMe ? _blue.withValues(alpha: 0.08) : Colors.grey[50],
              borderRadius: const BorderRadius.vertical(bottom: Radius.circular(16)),
            ),
            child: Row(children: [
              Icon(Icons.location_on, color: isMe ? _blue : Colors.grey[700], size: 18),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  '${lat.toStringAsFixed(4)}, ${lng.toStringAsFixed(4)}',
                  style: TextStyle(
                      fontSize: 12, fontWeight: FontWeight.w600,
                      color: isMe ? _blue : Colors.black87),
                ),
              ),
              Icon(Icons.open_in_new, size: 14, color: Colors.grey[400]),
            ]),
          ),
        ]),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// _LocationViewScreen — full screen view when tapping a location message
// ══════════════════════════════════════════════════════════════════════════════
class _LocationViewScreen extends StatefulWidget {
  final double lat, lng;
  const _LocationViewScreen({required this.lat, required this.lng});
  @override
  State<_LocationViewScreen> createState() => _LocationViewScreenState();
}

class _LocationViewScreenState extends State<_LocationViewScreen> {
  static const _blue = Color(0xFF0284C7);
  final MapController _mapController = MapController();
  LatLng? _myLocation;
  List<LatLng> _routePoints = [];
  String? _routeInfo;
  bool _loadingRoute = false;
  bool _loadingGps = false;

  late LatLng _target;

  @override
  void initState() {
    super.initState();
    _target = LatLng(widget.lat, widget.lng);
    _getMyLocation();
  }

  Future<void> _getMyLocation() async {
    setState(() => _loadingGps = true);
    try {
      final perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        setState(() => _loadingGps = false); return;
      }
      final pos = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high, timeLimit: const Duration(seconds: 8));
      if (mounted) setState(() { _myLocation = LatLng(pos.latitude, pos.longitude); _loadingGps = false; });
    } catch (_) {
      if (mounted) setState(() => _loadingGps = false);
    }
  }

  Future<void> _fetchRoute() async {
    if (_myLocation == null) return;
    setState(() { _loadingRoute = true; _routePoints = []; _routeInfo = null; });
    try {
      final from = _myLocation!;
      final url = Uri.parse(
          'https://router.project-osrm.org/route/v1/driving/'
          '${from.longitude},${from.latitude};${_target.longitude},${_target.latitude}'
          '?overview=full&geometries=geojson');
      final res = await http.get(url);
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final routes = data['routes'] as List;
        if (routes.isNotEmpty) {
          final route = routes.first;
          final coords = route['geometry']['coordinates'] as List;
          final points = coords.map((c) => LatLng(c[1] as double, c[0] as double)).toList();
          final distKm = ((route['distance'] as num) / 1000).toStringAsFixed(1);
          final durMin = ((route['duration'] as num) / 60).ceil();
          if (mounted) setState(() {
            _routePoints = points;
            _routeInfo = '$distKm km · $durMin min drive';
            _loadingRoute = false;
          });
          final bounds = LatLngBounds.fromPoints([from, _target, ...points]);
          _mapController.fitCamera(CameraFit.bounds(bounds: bounds, padding: const EdgeInsets.all(60)));
        } else {
          if (mounted) setState(() { _loadingRoute = false; _routeInfo = 'No route found'; });
        }
      }
    } catch (_) {
      if (mounted) setState(() { _loadingRoute = false; _routeInfo = 'Route unavailable'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black87),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Location', style: TextStyle(color: Colors.black87, fontWeight: FontWeight.w700)),
      ),
      body: Stack(children: [
        FlutterMap(
          mapController: _mapController,
          options: MapOptions(initialCenter: _target, initialZoom: 15),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'com.zylopages.app',
            ),
            if (_routePoints.isNotEmpty)
              PolylineLayer(polylines: [
                Polyline(points: _routePoints, color: _blue, strokeWidth: 4.5),
              ]),
            MarkerLayer(markers: [
              if (_myLocation != null)
                Marker(
                  point: _myLocation!,
                  width: 36, height: 36,
                  child: Container(
                    decoration: BoxDecoration(color: _blue, shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 3),
                        boxShadow: [BoxShadow(color: _blue.withValues(alpha: 0.4), blurRadius: 8)]),
                    child: const Icon(Icons.person, color: Colors.white, size: 18),
                  ),
                ),
              Marker(
                point: _target,
                width: 50, height: 60,
                alignment: const Alignment(0, -1),
                child: const Column(children: [
                  Icon(Icons.location_on, color: Color(0xFFEF4444), size: 40),
                ]),
              ),
            ]),
          ],
        ),

        // Bottom panel
        Positioned(
          left: 0, right: 0, bottom: 0,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(22)),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.1), blurRadius: 20)],
            ),
            padding: EdgeInsets.fromLTRB(20, 16, 20, MediaQuery.of(context).padding.bottom + 16),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Container(width: 40, height: 4,
                  decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
              const SizedBox(height: 14),
              Row(children: [
                Container(width: 38, height: 38,
                    decoration: BoxDecoration(color: Colors.red.withValues(alpha: 0.12), shape: BoxShape.circle),
                    child: const Icon(Icons.location_on, color: Color(0xFFEF4444), size: 20)),
                const SizedBox(width: 12),
                Expanded(child: Text(
                  '${widget.lat.toStringAsFixed(5)}, ${widget.lng.toStringAsFixed(5)}',
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
                )),
              ]),
              if (_routeInfo != null) ...[
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(color: _blue.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(12)),
                  child: Row(children: [
                    const Icon(Icons.directions_car, color: _blue, size: 18),
                    const SizedBox(width: 8),
                    Text(_routeInfo!, style: const TextStyle(color: _blue, fontWeight: FontWeight.w700, fontSize: 13)),
                  ]),
                ),
              ],
              const SizedBox(height: 14),
              if (_myLocation != null)
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _loadingRoute ? null : _fetchRoute,
                    icon: _loadingRoute
                        ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                        : const Icon(Icons.alt_route, color: Colors.white, size: 18),
                    label: Text(_loadingRoute ? 'Getting Route...' : 'Get Route to Here',
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _blue, elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                  ),
                )
              else
                _loadingGps
                    ? const Text('Getting your location...', style: TextStyle(color: Colors.grey))
                    : const Text('Location permission needed for route',
                        style: TextStyle(color: Colors.grey, fontSize: 12)),
            ]),
          ),
        ),
      ]),
    );
  }
}
