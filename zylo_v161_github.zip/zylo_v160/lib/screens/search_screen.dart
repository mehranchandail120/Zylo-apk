import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../widgets/zylo_cached_image.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import 'chat/chat_room_screen.dart';
import 'profile/view_profile_screen.dart';
import 'feed/post_deep_link_screen.dart';
import '../widgets/zylo_avatar.dart';
import '../widgets/zylo_people_suggestion.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen>
    with SingleTickerProviderStateMixin {
  final TextEditingController _searchCtrl = TextEditingController();
  late TabController _tabCtrl;
  String _query = '';
  Timer? _debounce;

  static const _blue = Color(0xFF0284C7);
  static const _indigo = Color(0xFF6366F1);

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
    _searchCtrl.addListener(() {
      _debounce?.cancel();
      _debounce = Timer(const Duration(milliseconds: 300), () {
        if (mounted) setState(() => _query = _searchCtrl.text.trim());
      });
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _tabCtrl.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final myUid = Provider.of<AuthService>(context).user?.uid ?? '';
    final isSearching = _query.isNotEmpty;

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFF),
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(myUid),
            _buildSearchBar(),
            if (isSearching) _buildSearchTabs(),
            if (!isSearching) _buildContactsQuickButton(myUid),
            if (!isSearching) _buildSectionTitle(),
            Expanded(
              child: isSearching
                  ? TabBarView(
                      controller: _tabCtrl,
                      children: [
                        _buildRealtimeResults(myUid),
                        _buildPostResults(myUid),
                      ])
                  : _AllUsersTab(myUid: myUid),
            ),
          ],
        ),
      ),
    );
  }


  Widget _buildSearchTabs() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 8),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: TabBar(
        controller: _tabCtrl,
        indicator: BoxDecoration(
          gradient: const LinearGradient(colors: [_blue, _indigo]),
          borderRadius: BorderRadius.circular(10)),
        labelColor: Colors.white,
        unselectedLabelColor: Colors.grey[500],
        labelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
        unselectedLabelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
        tabs: const [
          Tab(child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.person_rounded, size: 14),
            SizedBox(width: 5),
            Text('People'),
          ])),
          Tab(child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.article_rounded, size: 14),
            SizedBox(width: 5),
            Text('Posts'),
          ])),
        ],
      ),
    );
  }

  Widget _buildHeader(String myUid) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Discover',
                  style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF0C1A2E),
                      letterSpacing: -0.5)),
              Text('Find people, friends & more',
                  style: TextStyle(fontSize: 12, color: Colors.grey[500])),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withValues(alpha: 0.06),
                blurRadius: 12,
                offset: const Offset(0, 3))
          ],
        ),
        child: TextField(
          controller: _searchCtrl,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
          decoration: InputDecoration(
            hintText: 'Search username or ID...',
            hintStyle:
                TextStyle(color: Colors.grey[400], fontWeight: FontWeight.w400),
            prefixIcon:
                const Icon(Icons.search_rounded, color: _blue, size: 22),
            suffixIcon: _query.isNotEmpty
                ? GestureDetector(
                    onTap: () => _searchCtrl.clear(),
                    child: Icon(Icons.close_rounded,
                        color: Colors.grey[400], size: 20))
                : null,
            border: InputBorder.none,
            contentPadding:
                const EdgeInsets.symmetric(vertical: 14, horizontal: 4),
          ),
        ),
      ),
    );
  }

  Widget _buildContactsQuickButton(String myUid) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
      child: Row(children: [
        Expanded(child: GestureDetector(
          onTap: () => _showContactsSheet(myUid),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 8, offset: const Offset(0, 2))],
            ),
            child: Row(children: [
              Container(width: 36, height: 36,
                decoration: BoxDecoration(color: _blue.withValues(alpha: 0.1), shape: BoxShape.circle),
                child: const Icon(Icons.contacts_rounded, color: _blue, size: 20)),
              const SizedBox(width: 12),
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Contacts on Zylo', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: Color(0xFF0C1A2E))),
                Text('Find friends from your contacts', style: TextStyle(fontSize: 11, color: Colors.grey)),
              ])),
              const Icon(Icons.chevron_right, color: Colors.grey, size: 20),
            ]),
          ),
        )),
      ]),
    );
  }

  void _showContactsSheet(String myUid) {
    showModalBottomSheet(
      context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (ctx) => DraggableScrollableSheet(
        initialChildSize: 0.85, minChildSize: 0.5, maxChildSize: 0.95,
        builder: (_, scrollCtrl) => Container(
          decoration: const BoxDecoration(
            color: Color(0xFFF8FAFF),
            borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
          child: _ContactsOnZyloSheet(myUid: myUid, scrollController: scrollCtrl),
        ),
      ),
    );
  }

  Widget _buildSectionTitle() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── People You May Know horizontal strip ─────────────────────────────
      ZyloPeopleSuggestion(myUid: Provider.of<AuthService>(context, listen: false).user?.uid ?? ''),
      // ── All users title ───────────────────────────────────────────────────
      Padding(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 6),
        child: Row(children: [
          const Icon(Icons.people_outline_rounded, size: 15, color: Color(0xFF64748B)),
          const SizedBox(width: 6),
          Text('All Users',
            style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: Colors.grey[600])),
        ]),
      ),
    ]);
  }

  Widget _buildQuickActions(String myUid) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
      child: Row(
        children: [
          _QuickActionCard(
            icon: Icons.contacts_rounded,
            label: 'Contacts',
            subtitle: 'Sync & Find',
            color: const Color(0xFF3B82F6),
            bgColor: const Color(0xFFEFF6FF),
            onTap: () => _tabCtrl.animateTo(2),
          ),
          const SizedBox(width: 10),
          _QuickActionCard(
            icon: Icons.map_rounded,
            label: 'Explore Map',
            subtitle: 'Nearby Friends',
            color: const Color(0xFF10B981),
            bgColor: const Color(0xFFECFDF5),
            onTap: () => _tabCtrl.animateTo(3),
          ),
          const SizedBox(width: 10),
          _QuickActionCard(
            icon: Icons.people_rounded,
            label: 'All Users',
            subtitle: 'Browse All',
            color: const Color(0xFFF59E0B),
            bgColor: const Color(0xFFFFFBEB),
            onTap: () => _tabCtrl.animateTo(0),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterTabs() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 0),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.04),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: TabBar(
        controller: _tabCtrl,
        indicator: BoxDecoration(
          gradient:
              const LinearGradient(colors: [_blue, _indigo]),
          borderRadius: BorderRadius.circular(10),
        ),
        labelColor: Colors.white,
        unselectedLabelColor: Colors.grey[500],
        labelStyle:
            const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
        unselectedLabelStyle:
            const TextStyle(fontSize: 11, fontWeight: FontWeight.w500),
        tabs: const [
          Tab(text: '👥 All'),
          Tab(text: '🟢 Active'),
          Tab(text: '📱 Contacts'),
          Tab(text: '🗺️ Map'),
        ],
      ),
    );
  }

  Widget _buildTabContent(String myUid) {
    return TabBarView(
      controller: _tabCtrl,
      children: [
        _AllUsersTab(myUid: myUid),
        _ActiveUsersTab(myUid: myUid),
        _ContactsTab(myUid: myUid),
        const _MapTab(),
      ],
    );
  }

  Widget _buildRealtimeResults(String myUid) {
    if (_query.length < 2) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.search_rounded, size: 56, color: Colors.grey[300]),
            const SizedBox(height: 12),
            Text('Type at least 2 characters',
                style: TextStyle(color: Colors.grey[400], fontSize: 14)),
          ],
        ),
      );
    }
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('users')
          .where('username', isGreaterThanOrEqualTo: _query.toLowerCase())
          .where('username',
              isLessThanOrEqualTo: '${_query.toLowerCase()}\uf8ff')
          .limit(30)
          .snapshots(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(
              child: CircularProgressIndicator(color: _blue));
        }
        final docs =
            snap.data?.docs.where((d) => d.id != myUid).toList() ?? [];
        if (docs.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.person_search_rounded,
                    size: 56, color: Colors.grey[300]),
                const SizedBox(height: 12),
                Text('No results for "$_query"',
                    style: TextStyle(color: Colors.grey[400])),
              ],
            ),
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 80),
          itemCount: docs.length,
          itemBuilder: (_, i) {
            final u = docs[i].data() as Map<String, dynamic>;
            return _UserSearchCard(uid: docs[i].id, userData: u, myUid: myUid);
          },
        );
      },
    );
  }

  Widget _buildPostResults(String myUid) {
    if (_query.length < 2) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.article_rounded, size: 56, color: Colors.grey[300]),
            const SizedBox(height: 12),
            Text('Type at least 2 characters',
                style: TextStyle(color: Colors.grey[400], fontSize: 14)),
          ],
        ),
      );
    }
    return _PostSearchResults(query: _query.toLowerCase().trim(), myUid: myUid);
  }

}

// ── Realtime Post Search Results ──────────────────────────────────────────────
class _PostSearchResults extends StatefulWidget {
  final String query, myUid;
  const _PostSearchResults({required this.query, required this.myUid});
  @override
  State<_PostSearchResults> createState() => _PostSearchResultsState();
}

class _PostSearchResultsState extends State<_PostSearchResults> {
  static const _blue = Color(0xFF0284C7);

  // Merge keyword-match + text-prefix results deduped
  Stream<List<QueryDocumentSnapshot>> _buildStream() {
    final fs = FirebaseFirestore.instance;
    final q = widget.query;

    // Stream 1: keyword array match (exact word)
    final s1 = fs.collection('posts')
        .where('searchKeywords', arrayContains: q)
        .where('visibility', isEqualTo: 'public')
        .orderBy('createdAt', descending: true)
        .limit(25)
        .snapshots()
        .map((s) => s.docs);

    // Stream 2: text prefix match
    final s2 = fs.collection('posts')
        .where('text', isGreaterThanOrEqualTo: q)
        .where('text', isLessThanOrEqualTo: '$q\uf8ff')
        .where('visibility', isEqualTo: 'public')
        .orderBy('text')
        .orderBy('createdAt', descending: true)
        .limit(15)
        .snapshots()
        .map((s) => s.docs);

    // Combine both streams — dedupe by postId
    return s1.asyncMap((docs1) async {
      try {
        final snap2 = await fs.collection('posts')
            .where('text', isGreaterThanOrEqualTo: q)
            .where('text', isLessThanOrEqualTo: '$q\uf8ff')
            .where('visibility', isEqualTo: 'public')
            .orderBy('text')
            .limit(15)
            .get();
        final seen = <String>{};
        final merged = <QueryDocumentSnapshot>[];
        for (final d in [...docs1, ...snap2.docs]) {
          if (seen.add(d.id)) merged.add(d);
        }
        return merged;
      } catch (_) {
        return docs1;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<QueryDocumentSnapshot>>(
      stream: _buildStream(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(color: _blue, strokeWidth: 2));
        }
        final docs = (snap.data ?? [])
            .where((d) => d.id != widget.myUid)
            .toList();
        if (docs.isEmpty) {
          return Center(
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.search_off_rounded, size: 56, color: Colors.grey[300]),
              const SizedBox(height: 12),
              Text('No posts for "${widget.query}"',
                  style: TextStyle(color: Colors.grey[400])),
              const SizedBox(height: 6),
              Text('Try a different keyword',
                  style: TextStyle(fontSize: 12, color: Colors.grey[350])),
            ]),
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 80),
          itemCount: docs.length,
          itemBuilder: (_, i) {
            final data = docs[i].data() as Map<String, dynamic>;
            return _PostSearchCard(postId: docs[i].id, post: data, myUid: widget.myUid);
          },
        );
      },
    );
  }
}

// ── Zylo Loader ───────────────────────────────────────────────────────────────
class ZyloLoader extends StatelessWidget {
  const ZyloLoader({super.key});
  @override
  Widget build(BuildContext context) =>
      const CircularProgressIndicator(color: Color(0xFF0284C7), strokeWidth: 2.5);
}

// ── Quick Action Card ────────────────────────────────────────────────────────
class _QuickActionCard extends StatelessWidget {
  final IconData icon;
  final String label, subtitle;
  final Color color, bgColor;
  final VoidCallback onTap;
  const _QuickActionCard(
      {required this.icon, required this.label, required this.subtitle,
       required this.color, required this.bgColor, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 8, offset: const Offset(0, 2))],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: bgColor, borderRadius: BorderRadius.circular(10)),
                child: Icon(icon, color: color, size: 18),
              ),
              const SizedBox(height: 8),
              Text(label, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 11, color: Color(0xFF0C1A2E))),
              Text(subtitle, style: TextStyle(fontSize: 9, color: Colors.grey[500])),
            ],
          ),
        ),
      ),
    );
  }
}

// ── User Search Card ─────────────────────────────────────────────────────────
class _UserSearchCard extends StatefulWidget {
  final String uid, myUid;
  final Map<String, dynamic> userData;
  const _UserSearchCard({required this.uid, required this.userData, required this.myUid});
  @override
  State<_UserSearchCard> createState() => _UserSearchCardState();
}

class _UserSearchCardState extends State<_UserSearchCard> {
  static const _blue = Color(0xFF0284C7);

  @override
  Widget build(BuildContext context) {
    final u = widget.userData;
    final name      = u['username']  ?? 'User';
    final photo     = u['photoURL']  ?? '';
    final isOnline  = u['isOnline']  == true;
    final isPro     = u['isPro']     == true || u['subscription'] == 'pro';
    final isPrivate = u['isPublic']  == false;
    final bio       = u['bio'] as String? ?? '';

    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(
          builder: (_) => ViewProfileScreen(targetUid: widget.uid))),
      onLongPress: () => _showBlockSheet(context),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 8, offset: const Offset(0, 2))],
        ),
        child: Row(
          children: [
            Stack(children: [
              ZyloAvatar(
                photoUrl: photo.isNotEmpty ? photo : null,
                radius: 28,
              ),
              if (isOnline) Positioned(bottom: 1, right: 1,
                child: Container(width: 12, height: 12,
                  decoration: BoxDecoration(color: const Color(0xFF10B981), shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 2)))),
            ]),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Flexible(child: Text(name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14, color: Color(0xFF0C1A2E)), overflow: TextOverflow.ellipsis)),
                  if (isPro) ...[const SizedBox(width: 5),
                    Container(padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                      decoration: BoxDecoration(color: Colors.amber.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(5)),
                      child: const Text('PRO', style: TextStyle(fontSize: 9, color: Colors.amber, fontWeight: FontWeight.w900)))],
                  if (isPrivate) ...[const SizedBox(width: 5),
                    const Icon(Icons.lock_outline, size: 11, color: Colors.grey)],
                ]),
                const SizedBox(height: 3),
                Text(
                  bio.isNotEmpty ? bio : (isOnline ? 'Active now' : 'Offline'),
                  style: TextStyle(fontSize: 11, color: bio.isNotEmpty ? Colors.grey[500] : (isOnline ? Colors.green[600] : Colors.grey[400])),
                  maxLines: 1, overflow: TextOverflow.ellipsis),
              ]),
            ),
            const SizedBox(width: 8),
            Icon(Icons.chevron_right_rounded, color: Colors.grey[400], size: 20),
          ],
        ),
      ),
    );
  }

  void _showBlockSheet(BuildContext context) async {
    final fs = FirestoreService();
    final isBlocked = await fs.isUserBlocked(widget.uid).first;
    final name = widget.userData['username'] ?? 'User';
    if (!mounted) return;
    showModalBottomSheet(
      context: context, backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(margin: const EdgeInsets.only(top: 10, bottom: 8), width: 40, height: 4,
          decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Text(name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        ),
        const Divider(),
        if (isBlocked)
          ListTile(
            leading: const Icon(Icons.lock_open_outlined, color: Colors.green),
            title: Text('Unblock $name', style: const TextStyle(color: Colors.green, fontWeight: FontWeight.w600)),
            onTap: () async {
              Navigator.pop(ctx);
              await fs.unblockUser(widget.uid);
              if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text('$name unblocked'), backgroundColor: Colors.green,
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
            },
          )
        else
          ListTile(
            leading: const Icon(Icons.block_outlined, color: Colors.red),
            title: Text('Block $name', style: const TextStyle(color: Colors.red, fontWeight: FontWeight.w600)),
            onTap: () async {
              Navigator.pop(ctx);
              final confirm = await showDialog<bool>(
                context: context,
                builder: (_) => AlertDialog(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  title: Text('Block $name?'),
                  content: Text('$name won\'t be able to message you.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                    TextButton(onPressed: () => Navigator.pop(context, true),
                      child: const Text('Block', style: TextStyle(color: Colors.red, fontWeight: FontWeight.w700))),
                  ],
                ),
              );
              if (confirm == true) {
                await fs.blockUser(widget.uid);
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text('$name blocked'), backgroundColor: Colors.red,
                  behavior: SnackBarBehavior.floating,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
              }
            },
          ),
        const SizedBox(height: 8),
      ])),
    );
  }
}


class _AllUsersTab extends StatelessWidget {
  final String myUid;
  const _AllUsersTab({required this.myUid});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('users')
          .orderBy('createdAt', descending: true).limit(50).snapshots(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(child: ZyloLoader());
        }
        final docs = snap.data?.docs.where((d) => d.id != myUid).toList() ?? [];
        if (docs.isEmpty) return const _EmptyState(icon: Icons.people_outline, label: 'No users yet');
        return ListView.builder(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 80),
          itemCount: docs.length,
          itemBuilder: (_, i) {
            final u = docs[i].data() as Map<String, dynamic>;
            return _UserSearchCard(uid: docs[i].id, userData: u, myUid: myUid);
          },
        );
      },
    );
  }
}

// ── Active Users Tab ──────────────────────────────────────────────────────────
class _ActiveUsersTab extends StatelessWidget {
  final String myUid;
  const _ActiveUsersTab({required this.myUid});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('users')
          .where('isOnline', isEqualTo: true).limit(50).snapshots(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(child: ZyloLoader());
        }
        final docs = snap.data?.docs.where((d) => d.id != myUid).toList() ?? [];
        if (docs.isEmpty) return const _EmptyState(icon: Icons.circle_outlined, label: 'No one is active right now');
        return Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Row(children: [
              Container(width: 8, height: 8, decoration: const BoxDecoration(color: Color(0xFF10B981), shape: BoxShape.circle)),
              const SizedBox(width: 6),
              Text('${docs.length} active now', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: Color(0xFF10B981))),
            ]),
          ),
          Expanded(child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 80),
            itemCount: docs.length,
            itemBuilder: (_, i) {
              final u = docs[i].data() as Map<String, dynamic>;
              return _UserSearchCard(uid: docs[i].id, userData: u, myUid: myUid);
            },
          )),
        ]);
      },
    );
  }
}

// ── Contacts Tab ──────────────────────────────────────────────────────────────
class _ContactsTab extends StatefulWidget {
  final String myUid;
  const _ContactsTab({required this.myUid});
  @override
  State<_ContactsTab> createState() => _ContactsTabState();
}

class _ContactsTabState extends State<_ContactsTab> {
  List<Contact> _contacts = [];
  bool _loading = false;
  bool _permDenied = false;
  static const _blue = Color(0xFF0284C7);

  Future<void> _load() async {
    setState(() => _loading = true);
    final status = await Permission.contacts.request();
    if (!status.isGranted) {
      setState(() { _permDenied = true; _loading = false; });
      return;
    }
    try {
      final c = await FlutterContacts.getContacts(withProperties: true);
      setState(() { _contacts = c; _loading = false; });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: ZyloLoader());
    if (_permDenied) {
      return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(Icons.contacts_outlined, size: 56, color: Colors.grey[300]),
        const SizedBox(height: 12),
        const Text('Contacts permission needed', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
        const SizedBox(height: 12),
        ElevatedButton(
          onPressed: () => openAppSettings(),
          style: ElevatedButton.styleFrom(backgroundColor: _blue, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
          child: const Text('Open Settings'),
        ),
      ]));
    }
    if (_contacts.isEmpty) {
      return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF0284C7), Color(0xFF6366F1)]),
            shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: _blue.withValues(alpha: 0.3), blurRadius: 20, offset: const Offset(0, 8))],
          ),
          child: const Icon(Icons.contacts_rounded, size: 48, color: Colors.white),
        ),
        const SizedBox(height: 20),
        const Text('Sync Contacts', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20, color: Color(0xFF0C1A2E))),
        const SizedBox(height: 8),
        Text('Find your contacts on Zylo', style: TextStyle(color: Colors.grey[500], fontSize: 13)),
        const SizedBox(height: 24),
        GestureDetector(
          onTap: _load,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF0284C7), Color(0xFF6366F1)]),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [BoxShadow(color: _blue.withValues(alpha: 0.4), blurRadius: 12, offset: const Offset(0, 4))],
            ),
            child: const Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.sync_rounded, color: Colors.white, size: 18),
              SizedBox(width: 8),
              Text('Sync Now', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
            ]),
          ),
        ),
      ]));
    }
    final colors = [const Color(0xFF0284C7), const Color(0xFF6366F1), const Color(0xFF10B981), const Color(0xFFF59E0B), const Color(0xFFEF4444)];
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 80),
      itemCount: _contacts.length,
      itemBuilder: (_, i) {
        final c = _contacts[i];
        final phone = c.phones.isNotEmpty ? c.phones.first.number : 'No number';
        final initials = c.displayName.isNotEmpty ? c.displayName[0].toUpperCase() : '?';
        final color = colors[i % colors.length];
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 6, offset: const Offset(0, 2))]),
          child: Row(children: [
            CircleAvatar(radius: 22, backgroundColor: color.withValues(alpha: 0.15),
                child: Text(initials, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 16))),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(c.displayName, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: Color(0xFF0C1A2E))),
              Text(phone, style: TextStyle(fontSize: 11, color: Colors.grey[500])),
            ])),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(color: color.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
              child: Text('Invite', style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w700)),
            ),
          ]),
        );
      },
    );
  }
}

// ── Map Tab ───────────────────────────────────────────────────────────────────
class _MapTab extends StatelessWidget {
  const _MapTab();

  @override
  Widget build(BuildContext context) {
    const center = LatLng(20.5937, 78.9629);
    return Stack(children: [
      FlutterMap(
        options: const MapOptions(initialCenter: center, initialZoom: 5),
        children: [
          TileLayer(
            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            userAgentPackageName: 'com.zylopages.app',
          ),
          MarkerLayer(markers: [
            _marker(const LatLng(19.0760, 72.8777), '🧑'),
            _marker(const LatLng(28.6139, 77.2090), '👩'),
            _marker(const LatLng(12.9716, 77.5946), '🧑‍💼'),
            _marker(const LatLng(22.5726, 88.3639), '👨'),
          ]),
        ],
      ),
      Positioned(
        bottom: 80, left: 16, right: 16,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.1), blurRadius: 16, offset: const Offset(0, 4))]),
          child: Row(children: [
            const Icon(Icons.location_on_rounded, color: Color(0xFF10B981), size: 20),
            const SizedBox(width: 8),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Nearby Friends', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: Color(0xFF0C1A2E))),
              Text('Share location to find friends nearby', style: TextStyle(fontSize: 10, color: Colors.grey)),
            ])),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(color: const Color(0xFF10B981), borderRadius: BorderRadius.circular(10)),
              child: const Text('Share Location', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 11)),
            ),
          ]),
        ),
      ),
    ]);
  }

  Marker _marker(LatLng point, String emoji) => Marker(
    point: point, width: 38, height: 38,
    child: Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle,
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.2), blurRadius: 4, offset: const Offset(0, 2))]),
      child: Text(emoji, style: const TextStyle(fontSize: 18)),
    ),
  );
}

// ── _EmptyState ───────────────────────────────────────────────────────────
class _EmptyState extends StatelessWidget {
  final IconData icon;
  final String label;
  const _EmptyState({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 56, color: Colors.grey[300]),
          const SizedBox(height: 16),
          Text(label,
            style: const TextStyle(color: Colors.grey, fontSize: 15, fontWeight: FontWeight.w500),
            textAlign: TextAlign.center),
        ]),
      ),
    );
  }
}

// ── _ContactsOnZyloSheet ──────────────────────────────────────────────────
class _ContactsOnZyloSheet extends StatefulWidget {
  final String myUid;
  final ScrollController scrollController;
  const _ContactsOnZyloSheet({required this.myUid, required this.scrollController});

  @override
  State<_ContactsOnZyloSheet> createState() => _ContactsOnZyloSheetState();
}

class _ContactsOnZyloSheetState extends State<_ContactsOnZyloSheet> {
  List<Map<String, dynamic>> _zyloContacts = [];
  bool _loading = true;
  String? _error;

  static const _blue = Color(0xFF0284C7);

  @override
  void initState() {
    super.initState();
    _loadContacts();
  }

  Future<void> _loadContacts() async {
    try {
      final granted = await FlutterContacts.requestPermission(readonly: true);
      if (!granted) {
        if (mounted) setState(() { _loading = false; _error = 'Contacts permission denied'; });
        return;
      }
      final phoneContacts = await FlutterContacts.getContacts(withProperties: true);
      final phones = phoneContacts
        .expand((c) => c.phones.map((p) => p.normalizedNumber.replaceAll(RegExp(r'\D'), '')))
        .where((p) => p.length >= 7)
        .toSet()
        .toList();

      if (phones.isEmpty) {
        if (mounted) setState(() { _loading = false; });
        return;
      }

      // Query Firestore in batches of 10
      final fs = FirebaseFirestore.instance;
      final List<Map<String, dynamic>> found = [];
      for (int i = 0; i < phones.length; i += 10) {
        final batch = phones.sublist(i, i + 10 > phones.length ? phones.length : i + 10);
        final snap = await fs.collection('users')
          .where('phone', whereIn: batch)
          .get();
        for (final doc in snap.docs) {
          if (doc.id != widget.myUid) {
            found.add({...doc.data(), 'uid': doc.id});
          }
        }
      }
      if (mounted) setState(() { _zyloContacts = found; _loading = false; });
    } catch (e) {
      if (mounted) setState(() { _loading = false; _error = e.toString(); });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      // Handle bar
      Container(
        margin: const EdgeInsets.symmetric(vertical: 12),
        width: 40, height: 4,
        decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2)),
      ),
      const Padding(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        child: Text('Contacts on zylo.pages',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Color(0xFF0C1A2E))),
      ),
      if (_loading)
        const Expanded(child: Center(child: CircularProgressIndicator(color: _blue)))
      else if (_error != null)
        Expanded(child: _EmptyState(icon: Icons.error_outline, label: _error!))
      else if (_zyloContacts.isEmpty)
        const Expanded(child: _EmptyState(icon: Icons.people_outline, label: 'None of your contacts are on zylo.pages yet'))
      else
        Expanded(
          child: ListView.separated(
            controller: widget.scrollController,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            itemCount: _zyloContacts.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (_, i) {
              final user = _zyloContacts[i];
              final name = user['username'] as String? ?? 'Unknown';
              final photo = (user['photoURL'] ?? user['photoUrl']) as String? ?? '';
              final uid = user['uid'] as String;
              return ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                leading: ZyloAvatar(
                  photoUrl: photo.isNotEmpty ? photo : null,
                  radius: 24,
                ),
                title: Text(name, style: const TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF0C1A2E))),
                trailing: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.push(context, MaterialPageRoute(
                      builder: (_) => ChatRoomScreen(targetId: uid, targetName: name)));
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _blue,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  ),
                  child: const Text('Message', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                ),
              );
            },
          ),
        ),
    ]);
  }
}

// ── Post Search Card ──────────────────────────────────────────────────────────
class _PostSearchCard extends StatelessWidget {
  final String postId, myUid;
  final Map<String, dynamic> post;
  const _PostSearchCard({required this.postId, required this.post, required this.myUid});

  static const _blue = Color(0xFF0284C7);

  @override
  Widget build(BuildContext context) {
    final text      = post['text']        as String? ?? '';
    final images    = (post['images'] as List?)?.cast<String>() ?? [];
    final authorId  = post['authorId']    as String? ?? '';
    final authorName= post['authorName']  as String? ?? 'user';
    final authorPhoto=post['authorPhoto'] as String? ?? '';
    final createdAt = post['createdAt']   as dynamic;
    final likes     = (post['likes'] as List?)?.length ?? 0;
    final comments  = post['commentCount'] as int? ?? 0;

    String timeAgo = '';
    try {
      final date = createdAt is int
          ? DateTime.fromMillisecondsSinceEpoch(createdAt)
          : (createdAt?.toDate() as DateTime?);
      if (date != null) {
        final diff = DateTime.now().difference(date);
        if (diff.inDays > 0) timeAgo = '${diff.inDays}d ago';
        else if (diff.inHours > 0) timeAgo = '${diff.inHours}h ago';
        else timeAgo = '${diff.inMinutes}m ago';
      }
    } catch (_) {}

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus(); // dismiss keyboard
        Navigator.push(context, MaterialPageRoute(
          builder: (_) => PostDeepLinkScreen(postId: postId)));
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.grey.withValues(alpha: 0.12)),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 10, offset: const Offset(0, 2))]),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // Author row
            Row(children: [
              GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => ViewProfileScreen(targetUid: authorId))),
                child: CircleAvatar(
                  radius: 18,
                  backgroundImage: authorPhoto.isNotEmpty
                    ? CachedNetworkImageProvider(authorPhoto) : null,
                  backgroundColor: const Color(0xFFEFF6FF),
                  child: authorPhoto.isEmpty
                    ? Text(authorName.isNotEmpty ? authorName[0].toUpperCase() : '?',
                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: _blue))
                    : null),
              ),
              const SizedBox(width: 8),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('@$authorName',
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: Color(0xFF0C1A2E))),
                if (timeAgo.isNotEmpty)
                  Text(timeAgo, style: TextStyle(fontSize: 11, color: Colors.grey[500])),
              ])),
              // Engagement pills
              Row(children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(color: Colors.red.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(8)),
                  child: Row(children: [
                    const Icon(Icons.favorite_rounded, color: Colors.red, size: 12),
                    const SizedBox(width: 3),
                    Text('$likes', style: const TextStyle(fontSize: 11, color: Colors.red, fontWeight: FontWeight.w700)),
                  ])),
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(color: _blue.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(8)),
                  child: Row(children: [
                    const Icon(Icons.chat_bubble_rounded, color: _blue, size: 12),
                    const SizedBox(width: 3),
                    Text('$comments', style: const TextStyle(fontSize: 11, color: _blue, fontWeight: FontWeight.w700)),
                  ])),
              ]),
            ]),
            if (text.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(text,
                maxLines: 3, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 13, color: Color(0xFF1A2A3A), height: 1.45)),
            ],
            if (images.isNotEmpty) ...[
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: ZyloCachedImage(
                  url: images[0],
                  height: 140, width: null,
                  fit: BoxFit.cover,
                  placeholder: (_, __) => Container(height: 140, color: Colors.grey[100]),
                  errorWidget: const SizedBox.shrink())),
            ],
          ]),
        ),
      ),
    );
  }
}
