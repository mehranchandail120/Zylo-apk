import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:receive_sharing_intent/receive_sharing_intent.dart';
import 'package:flutter_app_badger/flutter_app_badger.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import '../services/migration_service.dart';
import '../services/notification_service.dart';
import '../services/version_checker_service.dart';
import '../services/share_intent_service.dart';
import '../widgets/zylo_cached_image.dart';
import '../widgets/share_to_zylo_sheet.dart';
import 'chat/chat_list_screen.dart';
import 'chat/chat_room_screen.dart';
import 'profile/profile_screen.dart';
import 'search_screen.dart';
import 'feed/feed_screen.dart';
import 'feed/create_post_sheet.dart';

class HomeScreen extends StatefulWidget {
  final int initialTab;
  const HomeScreen({super.key, this.initialTab = 0});
  @override State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  late int _currentIndex = widget.initialTab;
  final FirestoreService _fs = FirestoreService();

  // ── Back-button exit ─────────────────────────────────────────────────────
  DateTime? _lastBackPress;

  // ── No-internet overlay ───────────────────────────────────────────────────
  bool _isOnline = true;
  Timer? _connectTimer;

  // ── App icon badge (unread count) ─────────────────────────────────────────
  StreamSubscription<int>? _badgeSub;
  int _lastBadgeCount = 0;

  // ── In-app message notification ──────────────────────────────────────────
  StreamSubscription? _msgSub;
  OverlayEntry? _notifOverlay;
  Timer? _notifTimer;
  String? _lastSeenMsgId;

  final List<Widget> _screens = const [
    ChatListScreen(),
    FeedScreen(),
    SearchScreen(),
    ProfileScreen(),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _fs.updateOnlineStatus(true));
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final auth = Provider.of<AuthService>(context, listen: false);
      // Run migration async — don't block UI
      MigrationService.runIfNeeded(auth.user?.uid ?? '').catchError((_) {});
      _initShareIntent();
      // Defer version check 8s after startup — not critical path
      Future.delayed(const Duration(seconds: 8), () {
        if (mounted) _checkForUpdate();
      });
    });
    _startConnectivityMonitor();
    WidgetsBinding.instance.addPostFrameCallback((_) => _initMsgListener());
    WidgetsBinding.instance.addPostFrameCallback((_) => _initBadgeListener());
  }

  void _initShareIntent() {
    final svc = ShareIntentService.instance;

    svc.onMediaShared = (files) {
      if (!mounted) return;
      final info = SharedMediaInfo(files: files);
      showShareToZyloSheet(context, info);
    };

    svc.onTextShared = (text) {
      if (!mounted) return;
      final info = SharedMediaInfo(text: text);
      showShareToZyloSheet(context, info);
    };
  }

  // ── App icon badge ────────────────────────────────────────────────────────
  void _initBadgeListener() {
    final auth = Provider.of<AuthService>(context, listen: false);
    if (auth.user == null) return;
    final ns = NotificationService();
    _badgeSub = ns.unreadCountStream().listen((count) {
      if (!mounted) return;
      if (count == _lastBadgeCount) return; // no change
      _lastBadgeCount = count;
      _updateBadge(count);
    });
  }

  void _updateBadge(int count) {
    try {
      if (count > 0) {
        FlutterAppBadger.updateBadgeCount(count);
      } else {
        FlutterAppBadger.removeBadge();
      }
    } catch (_) {}
  }

  void _startConnectivityMonitor() {
    _checkOnline();
    _connectTimer = Timer.periodic(const Duration(seconds: 15), (_) => _checkOnline());
  }

  Future<void> _checkOnline() async {
    bool online = false;
    try {
      // Real DNS lookup — works even if Firestore is slow/unavailable
      final result = await InternetAddress.lookup('google.com')
          .timeout(const Duration(seconds: 4));
      online = result.isNotEmpty && result.first.rawAddress.isNotEmpty;
    } on SocketException catch (_) {
      online = false;
    } on TimeoutException catch (_) {
      online = false;
    } catch (_) {
      online = false;
    }
    if (mounted && online != _isOnline) setState(() => _isOnline = online);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _connectTimer?.cancel();
    _msgSub?.cancel();
    _notifTimer?.cancel();
    _notifOverlay?.remove();
    _badgeSub?.cancel();
    try { FlutterAppBadger.removeBadge(); } catch (_) {}
    _fs.updateOnlineStatus(false);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    switch (state) {
      case AppLifecycleState.resumed: _fs.updateOnlineStatus(true); break;
      case AppLifecycleState.paused:
      case AppLifecycleState.inactive:
      case AppLifecycleState.detached: _fs.updateOnlineStatus(false); break;
      default: break;
    }
  }


  // ── In-app message notification listener ─────────────────────────────────
  void _initMsgListener() {
    final auth = Provider.of<AuthService>(context, listen: false);
    final myUid = auth.user?.uid ?? '';
    if (myUid.isEmpty) return;

    // ── Optimized: only listen to most recent chat doc change ──────────────
    // orderBy lastMsgTime + limit(1) = only 1 doc read per message
    _msgSub = FirebaseFirestore.instance
        .collection('chats')
        .where('members', arrayContains: myUid)
        .orderBy('lastMsgTime', descending: true)
        .limit(5) // only top 5 active chats
        .snapshots()
        .listen((snap) {
      if (snap.docs.isEmpty) return;
      if (_currentIndex == 0) return; // already on chats tab

      // Find most recent incoming message
      for (final doc in snap.docs) {
        final d = doc.data();
        final lastMsg = d['lastMessage'] as Map<String, dynamic>?;
        if (lastMsg == null) continue;
        final senderId = lastMsg['senderId'] as String? ?? '';
        if (senderId == myUid || senderId.isEmpty) continue;

        final ts = (lastMsg['timestamp'] as Timestamp?)?.toDate();
        if (ts == null) continue;
        // Only show if message is fresh (within 8 seconds)
        if (DateTime.now().difference(ts).inSeconds > 8) continue;

        final msgId = '${doc.id}_${ts.millisecondsSinceEpoch}';
        if (msgId == _lastSeenMsgId) continue;

        _lastSeenMsgId = msgId;
        _showMsgBanner(
          name:   lastMsg['senderName']   as String? ?? 'Someone',
          text:   lastMsg['text']         as String? ?? '📎 Attachment',
          avatar: lastMsg['senderAvatar'] as String?,
          senderId: senderId,
          chatId: doc.id,
          myUid:  myUid,
        );
        break; // show only 1 banner at a time
      }
    });
  }

  void _showMsgBanner({
    required String name, required String text, required String? avatar,
    required String senderId, required String chatId, required String myUid,
  }) {
    _notifOverlay?.remove();
    _notifOverlay = null;

    final overlay = Overlay.of(context);

    late OverlayEntry entry;
    entry = OverlayEntry(builder: (_) => _InAppMsgBanner(
      name:   name,
      text:   text,
      avatar: avatar,
      onTap: () {
        entry.remove();
        _notifTimer?.cancel();
        setState(() => _currentIndex = 0);
        // Push to chat room
        Future.microtask(() {
          if (mounted) {
            Navigator.push(context, MaterialPageRoute(
              builder: (_) => ChatRoomScreen(
                targetId:   senderId,
                targetName: name,
              )));
          }
        });
      },
      onDismiss: () {
        entry.remove();
        _notifTimer?.cancel();
      },
    ));

    overlay.insert(entry);
    _notifOverlay = entry;

    _notifTimer?.cancel();
    _notifTimer = Timer(const Duration(seconds: 5), () {
      if (entry.mounted) entry.remove();
      _notifOverlay = null;
    });
  }

  Future<void> _checkForUpdate() async {
    if (!mounted) return;
    await VersionCheckerService.check(
      context,
      currentVersion: '1.5.0', // ← update this on every release
      silent: true,
    );
  }

  Future<bool> _onWillPop() async {
    // If not on home tab, go to home tab first
    if (_currentIndex != 0) {
      setState(() => _currentIndex = 0);
      return false;
    }
    // Double-back to exit
    final now = DateTime.now();
    if (_lastBackPress == null || now.difference(_lastBackPress!) > const Duration(seconds: 2)) {
      _lastBackPress = now;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Press back once more to exit'),
        duration: Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
      ));
      return false;
    }
    // Show exit confirm dialog
    final exit = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Row(children: [
          Icon(Icons.exit_to_app_rounded, color: Color(0xFF0284C7), size: 22),
          SizedBox(width: 8),
          Text('Exit App?', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
        ]),
        content: const Text('Are you sure you want to close Zylo?',
          style: TextStyle(fontSize: 13, color: Colors.black54)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel', style: TextStyle(fontWeight: FontWeight.w700))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF0284C7),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Yes, Exit', style: TextStyle(fontWeight: FontWeight.w700))),
        ]));
    if (exit == true) SystemNavigator.pop();
    return false;
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthService>(context);
    final myUid = auth.user?.uid ?? '';

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (!didPop) await _onWillPop();
      },
      child: Stack(children: [
        Scaffold(
          body: IndexedStack(index: _currentIndex, children: _screens),
          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.07), blurRadius: 24, offset: const Offset(0, -4))]),
            child: SafeArea(child: SizedBox(height: 60, child: Row(children: [
              _NavItem(icon: Icons.chat_bubble_outline, activeIcon: Icons.chat_bubble,
                label: 'Chats', selected: _currentIndex == 0, onTap: () => setState(() => _currentIndex = 0)),
              _NavItem(icon: Icons.dashboard_outlined, activeIcon: Icons.dashboard_rounded,
                label: 'Feed', selected: _currentIndex == 1, onTap: () => setState(() => _currentIndex = 1)),
              // ── Centre + button ──────────────────────────────────────────
              Expanded(child: GestureDetector(
                onTap: () {
                  final auth = Provider.of<AuthService>(context, listen: false);
                  final myUid = auth.user?.uid ?? '';
                  showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    backgroundColor: Colors.transparent,
                    builder: (_) => FeedCreatePostSheet(myUid: myUid, auth: auth),
                  );
                },
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Container(
                    width: 48, height: 48,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF0284C7), Color(0xFF7C3AED)],
                        begin: Alignment.topLeft, end: Alignment.bottomRight),
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(
                        color: const Color(0xFF0284C7).withValues(alpha: 0.4),
                        blurRadius: 12, offset: const Offset(0, 4))]),
                    child: const Icon(Icons.add, color: Colors.white, size: 26)),
                ]),
              )),
              _SearchNavItem(selected: _currentIndex == 2, myUid: myUid, onTap: () => setState(() => _currentIndex = 2)),
              _ProfileNavItem(selected: _currentIndex == 3, auth: auth, onTap: () => setState(() => _currentIndex = 3)),
            ]))),
          ),
        ),
        // ── No Internet Overlay ──────────────────────────────────────────────
        if (!_isOnline)
          Positioned.fill(
            child: Material(
              color: Colors.white,
              child: SafeArea(
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Container(
                    width: 100, height: 100,
                    decoration: BoxDecoration(
                      color: Colors.blue.withValues(alpha: 0.08),
                      shape: BoxShape.circle),
                    child: const Icon(Icons.wifi_off_rounded, size: 52, color: Color(0xFF0284C7))),
                  const SizedBox(height: 24),
                  const Text('No Internet Connection 😕',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Colors.black87)),
                  const SizedBox(height: 10),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 48),
                    child: Text('Please check your WiFi or mobile data\nand try again.',
                      style: TextStyle(fontSize: 14, color: Colors.grey[500], height: 1.5),
                      textAlign: TextAlign.center)),
                  const SizedBox(height: 32),
                  GestureDetector(
                    onTap: () async {
                      setState(() => _isOnline = true); // optimistic
                      await _checkOnline();
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF0284C7), Color(0xFF7C3AED)]),
                        borderRadius: BorderRadius.circular(30),
                        boxShadow: [BoxShadow(
                          color: const Color(0xFF0284C7).withValues(alpha: 0.35),
                          blurRadius: 16, offset: const Offset(0, 6))]),
                      child: const Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.refresh_rounded, color: Colors.white, size: 20),
                        SizedBox(width: 10),
                        Text('Try Again',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
                      ]))),
                  const SizedBox(height: 20),
                  Text('Version 1.5.0',
                    style: TextStyle(fontSize: 11, color: Colors.grey[400])),
                ]),
              ),
            ),
          ),
      ]),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon, activeIcon; final String label; final bool selected; final VoidCallback onTap;
  const _NavItem({required this.icon, required this.activeIcon, required this.label, required this.selected, required this.onTap});
  @override
  Widget build(BuildContext context) => Expanded(child: GestureDetector(
    onTap: onTap, behavior: HitTestBehavior.opaque,
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      AnimatedSwitcher(duration: const Duration(milliseconds: 200),
        child: Icon(selected ? activeIcon : icon, key: ValueKey(selected),
          color: selected ? const Color(0xFF0284C7) : Colors.grey, size: 24)),
      const SizedBox(height: 2),
      Text(label, style: TextStyle(fontSize: 10,
        fontWeight: selected ? FontWeight.w800 : FontWeight.normal,
        color: selected ? const Color(0xFF0284C7) : Colors.grey)),
    ])));
}

class _SearchNavItem extends StatelessWidget {
  final bool selected; final String myUid; final VoidCallback onTap;
  const _SearchNavItem({required this.selected, required this.myUid, required this.onTap});
  @override
  Widget build(BuildContext context) => Expanded(child: GestureDetector(
    onTap: onTap, behavior: HitTestBehavior.opaque,
    child: Stack(alignment: Alignment.center, children: [
      Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(selected ? Icons.search : Icons.search_outlined,
          color: selected ? const Color(0xFF0284C7) : Colors.grey, size: 24),
        const SizedBox(height: 2),
        Text('Search', style: TextStyle(fontSize: 10,
          fontWeight: selected ? FontWeight.w800 : FontWeight.normal,
          color: selected ? const Color(0xFF0284C7) : Colors.grey)),
      ]),
      if (myUid.isNotEmpty)
        Positioned(top: 6, right: 12,
          child: StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance.collection('friendRequests')
                .where('toUid', isEqualTo: myUid).where('status', isEqualTo: 'pending').snapshots(),
            builder: (_, snap) {
              final count = snap.data?.docs.length ?? 0;
              if (count == 0) return const SizedBox.shrink();
              return Container(width: 16, height: 16,
                decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                child: Center(child: Text(count > 9 ? '9+' : '$count',
                  style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w900))));
            })),
    ])));
}

class _ProfileNavItem extends StatelessWidget {
  final bool selected; final AuthService auth; final VoidCallback onTap;
  const _ProfileNavItem({required this.selected, required this.auth, required this.onTap});
  @override
  Widget build(BuildContext context) => Expanded(child: GestureDetector(
    onTap: onTap, behavior: HitTestBehavior.opaque,
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Container(width: 28, height: 28,
        decoration: BoxDecoration(shape: BoxShape.circle,
          border: Border.all(color: selected ? const Color(0xFF0284C7) : Colors.transparent, width: 2.5)),
        child: ClipOval(child: auth.photoURL != null && auth.photoURL!.isNotEmpty
          ? ZyloCachedImage(url: auth.photoURL!, fit: BoxFit.cover,
              placeholder: (_, __) => Container(color: const Color(0xFF0284C7), child: const Icon(Icons.person, color: Colors.white, size: 16)),
              errorWidget: Container(color: const Color(0xFF0284C7), child: const Icon(Icons.person, color: Colors.white, size: 16)))
          : Container(color: selected ? const Color(0xFF0284C7) : Colors.grey, child: const Icon(Icons.person, color: Colors.white, size: 16)))),
      const SizedBox(height: 2),
      Text('Profile', style: TextStyle(fontSize: 10,
        fontWeight: selected ? FontWeight.w800 : FontWeight.normal,
        color: selected ? const Color(0xFF0284C7) : Colors.grey)),
    ])));
}

// ── In-App Message Banner ─────────────────────────────────────────────────────
class _InAppMsgBanner extends StatefulWidget {
  final String name, text;
  final String? avatar;
  final VoidCallback onTap, onDismiss;
  const _InAppMsgBanner({
    required this.name, required this.text, required this.avatar,
    required this.onTap, required this.onDismiss,
  });
  @override State<_InAppMsgBanner> createState() => _InAppMsgBannerState();
}

class _InAppMsgBannerState extends State<_InAppMsgBanner>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<Offset> _slide;
  late Animation<double> _fade;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 380));
    _slide = Tween<Offset>(begin: const Offset(0, -1.2), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _ctrl.forward();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  Future<void> _dismiss() async {
    await _ctrl.reverse();
    widget.onDismiss();
  }

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).padding.top + 8;
    return Positioned(
      top: top, left: 14, right: 14,
      child: SlideTransition(
        position: _slide,
        child: FadeTransition(
          opacity: _fade,
          child: GestureDetector(
            onTap: widget.onTap,
            onVerticalDragEnd: (d) { if (d.primaryVelocity != null && d.primaryVelocity! < 0) _dismiss(); },
            child: Material(
              color: Colors.transparent,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(color: Colors.black.withValues(alpha: 0.14), blurRadius: 24, offset: const Offset(0, 6)),
                    BoxShadow(color: const Color(0xFF0284C7).withValues(alpha: 0.08), blurRadius: 12),
                  ],
                  border: Border.all(color: Colors.white, width: 1)),
                child: Row(children: [
                  // Avatar
                  Container(
                    width: 44, height: 44,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                        colors: [Color(0xFF0284C7), Color(0xFF7C3AED)],
                        begin: Alignment.topLeft, end: Alignment.bottomRight),
                      border: Border.all(color: const Color(0xFF0284C7).withValues(alpha: 0.2), width: 2)),
                    child: ClipOval(
                      child: widget.avatar != null && widget.avatar!.isNotEmpty
                          ? Image.network(widget.avatar!, fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => _DefaultAvatar(name: widget.name))
                          : _DefaultAvatar(name: widget.name))),

                  const SizedBox(width: 12),

                  // Text
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      const Icon(Icons.chat_bubble_rounded, size: 11, color: Color(0xFF0284C7)),
                      const SizedBox(width: 4),
                      Expanded(child: Text(widget.name,
                        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800,
                          color: Color(0xFF0D1B2A)),
                        overflow: TextOverflow.ellipsis)),
                      Text('now', style: TextStyle(fontSize: 10, color: Colors.grey[400])),
                    ]),
                    const SizedBox(height: 3),
                    Text(widget.text,
                      style: TextStyle(fontSize: 12, color: Colors.grey[600], height: 1.3),
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  ])),

                  const SizedBox(width: 8),

                  // Dismiss X
                  GestureDetector(
                    onTap: _dismiss,
                    behavior: HitTestBehavior.opaque,
                    child: Container(
                      width: 28, height: 28,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF1F5F9), shape: BoxShape.circle),
                      child: const Icon(Icons.close_rounded, size: 14, color: Color(0xFF94A3B8)))),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _DefaultAvatar extends StatelessWidget {
  final String name;
  const _DefaultAvatar({required this.name});
  @override
  Widget build(BuildContext context) => Container(
    color: const Color(0xFF0284C7),
    child: Center(child: Text(
      name.isNotEmpty ? name[0].toUpperCase() : '?',
      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18))));
}
