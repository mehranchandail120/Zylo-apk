import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'package:share_plus/share_plus.dart';
import 'dart:async';

class VideoPlayerScreen extends StatefulWidget {
  final String url;
  final String title;
  final bool isLive;

  const VideoPlayerScreen({
    super.key,
    required this.url,
    required this.title,
    this.isLive = false,
  });

  @override
  State<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen>
    with WidgetsBindingObserver {
  late VideoPlayerController _controller;
  bool _isInitialized = false;
  bool _showControls = true;
  bool _isLandscape = false;
  bool _hasError = false;
  Timer? _hideTimer;
  double _volume = 1.0;
  bool _isMuted = false;
  bool _isBuffering = false;

  // Double-tap seek animation
  bool _showSeekLeft = false;
  bool _showSeekRight = false;

  static const _blue = Color(0xFF0284C7);
  static const _seekSeconds = 10;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    if (widget.isLive) {
      SystemChrome.setPreferredOrientations([
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
        DeviceOrientation.portraitUp,
      ]);
    }
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _initializePlayer();
    _startHideTimer();
  }

  // ── Background/tab switch: keep playing ──────────────────────────────────
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Do NOT pause on inactive/hidden — video keeps playing in background
    // Only stop if app is fully detached (killed)
    if (state == AppLifecycleState.detached) {
      _controller.pause();
    }
  }

  Future<void> _initializePlayer() async {
    try {
      final urlStr = widget.url.trim();
      if (urlStr.isEmpty) { if (mounted) setState(() => _hasError = true); return; }
      _controller = VideoPlayerController.networkUrl(
        Uri.parse(urlStr),
        httpHeaders: const {
          'Connection': 'keep-alive',
          'User-Agent': 'Zylo/1.0 (Android)',
          'Accept':     '*/*',
        },
        videoPlayerOptions: VideoPlayerOptions(
          mixWithOthers: false,
          allowBackgroundPlayback: false,
        ),
      );
      _controller.addListener(_onControllerUpdate);
      await _controller.initialize();
      if (!mounted) { _controller.dispose(); return; }
      setState(() => _isInitialized = true);
      await _controller.play();
    } catch (e) {
      debugPrint('[ZyloVideo] Screen error: $e | url: ${widget.url}');
      if (mounted) setState(() => _hasError = true);
    }
  }

  void _onControllerUpdate() {
    if (!mounted) return;
    final buffering = _controller.value.isBuffering;
    if (buffering != _isBuffering) setState(() => _isBuffering = buffering);
  }

  void _startHideTimer() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(seconds: 4), () {
      if (mounted) setState(() => _showControls = false);
    });
  }

  void _toggleControls() {
    setState(() => _showControls = !_showControls);
    if (_showControls) _startHideTimer();
  }

  // ── Double-tap seek ────────────────────────────────────────────────────────
  void _seekForward() {
    if (!_isInitialized) return;
    final pos = _controller.value.position;
    final dur = _controller.value.duration;
    final newPos = pos + const Duration(seconds: _seekSeconds);
    _controller.seekTo(newPos > dur ? dur : newPos);
    setState(() => _showSeekRight = true);
    Future.delayed(const Duration(milliseconds: 700), () {
      if (mounted) setState(() => _showSeekRight = false);
    });
    _startHideTimer();
  }

  void _seekBackward() {
    if (!_isInitialized) return;
    final pos = _controller.value.position;
    final newPos = pos - const Duration(seconds: _seekSeconds);
    _controller.seekTo(newPos < Duration.zero ? Duration.zero : newPos);
    setState(() => _showSeekLeft = true);
    Future.delayed(const Duration(milliseconds: 700), () {
      if (mounted) setState(() => _showSeekLeft = false);
    });
    _startHideTimer();
  }

  void _toggleLandscape() {
    setState(() => _isLandscape = !_isLandscape);
    if (_isLandscape) {
      SystemChrome.setPreferredOrientations([
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    } else {
      SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    }
  }

  void _shareChannel() {
    Share.share(
      'Watch "${widget.title}" live on Zylo!\n${widget.url}',
      subject: widget.title,
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _hideTimer?.cancel();
    _controller.removeListener(_onControllerUpdate);
    _controller.dispose();
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: OrientationBuilder(
        builder: (context, orientation) {
          final isLand = orientation == Orientation.landscape;
          return GestureDetector(
            onTap: _toggleControls,
            child: Stack(alignment: Alignment.center, children: [
              // ── Video ────────────────────────────────────────────────────
              if (_isInitialized)
                Center(
                  child: AspectRatio(
                    aspectRatio: isLand
                        ? (MediaQuery.of(context).size.width /
                            MediaQuery.of(context).size.height)
                        : _controller.value.aspectRatio,
                    child: VideoPlayer(_controller),
                  ),
                )
              else if (_hasError)
                _buildError()
              else
                const Center(child: CircularProgressIndicator(color: Colors.white)),

              // ── Buffering spinner ─────────────────────────────────────────
              if (_isBuffering && _isInitialized)
                const Center(
                    child: CircularProgressIndicator(
                        color: Colors.white70, strokeWidth: 2)),

              // ── Double-tap zones: left = back, right = forward ────────────
              Positioned.fill(
                child: Row(children: [
                  // Left zone — seek back
                  Expanded(
                    child: GestureDetector(
                      onDoubleTap: _seekBackward,
                      behavior: HitTestBehavior.translucent,
                      child: AnimatedOpacity(
                        opacity: _showSeekLeft ? 1 : 0,
                        duration: const Duration(milliseconds: 200),
                        child: Center(
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 18, vertical: 12),
                            decoration: BoxDecoration(
                              color: Colors.black45,
                              borderRadius: BorderRadius.circular(40),
                            ),
                            child: Row(mainAxisSize: MainAxisSize.min, children: [
                              const Icon(Icons.fast_rewind_rounded,
                                  color: Colors.white, size: 28),
                              const SizedBox(width: 4),
                              Text('${_seekSeconds}s',
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w700)),
                            ]),
                          ),
                        ),
                      ),
                    ),
                  ),
                  // Right zone — seek forward
                  Expanded(
                    child: GestureDetector(
                      onDoubleTap: _seekForward,
                      behavior: HitTestBehavior.translucent,
                      child: AnimatedOpacity(
                        opacity: _showSeekRight ? 1 : 0,
                        duration: const Duration(milliseconds: 200),
                        child: Center(
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 18, vertical: 12),
                            decoration: BoxDecoration(
                              color: Colors.black45,
                              borderRadius: BorderRadius.circular(40),
                            ),
                            child: Row(mainAxisSize: MainAxisSize.min, children: [
                              Text('${_seekSeconds}s',
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w700)),
                              const SizedBox(width: 4),
                              const Icon(Icons.fast_forward_rounded,
                                  color: Colors.white, size: 28),
                            ]),
                          ),
                        ),
                      ),
                    ),
                  ),
                ]),
              ),

              // ── Controls overlay ──────────────────────────────────────────
              if (_showControls) _buildControls(isLand),
            ]),
          );
        },
      ),
    );
  }

  Widget _buildError() {
    return Center(
      child:
          Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.signal_wifi_off_rounded,
            color: Colors.white54, size: 56),
        const SizedBox(height: 16),
        const Text('Stream unavailable',
            style: TextStyle(color: Colors.white70, fontSize: 16)),
        const SizedBox(height: 8),
        const Text(
            'This channel may be offline or\nthe stream URL has changed.',
            style: TextStyle(color: Colors.white38, fontSize: 12),
            textAlign: TextAlign.center),
        const SizedBox(height: 20),
        ElevatedButton.icon(
          style: ElevatedButton.styleFrom(backgroundColor: _blue),
          icon: const Icon(Icons.refresh_rounded, size: 16),
          label: const Text('Retry'),
          onPressed: () {
            setState(() {
              _hasError = false;
              _isInitialized = false;
            });
            _initializePlayer();
          },
        ),
      ]),
    );
  }

  Widget _buildControls(bool isLand) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Colors.black54,
            Colors.transparent,
            Colors.transparent,
            Colors.black54
          ],
          stops: [0, 0.3, 0.7, 1],
        ),
      ),
      child:
          Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        // ── Top bar ───────────────────────────────────────────────────────
        SafeArea(
          bottom: false,
          child: Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            child: Row(children: [
              IconButton(
                icon: const Icon(Icons.arrow_back_ios_new_rounded,
                    color: Colors.white, size: 20),
                onPressed: () => Navigator.pop(context),
              ),
              Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(widget.title,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold),
                          overflow: TextOverflow.ellipsis),
                      if (widget.isLive)
                        Row(children: [
                          Container(
                              width: 6,
                              height: 6,
                              decoration: const BoxDecoration(
                                  color: Colors.red,
                                  shape: BoxShape.circle)),
                          const SizedBox(width: 4),
                          const Text('LIVE',
                              style: TextStyle(
                                  color: Colors.red,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w900)),
                        ]),
                    ]),
              ),
              IconButton(
                icon: const Icon(Icons.share_rounded, color: Colors.white),
                onPressed: _shareChannel,
              ),
            ]),
          ),
        ),

        // ── Center play/pause ──────────────────────────────────────────────
        GestureDetector(
          onTap: () {
            setState(() {
              _controller.value.isPlaying
                  ? _controller.pause()
                  : _controller.play();
            });
            _startHideTimer();
          },
          child: Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: Colors.black38,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white38, width: 1.5),
            ),
            child: Icon(
              _isBuffering
                  ? Icons.hourglass_empty_rounded
                  : (_controller.value.isPlaying
                      ? Icons.pause_rounded
                      : Icons.play_arrow_rounded),
              color: Colors.white,
              size: 36,
            ),
          ),
        ),

        // ── Bottom bar ────────────────────────────────────────────────────
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 0, 8, 4),
            child:
                Column(mainAxisSize: MainAxisSize.min, children: [
              if (!widget.isLive)
                VideoProgressIndicator(
                  _controller,
                  allowScrubbing: true,
                  colors: const VideoProgressColors(
                      playedColor: _blue,
                      bufferedColor: Colors.white24,
                      backgroundColor: Colors.white12),
                ),
              Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(children: [
                      IconButton(
                        icon: Icon(
                            _isMuted
                                ? Icons.volume_off_rounded
                                : Icons.volume_up_rounded,
                            color: Colors.white,
                            size: 20),
                        onPressed: () {
                          setState(() {
                            _isMuted = !_isMuted;
                            _controller
                                .setVolume(_isMuted ? 0 : _volume);
                          });
                        },
                      ),
                      SizedBox(
                        width: 80,
                        child: SliderTheme(
                          data: SliderTheme.of(context).copyWith(
                            thumbShape: const RoundSliderThumbShape(
                                enabledThumbRadius: 6),
                            overlayShape:
                                const RoundSliderOverlayShape(
                                    overlayRadius: 12),
                            trackHeight: 2,
                          ),
                          child: Slider(
                            value: _isMuted ? 0 : _volume,
                            activeColor: Colors.white,
                            inactiveColor: Colors.white24,
                            onChanged: (v) {
                              setState(() {
                                _volume = v;
                                _isMuted = v == 0;
                                _controller.setVolume(v);
                              });
                            },
                          ),
                        ),
                      ),
                    ]),
                    Row(children: [
                      if (widget.isLive)
                        Container(
                          margin: const EdgeInsets.only(right: 8),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: Colors.red.withValues(alpha: 0.2),
                            borderRadius: BorderRadius.circular(4),
                            border: Border.all(
                                color: Colors.red.withValues(alpha: 0.5)),
                          ),
                          child: const Text('● LIVE',
                              style: TextStyle(
                                  color: Colors.red,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w900)),
                        ),
                      // ── Fullscreen button ─── only rotates, does NOT pop ──
                      IconButton(
                        icon: Icon(
                          _isLandscape
                              ? Icons.fullscreen_exit_rounded
                              : Icons.fullscreen_rounded,
                          color: Colors.white,
                          size: 24,
                        ),
                        onPressed: _toggleLandscape,
                      ),
                    ]),
                  ]),
            ]),
          ),
        ),
      ]),
    );
  }
}
