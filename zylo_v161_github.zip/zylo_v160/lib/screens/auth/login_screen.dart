import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../services/auth_service.dart';
import '../home_screen.dart';
import 'register_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> with SingleTickerProviderStateMixin {
  final _emailCtrl = TextEditingController();
  final _passCtrl  = TextEditingController();

  bool _isLoading       = false;
  bool _isGoogleLoading = false;
  bool _obscurePass     = true;
  bool _saveInfo        = false;
  bool _hasSaved        = false;
  String? _error;

  late final AnimationController _animCtrl;
  late final Animation<double> _fadeIn;
  late final Animation<Offset> _slideUp;

  static const _blue   = Color(0xFF0284C7);
  static const _darkBg = Color(0xFF0C1A2E);
  static const _kEmail = 'saved_email';
  static const _kPass  = 'saved_pass';
  static const _kSave  = 'save_creds';

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeIn   = CurvedAnimation(parent: _animCtrl, curve: Curves.easeOut);
    _slideUp  = Tween(begin: const Offset(0, 0.08), end: Offset.zero)
        .chain(CurveTween(curve: Curves.easeOutCubic)).animate(_animCtrl);
    _animCtrl.forward();
    _loadSaved();
  }

  Future<void> _loadSaved() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getBool(_kSave) ?? false;
    if (saved) {
      final email = prefs.getString(_kEmail) ?? '';
      final pass  = prefs.getString(_kPass)  ?? '';
      if (email.isNotEmpty && pass.isNotEmpty) {
        setState(() {
          _emailCtrl.text = email;
          _passCtrl.text  = pass;
          _saveInfo = true;
          _hasSaved = true;
        });
      }
    }
  }

  Future<void> _saveCreds(String email, String pass) async {
    final prefs = await SharedPreferences.getInstance();
    if (_saveInfo) {
      await prefs.setString(_kEmail, email);
      await prefs.setString(_kPass, pass);
      await prefs.setBool(_kSave, true);
    } else {
      await prefs.remove(_kEmail);
      await prefs.remove(_kPass);
      await prefs.setBool(_kSave, false);
    }
  }

  Future<void> _login() async {
    final email = _emailCtrl.text.trim();
    final pass  = _passCtrl.text;
    if (email.isEmpty || pass.isEmpty) {
      setState(() => _error = 'Please enter email and password');
      return;
    }
    setState(() { _isLoading = true; _error = null; });
    final auth   = Provider.of<AuthService>(context, listen: false);
    final result = await auth.login(email, pass);
    if (!mounted) return;
    if (result != null) {
      setState(() { _error = result; _isLoading = false; });
    } else {
      await _saveCreds(email, pass);
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeScreen()));
    }
  }

  Future<void> _googleSignIn() async {
    setState(() { _isGoogleLoading = true; _error = null; });
    final auth   = Provider.of<AuthService>(context, listen: false);
    try {
      final result = await auth.signInWithGoogle();
      if (!mounted) return;
      setState(() => _isGoogleLoading = false);
      if (result == null) {
        setState(() => _error = 'Google sign-in was cancelled or failed. Please try again.');
        return;
      }
      if (result['isNewUser'] == true) {
        Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => RegisterScreen(googleUser: result['googleUser'])));
      } else {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeScreen()));
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isGoogleLoading = false;
        _error = 'Google sign-in failed: ${e.toString().replaceAll('Exception: ', '')}';
      });
    }
  }

  Future<void> _showForgotPassword() async {
    final resetEmailCtrl = TextEditingController(text: _emailCtrl.text.trim());
    String? msg;
    bool sent = false;
    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Reset Password',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: _darkBg)),
          content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Enter your email and we\'ll send a reset link.',
              style: TextStyle(fontSize: 13, color: Colors.grey)),
            const SizedBox(height: 16),
            TextField(
              controller: resetEmailCtrl,
              keyboardType: TextInputType.emailAddress,
              decoration: InputDecoration(
                hintText: 'Email address',
                prefixIcon: const Icon(Icons.email_outlined, color: _blue),
                filled: true, fillColor: const Color(0xFFF1F5F9),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: _blue, width: 1.5))),
            ),
            if (msg != null) ...[
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: sent ? Colors.green[50] : Colors.red[50],
                  borderRadius: BorderRadius.circular(10)),
                child: Row(children: [
                  Icon(sent ? Icons.check_circle_outline : Icons.error_outline,
                    color: sent ? Colors.green : Colors.red, size: 16),
                  const SizedBox(width: 8),
                  Expanded(child: Text(msg!, style: TextStyle(fontSize: 12,
                    color: sent ? Colors.green[700] : Colors.red))),
                ]),
              ),
            ],
          ]),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel', style: TextStyle(color: Colors.grey))),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: _blue, foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)), elevation: 0),
              onPressed: sent ? null : () async {
                final email = resetEmailCtrl.text.trim();
                if (email.isEmpty || !email.contains('@')) {
                  setS(() { msg = 'Please enter a valid email.'; sent = false; });
                  return;
                }
                final auth   = Provider.of<AuthService>(ctx, listen: false);
                final result = await auth.sendPasswordResetEmail(email);
                setS(() {
                  msg  = result == null ? 'Reset link sent! Check your inbox.' : result;
                  sent = result == null;
                });
              },
              child: const Text('Send Link', style: TextStyle(fontWeight: FontWeight.w700))),
          ],
        ),
      ),
    );
    resetEmailCtrl.dispose();
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    _emailCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colors.white,
      // ── No keyboard-resize so layout stays fixed ──────────────────────────
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeIn,
          child: SlideTransition(
            position: _slideUp,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 28),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // ── Top branding ─────────────────────────────────────────
                  SizedBox(height: size.height * 0.06),
                  Center(
                    child: Column(children: [
                      Image.asset('assets/images/zylo_logo.png',
                        width: 80, height: 80, fit: BoxFit.contain),
                      const SizedBox(height: 10),
                      const Text('zylo.pages',
                        style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900,
                          color: _blue, letterSpacing: -0.5)),
                      const SizedBox(height: 2),
                      const Text('CONNECT • EXPLORE SECURELY',
                        style: TextStyle(fontSize: 8, fontWeight: FontWeight.bold,
                          color: Colors.grey, letterSpacing: 2.5)),
                    ]),
                  ),

                  SizedBox(height: size.height * 0.05),

                  // ── Heading ───────────────────────────────────────────────
                  const Text('Welcome back',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: _darkBg)),
                  const SizedBox(height: 2),
                  const Text('Sign in to continue',
                    style: TextStyle(fontSize: 13, color: Colors.grey)),

                  const SizedBox(height: 22),

                  // ── Email field ───────────────────────────────────────────
                  _buildField(ctrl: _emailCtrl, hint: 'Email address',
                    icon: Icons.email_outlined, keyboard: TextInputType.emailAddress),
                  const SizedBox(height: 12),

                  // ── Password field ────────────────────────────────────────
                  TextField(
                    controller: _passCtrl,
                    obscureText: _obscurePass,
                    onSubmitted: (_) => _login(),
                    decoration: _fieldDecoration(
                      hint: 'Password',
                      prefix: Icons.lock_outline,
                      suffix: IconButton(
                        icon: Icon(_obscurePass
                          ? Icons.visibility_off_outlined
                          : Icons.visibility_outlined,
                          color: Colors.grey, size: 20),
                        onPressed: () => setState(() => _obscurePass = !_obscurePass))),
                  ),

                  const SizedBox(height: 12),

                  // ── Save info + Forgot row ────────────────────────────────
                  Row(children: [
                    GestureDetector(
                      onTap: () => setState(() => _saveInfo = !_saveInfo),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          width: 20, height: 20,
                          decoration: BoxDecoration(
                            color: _saveInfo ? _blue : Colors.transparent,
                            borderRadius: BorderRadius.circular(5),
                            border: Border.all(color: _saveInfo ? _blue : Colors.grey[400]!, width: 2)),
                          child: _saveInfo
                            ? const Icon(Icons.check, color: Colors.white, size: 13)
                            : const SizedBox.shrink()),
                        const SizedBox(width: 8),
                        const Text('Save login info',
                          style: TextStyle(fontSize: 12, color: Colors.black87, fontWeight: FontWeight.w500)),
                      ]),
                    ),
                    const Spacer(),
                    GestureDetector(
                      onTap: _showForgotPassword,
                      child: const Text('Forgot Password?',
                        style: TextStyle(fontSize: 12, color: _blue, fontWeight: FontWeight.w600))),
                  ]),

                  // ── Saved info hint ───────────────────────────────────────
                  if (_hasSaved) ...[
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                      decoration: BoxDecoration(
                        color: const Color(0xFFEFF6FF),
                        borderRadius: BorderRadius.circular(10)),
                      child: const Row(children: [
                        Icon(Icons.info_outline, color: _blue, size: 14),
                        SizedBox(width: 8),
                        Text('Saved info loaded — tap Login',
                          style: TextStyle(fontSize: 11, color: _blue, fontWeight: FontWeight.w600)),
                      ]),
                    ),
                  ],

                  // ── Error banner ──────────────────────────────────────────
                  if (_error != null) ...[
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.red[50], borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.red[200]!)),
                      child: Row(children: [
                        const Icon(Icons.error_outline, color: Colors.red, size: 16),
                        const SizedBox(width: 8),
                        Expanded(child: Text(_error!,
                          style: const TextStyle(color: Colors.red, fontSize: 12))),
                      ]),
                    ),
                  ],

                  const Spacer(),

                  // ── Login button ──────────────────────────────────────────
                  SizedBox(
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _isLoading ? null : _login,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _blue, foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        elevation: 0),
                      child: _isLoading
                        ? const SizedBox(width: 20, height: 20,
                            child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                        : const Text('Login',
                            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // ── Divider ───────────────────────────────────────────────
                  Row(children: [
                    Expanded(child: Divider(color: Colors.grey[200], thickness: 1.5)),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Text('OR',
                        style: TextStyle(color: Colors.grey[400], fontSize: 11, fontWeight: FontWeight.w600))),
                    Expanded(child: Divider(color: Colors.grey[200], thickness: 1.5)),
                  ]),

                  const SizedBox(height: 16),

                  // ── Google button ─────────────────────────────────────────
                  SizedBox(
                    height: 50,
                    child: _isGoogleLoading
                      ? Container(
                          decoration: BoxDecoration(
                            color: const Color(0xFFF1F5F9),
                            borderRadius: BorderRadius.circular(14)),
                          child: const Center(child: SizedBox(width: 20, height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2))))
                      : GestureDetector(
                          onTap: _googleSignIn,
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: Colors.grey[200]!, width: 1.5),
                              color: Colors.white,
                              boxShadow: [BoxShadow(
                                color: Colors.black.withValues(alpha: 0.04),
                                blurRadius: 8, offset: const Offset(0, 2))]),
                            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                              _GoogleColorG(size: 20),
                              const SizedBox(width: 10),
                              const Text('Continue with Google',
                                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600,
                                  color: Color(0xFF3C4043))),
                            ]),
                          ),
                        ),
                  ),

                  const SizedBox(height: 20),

                  // ── Sign up row ───────────────────────────────────────────
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    const Text("Don't have an account? ",
                      style: TextStyle(color: Colors.grey, fontSize: 13)),
                    GestureDetector(
                      onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const RegisterScreen())),
                      child: const Text('Create one',
                        style: TextStyle(color: _blue, fontWeight: FontWeight.w700, fontSize: 13))),
                  ]),

                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  InputDecoration _fieldDecoration({
    required String hint,
    required IconData prefix,
    Widget? suffix,
  }) {
    return InputDecoration(
      hintText: hint,
      prefixIcon: Icon(prefix, color: _blue),
      suffixIcon: suffix,
      filled: true,
      fillColor: const Color(0xFFF1F5F9),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: _blue, width: 1.5)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    );
  }

  Widget _buildField({
    required TextEditingController ctrl,
    required String hint,
    required IconData icon,
    TextInputType keyboard = TextInputType.text,
  }) {
    return TextField(
      controller: ctrl,
      keyboardType: keyboard,
      decoration: _fieldDecoration(hint: hint, prefix: icon),
    );
  }
}

// ── Google color "G" icon ──────────────────────────────────────────────────────
class _GoogleColorG extends StatelessWidget {
  final double size;
  const _GoogleColorG({required this.size});
  @override
  Widget build(BuildContext context) =>
      SizedBox(width: size, height: size, child: CustomPaint(painter: _GoogleGPainter()));
}

class _GoogleGPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w  = size.width;
    final h  = size.height;
    final rect = Rect.fromLTWH(w * 0.04, h * 0.04, w * 0.92, h * 0.92);
    final sw = w * 0.2;
    void arc(double start, double sweep, Color color) {
      canvas.drawArc(rect, start * 3.14159 / 180, sweep * 3.14159 / 180, false,
        Paint()..color = color..style = PaintingStyle.stroke
          ..strokeWidth = sw..strokeCap = StrokeCap.butt);
    }
    arc(-90,  140, const Color(0xFF4285F4));
    arc(-230, 130, const Color(0xFFEA4335));
    arc(50,    75, const Color(0xFFFBBC05));
    arc(125,   55, const Color(0xFF34A853));
    final white = Paint()..color = Colors.white;
    canvas.drawRect(Rect.fromLTWH(w * 0.48, h * 0.38, w * 0.56, h * 0.24), white);
    canvas.drawOval(Rect.fromLTWH(w * 0.22, h * 0.22, w * 0.56, h * 0.56), white);
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}
