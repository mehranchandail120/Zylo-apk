import 'dart:io';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import '../../services/auth_service.dart';
import '../../services/file_service.dart';
import '../../services/firestore_service.dart';
import '../home_screen.dart';
import '../zylo_guide_screen.dart';

enum _Step { username, gender, photo, bio, email, phone, privacy, done }

class RegisterScreen extends StatefulWidget {
  final User? googleUser;
  const RegisterScreen({super.key, this.googleUser});
  bool get isGoogleFlow => googleUser != null;

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  late _Step _step;
  final _usernameCtrl = TextEditingController();
  final _emailCtrl    = TextEditingController();
  final _passCtrl     = TextEditingController();
  final _confirmPassCtrl = TextEditingController();
  final _phoneCtrl    = TextEditingController();
  final _bioCtrl      = TextEditingController();
  String _gender = 'boy';
  File?  _pickedPhoto;
  String? _uploadedPhotoUrl;
  bool _isLoading = false;
  bool _isPublic = true;
  bool _isUploading = false;
  String? _error;
  // Username availability check
  Timer? _usernameDebounce;
  bool? _usernameAvailable;   // null=unchecked, true=free, false=taken
  bool _checkingUsername = false;

  static const _blue = Color(0xFF0284C7);

  @override
  void initState() {
    super.initState();
    _step = _Step.username;
    _usernameCtrl.addListener(_onUsernameChanged);
    if (widget.isGoogleFlow) {
      _emailCtrl.text = widget.googleUser?.email ?? '';
      _uploadedPhotoUrl = widget.googleUser?.photoURL;
    }
  }

  @override
  void dispose() {
    _usernameDebounce?.cancel();
    _usernameCtrl.dispose();
    _emailCtrl.dispose();
    _passCtrl.dispose();
    _confirmPassCtrl.dispose();
    _phoneCtrl.dispose();
    _bioCtrl.dispose();
    super.dispose();
  }

  // Steps: username → gender → photo → bio → [email if normal] → phone → done
  _Step _nextStep(_Step cur) {
    switch (cur) {
      case _Step.username: return _Step.gender;
      case _Step.gender:   return _Step.photo;
      case _Step.photo:    return _Step.bio;
      case _Step.bio:      return widget.isGoogleFlow ? _Step.phone : _Step.email;
      case _Step.email:    return _Step.phone;
      case _Step.phone:    return _Step.privacy;
      case _Step.privacy:  return _Step.done;
      default:             return _Step.done;
    }
  }

  _Step _prevStep(_Step cur) {
    switch (cur) {
      case _Step.gender:   return _Step.username;
      case _Step.photo:    return _Step.gender;
      case _Step.bio:      return _Step.photo;
      case _Step.email:    return _Step.bio;
      case _Step.phone:    return widget.isGoogleFlow ? _Step.bio : _Step.email;
      case _Step.privacy:  return _Step.phone;
      default:             return _Step.username;
    }
  }

  int get _totalSteps => widget.isGoogleFlow ? 6 : 7;

  int get _stepIndex {
    switch (_step) {
      case _Step.username: return 0;
      case _Step.gender:   return 1;
      case _Step.photo:    return 2;
      case _Step.bio:      return 3;
      case _Step.email:    return widget.isGoogleFlow ? 99 : 4;
      case _Step.phone:    return widget.isGoogleFlow ? 4 : 5;
      case _Step.privacy:  return widget.isGoogleFlow ? 5 : 6;
      default:             return 0;
    }
  }

  void _onUsernameChanged() {
    final u = _usernameCtrl.text.trim();
    if (u.length < 3) {
      setState(() { _usernameAvailable = null; _checkingUsername = false; });
      _usernameDebounce?.cancel();
      return;
    }
    setState(() { _checkingUsername = true; _usernameAvailable = null; });
    _usernameDebounce?.cancel();
    _usernameDebounce = Timer(const Duration(milliseconds: 500), () async {
      try {
        final taken = await FirestoreService().isUsernameTaken(u);
        if (mounted && _usernameCtrl.text.trim() == u) {
          setState(() { _usernameAvailable = !taken; _checkingUsername = false; });
        }
      } catch (_) {
        if (mounted) setState(() { _checkingUsername = false; _usernameAvailable = null; });
      }
    });
  }

  void _next() async {
    setState(() => _error = null);

    if (_step == _Step.username) {
      final u = _usernameCtrl.text.trim();
      if (u.length < 3) {
        setState(() => _error = 'Username must be at least 3 characters');
        return;
      }
      setState(() => _isLoading = true);
      try {
        final taken = await FirestoreService().isUsernameTaken(u);
        if (taken) {
          setState(() { _error = 'Username already taken. Try another.'; _isLoading = false; });
          return;
        }
      } catch (_) {}
      setState(() { _isLoading = false; _step = _nextStep(_step); });
    } else if (_step == _Step.gender) {
      setState(() => _step = _nextStep(_step));
    } else if (_step == _Step.photo) {
      // photo upload optional – skip is fine
      setState(() => _step = _nextStep(_step));
    } else if (_step == _Step.bio) {
      setState(() => _step = _nextStep(_step));
    } else if (_step == _Step.email) {
      final e = _emailCtrl.text.trim();
      final p = _passCtrl.text;
      final cp = _confirmPassCtrl.text;
      if (!e.contains('@') || !e.contains('.')) {
        setState(() => _error = 'Enter a valid email address');
        return;
      }
      if (p.length < 8) {
        setState(() => _error = 'Password must be at least 8 characters');
        return;
      }
      if (!p.contains(RegExp(r'[A-Z]'))) {
        setState(() => _error = 'Password must contain at least one uppercase letter');
        return;
      }
      if (!p.contains(RegExp(r'[0-9]'))) {
        setState(() => _error = 'Password must contain at least one number');
        return;
      }
      if (p != cp) {
        setState(() => _error = 'Passwords do not match');
        return;
      }
      setState(() => _step = _nextStep(_step));
    } else if (_step == _Step.phone) {
      setState(() => _step = _nextStep(_step));
    } else if (_step == _Step.privacy) {
      await _register();
    }
  }

  Future<void> _pickPhoto() async {
    final picker = ImagePicker();
    final xfile = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (xfile == null) return;
    setState(() { _pickedPhoto = File(xfile.path); _isUploading = true; });
    // Note: During registration, we don't have a userId yet if it's a new user.
    // However, Supabase might require a path. We can use 'temp' or 'registration'.
    // If it's Google flow, we might have a UID.
    final userId = widget.googleUser?.uid ?? 'new_user';
    try {
      final url = await FileService.uploadFile(_pickedPhoto!, userId);
      setState(() { _uploadedPhotoUrl = url; _isUploading = false; });
    } catch (e) {
      setState(() { _isUploading = false; _error = 'Upload failed: $e'; });
    }
  }

  Future<void> _register() async {
    setState(() { _isLoading = true; _error = null; });
    final auth = Provider.of<AuthService>(context, listen: false);
    try {
      String? result;
      final bio = _bioCtrl.text.trim();
      if (widget.isGoogleFlow) {
        result = await auth.saveGoogleUserProfile(
          _usernameCtrl.text.trim(), _gender, _phoneCtrl.text.trim(),
          photoURL: _uploadedPhotoUrl, bio: bio, isPublic: _isPublic,
        );
      } else {
        result = await auth.register(
          _usernameCtrl.text.trim(), _emailCtrl.text.trim(), _passCtrl.text,
          _gender, _phoneCtrl.text.trim(),
          photoURL: _uploadedPhotoUrl, bio: bio, isPublic: _isPublic,
        );
      }
      if (result != null) {
        setState(() { _isLoading = false; _error = result; });
      } else {
        if (mounted) {
          Navigator.pushAndRemoveUntil(
            context, MaterialPageRoute(builder: (_) => const ZyloGuideScreen(isNewUser: true)), (r) => false);
        }
      }
    } catch (e) {
      setState(() { _isLoading = false; _error = e.toString(); });
    }
  }

  Widget _wrapper({required String title, required String subtitle, required Widget child}) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: Color(0xFF0C1A2E))),
      const SizedBox(height: 6),
      Text(subtitle, style: const TextStyle(fontSize: 13, color: Colors.grey)),
      const SizedBox(height: 28),
      child,
    ]);
  }

  Widget _textField({
    required TextEditingController ctrl, required String hint, required IconData icon,
    bool obscure = false, bool readOnly = false, TextInputType keyboardType = TextInputType.text,
    int maxLines = 1, Widget? suffixWidget,
  }) {
    return TextField(
      controller: ctrl, obscureText: obscure, readOnly: readOnly,
      keyboardType: keyboardType, maxLines: maxLines,
      decoration: InputDecoration(
        hintText: hint,
        prefixIcon: Icon(icon, color: readOnly ? Colors.grey : _blue),
        suffixIcon: suffixWidget,
        filled: true,
        fillColor: readOnly ? const Color(0xFFE8F0FE) : const Color(0xFFF1F5F9),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: _blue, width: 1.5),
        ),
      ),
    );
  }

  Widget _stepUsername() {
    // Availability indicator suffix
    Widget? suffix;
    if (_checkingUsername) {
      suffix = const Padding(
        padding: EdgeInsets.all(12),
        child: SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
      );
    } else if (_usernameAvailable == true) {
      suffix = const Icon(Icons.check_circle_rounded, color: Color(0xFF10B981), size: 20);
    } else if (_usernameAvailable == false) {
      suffix = const Icon(Icons.cancel_rounded, color: Colors.red, size: 20);
    }

    return _wrapper(
      title: "Choose a Username",
      subtitle: "This is how others will find you on Zylo.",
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _textField(ctrl: _usernameCtrl, hint: "Username (e.g. john_doe)", icon: Icons.person_outline, suffixWidget: suffix),
        if (_usernameAvailable == false)
          const Padding(
            padding: EdgeInsets.only(top: 6, left: 4),
            child: Text('Username already taken', style: TextStyle(color: Colors.red, fontSize: 12)),
          ),
        if (_usernameAvailable == true)
          const Padding(
            padding: EdgeInsets.only(top: 6, left: 4),
            child: Text('Username is available!', style: TextStyle(color: Color(0xFF10B981), fontSize: 12, fontWeight: FontWeight.w600)),
          ),
      ]),
    );
  }

  Widget _stepGender() => _wrapper(
    title: "Select Your Gender",
    subtitle: "This helps us personalise your avatar.",
    child: Row(children: [
      _genderCard('boy', Icons.male, 'Male'),
      const SizedBox(width: 16),
      _genderCard('girl', Icons.female, 'Female'),
    ]),
  );

  Widget _genderCard(String value, IconData icon, String label) {
    final selected = _gender == value;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _gender = value),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 22),
          decoration: BoxDecoration(
            color: selected ? const Color(0xFFEFF6FF) : const Color(0xFFF1F5F9),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: selected ? _blue : Colors.transparent, width: 2),
          ),
          child: Column(children: [
            Icon(icon, size: 36, color: selected ? _blue : Colors.grey),
            const SizedBox(height: 8),
            Text(label, style: TextStyle(fontWeight: FontWeight.w600, color: selected ? _blue : Colors.grey[600])),
          ]),
        ),
      ),
    );
  }

  Widget _stepPhoto() => _wrapper(
    title: "Add a Profile Photo",
    subtitle: "Let your friends recognise you. (Optional)",
    child: Center(
      child: Column(children: [
        GestureDetector(
          onTap: _isUploading ? null : _pickPhoto,
          child: Stack(children: [
            CircleAvatar(
              radius: 72,
              backgroundColor: const Color(0xFFEFF6FF),
              backgroundImage: _pickedPhoto != null ? FileImage(_pickedPhoto!) : null,
              child: _pickedPhoto == null
                  ? Icon(Icons.person_add_alt_1, size: 52, color: Colors.grey[400])
                  : null,
            ),
            Positioned(bottom: 4, right: 4,
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: _blue, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)),
                child: _isUploading
                    ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.camera_alt, size: 16, color: Colors.white),
              )),
          ]),
        ),
        const SizedBox(height: 16),
        TextButton(
          onPressed: _isUploading ? null : _pickPhoto,
          child: Text(_pickedPhoto == null ? 'Choose from Gallery' : 'Change Photo',
              style: const TextStyle(color: _blue, fontWeight: FontWeight.w600)),
        ),
        if (_uploadedPhotoUrl != null && _pickedPhoto != null)
          Container(
            margin: const EdgeInsets.only(top: 8),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(color: Colors.green[50], borderRadius: BorderRadius.circular(20)),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.check_circle, color: Colors.green, size: 14),
              const SizedBox(width: 6),
              Text('Photo uploaded', style: TextStyle(color: Colors.green[700], fontSize: 12, fontWeight: FontWeight.w600)),
            ]),
          ),
      ]),
    ),
  );

  Widget _stepBio() => _wrapper(
    title: "Write a Short Bio",
    subtitle: "Tell others a bit about yourself. (Optional)",
    child: _textField(
      ctrl: _bioCtrl, hint: "e.g. Coffee lover, traveller...",
      icon: Icons.info_outline, maxLines: 3,
    ),
  );

  bool _showPass = false;
  bool _showConfirmPass = false;

  // ── Password strength ────────────────────────────────────────────────────
  double _passStrength(String p) {
    if (p.isEmpty) return 0;
    double s = 0;
    if (p.length >= 8) s += 0.25;
    if (p.contains(RegExp(r'[A-Z]'))) s += 0.25;
    if (p.contains(RegExp(r'[0-9]'))) s += 0.25;
    if (p.contains(RegExp(r'[!@#\$%^&*]'))) s += 0.25;
    return s;
  }

  Color _passStrengthColor(double s) {
    if (s <= 0.25) return Colors.red;
    if (s <= 0.5)  return Colors.orange;
    if (s <= 0.75) return Colors.amber;
    return const Color(0xFF10B981);
  }

  String _passStrengthLabel(double s) {
    if (s <= 0.25) return 'Weak';
    if (s <= 0.5)  return 'Fair';
    if (s <= 0.75) return 'Good';
    return 'Strong ✓';
  }

  Widget _stepEmail() => _wrapper(
    title: "Your Email & Password",
    subtitle: "We'll use this to log you in securely.",
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _textField(ctrl: _emailCtrl, hint: "Email address", icon: Icons.email_outlined, keyboardType: TextInputType.emailAddress),
      const SizedBox(height: 14),
      // Password field with toggle
      StatefulBuilder(builder: (_, ss) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        TextField(
          controller: _passCtrl,
          obscureText: !_showPass,
          onChanged: (_) => ss(() {}),
          decoration: InputDecoration(
            hintText: "Password",
            prefixIcon: const Icon(Icons.lock_outline, color: _blue),
            suffixIcon: IconButton(
              icon: Icon(_showPass ? Icons.visibility_off : Icons.visibility, color: Colors.grey, size: 20),
              onPressed: () => setState(() => _showPass = !_showPass),
            ),
            filled: true, fillColor: const Color(0xFFF3F6FB),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: _blue, width: 1.5)),
          ),
        ),
        if (_passCtrl.text.isNotEmpty) ...[ 
          const SizedBox(height: 8),
          Builder(builder: (_) {
            final s = _passStrength(_passCtrl.text);
            return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: s, minHeight: 5,
                  backgroundColor: Colors.grey.shade200,
                  valueColor: AlwaysStoppedAnimation(_passStrengthColor(s)),
                ),
              ),
              const SizedBox(height: 4),
              Text(_passStrengthLabel(s), style: TextStyle(fontSize: 11, color: _passStrengthColor(s), fontWeight: FontWeight.w600)),
            ]);
          }),
        ],
        const SizedBox(height: 6),
        // Requirements checklist
        _passRequirement('At least 8 characters', _passCtrl.text.length >= 8),
        _passRequirement('One uppercase letter (A-Z)', _passCtrl.text.contains(RegExp(r'[A-Z]'))),
        _passRequirement('One number (0-9)', _passCtrl.text.contains(RegExp(r'[0-9]'))),
      ])),
      const SizedBox(height: 14),
      // Confirm password
      TextField(
        controller: _confirmPassCtrl,
        obscureText: !_showConfirmPass,
        decoration: InputDecoration(
          hintText: "Confirm Password",
          prefixIcon: const Icon(Icons.lock_reset_outlined, color: _blue),
          suffixIcon: IconButton(
            icon: Icon(_showConfirmPass ? Icons.visibility_off : Icons.visibility, color: Colors.grey, size: 20),
            onPressed: () => setState(() => _showConfirmPass = !_showConfirmPass),
          ),
          filled: true, fillColor: const Color(0xFFF3F6FB),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: _blue, width: 1.5)),
        ),
      ),
    ]),
  );

  Widget _passRequirement(String text, bool met) => Padding(
    padding: const EdgeInsets.only(bottom: 2),
    child: Row(children: [
      Icon(met ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
        size: 14, color: met ? const Color(0xFF10B981) : Colors.grey),
      const SizedBox(width: 6),
      Text(text, style: TextStyle(fontSize: 11, color: met ? const Color(0xFF10B981) : Colors.grey)),
    ]),
  );

  Widget _stepPhone() => _wrapper(
    title: "Your Phone Number",
    subtitle: "Used to verify identity and connect friends.",
    child: Column(children: [
      if (widget.isGoogleFlow) ...[
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(color: const Color(0xFFE8F0FE), borderRadius: BorderRadius.circular(14)),
          child: Row(children: [
            const Icon(Icons.email_outlined, color: Color(0xFF4285F4), size: 20),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text("Google Account", style: TextStyle(fontSize: 11, color: Colors.grey)),
              Text(widget.googleUser?.email ?? '', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Color(0xFF0C1A2E))),
            ])),
          ]),
        ),
        const SizedBox(height: 14),
      ],
      _textField(ctrl: _phoneCtrl, hint: "Phone Number (e.g. +91 999...)", icon: Icons.phone, keyboardType: TextInputType.phone),
    ]),
  );


  Widget _stepPrivacy() => _wrapper(
    title: 'Account Privacy',
    subtitle: 'Choose who can see your profile and posts.',
    child: Column(children: [
      // Public option
      GestureDetector(
        onTap: () => setState(() => _isPublic = true),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: _isPublic ? const Color(0xFF0284C7).withValues(alpha: 0.08) : Colors.white,
            border: Border.all(
              color: _isPublic ? const Color(0xFF0284C7) : const Color(0xFFE5E5EA),
              width: _isPublic ? 2 : 1,
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: const Color(0xFF0284C7).withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.public_rounded, color: Color(0xFF0284C7), size: 26),
            ),
            const SizedBox(width: 16),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Public Account', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: Color(0xFF0C1A2E))),
              const SizedBox(height: 4),
              Text('Anyone can see your profile, posts and follow you.', style: TextStyle(fontSize: 12, color: Colors.grey[600], height: 1.4)),
            ])),
            if (_isPublic)
              const Icon(Icons.check_circle_rounded, color: Color(0xFF0284C7), size: 24),
          ]),
        ),
      ),

      const SizedBox(height: 14),

      // Private option
      GestureDetector(
        onTap: () => setState(() => _isPublic = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: !_isPublic ? const Color(0xFF8B5CF6).withValues(alpha: 0.08) : Colors.white,
            border: Border.all(
              color: !_isPublic ? const Color(0xFF8B5CF6) : const Color(0xFFE5E5EA),
              width: !_isPublic ? 2 : 1,
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: const Color(0xFF8B5CF6).withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.lock_rounded, color: Color(0xFF8B5CF6), size: 26),
            ),
            const SizedBox(width: 16),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Private Account', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: Color(0xFF0C1A2E))),
              const SizedBox(height: 4),
              Text('Only approved followers can see your posts and profile.', style: TextStyle(fontSize: 12, color: Colors.grey[600], height: 1.4)),
            ])),
            if (!_isPublic)
              const Icon(Icons.check_circle_rounded, color: Color(0xFF8B5CF6), size: 24),
          ]),
        ),
      ),

      const SizedBox(height: 20),

      // Info box
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFFF3F6FB),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Icon(Icons.info_outline_rounded, size: 16, color: Colors.grey),
          const SizedBox(width: 8),
          Expanded(child: Text(
            _isPublic
                ? 'Your profile will be visible to everyone on Zylo.'
                : 'People will need to send a follow request to see your content.',
            style: const TextStyle(fontSize: 12, color: Colors.black54, height: 1.5),
          )),
        ]),
      ),
    ]),
  );

  Widget _body() {
    switch (_step) {
      case _Step.username: return _stepUsername();
      case _Step.gender:   return _stepGender();
      case _Step.photo:    return _stepPhoto();
      case _Step.bio:      return _stepBio();
      case _Step.email:    return _stepEmail();
      case _Step.phone:    return _stepPhone();
      case _Step.privacy:  return _stepPrivacy();
      default:             return _stepUsername();
    }
  }

  String get _btnLabel {
    if (_step == _Step.privacy) return _isLoading ? 'Creating Account...' : 'Create Account';
    if (_step == _Step.photo) return _pickedPhoto == null ? 'Skip' : 'Continue';
    if (_step == _Step.bio) return _bioCtrl.text.trim().isEmpty ? 'Skip' : 'Continue';
    return 'Continue';
  }

  void _goBack() => setState(() { _error = null; _step = _prevStep(_step); });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white, elevation: 0,
        leading: _step != _Step.username
            ? IconButton(icon: const Icon(Icons.arrow_back_ios, color: Colors.black87, size: 20), onPressed: _goBack)
            : null,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(_totalSteps, (i) => AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            margin: const EdgeInsets.symmetric(horizontal: 3),
            width: i == _stepIndex ? 20 : 8, height: 8,
            decoration: BoxDecoration(
              color: i <= _stepIndex ? _blue : Colors.grey[300],
              borderRadius: BorderRadius.circular(4),
            ),
          )),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(child: _body()),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(color: Colors.red[50], borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.red[200]!)),
                child: Row(children: [
                  const Icon(Icons.error_outline, color: Colors.red, size: 18),
                  const SizedBox(width: 8),
                  Expanded(child: Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 13))),
                ]),
              ),
            ],
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity, height: 52,
              child: ElevatedButton(
                onPressed: (_isLoading || _isUploading) ? null : _next,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _blue,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  elevation: 0,
                ),
                child: (_isLoading || _isUploading)
                    ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : Text(_btnLabel, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15)),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
