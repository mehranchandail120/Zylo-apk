// ═══════════════════════════════════════════════════════════════════════════
// Zylo Storage — Permanent Cloud File Manager
// Files stored in Firestore per UID + Cloudflare/Telegram CDN
// Sections: Photos · Videos · Files   |   Long-press: Download / Share / Delete
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:convert';
import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gal/gal.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:permission_handler/permission_handler.dart';
import 'package:share_plus/share_plus.dart';
import '../../services/cloudflare_service.dart';

// ── File category helper ──────────────────────────────────────────────────
enum _FileCategory { photos, videos, files }

_FileCategory _categorize(String fileName) {
  final ext = p.extension(fileName).toLowerCase().replaceAll('.', '');
  const photoExts = {'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'heic', 'heif', 'svg'};
  const videoExts = {'mp4', 'mkv', 'mov', 'avi', 'webm', 'flv', 'm4v', '3gp', 'ts'};
  if (photoExts.contains(ext)) return _FileCategory.photos;
  if (videoExts.contains(ext)) return _FileCategory.videos;
  return _FileCategory.files;
}

class FileManagerScreen extends StatefulWidget {
  final void Function(UploadResult result)? onUploaded;
  final bool showBackButton;

  const FileManagerScreen({
    super.key,
    this.onUploaded,
    this.showBackButton = true,
  });

  @override
  State<FileManagerScreen> createState() => _FileManagerScreenState();
}

class _FileManagerScreenState extends State<FileManagerScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;

  // Upload state
  File? _pickedFile;
  String? _pickedFileName;
  int _pickedFileSize = 0;
  double _uploadProgress = 0;
  bool _isUploading = false;
  String? _uploadError;
  UploadResult? _lastUpload;

  // Storage list
  List<Map<String, dynamic>> _allFiles = [];
  bool _loading = true;

  static const _blue   = Color(0xFF0284C7);
  static const _green  = Color(0xFF10B981);
  static const _purple = Color(0xFF7C3AED);
  static const _kBg    = Color(0xFF0A0A0A);
  static const _kCard  = Color(0xFF161616);
  static const _kText  = Color(0xFFE8E8E8);
  static const _kSub   = Color(0xFF888888);

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 4, vsync: this);
    _loadFiles();
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  Future<void> _loadFiles() async {
    setState(() => _loading = true);
    final files = await CloudflareService.getSavedUploads();
    if (mounted) setState(() { _allFiles = files; _loading = false; });
  }

  List<Map<String, dynamic>> _filtered(_FileCategory cat) =>
      _allFiles.where((f) => _categorize(f['file_name'] as String? ?? '') == cat).toList();

  // ─── Upload ───────────────────────────────────────────────────────────────

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(allowMultiple: false, type: FileType.any);
    if (result == null || result.files.isEmpty) return;
    final pf = result.files.first;
    if (pf.path == null) return;
    setState(() {
      _pickedFile = File(pf.path!);
      _pickedFileName = pf.name;
      _pickedFileSize = pf.size;
      _uploadProgress = 0;
      _uploadError = null;
      _lastUpload = null;
    });
  }

  Future<void> _startUpload() async {
    if (_pickedFile == null) return;
    setState(() { _isUploading = true; _uploadProgress = 0; _uploadError = null; _lastUpload = null; });
    try {
      final result = await CloudflareService.uploadFile(
        _pickedFile!,
        onProgress: (prog) { if (mounted) setState(() => _uploadProgress = prog); },
      );
      if (mounted) {
        // Save done — reload list first
        await _loadFiles();

        // Figure out which tab to jump to based on file type
        final cat = _categorize(result.fileName);
        final tabIndex = cat == _FileCategory.photos ? 1
            : cat == _FileCategory.videos ? 2 : 3;

        setState(() {
          _isUploading = false;
          _lastUpload  = result;
          // Clear picker so upload tab is clean
          _pickedFile      = null;
          _pickedFileName  = null;
          _pickedFileSize  = 0;
          _uploadProgress  = 0;
        });

        widget.onUploaded?.call(result);

        // Jump to the correct tab (Photos / Videos / Files)
        _tab.animateTo(tabIndex);

        _showSnack(
          cat == _FileCategory.photos ? '📷 Photo saved to Zylo Storage!'
            : cat == _FileCategory.videos ? '🎬 Video saved to Zylo Storage!'
            : '📁 File saved to Zylo Storage!',
          _green,
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() { _isUploading = false; _uploadError = e.toString(); });
        _showSnack('Upload failed: $e', Colors.red);
      }
    }
  }

  // ─── Long-press options ───────────────────────────────────────────────────

  void _showFileOptions(Map<String, dynamic> item) {
    final fileName = item['file_name'] as String? ?? 'file';
    final fileId   = item['file_id']   as String? ?? '';
    final fileSize = item['file_size'] as int?    ?? 0;
    final emoji    = CloudflareService.getFileEmoji(fileName);

    showModalBottomSheet(
      context: context,
      backgroundColor: _kCard,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(margin: const EdgeInsets.only(top: 10), width: 36, height: 4,
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(children: [
              Container(width: 48, height: 48,
                decoration: BoxDecoration(color: _blue.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(12)),
                child: Center(child: Text(emoji, style: const TextStyle(fontSize: 24)))),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(fileName, style: const TextStyle(color: _kText, fontWeight: FontWeight.w700, fontSize: 14),
                  maxLines: 1, overflow: TextOverflow.ellipsis),
                if (fileSize > 0)
                  Text(CloudflareService.formatFileSize(fileSize), style: const TextStyle(color: _kSub, fontSize: 12)),
              ])),
            ]),
          ),
          const SizedBox(height: 16),
          const Divider(color: Colors.white12, height: 1),
          _sheetOption(Icons.download_rounded, _green, 'Download to Device', () {
            Navigator.pop(context);
            _downloadFile(fileId, fileName);
          }),
          _sheetOption(Icons.share_rounded, _blue, 'Share', () {
            Navigator.pop(context);
            Share.share('zylo:file:$fileId:$fileName', subject: 'Zylo Storage: $fileName');
          }),
          _sheetOption(Icons.copy_rounded, Colors.orange, 'Copy File ID', () {
            Navigator.pop(context);
            Clipboard.setData(ClipboardData(text: fileId));
            _showSnack('File ID copied!', _blue);
          }),
          const Divider(color: Colors.white12, height: 1),
          _sheetOption(Icons.delete_outline_rounded, Colors.red, 'Delete from Zylo Storage', () async {
            Navigator.pop(context);
            await _confirmDelete(fileId, fileName);
          }),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  Widget _sheetOption(IconData icon, Color color, String label, VoidCallback onTap) =>
    ListTile(
      onTap: onTap,
      leading: Container(width: 38, height: 38,
        decoration: BoxDecoration(color: color.withValues(alpha: 0.12), shape: BoxShape.circle),
        child: Icon(icon, color: color, size: 18)),
      title: Text(label, style: const TextStyle(color: _kText, fontWeight: FontWeight.w600, fontSize: 14)),
    );

  Future<void> _confirmDelete(String fileId, String fileName) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Delete File', style: TextStyle(color: _kText, fontWeight: FontWeight.w800)),
        content: Text('Remove "$fileName" from Zylo Storage?\nThe file will no longer be accessible.',
            style: const TextStyle(color: _kSub, fontSize: 13, height: 1.5)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel', style: TextStyle(color: _kSub))),
          ElevatedButton(onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            child: const Text('Delete')),
        ],
      ),
    );
    if (ok == true) {
      await CloudflareService.deleteUpload(fileId);
      _loadFiles();
      _showSnack('Deleted from Zylo Storage', Colors.red);
    }
  }

  Future<void> _downloadFile(String fileId, String fileName) async {
    if (Platform.isAndroid) {
      try {
        final info = await DeviceInfoPlugin().androidInfo;
        if (info.version.sdkInt <= 29) {
          final status = await Permission.storage.request();
          if (!status.isGranted) {
            _showSnack('Storage permission denied', Colors.red);
            return;
          }
        }
      } catch (_) {}
    }
    _showSnack('Downloading...', _blue);
    try {
      final dl = await CloudflareService.downloadFile(fileId, fileName);
      final cat = _categorize(dl.fileName);

      if (cat == _FileCategory.photos || cat == _FileCategory.videos) {
        // ── Save to Gallery (Photos/Videos) ─────────────────────────────
        try {
          if (cat == _FileCategory.photos) {
            await Gal.putImage(dl.file.path, album: 'Zylo');
          } else {
            await Gal.putVideo(dl.file.path, album: 'Zylo');
          }
          // Clean up temp file
          dl.file.deleteSync();
          if (mounted) _showSnack('Saved to Gallery → Zylo album ✓', _green);
        } catch (galErr) {
          // Fallback: keep in downloads folder
          if (mounted) _showSnack('Saved to ${dl.file.path}', _green);
        }
      } else {
        // ── Other files — keep in downloads folder ──────────────────────
        if (mounted) _showSnack('Saved to Downloads/zylo ✓', _green);
      }
    } catch (e) {
      if (mounted) _showSnack('Download failed: $e', Colors.red);
    }
  }

  void _showSnack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontWeight: FontWeight.w600)),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      duration: const Duration(seconds: 3),
    ));
  }

  // ─── Build ────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      appBar: AppBar(
        backgroundColor: _kCard,
        foregroundColor: _kText,
        elevation: 0,
        centerTitle: false,
        automaticallyImplyLeading: widget.showBackButton,
        title: Row(children: [
          Container(width: 34, height: 34,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [_purple, _blue]),
              borderRadius: BorderRadius.circular(10)),
            child: const Icon(Icons.cloud_rounded, color: Colors.white, size: 18)),
          const SizedBox(width: 10),
          const Text('Zylo Storage', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
        ]),
        actions: [
          IconButton(icon: const Icon(Icons.refresh_rounded, size: 20), onPressed: _loadFiles),
        ],
        bottom: TabBar(
          controller: _tab,
          indicatorColor: _blue,
          indicatorWeight: 2.5,
          labelColor: _blue,
          unselectedLabelColor: _kSub,
          labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 11),
          tabs: const [
            Tab(icon: Icon(Icons.upload_rounded, size: 18), text: 'Upload'),
            Tab(icon: Icon(Icons.image_rounded, size: 18), text: 'Photos'),
            Tab(icon: Icon(Icons.videocam_rounded, size: 18), text: 'Videos'),
            Tab(icon: Icon(Icons.folder_rounded, size: 18), text: 'Files'),
          ],
        ),
      ),
      body: TabBarView(controller: _tab, children: [
        _buildUploadTab(),
        _buildCategoryTab(_FileCategory.photos, Icons.image_outlined, 'No photos uploaded yet'),
        _buildCategoryTab(_FileCategory.videos, Icons.videocam_outlined, 'No videos uploaded yet'),
        _buildCategoryTab(_FileCategory.files,  Icons.folder_outlined,  'No files uploaded yet'),
      ]),
    );
  }

  // ─── Upload Tab ───────────────────────────────────────────────────────────

  Widget _buildUploadTab() => SingleChildScrollView(
    padding: const EdgeInsets.all(20),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _infoBanner(
        icon: Icons.cloud_upload_outlined, color: _blue,
        title: 'Upload Any File',
        subtitle: 'Photos, videos, APKs, documents — stored permanently in your Zylo Storage. '
            'Files survive app reinstalls and are tied to your account ID.',
      ),
      const SizedBox(height: 20),
      GestureDetector(
        onTap: _isUploading ? null : _pickFile,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          width: double.infinity,
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: _pickedFile != null ? _blue.withValues(alpha: 0.08) : _kCard,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: _pickedFile != null ? _blue.withValues(alpha: 0.5) : Colors.white.withValues(alpha: 0.08),
              width: 1.5),
          ),
          child: _pickedFile == null ? _emptyPickerContent() : _pickedFileContent(),
        ),
      ),
      if (_isUploading) ...[const SizedBox(height: 20), _progressCard()],
      if (_uploadError != null) ...[const SizedBox(height: 16), _errorCard(_uploadError!)],
      if (_lastUpload != null) ...[const SizedBox(height: 20), _uploadResultCard(_lastUpload!)],
      if (_pickedFile != null && !_isUploading) ...[
        const SizedBox(height: 20),
        SizedBox(
          width: double.infinity, height: 52,
          child: ElevatedButton.icon(
            onPressed: _startUpload,
            style: ElevatedButton.styleFrom(
              backgroundColor: _blue, foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), elevation: 4),
            icon: const Icon(Icons.cloud_upload_rounded, size: 20),
            label: const Text('Upload to Zylo Storage',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
          ),
        ),
        const SizedBox(height: 10),
        Center(child: TextButton(
          onPressed: () => setState(() { _pickedFile = null; _lastUpload = null; _uploadError = null; }),
          child: const Text('Clear', style: TextStyle(color: Colors.red)))),
      ],
      if (_allFiles.isNotEmpty) ...[const SizedBox(height: 24), _buildStorageSummary()],
    ]),
  );

  Widget _buildStorageSummary() {
    final photos = _filtered(_FileCategory.photos).length;
    final videos = _filtered(_FileCategory.videos).length;
    final files  = _filtered(_FileCategory.files).length;
    final totalSize = _allFiles.fold<int>(0, (s, f) => s + (f['file_size'] as int? ?? 0));
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: _kCard, borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withValues(alpha: 0.06))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Your Storage', style: TextStyle(color: _kText, fontWeight: FontWeight.w700, fontSize: 13)),
        const SizedBox(height: 12),
        Row(children: [
          _summaryItem('📷', 'Photos', photos),
          _summaryItem('🎬', 'Videos', videos),
          _summaryItem('📁', 'Files', files),
          _summaryItem('☁️', 'Total', _allFiles.length),
        ]),
        const SizedBox(height: 10),
        const Divider(color: Colors.white12, height: 1),
        const SizedBox(height: 10),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('Total size', style: TextStyle(color: _kSub, fontSize: 12)),
          Text(CloudflareService.formatFileSize(totalSize),
              style: const TextStyle(color: _kText, fontWeight: FontWeight.w700, fontSize: 12)),
        ]),
      ]),
    );
  }

  Widget _summaryItem(String emoji, String label, int count) => Expanded(
    child: Column(children: [
      Text(emoji, style: const TextStyle(fontSize: 20)),
      const SizedBox(height: 4),
      Text('$count', style: const TextStyle(color: _kText, fontWeight: FontWeight.w800, fontSize: 16)),
      Text(label, style: const TextStyle(color: _kSub, fontSize: 11)),
    ]),
  );

  Widget _emptyPickerContent() => Column(children: [
    Container(width: 64, height: 64,
      decoration: BoxDecoration(color: _blue.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(20)),
      child: const Icon(Icons.add_rounded, color: _blue, size: 36)),
    const SizedBox(height: 16),
    const Text('Tap to Pick a File', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
    const SizedBox(height: 6),
    Text('Images • Videos • APKs • Documents • Archives',
        style: TextStyle(color: _kSub, fontSize: 12), textAlign: TextAlign.center),
  ]);

  Widget _pickedFileContent() {
    final emoji = CloudflareService.getFileEmoji(_pickedFileName ?? '');
    return Row(children: [
      Container(width: 52, height: 52,
        decoration: BoxDecoration(color: _blue.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(14)),
        child: Center(child: Text(emoji, style: const TextStyle(fontSize: 26)))),
      const SizedBox(width: 14),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(_pickedFileName ?? 'unknown',
          style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700),
          maxLines: 2, overflow: TextOverflow.ellipsis),
        const SizedBox(height: 4),
        Text(CloudflareService.formatFileSize(_pickedFileSize), style: TextStyle(color: _kSub, fontSize: 12)),
      ])),
      Icon(Icons.chevron_right_rounded, color: _kSub),
    ]);
  }

  // ─── Category Tab (Photos / Videos / Files) ───────────────────────────────

  Widget _buildCategoryTab(_FileCategory cat, IconData emptyIcon, String emptyMsg) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: _blue));
    final items = _filtered(cat);
    if (items.isEmpty) {
      return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(emptyIcon, color: _kSub, size: 56),
        const SizedBox(height: 12),
        Text(emptyMsg, style: TextStyle(color: _kSub, fontSize: 15)),
        const SizedBox(height: 6),
        Text('Upload files to see them here',
            style: TextStyle(color: _kSub.withValues(alpha: 0.5), fontSize: 12)),
      ]));
    }

    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 6),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('${items.length} file${items.length == 1 ? '' : 's'}',
              style: TextStyle(color: _kSub, fontSize: 12, fontWeight: FontWeight.w600)),
          Text('Tap to open • Long-press for options',
              style: TextStyle(color: _kSub.withValues(alpha: 0.5), fontSize: 11)),
        ]),
      ),
      // Photos → grid, others → list
      Expanded(
        child: cat == _FileCategory.photos
            ? _buildPhotoGrid(items)
            : ListView.separated(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                itemCount: items.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (_, i) => _fileCard(items[i]),
              ),
      ),
    ]);
  }

  Widget _buildPhotoGrid(List<Map<String, dynamic>> items) {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 24),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 4,
        mainAxisSpacing: 4,
      ),
      itemCount: items.length,
      itemBuilder: (_, i) {
        final item     = items[i];
        final fileId   = item['file_id'] as String? ?? '';
        final fileName = item['file_name'] as String? ?? '';
        // Build Telegram CDN thumb URL via CloudflareService
        return GestureDetector(
          onTap: () => _openPhotoViewer(item),
          onLongPress: () => _showFileOptions(item),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Stack(fit: StackFit.expand, children: [
              // Thumbnail via Telegram file_id
              _TelegramThumb(fileId: fileId),
              // Bottom gradient + filename
              Positioned(
                bottom: 0, left: 0, right: 0,
                child: Container(
                  padding: const EdgeInsets.fromLTRB(6, 12, 6, 4),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.bottomCenter, end: Alignment.topCenter,
                      colors: [Colors.black87, Colors.transparent])),
                  child: Text(fileName,
                    style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w600),
                    maxLines: 1, overflow: TextOverflow.ellipsis),
                ),
              ),
            ]),
          ),
        );
      },
    );
  }

  void _openPhotoViewer(Map<String, dynamic> item) {
    final fileId   = item['file_id']   as String? ?? '';
    final fileName = item['file_name'] as String? ?? '';
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => _PhotoViewerScreen(fileId: fileId, fileName: fileName),
    ));
  }

  Widget _fileCard(Map<String, dynamic> item) {
    final fileName   = item['file_name']   as String? ?? 'unknown';
    final fileId     = item['file_id']     as String? ?? '';
    final fileSize   = item['file_size']   as int?    ?? 0;
    final uploadedAt = item['uploaded_at'] as String? ?? '';
    final emoji = CloudflareService.getFileEmoji(fileName);
    final cat   = _categorize(fileName);
    final accentColor = cat == _FileCategory.photos ? Colors.pinkAccent
        : cat == _FileCategory.videos ? Colors.deepPurpleAccent : _blue;

    return GestureDetector(
      onLongPress: () => _showFileOptions(item),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _kCard, borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white.withValues(alpha: 0.05))),
        child: Row(children: [
          Container(width: 46, height: 46,
            decoration: BoxDecoration(color: accentColor.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(12)),
            child: Center(child: Text(emoji, style: const TextStyle(fontSize: 24)))),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(fileName,
              style: const TextStyle(color: _kText, fontWeight: FontWeight.w700, fontSize: 13),
              maxLines: 1, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 4),
            Row(children: [
              if (fileSize > 0) ...[
                Text(CloudflareService.formatFileSize(fileSize), style: TextStyle(color: _kSub, fontSize: 10)),
                Text('  ·  ', style: TextStyle(color: _kSub, fontSize: 10)),
              ],
              if (uploadedAt.isNotEmpty)
                Expanded(child: Text(_formatDate(uploadedAt),
                    style: TextStyle(color: _kSub, fontSize: 10), overflow: TextOverflow.ellipsis)),
            ]),
          ])),
          GestureDetector(
            onTap: () { Clipboard.setData(ClipboardData(text: fileId)); _showSnack('File ID copied!', _blue); },
            child: Padding(padding: const EdgeInsets.all(6),
                child: Icon(Icons.copy_rounded, color: _kSub, size: 16))),
          GestureDetector(
            onTap: () => _showFileOptions(item),
            child: Padding(padding: const EdgeInsets.all(6),
                child: Icon(Icons.more_vert_rounded, color: _kSub, size: 18))),
        ]),
      ),
    );
  }

  // ─── Shared widgets ───────────────────────────────────────────────────────

  Widget _infoBanner({required IconData icon, required Color color, required String title, required String subtitle}) =>
    Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.2))),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(width: 36, height: 36,
          decoration: BoxDecoration(color: color.withValues(alpha: 0.15), shape: BoxShape.circle),
          child: Icon(icon, color: color, size: 18)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 13)),
          const SizedBox(height: 4),
          Text(subtitle, style: TextStyle(color: _kSub, fontSize: 12, height: 1.4)),
        ])),
      ]),
    );

  Widget _progressCard() {
    final pct = (_uploadProgress * 100).toStringAsFixed(0);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: _kCard, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _blue.withValues(alpha: 0.3))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          SizedBox(width: 20, height: 20,
              child: CircularProgressIndicator(value: _uploadProgress, strokeWidth: 2.5, color: _blue)),
          const SizedBox(width: 10),
          const Expanded(child: Text('Uploading...', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13))),
          Text('$pct%', style: const TextStyle(color: _blue, fontWeight: FontWeight.w800, fontSize: 13)),
        ]),
        const SizedBox(height: 10),
        ClipRRect(borderRadius: BorderRadius.circular(6),
          child: LinearProgressIndicator(
            value: _uploadProgress, minHeight: 5,
            backgroundColor: Colors.white.withValues(alpha: 0.06),
            valueColor: const AlwaysStoppedAnimation<Color>(_blue))),
      ]),
    );
  }

  Widget _errorCard(String error) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: Colors.red.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(12),
      border: Border.all(color: Colors.red.withValues(alpha: 0.3))),
    child: Row(children: [
      const Icon(Icons.error_outline, color: Colors.red, size: 18),
      const SizedBox(width: 10),
      Expanded(child: Text(error, style: const TextStyle(color: Colors.red, fontSize: 12),
          maxLines: 3, overflow: TextOverflow.ellipsis)),
    ]),
  );

  Widget _uploadResultCard(UploadResult result) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: _green.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(14),
      border: Border.all(color: _green.withValues(alpha: 0.3))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Row(children: [
        Icon(Icons.check_circle_rounded, color: _green, size: 20),
        SizedBox(width: 8),
        Text('Upload Successful!', style: TextStyle(color: _green, fontWeight: FontWeight.w800, fontSize: 14)),
      ]),
      const SizedBox(height: 10),
      Text(result.fileName, style: const TextStyle(color: _kText, fontWeight: FontWeight.w700, fontSize: 13)),
      const SizedBox(height: 4),
      Text(result.fileId, style: TextStyle(color: _kSub, fontSize: 11, fontFamily: 'monospace'),
          maxLines: 1, overflow: TextOverflow.ellipsis),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: OutlinedButton.icon(
          onPressed: () { Clipboard.setData(ClipboardData(text: result.fileId)); _showSnack('Copied!', _blue); },
          style: OutlinedButton.styleFrom(foregroundColor: _blue, side: BorderSide(color: _blue.withValues(alpha: 0.5)),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12)),
          icon: const Icon(Icons.copy_rounded, size: 14),
          label: const Text('Copy ID', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)))),
        const SizedBox(width: 10),
        Expanded(child: OutlinedButton.icon(
          onPressed: () => Share.share('zylo:file:${result.fileId}:${result.fileName}'),
          style: OutlinedButton.styleFrom(foregroundColor: _green, side: BorderSide(color: _green.withValues(alpha: 0.5)),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12)),
          icon: const Icon(Icons.share_rounded, size: 14),
          label: const Text('Share', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)))),
      ]),
    ]),
  );

  String _formatDate(String iso) {
    try {
      final dt = DateTime.parse(iso).toLocal();
      final m = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      return '${m[dt.month-1]} ${dt.day}, ${dt.year}';
    } catch (_) { return iso; }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// _TelegramThumb — loads image thumbnail from Telegram CDN via file_id
// ─────────────────────────────────────────────────────────────────────────────
class _TelegramThumb extends StatefulWidget {
  final String fileId;
  const _TelegramThumb({required this.fileId});

  @override
  State<_TelegramThumb> createState() => _TelegramThumbState();
}

class _TelegramThumbState extends State<_TelegramThumb> {
  String? _url;
  bool _loading = true;
  bool _error = false;

  @override
  void initState() {
    super.initState();
    _resolve();
  }

  Future<void> _resolve() async {
    try {
      final token = CloudflareService.tgToken;
      final resp = await http.get(
        Uri.parse('https://api.telegram.org/bot$token/getFile?file_id=${widget.fileId}'),
      ).timeout(const Duration(seconds: 8));
      final body = jsonDecode(resp.body);
      if (body['ok'] == true) {
        final path = body['result']['file_path'];
        final url  = 'https://api.telegram.org/file/bot$token/$path';
        if (mounted) setState(() { _url = url; _loading = false; });
      } else {
        if (mounted) setState(() { _loading = false; _error = true; });
      }
    } catch (_) {
      if (mounted) setState(() { _loading = false; _error = true; });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Container(color: const Color(0xFF1E1E1E),
        child: const Center(child: SizedBox(width: 18, height: 18,
          child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF0284C7)))));
    }
    if (_error || _url == null) {
      return Container(color: const Color(0xFF1E1E1E),
        child: const Center(child: Icon(Icons.broken_image_rounded, color: Colors.white24, size: 28)));
    }
    return Image.network(_url!, fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(color: const Color(0xFF1E1E1E),
        child: const Center(child: Icon(Icons.broken_image_rounded, color: Colors.white24, size: 28))));
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// _PhotoViewerScreen — fullscreen photo viewer
// ─────────────────────────────────────────────────────────────────────────────
class _PhotoViewerScreen extends StatefulWidget {
  final String fileId;
  final String fileName;
  const _PhotoViewerScreen({required this.fileId, required this.fileName});

  @override
  State<_PhotoViewerScreen> createState() => _PhotoViewerScreenState();
}

class _PhotoViewerScreenState extends State<_PhotoViewerScreen> {
  String? _url;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _resolve();
  }

  Future<void> _resolve() async {
    try {
      final token = CloudflareService.tgToken;
      final resp = await http.get(
        Uri.parse('https://api.telegram.org/bot$token/getFile?file_id=${widget.fileId}'),
      ).timeout(const Duration(seconds: 10));
      final body = jsonDecode(resp.body);
      if (body['ok'] == true) {
        final path = body['result']['file_path'];
        if (mounted) setState(() {
          _url = 'https://api.telegram.org/file/bot$token/$path';
          _loading = false;
        });
      } else {
        if (mounted) setState(() => _loading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(widget.fileName,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
          maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          if (_url != null)
            IconButton(
              icon: const Icon(Icons.download_rounded),
              onPressed: () async {
                try {
                  final dl = await CloudflareService.downloadFile(widget.fileId, widget.fileName);
                  await Gal.putImage(dl.file.path, album: 'Zylo');
                  dl.file.deleteSync();
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                      content: Text('Saved to Gallery → Zylo album ✓'),
                      backgroundColor: Color(0xFF10B981),
                      behavior: SnackBarBehavior.floating,
                    ));
                  }
                } catch (_) {}
              },
            ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFF0284C7)))
          : _url == null
              ? const Center(child: Icon(Icons.broken_image_rounded, color: Colors.white24, size: 64))
              : InteractiveViewer(
                  minScale: 0.5,
                  maxScale: 4.0,
                  child: Center(
                    child: Image.network(_url!, fit: BoxFit.contain),
                  ),
                ),
    );
  }
}
