import 'package:flutter/material.dart';
import 'auth/login_screen.dart';
import 'auth/register_screen.dart';
import 'privacy_policy_screen.dart';

class GetStartedScreen extends StatefulWidget {
  const GetStartedScreen({super.key});
  @override
  State<GetStartedScreen> createState() => _GetStartedScreenState();
}

class _GetStartedScreenState extends State<GetStartedScreen>
    with TickerProviderStateMixin {
  late AnimationController _bgCtrl;
  late AnimationController _fadeCtrl;
  late AnimationController _floatCtrl;
  late Animation<double> _bgAnim;
  late Animation<double> _fadeAnim;
  late Animation<double> _floatAnim;
  int _pageIndex = 0;

  final List<_OnboardPage> _pages = const [
    _OnboardPage(
      emoji: '🌍',
      title: 'A Social Where\nYou Belong',
      subtitle: 'Connect with real people, share real moments. No algorithms, no politics — just you and your world.',
      gradStart: Color(0xFF0C4A6E),
      gradEnd: Color(0xFF1D4ED8),
    ),
    _OnboardPage(
      emoji: '🚫',
      title: 'No AI.\nNo Politics.',
      subtitle: 'We built a space free from AI-generated noise and political debates. Pure human connection.',
      gradStart: Color(0xFF1D4ED8),
      gradEnd: Color(0xFF7C3AED),
    ),
    _OnboardPage(
      emoji: '✨',
      title: 'Be Real.\nBe You.',
      subtitle: 'Share posts, stories, chat with friends — authentically. Zylo is where real life happens.',
      gradStart: Color(0xFF7C3AED),
      gradEnd: Color(0xFF0284C7),
    ),
  ];

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 8))..repeat();
    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _floatCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat(reverse: true);
    _bgAnim   = Tween(begin: 0.0, end: 1.0).animate(_bgCtrl);
    _fadeAnim  = Tween(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut));
    _floatAnim = Tween(begin: -8.0, end: 8.0).animate(CurvedAnimation(parent: _floatCtrl, curve: Curves.easeInOut));
    _fadeCtrl.forward();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _fadeCtrl.dispose();
    _floatCtrl.dispose();
    super.dispose();
  }

  void _nextPage() {
    if (_pageIndex < _pages.length - 1) {
      _fadeCtrl.reverse().then((_) {
        setState(() => _pageIndex++);
        _fadeCtrl.forward();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final page = _pages[_pageIndex];
    return Scaffold(
      body: AnimatedBuilder(
        animation: _bgCtrl,
        builder: (_, __) => Container(
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [page.gradStart, page.gradEnd],
            ),
          ),
          child: SafeArea(
            child: Stack(
              children: [
                // Decorative BG blobs
                Positioned(top: -60, right: -60,
                  child: Container(width: 240, height: 240,
                    decoration: BoxDecoration(shape: BoxShape.circle,
                      color: Colors.white.withValues(alpha: 0.05)))),
                Positioned(bottom: 100, left: -80,
                  child: Container(width: 280, height: 280,
                    decoration: BoxDecoration(shape: BoxShape.circle,
                      color: Colors.white.withValues(alpha: 0.04)))),
                Positioned(top: 160, right: -40,
                  child: Container(width: 140, height: 140,
                    decoration: BoxDecoration(shape: BoxShape.circle,
                      color: Colors.white.withValues(alpha: 0.03)))),

                Column(
                  children: [
                    // Skip button
                    Align(
                      alignment: Alignment.topRight,
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: _pageIndex < _pages.length - 1
                          ? GestureDetector(
                              onTap: () => Navigator.pushReplacement(context,
                                MaterialPageRoute(builder: (_) => const LoginScreen())),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                                decoration: BoxDecoration(
                                  color: Colors.white.withValues(alpha: 0.15),
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(color: Colors.white.withValues(alpha: 0.25))),
                                child: const Text('Skip', style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
                              ),
                            )
                          : const SizedBox(height: 36),
                      ),
                    ),

                    const Flexible(child: SizedBox(height: 20)),
                    FadeTransition(
                      opacity: _fadeAnim,
                      child: AnimatedBuilder(
                        animation: _floatCtrl,
                        builder: (_, __) => Transform.translate(
                          offset: Offset(0, _floatAnim.value),
                          child: SizedBox(
                            width: 220, height: 220,
                            child: Stack(alignment: Alignment.center, children: [
                              Opacity(
                                opacity: 0.55,
                                child: Image.asset('assets/images/get_started.png',
                                  width: 200, height: 200, fit: BoxFit.contain)),
                              Container(
                                width: 96, height: 96,
                                decoration: BoxDecoration(
                                  color: Colors.white.withValues(alpha: 0.2),
                                  shape: BoxShape.circle,
                                  border: Border.all(color: Colors.white.withValues(alpha: 0.35), width: 2),
                                  boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.18), blurRadius: 30, offset: const Offset(0, 10))]),
                                child: Center(child: Text(page.emoji, style: const TextStyle(fontSize: 46))),
                              ),
                            ]),
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 24),

                    // Zylo wordmark
                    FadeTransition(
                      opacity: _fadeAnim,
                      child: ShaderMask(
                        shaderCallback: (b) => const LinearGradient(
                          colors: [Colors.white, Color(0xFFBAE6FD)]).createShader(b),
                        child: const Text('zylo',
                          style: TextStyle(fontSize: 52, fontWeight: FontWeight.w900,
                            color: Colors.white, fontStyle: FontStyle.italic, letterSpacing: -2)),
                      ),
                    ),

                    const SizedBox(height: 24),

                    // Title
                    FadeTransition(
                      opacity: _fadeAnim,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 32),
                        child: Text(page.title,
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900,
                            color: Colors.white, height: 1.2, letterSpacing: -0.5)),
                      ),
                    ),

                    const SizedBox(height: 16),

                    // Subtitle
                    FadeTransition(
                      opacity: _fadeAnim,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 36),
                        child: Text(page.subtitle,
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 15, color: Colors.white.withValues(alpha: 0.8), height: 1.6)),
                      ),
                    ),

                    const SizedBox(height: 16),

                    // Page dots
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(_pages.length, (i) => AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        width: _pageIndex == i ? 24 : 8,
                        height: 8,
                        decoration: BoxDecoration(
                          color: _pageIndex == i ? Colors.white : Colors.white.withValues(alpha: 0.35),
                          borderRadius: BorderRadius.circular(4)),
                      )),
                    ),

                    const SizedBox(height: 20),

                    // CTA Buttons
                    Padding(
                      padding: const EdgeInsets.fromLTRB(24, 0, 24, 16),
                      child: _pageIndex < _pages.length - 1
                        ? GestureDetector(
                            onTap: _nextPage,
                            child: Container(
                              width: double.infinity,
                              height: 56,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(18),
                                boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.2), blurRadius: 16, offset: const Offset(0, 6))],
                              ),
                              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                Text('Continue', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: page.gradStart)),
                                const SizedBox(width: 8),
                                Icon(Icons.arrow_forward_rounded, color: page.gradStart, size: 20),
                              ]),
                            ),
                          )
                        : Column(children: [
                            // Get Started
                            GestureDetector(
                              onTap: () => Navigator.pushReplacement(context,
                                MaterialPageRoute(builder: (_) => const PrivacyPolicyScreen())),
                              child: Container(
                                width: double.infinity, height: 56,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(18),
                                  boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.2), blurRadius: 16, offset: const Offset(0, 6))],
                                ),
                                child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                  Icon(Icons.rocket_launch_rounded, color: Color(0xFF0284C7), size: 22),
                                  SizedBox(width: 10),
                                  Text('Get Started — It\'s Free', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Color(0xFF0284C7))),
                                ]),
                              ),
                            ),
                            const SizedBox(height: 14),
                            // Log In
                            GestureDetector(
                              onTap: () => Navigator.pushReplacement(context,
                                MaterialPageRoute(builder: (_) => const LoginScreen())),
                              child: Container(
                                width: double.infinity, height: 52,
                                decoration: BoxDecoration(
                                  color: Colors.white.withValues(alpha: 0.15),
                                  borderRadius: BorderRadius.circular(18),
                                  border: Border.all(color: Colors.white.withValues(alpha: 0.4), width: 1.5),
                                ),
                                child: const Center(child: Text('I already have an account', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: Colors.white))),
                              ),
                            ),
                          ]),
                    ),

                    // Terms line
                    Padding(
                      padding: const EdgeInsets.only(bottom: 20),
                      child: Text('By continuing, you agree to our Terms & Privacy Policy',
                        style: TextStyle(fontSize: 11, color: Colors.white.withValues(alpha: 0.45)),
                        textAlign: TextAlign.center),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _OnboardPage {
  final String emoji, title, subtitle;
  final Color gradStart, gradEnd;
  const _OnboardPage({
    required this.emoji, required this.title, required this.subtitle,
    required this.gradStart, required this.gradEnd,
  });
}
