import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'dart:io';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';
import '../../services/notification_service.dart';
import '../../services/file_service.dart';
import '../../services/chat_lock_service.dart';
import '../../services/cache_service.dart';
import 'package:image_picker/image_picker.dart';
import 'chat_room_screen.dart';
import 'chat_info_screen.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:photo_manager_image_provider/photo_manager_image_provider.dart';
import '../../widgets/zylo_avatar.dart';
import '../../widgets/zylo_shimmer.dart';
import '../settings_screen.dart';
import 'saved_messages_screen.dart';
import 'time_capsule_screen.dart';
import '../../widgets/zylo_chat_design.dart';
import '../../services/local_db_service.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../widgets/zylo_cached_image.dart';

class ChatListScreen extends StatefulWidget {
  const ChatListScreen({super.key});
  @override
  State<ChatListScreen> createState() => _ChatListScreenState();
}

class _ChatListScreenState extends State<ChatListScreen> {
  final FirestoreService _fs = FirestoreService();
  final NotificationService _ns = NotificationService();
  // final CloudinaryService _cloud = CloudinaryService();
  final TextEditingController _searchCtrl = TextEditingController();
  String _searchQuery = '';
  StreamSubscription<QuerySnapshot>? _chatCacheSub;
  // ── Perf: cache lock states to avoid FutureBuilder on every rebuild ──────
  final Map<String, bool> _lockCache = {};
  final Map<String, bool> _followingCache = {};

  // ── Following set (SQLite-backed, preloaded) ────────────────────────────
  Set<String> _followingUids = {};
  bool _followingLoaded = false;

  // ── Stream-free user data cache: subscribe once per user, store in map ───
  final Map<String, Map<String, dynamic>> _userDataCache = {};
  final Map<String, bool> _typingCache = {};
  final Map<String, StreamSubscription> _userSubs = {};
  final Map<String, StreamSubscription> _typingSubs = {};

  @override
  void initState() {
    super.initState();
    _searchCtrl.addListener(() => setState(() => _searchQuery = _searchCtrl.text.toLowerCase().trim()));
    _startCacheWriteThrough();
    // Preload all lock states in one disk read — no per-tile async needed
    ChatLockService.preloadAll();
    // Preload following list from SQLite (instant, no network)
    _preloadFollowing();
  }

  void _startCacheWriteThrough() {
    _chatCacheSub = _fs.getChats().listen((snap) async {
      final myUid = FirebaseAuth.instance.currentUser?.uid;
      if (myUid == null) return;
      final chats = snap.docs.map((d) {
        final data = Map<String, dynamic>.from(d.data() as Map<String, dynamic>);
        data.forEach((k, v) {
          if (v is Timestamp) data[k] = v.millisecondsSinceEpoch;
        });
        return data;
      }).toList();
      // Hive cache (existing)
      await CacheService.cacheChats(myUid, chats);
      // SQLite sync — unread counts + last messages
      for (final chat in chats) {
        final participants = chat['participants'] as List? ?? [];
        final otherUid = participants.firstWhere((p) => p != myUid, orElse: () => '');
        if (otherUid.isEmpty) continue;
        final unreadMap = chat['unreadCount'] as Map? ?? {};
        final unread = (unreadMap[myUid] ?? 0) as int;
        final lastMsg = chat['lastMsg'] as String? ?? '';
        final lastMsgTimeMs = chat['lastMsgTime'] as int?;
        LocalDbService.instance.upsertChatSummary(
          myUid: myUid,
          otherUid: otherUid,
          lastMsg: lastMsg,
          lastMsgTimeMs: lastMsgTimeMs,
          unreadCount: unread,
        ).catchError((_) {});
      }
    });
  }

  @override
  void dispose() {
    _chatCacheSub?.cancel();
    for (final s in _userSubs.values) s.cancel();
    for (final s in _typingSubs.values) s.cancel();
    _searchCtrl.dispose();
    super.dispose();
  }

  // ── Subscribe to user doc once, update cache on change ───────────────────
  void _subscribeUser(String uid) {
    if (_userSubs.containsKey(uid)) return;
    _userSubs[uid] = FirebaseFirestore.instance
        .collection('users').doc(uid).snapshots()
        .listen((snap) {
      final data = snap.data() as Map<String, dynamic>? ?? {};
      if (mounted) setState(() => _userDataCache[uid] = data);
    });
  }

  // ── Preload following list from SQLite ───────────────────────────────────
  Future<void> _preloadFollowing() async {
    final myUid = FirebaseAuth.instance.currentUser?.uid;
    if (myUid == null) return;
    // Load Inner Circle membership from Firestore (SQLite following table removed)
    FirebaseFirestore.instance
        .collection('users').doc(myUid).collection('friends')
        .where('status', isEqualTo: 'friends')
        .get().then((snap) {
      final fresh = snap.docs.map((d) => d.id).toSet();
      if (mounted) setState(() { _followingUids = fresh; _followingLoaded = true; });
    }).catchError((_) {
      if (mounted) setState(() => _followingLoaded = true);
    });
  }

  // ── Subscribe to typing indicator once per user ───────────────────────────
  void _subscribeTyping(String uid) {
    if (_typingSubs.containsKey(uid)) return;
    _typingSubs[uid] = _fs.isOtherTyping(uid).listen((val) {
      if (mounted && _typingCache[uid] != val)
        setState(() => _typingCache[uid] = val);
    });
  }

  void _showFullScreenPhoto(BuildContext context, String photo, String name) {
    Navigator.push(context, PageRouteBuilder(
      opaque: false,
      pageBuilder: (_, __, ___) => _FullScreenPhotoView(photoUrl: photo, name: name),
    ));
  }

  void _showNotifications(BuildContext context, String myUid) {
    showModalBottomSheet(
      context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (ctx) => _NotificationsSheet(myUid: myUid, ns: _ns),
    );
  }

  void _showChatOptions(Map<String, dynamic> chat, String myUid, String otherUid, String otherName) async {
    // Run all async calls in parallel for speed
    final results = await Future.wait([
      _fs.isUserBlocked(otherUid).first,
      ChatLockService.isLocked(otherUid),
      FirebaseFirestore.instance
          .collection('users').doc(myUid)
          .collection('mutedChats').doc(otherUid).get(),
    ]);
    if (!mounted) return;
    final isBlocked = results[0] as bool;
    final isLocked = results[1] as bool;
    final myMuteDoc = results[2] as DocumentSnapshot;
    final isMutedByMe = myMuteDoc.exists;
    // Use a fresh context after async gap
    final ctx = context;
    showModalBottomSheet(
      context: ctx, backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheetCtx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(margin: const EdgeInsets.only(top: 10, bottom: 8), width: 40, height: 4,
            decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
          // LOCK OPTION
          _opt(
            isLocked ? Colors.green[50]! : const Color(0xFFEFF6FF),
            isLocked ? Icons.lock_open_rounded : Icons.lock_rounded,
            isLocked ? Colors.green[700]! : const Color(0xFF0284C7),
            isLocked ? 'Unlock Chat' : '🔒 Lock Chat',
            isLocked ? Colors.green[700]! : const Color(0xFF0284C7),
            () async {
              Navigator.pop(sheetCtx);
              if (isLocked) {
                await _unlockChat(context, otherUid, otherName);
              } else {
                await _lockChat(context, otherUid, otherName);
              }
            }),
          // MUTE OPTION — real implementation
          _opt(
            isMutedByMe ? Colors.green[50]! : Colors.orange[50]!,
            isMutedByMe ? Icons.notifications_active_outlined : Icons.notifications_off_outlined,
            isMutedByMe ? Colors.green[700]! : Colors.orange[700]!,
            isMutedByMe ? 'Unmute Notifications' : 'Mute Notifications',
            isMutedByMe ? Colors.green[700]! : Colors.orange[700]!,
            () async {
              Navigator.pop(sheetCtx);
              if (isMutedByMe) {
                await _ns.unmuteChat(otherUid);
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text('🔔 $otherName unmuted'),
                  backgroundColor: Colors.green,
                  behavior: SnackBarBehavior.floating,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
              } else {
                await _ns.muteChat(otherUid);
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text('🔕 $otherName muted'),
                  backgroundColor: Colors.orange[700],
                  behavior: SnackBarBehavior.floating,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
              }
            }),
          _opt(const Color(0xFFFFF9C4), Icons.cleaning_services_outlined, Colors.orange[800]!, 'Clear Chat', Colors.orange[800]!,
            () { Navigator.pop(sheetCtx); _confirmClear(otherUid, otherName); }),
          isBlocked
            ? _opt(Colors.green[50]!, Icons.lock_open_outlined, Colors.green[700]!, 'Unblock $otherName', Colors.green[700]!,
                () async {
                  Navigator.pop(sheetCtx);
                  await _fs.unblockUser(otherUid);
                  if (mounted) ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('$otherName unblocked'), backgroundColor: Colors.green));
                })
            : _opt(Colors.red[50]!, Icons.block_outlined, Colors.red[700]!, 'Block $otherName', Colors.red[700]!,
                () async {
                  Navigator.pop(sheetCtx);
                  final confirm = await showDialog<bool>(
                    context: context,
                    builder: (_) => AlertDialog(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      title: Text('Block $otherName?'),
                      content: Text('$otherName won\'t be able to message you.'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                        TextButton(onPressed: () => Navigator.pop(context, true),
                          child: const Text('Block', style: TextStyle(color: Colors.red))),
                      ],
                    ),
                  );
                  if (confirm == true) {
                    await _fs.blockUser(otherUid);
                    if (mounted) ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('$otherName blocked'), backgroundColor: Colors.red));
                  }
                }),
          _opt(Colors.deepOrange[50]!, Icons.flag_outlined, Colors.deepOrange[700]!, 'Report $otherName', Colors.deepOrange[700]!, () => Navigator.pop(sheetCtx)),
          _opt(Colors.red[50]!, Icons.person_remove_outlined, Colors.red[800]!, 'Remove from Chat List', Colors.red[800]!,
            () async {
              Navigator.pop(sheetCtx);
              final confirm = await showDialog<bool>(
                context: context,
                builder: (_) => AlertDialog(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  title: Text('Remove $otherName?'),
                  content: const Text('This chat will be removed from your list. They will not be notified.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                    TextButton(onPressed: () => Navigator.pop(context, true),
                      child: const Text('Remove', style: TextStyle(color: Colors.red, fontWeight: FontWeight.w700))),
                  ],
                ),
              );
              if (confirm == true) {
                final chatId = ([myUid, otherUid]..sort()).join('_');
                await FirebaseFirestore.instance.collection('chats').doc(chatId).delete();
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text('$otherName removed from chat list'),
                  backgroundColor: Colors.red[700],
                  behavior: SnackBarBehavior.floating,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
              }
            }),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  Future<void> _lockChat(BuildContext ctx, String otherUid, String otherName) async {
    final canBio = await ChatLockService.canUseBiometrics();
    if (!mounted) return;
    // Show lock setup sheet
    showModalBottomSheet(
      context: ctx, backgroundColor: Colors.transparent, isScrollControlled: true,
      builder: (_) => _LockSetupSheet(chatId: otherUid, chatName: otherName, canBio: canBio,
        onLocked: () {
          if (mounted) ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
            content: Text('🔒 Chat with $otherName locked!'),
            backgroundColor: const Color(0xFF0284C7),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
        }));
  }

  Future<void> _unlockChat(BuildContext ctx, String otherUid, String otherName) async {
    final hasPin = await ChatLockService.getPin(otherUid) != null;
    final canBio = await ChatLockService.canUseBiometrics();
    if (!mounted) return;
    bool authenticated = false;
    if (canBio) {
      authenticated = await ChatLockService.authenticateBiometric();
    }
    if (!authenticated && hasPin) {
      if (!mounted) return;
      final entered = await _showPinDialog(ctx, otherUid);
      authenticated = entered;
    }
    if (authenticated) {
      await ChatLockService.removeLock(otherUid);
      if (mounted) ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
        content: Text('🔓 Chat with $otherName unlocked'),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
    }
  }

  Future<bool> _showPinDialog(BuildContext ctx, String chatId) async {
    final ctrl = TextEditingController();
    final result = await showDialog<bool>(
      context: ctx,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Row(children: [
          Icon(Icons.lock_rounded, color: Color(0xFF0284C7), size: 20),
          SizedBox(width: 8),
          Text('Enter PIN', style: TextStyle(fontWeight: FontWeight.w900)),
        ]),
        content: TextField(
          controller: ctrl, keyboardType: TextInputType.number,
          maxLength: 4, obscureText: true, textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: 8),
          decoration: InputDecoration(
            hintText: '••••', counterText: '',
            filled: true, fillColor: const Color(0xFFF1F5F9),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0284C7), foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () async {
              final saved = await ChatLockService.getPin(chatId);
              Navigator.pop(ctx, ctrl.text == saved);
            },
            child: const Text('Unlock')),
        ],
      ),
    );
    return result ?? false;
  }

  Widget _opt(Color bg, IconData icon, Color iconColor, String label, Color? labelColor, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(14)),
      child: ListTile(
        leading: Icon(icon, color: iconColor),
        title: Text(label, style: TextStyle(fontWeight: FontWeight.w600, color: labelColor ?? Colors.black87)),
        onTap: onTap,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }

  void _confirmClear(String otherUid, String name) {
    showDialog(context: context, builder: (_) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: const Row(children: [
        Icon(Icons.cleaning_services_outlined, color: Colors.orange, size: 22),
        SizedBox(width: 8),
        Text('Clear Chat', style: TextStyle(fontWeight: FontWeight.w900)),
      ]),
      content: Text('How do you want to clear your chat with $name?'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        TextButton(
          onPressed: () async {
            Navigator.pop(context);
            await _fs.clearChat(otherUid);
            if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: const Text('Chat cleared for you'),
              backgroundColor: Colors.orange[700],
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
          },
          child: const Text('For Me Only', style: TextStyle(color: Colors.orange, fontWeight: FontWeight.w700)),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.red,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
          onPressed: () async {
            Navigator.pop(context);
            await _fs.clearChatBothSides(otherUid);
            if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: const Text('🗑️ Chat cleared for both sides'),
              backgroundColor: Colors.red[700],
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
          },
          child: const Text('For Both Sides', style: TextStyle(fontWeight: FontWeight.w700)),
        ),
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthService>(context);
    final myUid = auth.user?.uid ?? '';

    return Scaffold(
      backgroundColor: kBgList,
      body: SafeArea(
        child: Column(children: [
          // ── Header ──────────────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 14, 14, 6),
            child: Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('zylo.pages',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: kBrand, letterSpacing: -0.8)),
                const Text('Zylo Fast Messages',
                  style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: Color(0xFF94A3B8), letterSpacing: 0.2)),
              ])),
              StreamBuilder<int>(
                stream: myUid.isNotEmpty ? _ns.unreadCountStream() : const Stream.empty(),
                builder: (context, snap) {
                  final count = snap.data ?? 0;
                  return GestureDetector(
                    onTap: () => _showNotifications(context, myUid),
                    child: Stack(children: [
                      Container(width: 40, height: 40,
                        decoration: BoxDecoration(
                          color: count > 0 ? kBrand.withValues(alpha: 0.10) : const Color(0xFFEFF6FF),
                          shape: BoxShape.circle,
                          border: Border.all(color: count > 0 ? kBrand.withValues(alpha: 0.3) : Colors.transparent, width: 1)),
                        child: Icon(count > 0 ? Icons.notifications_rounded : Icons.notifications_none,
                          color: count > 0 ? kBrand : const Color(0xFF64748B), size: 21)),
                      if (count > 0)
                        Positioned(top: 4, right: 4,
                          child: Container(padding: const EdgeInsets.all(3),
                            decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                            child: Text(count > 99 ? '99+' : '$count',
                              style: const TextStyle(color: Colors.white, fontSize: 7.5, fontWeight: FontWeight.w900)))),
                    ]));
                },
              ),
              const SizedBox(width: 8),
              PopupMenuButton<String>(
                icon: Container(width: 40, height: 40,
                  decoration: const BoxDecoration(color: Color(0xFFEFF6FF), shape: BoxShape.circle),
                  child: const Icon(Icons.more_vert_rounded, color: Color(0xFF64748B), size: 21)),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                offset: const Offset(0, 44),
                onSelected: (val) {
                  if (val == 'saved') {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => const SavedMessagesScreen()));
                  } else if (val == 'capsule') {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => const TimeCapsuleScreen()));
                  } else if (val == 'settings') {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()));
                  }
                },
                itemBuilder: (_) => [
                  const PopupMenuItem(value: 'saved', child: Row(children: [
                    Icon(Icons.bookmark_rounded, color: Color(0xFF0284C7), size: 18),
                    SizedBox(width: 10),
                    Text('Saved Messages', style: TextStyle(fontWeight: FontWeight.w600)),
                  ])),
                  const PopupMenuItem(value: 'capsule', child: Row(children: [
                    Text('⏳', style: TextStyle(fontSize: 16)),
                    SizedBox(width: 10),
                    Text('Zylo Capsule', style: TextStyle(fontWeight: FontWeight.w600, color: Color(0xFFB8860B))),
                  ])),
                  const PopupMenuItem(value: 'settings', child: Row(children: [
                    Icon(Icons.settings_rounded, color: Color(0xFF64748B), size: 18),
                    SizedBox(width: 10),
                    Text('Settings', style: TextStyle(fontWeight: FontWeight.w600)),
                  ])),
                ],
              ),
            ]),
          ),
          // ── Glass Search bar ─────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 4, 14, 8),
            child: ZyloGlassSearchBar(
              controller: _searchCtrl,
              hint: 'Search FM chats...',
              onClear: () => setState(() => _searchQuery = ''),
            ),
          ),
          // Admin Banner
          _AdminBannerWidget(),
          // Friends row
          _FriendsRow(myUid: myUid),
          // Chat list
          Expanded(
            child: myUid.isEmpty
                ? const ChatListShimmer()
                : StreamBuilder<QuerySnapshot>(
                    stream: _fs.getChats(),
                    builder: (context, snap) {
                      if (snap.connectionState == ConnectionState.waiting) {
                        // ── Cache-first: show cached chats instantly ──────────────
                        final myUid = FirebaseAuth.instance.currentUser?.uid ?? '';
                        final cached = CacheService.getStaleCachedChats(myUid);
                        if (cached != null && cached.isNotEmpty) {
                          // Show cached data with a subtle loading indicator
                          return Stack(children: [
                            _buildChatListFromCache(cached, myUid),
                            const Positioned(
                              top: 8, right: 16,
                              child: SizedBox(width: 16, height: 16,
                                child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF0284C7))),
                            ),
                          ]);
                        }
                        return const _ChatSkeletonLoader();
                      }
                      if (snap.hasError) {
                        // ── Offline fallback ──────────────────────────────────────
                        final myUid = FirebaseAuth.instance.currentUser?.uid ?? '';
                        final cached = CacheService.getStaleCachedChats(myUid);
                        if (cached != null && cached.isNotEmpty) {
                          return _buildChatListFromCache(cached, myUid);
                        }
                        return Center(child: Text('Error: ${snap.error}'));
                      }
                      var chats = snap.data?.docs ?? [];
                      if (chats.isEmpty) {
                        return Center(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 40),
                            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                              Image.asset('assets/images/no_friends.png', width: 200, height: 200, fit: BoxFit.contain),
                              const SizedBox(height: 16),
                              const Text('No Chats Yet', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Colors.black87)),
                              const SizedBox(height: 8),
                              Text('Tap + to start a conversation\nor add friends to chat with',
                                style: TextStyle(color: Colors.grey[500], fontSize: 13, height: 1.5),
                                textAlign: TextAlign.center),
                            ]),
                          ),
                        );
                      }
                      return ListView.builder(
                        padding: const EdgeInsets.only(bottom: 80, top: 4),
                        itemCount: chats.length + 1,
                        addAutomaticKeepAlives: false,
                        addRepaintBoundaries: true,
                        cacheExtent: 300,
                        itemBuilder: (context, i) {
                          // E2E encrypted footer
                          if (i == chats.length) {
                            return Padding(
                              padding: const EdgeInsets.fromLTRB(0, 4, 0, 16),
                              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                const Icon(Icons.lock_rounded, size: 11, color: Color(0xFF9CA3AF)),
                                const SizedBox(width: 4),
                                Text('Zylo FM • End-to-end encrypted',
                                  style: TextStyle(fontSize: 10.5, color: Colors.grey[400], fontWeight: FontWeight.w500)),
                              ]),
                            );
                          }
                          final chat = chats[i].data() as Map<String, dynamic>;
                          final otherUid = (chat['participants'] as List).firstWhere((p) => p != myUid, orElse: () => '');
                          final unreadMap = chat['unreadCount'] as Map<String, dynamic>? ?? {};
                          final unread = (unreadMap[myUid] ?? 0) as int;
                          final lastMsg = chat['lastMsg'] ?? '';
                          final lastTime = chat['lastMsgTime'] as Timestamp?;
                          final timeStr = lastTime != null ? _formatTime(lastTime.toDate()) : '';

                          // ── Stream-free: subscribe once, read from cache ──────────
                          _subscribeUser(otherUid);
                          _subscribeTyping(otherUid);

                          // cache follow state
                          // Following: instant lookup from preloaded Set (no Firestore per-tile)
                          _followingCache[otherUid] = _followingUids.contains(otherUid);
                          // Lock state: sync read from memory cache (preloaded in initState)
                          final syncLocked = ChatLockService.isLockedSync(otherUid);
                          if (syncLocked != null && _lockCache[otherUid] != syncLocked) {
                            // Update local map without setState (next build will pick it up)
                            _lockCache[otherUid] = syncLocked;
                          } else if (syncLocked == null && !_lockCache.containsKey(otherUid)) {
                            // Not in memory yet — async fallback once
                            ChatLockService.isLocked(otherUid).then((v) {
                              if (mounted && _lockCache[otherUid] != v)
                                setState(() => _lockCache[otherUid] = v);
                            });
                          }

                          final userData = _userDataCache[otherUid] ?? {};
                          final rawOnline = userData['isOnline'] == true;
                          final lastSeenTs = userData['lastSeen'] as dynamic;
                          bool isOnline = false;
                          if (rawOnline && lastSeenTs != null) {
                            try {
                              final ls = (lastSeenTs.runtimeType.toString().contains('Timestamp'))
                                  ? (lastSeenTs as dynamic).toDate() as DateTime
                                  : DateTime.now();
                              isOnline = DateTime.now().difference(ls).inMinutes <= 5;
                            } catch (_) { isOnline = true; }
                          } else if (rawOnline) { isOnline = true; }

                          final lastSeen = userData['lastSeen'] as Timestamp?;
                          final liveName = (userData['username'] as String? ?? '').isNotEmpty
                              ? userData['username'] as String
                              : (chat['participantNames'] as Map<String, dynamic>?)?[otherUid] as String? ?? 'User';
                          final livePhoto = (userData['photoURL'] as String? ?? '').isNotEmpty
                              ? userData['photoURL'] as String
                              : (chat['participantPhotos'] as Map<String, dynamic>?)?[otherUid] as String? ?? '';

                          // Apply search filter using live name
                          if (_searchQuery.isNotEmpty &&
                              !liveName.toLowerCase().contains(_searchQuery) &&
                              !lastMsg.toLowerCase().contains(_searchQuery)) {
                            return const SizedBox.shrink();
                          }

                          String statusStr = '';
                          if (lastSeen != null) {
                            final diff = DateTime.now().difference(lastSeen.toDate());
                            if (diff.inMinutes < 60) statusStr = 'Last seen \${diff.inMinutes}m ago';
                            else if (diff.inHours < 24) statusStr = 'Last seen \${diff.inHours}h ago';
                            else statusStr = 'Last seen \${diff.inDays}d ago';
                          }

                          final isTyping = _typingCache[otherUid] == true;
                          return ZyloChatTile(
                            name: liveName,
                            photoUrl: livePhoto,
                            lastMsg: lastMsg.isNotEmpty ? lastMsg : statusStr,
                            timeStr: timeStr,
                            unread: unread,
                            isOnline: isOnline,
                            isLocked: _lockCache[otherUid] == true,
                            isTyping: isTyping,
                            notFollowing: !(_followingUids.contains(otherUid)),
                            typingWidget: const _TypingDots(),
                            onTap: () async {
                              final locked = await ChatLockService.isLocked(otherUid);
                              if (locked) {
                                bool ok = false;
                                if (await ChatLockService.canUseBiometrics())
                                  ok = await ChatLockService.authenticateBiometric();
                                if (!ok) {
                                  final pin = await ChatLockService.getPin(otherUid);
                                  if (pin != null && context.mounted)
                                    ok = await _showPinDialog(context, otherUid);
                                }
                                if (!ok) return;
                              }
                              _fs.markAsRead(otherUid);
                              if (context.mounted) Navigator.push(context, CupertinoPageRoute(
                                builder: (_) => ChatRoomScreen(targetId: otherUid, targetName: liveName)));
                            },
                            onLongPress: () => _showChatOptions(chat, myUid, otherUid, liveName),
                            onAvatarTap: () => Navigator.push(context, MaterialPageRoute(
                              builder: (_) => ChatInfoScreen(
                                targetName: liveName, targetId: otherUid,
                                targetPhoto: livePhoto.isNotEmpty ? livePhoto : null))),
                            avatarFallback: livePhoto.isNotEmpty
                                ? ZyloCachedImage(
                                    url: livePhoto,
                                    width: null, height: null, fit: BoxFit.cover,
                                    errorWidget: _avatarFallback(liveName, 26))
                                : _avatarFallback(liveName, 26),
                          );
                        },
                      );
                    },
                  ),
          ),
        ]),
      ),
    );
  }

  // ── Cache fallback list builder ─────────────────────────────────────────────
  Widget _buildChatListFromCache(List<Map<String, dynamic>> chats, String myUid) {
    final filtered = chats.where((chat) {
      if (_searchQuery.isEmpty) return true;
      final participants = chat['participants'] as List? ?? [];
      final otherUid = participants.firstWhere((p) => p != myUid, orElse: () => '');
      final names = chat['participantNames'] as Map? ?? {};
      final name = (names[otherUid] ?? '').toString().toLowerCase();
      final lastMsg = (chat['lastMsg'] ?? '').toString().toLowerCase();
      return name.contains(_searchQuery) || lastMsg.contains(_searchQuery);
    }).toList();

    if (filtered.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Image.asset('assets/images/no_friends.png', width: 180, height: 180, fit: BoxFit.contain),
            const SizedBox(height: 16),
            const Text('No Results', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Colors.black87)),
            const SizedBox(height: 6),
            Text('No chats match your search', style: TextStyle(color: Colors.grey[500], fontSize: 13)),
          ]),
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 80),
      itemCount: filtered.length,
      itemBuilder: (context, i) {
        final chat = filtered[i];
        final participants = chat['participants'] as List? ?? [];
        final otherUid = participants.firstWhere((p) => p != myUid, orElse: () => '');
        final names = chat['participantNames'] as Map<String, dynamic>? ?? {};
        final photos = chat['participantPhotos'] as Map<String, dynamic>? ?? {};
        final name = (names[otherUid] ?? 'User').toString();
        final photo = (photos[otherUid] ?? '').toString();
        final lastMsg = (chat['lastMsg'] ?? '').toString();
        final unreadMap = chat['unreadCount'] as Map? ?? {};
        final unread = (unreadMap[myUid] ?? 0) as int;
        final lastTimestamp = chat['lastMsgTime'];
        final lastTime = lastTimestamp != null
            ? _formatTime(DateTime.fromMillisecondsSinceEpoch(lastTimestamp as int))
            : '';

        // Lock state from memory cache (preloaded in initState)
        final syncLocked = ChatLockService.isLockedSync(otherUid);
        if (syncLocked != null) {
          _lockCache[otherUid] = syncLocked;
        } else if (!_lockCache.containsKey(otherUid)) {
          ChatLockService.isLocked(otherUid).then((v) {
            if (mounted && _lockCache[otherUid] != v)
              setState(() => _lockCache[otherUid] = v);
          });
        }
        final isLockedCached = _lockCache[otherUid] == true;

        return InkWell(
          onTap: () async {
            // Fast path: use cache first, then verify
            final lockedFast = _lockCache[otherUid] ?? false;
            if (lockedFast) {
              bool ok = false;
              if (await ChatLockService.canUseBiometrics()) {
                ok = await ChatLockService.authenticateBiometric();
              }
              if (!ok) {
                final pin = await ChatLockService.getPin(otherUid);
                if (pin != null && context.mounted) {
                  ok = await _showPinDialog(context, otherUid);
                }
              }
              if (!ok) return;
            }
            _fs.markAsRead(otherUid);
            if (context.mounted) Navigator.push(context, CupertinoPageRoute(
              builder: (_) => ChatRoomScreen(targetId: otherUid, targetName: name),
            ));
          },
          onLongPress: () => _showChatOptions(chat, myUid, otherUid, name),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: Row(children: [
              // Avatar with lock overlay
              SizedBox(width: 56, height: 56, child: Stack(children: [
                photo.isNotEmpty && (photo.startsWith('http://') || photo.startsWith('https://'))
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(28),
                      child: ZyloCachedImage(
                        url: photo, width: 52, height: 52, fit: BoxFit.cover,
                        placeholder: (_, __) => _avatarFallback(name, 26),
                        errorWidget: _avatarFallback(name, 26),
                      ))
                  : _avatarFallback(name, 28),
                // Lock badge on avatar
                if (isLockedCached)
                  Positioned(top: 0, right: 0,
                    child: Container(
                      width: 18, height: 18,
                      decoration: BoxDecoration(
                        color: const Color(0xFF0284C7),
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 2)),
                      child: const Icon(Icons.lock_rounded, size: 10, color: Colors.white))),
              ])),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(child: Text(name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15), overflow: TextOverflow.ellipsis)),
                  Text(lastTime, style: TextStyle(color: Colors.grey[500], fontSize: 11)),
                ]),
                const SizedBox(height: 2),
                Row(children: [
                  Expanded(child: Text(lastMsg, style: TextStyle(color: Colors.grey[600], fontSize: 13), maxLines: 1, overflow: TextOverflow.ellipsis)),
                  if (unread > 0)
                    Container(width: 20, height: 20,
                      decoration: const BoxDecoration(color: Color(0xFF0284C7), shape: BoxShape.circle),
                      child: Center(child: Text(unread > 99 ? '99+' : '$unread', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w900)))),
                ]),
              ])),
            ]),
          ),
        );
      },
    );
  }

  Widget _avatarFallback(String name, double radius) {
    const colors = [
      Color(0xFF0284C7), Color(0xFF7C3AED), Color(0xFF059669),
      Color(0xFFD97706), Color(0xFFDC2626), Color(0xFF0891B2),
      Color(0xFF9333EA), Color(0xFF065F46), Color(0xFFB45309),
    ];
    final seed = name.isNotEmpty ? name[0].codeUnitAt(0) : 0;
    final bg = colors[seed % colors.length];
    final parts = name.trim().split(RegExp(r'\s+'));
    final initials = parts.length >= 2
        ? '\${parts[0][0]}\${parts[1][0]}'.toUpperCase()
        : name.isNotEmpty ? name[0].toUpperCase() : '?';
    // Full-fill for ZyloDashedRingAvatar clip — no fixed size
    return Container(
      width: double.infinity,
      height: double.infinity,
      color: bg,
      alignment: Alignment.center,
      child: Text(initials,
        style: TextStyle(color: Colors.white, fontSize: radius * 0.65,
          fontWeight: FontWeight.w800, letterSpacing: 0.5)),
    );
  }

  void _showAddMenu(BuildContext context, String myUid, AuthService auth) {
    showModalBottomSheet(
      context: context, backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(margin: const EdgeInsets.only(top: 10, bottom: 8), width: 40, height: 4,
          decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
        const Padding(padding: EdgeInsets.fromLTRB(20, 4, 20, 12),
          child: Align(alignment: Alignment.centerLeft,
            child: Text('Create', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)))),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF0284C7), Color(0xFF0EA5E9)],
              begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: BorderRadius.circular(16)),
          child: ListTile(
            leading: const Icon(Icons.chat_rounded, color: Colors.white),
            title: const Text('New Chat', style: TextStyle(fontWeight: FontWeight.w700, color: Colors.white, fontSize: 15)),
            subtitle: const Text('Start a conversation', style: TextStyle(color: Colors.white70, fontSize: 12)),
            onTap: () { Navigator.pop(ctx); _showNewChatDialog(context, myUid); })),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF7C3AED), Color(0xFFEC4899)],
              begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: BorderRadius.circular(16)),
          child: ListTile(
            leading: const Icon(Icons.post_add_rounded, color: Colors.white),
            title: const Text('Create Post', style: TextStyle(fontWeight: FontWeight.w700, color: Colors.white, fontSize: 15)),
            subtitle: const Text('Share with everyone on Feed', style: TextStyle(color: Colors.white70, fontSize: 12)),
            onTap: () {
              Navigator.pop(ctx);
              showModalBottomSheet(
                context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
                builder: (_) => _QuickCreatePost(myUid: myUid, auth: auth));
            })),
        const SizedBox(height: 12),
      ])));
  }

  void _showNewChatDialog(BuildContext context, String myUid) {
    final ctrl = TextEditingController();
    showModalBottomSheet(
      context: context, isScrollControlled: true, backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom + 24, top: 20, left: 20, right: 20),
        child: StatefulBuilder(builder: (ctx, setS) => Column(mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('New Chat', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 14),
            TextField(
              controller: ctrl, autofocus: true,
              decoration: InputDecoration(
                hintText: 'Search username...',
                prefixIcon: const Icon(Icons.search),
                filled: true, fillColor: const Color(0xFFF1F5F9),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
              ),
              onChanged: (_) => setS(() {}),
            ),
            const SizedBox(height: 12),
            StreamBuilder<QuerySnapshot>(
              stream: ctrl.text.length >= 2
                  ? _fs.searchUsers(ctrl.text.toLowerCase().trim())
                  : const Stream.empty(),
              builder: (context, snap) {
                final users = snap.data?.docs ?? [];
                final filtered = users.where((d) => d.id != myUid).toList();
                return ListView.builder(
                  shrinkWrap: true, itemCount: filtered.length,
                  itemBuilder: (_, i) {
                    final u = filtered[i].data() as Map<String, dynamic>;
                    final photo = u['photoURL'] as String? ?? '';
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor: const Color(0xFF0284C7),
                        backgroundImage: photo.isNotEmpty ? CachedNetworkImageProvider(photo) : null,
                        child: photo.isEmpty ? Text((u['username'] ?? '?')[0].toUpperCase(),
                            style: const TextStyle(color: Colors.white)) : null,
                      ),
                      title: Text('@${u['username'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Text(u['email'] ?? '', style: const TextStyle(fontSize: 11)),
                      onTap: () async {
                        final name = u['username'] ?? 'User';
                        await _fs.ensureChatExists(filtered[i].id, name, photo);
                        if (context.mounted) {
                          Navigator.pop(context);
                          Navigator.push(context, MaterialPageRoute(
                            builder: (_) => ChatRoomScreen(targetId: filtered[i].id, targetName: name),
                          ));
                        }
                      },
                    );
                  },
                );
              },
            ),
          ])),
      ),
    );
  }

  String _formatTime(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inDays == 0) {
      final h = dt.hour > 12 ? dt.hour - 12 : dt.hour == 0 ? 12 : dt.hour;
      final m = dt.minute.toString().padLeft(2, '0');
      return '$h:$m ${dt.hour >= 12 ? "PM" : "AM"}';
    } else if (diff.inDays == 1) {
      return 'Yesterday';
    } else if (diff.inDays < 7) {
      const days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
      return days[dt.weekday % 7];
    } else {
      return '${dt.day}/${dt.month}';
    }
  }
}


// ── Typing Dots Animation ─────────────────────────────────────────────────────
class _TypingDots extends StatefulWidget {
  const _TypingDots();
  @override State<_TypingDots> createState() => _TypingDotsState();
}

class _TypingDotsState extends State<_TypingDots> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat();
  }
  @override void dispose() { _ctrl.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) {
        return Row(mainAxisSize: MainAxisSize.min, children: List.generate(3, (i) {
          final phase = (_ctrl.value + i * 0.33) % 1.0;
          final opacity = (phase < 0.5 ? phase * 2 : (1 - phase) * 2).clamp(0.2, 1.0);
          return Container(
            margin: const EdgeInsets.symmetric(horizontal: 1),
            width: 4, height: 4,
            decoration: BoxDecoration(
              color: const Color(0xFF0284C7).withValues(alpha: opacity),
              shape: BoxShape.circle),
          );
        }));
      },
    );
  }
}

// ── Full Screen Photo View ───────────────────────────────────────────
class _FullScreenPhotoView extends StatelessWidget {
  final String photoUrl;
  final String name;
  const _FullScreenPhotoView({required this.photoUrl, required this.name});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(name, style: const TextStyle(color: Colors.white)),
      ),
      body: Center(
        child: InteractiveViewer(
          child: Image.network(photoUrl, fit: BoxFit.contain,
            errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white54, size: 64)),
        ),
      ),
    );
  }
}

// ── Notifications Sheet ──────────────────────────────────────────────
class _NotificationsSheet extends StatelessWidget {
  final String myUid;
  final NotificationService ns;
  const _NotificationsSheet({required this.myUid, required this.ns});

  IconData _iconFor(String type) {
    switch (type) {
      case 'message':       return Icons.chat_bubble_rounded;
      case 'friend_request': return Icons.person_add_rounded;
      case 'like':          return Icons.favorite_rounded;
      case 'comment':       return Icons.comment_rounded;
      case 'broadcast':     return Icons.campaign_rounded;
      case 'announcement':  return Icons.announcement_rounded;
      default:              return Icons.notifications_rounded;
    }
  }

  Color _colorFor(String type) {
    switch (type) {
      case 'message':       return const Color(0xFF0284C7);
      case 'friend_request': return const Color(0xFF7C3AED);
      case 'like':          return const Color(0xFFEF4444);
      case 'comment':       return const Color(0xFF059669);
      case 'broadcast':     return const Color(0xFFFFBB35);
      case 'announcement':  return const Color(0xFF0EA5E9);
      default:              return Colors.grey;
    }
  }

  String _timeAgo(DateTime dt) {
    final d = DateTime.now().difference(dt);
    if (d.inMinutes < 1) return 'Just now';
    if (d.inHours < 1)   return '${d.inMinutes}m ago';
    if (d.inDays < 1)    return '${d.inHours}h ago';
    if (d.inDays < 7)    return '${d.inDays}d ago';
    return '${dt.day}/${dt.month}';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.78,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      child: Column(children: [
        // Handle
        Container(margin: const EdgeInsets.only(top: 10, bottom: 4), width: 40, height: 4,
          decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),

        // Header row
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 10, 12, 8),
          child: Row(children: [
            const Text('Notifications', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
            const Spacer(),
            // Mark all read button
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('users').doc(myUid)
                  .collection('notifications')
                  .where('read', isEqualTo: false)
                  .snapshots(),
              builder: (_, snap) {
                final unreadCount = snap.data?.docs.length ?? 0;
                if (unreadCount == 0) return const SizedBox.shrink();
                return TextButton.icon(
                  onPressed: () async {
                    await ns.markAllAsRead();
                  },
                  icon: const Icon(Icons.done_all_rounded, size: 16),
                  label: Text('Mark all read ($unreadCount)',
                    style: const TextStyle(fontSize: 12)),
                  style: TextButton.styleFrom(
                    foregroundColor: const Color(0xFF0284C7),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  ),
                );
              },
            ),
          ]),
        ),

        const Divider(height: 1, color: Color(0xFFF1F5F9)),

        // List
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('users').doc(myUid)
                .collection('notifications')
                .orderBy('createdAt', descending: true)
                .limit(50)
                .snapshots(),
            builder: (ctx, snap) {
              if (snap.connectionState == ConnectionState.waiting) {
                return const Center(child: ZyloLoader());
              }
              final docs = snap.data?.docs ?? [];
              if (docs.isEmpty) {
                return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.notifications_none, size: 56, color: Colors.grey[200]),
                  const SizedBox(height: 12),
                  Text('No notifications yet',
                    style: TextStyle(color: Colors.grey[400], fontWeight: FontWeight.w600)),
                ]));
              }
              return ListView.separated(
                padding: const EdgeInsets.only(bottom: 24),
                itemCount: docs.length,
                separatorBuilder: (_, __) => const Divider(height: 1, indent: 72, color: Color(0xFFF1F5F9)),
                itemBuilder: (_, i) {
                  final doc  = docs[i];
                  final d    = doc.data() as Map<String, dynamic>;
                  final type = d['type'] as String? ?? '';
                  final text = d['text'] as String? ?? '';
                  final read = d['read'] as bool? ?? false;
                  final fromUid  = d['fromUid']  as String? ?? '';
                  final fromName = d['fromName'] as String? ?? '';
                  final chatId   = d['chatId']   as String? ?? '';
                  final ts       = d['createdAt'] as Timestamp?;
                  final color    = _colorFor(type);

                  return InkWell(
                    onTap: () async {
                      // Mark as read on tap
                      if (!read) {
                        await FirebaseFirestore.instance
                            .collection('users').doc(myUid)
                            .collection('notifications').doc(doc.id)
                            .update({'read': true});
                      }
                      // Navigate to chat if message type
                      if ((type == 'message') && fromUid.isNotEmpty && context.mounted) {
                        Navigator.pop(context);
                        Navigator.push(context, MaterialPageRoute(
                          builder: (_) => ChatRoomScreen(
                            targetId: fromUid,
                            targetName: fromName.isNotEmpty ? fromName : 'User',
                          ),
                        ));
                      }
                    },
                    child: Container(
                      color: read ? Colors.white : const Color(0xFFF0F9FF),
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        // Icon
                        Container(
                          width: 44, height: 44,
                          decoration: BoxDecoration(
                            color: color.withValues(alpha: 0.1),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(_iconFor(type), color: color, size: 20),
                        ),
                        const SizedBox(width: 12),

                        // Content
                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Row(children: [
                              Expanded(
                                child: Text(text,
                                  style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: read ? FontWeight.w500 : FontWeight.w700,
                                    color: Colors.black87,
                                    height: 1.35,
                                  ),
                                ),
                              ),
                              if (!read)
                                Container(
                                  width: 8, height: 8,
                                  margin: const EdgeInsets.only(left: 8, top: 4),
                                  decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                                ),
                            ]),
                            const SizedBox(height: 4),
                            Row(children: [
                              if (ts != null)
                                Text(_timeAgo(ts.toDate()),
                                  style: TextStyle(fontSize: 11, color: Colors.grey[400])),
                              const Spacer(),

                              // Reply button — only for message type
                              if (type == 'message' && fromUid.isNotEmpty)
                                GestureDetector(
                                  onTap: () => _showQuickReply(context, doc.id, fromUid, fromName, myUid),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFEFF6FF),
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(color: const Color(0xFF0284C7).withValues(alpha: 0.3)),
                                    ),
                                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                                      const Icon(Icons.reply_rounded, size: 13, color: Color(0xFF0284C7)),
                                      const SizedBox(width: 4),
                                      const Text('Reply',
                                        style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
                                          color: Color(0xFF0284C7))),
                                    ]),
                                  ),
                                ),

                              // Mark as read — for unread non-message types
                              if (!read && type != 'message')
                                GestureDetector(
                                  onTap: () async {
                                    await FirebaseFirestore.instance
                                        .collection('users').doc(myUid)
                                        .collection('notifications').doc(doc.id)
                                        .update({'read': true});
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: Colors.grey[100],
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: const Text('Mark read',
                                      style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600,
                                        color: Colors.grey)),
                                  ),
                                ),
                            ]),
                          ]),
                        ),
                      ]),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ]),
    );
  }

  void _showQuickReply(BuildContext context, String notifId, String fromUid, String fromName, String myUid) {
    final ctrl = TextEditingController();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 16,
          top: 16, left: 16, right: 16,
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Row(children: [
            const Icon(Icons.reply_rounded, size: 16, color: Color(0xFF0284C7)),
            const SizedBox(width: 8),
            Text('Reply to $fromName',
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
          ]),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(
              child: TextField(
                controller: ctrl,
                autofocus: true,
                decoration: InputDecoration(
                  hintText: 'Type a reply...',
                  hintStyle: TextStyle(color: Colors.grey[400], fontSize: 13),
                  filled: true,
                  fillColor: const Color(0xFFF1F5F9),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(24),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                ),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: () async {
                final text = ctrl.text.trim();
                if (text.isEmpty) return;
                Navigator.pop(ctx);
                // Send the reply via NotificationService quickReply
                await FirebaseFirestore.instance
                    .collection('users').doc(myUid)
                    .collection('notifications').doc(notifId)
                    .update({'read': true}).catchError((_) {});
                final ids = [myUid, fromUid]..sort();
                final chatId = '${ids[0]}_${ids[1]}';
                await FirebaseFirestore.instance.collection('chats').doc(chatId)
                    .collection('messages').add({
                  'senderId': myUid,
                  'text': text,
                  'mediaType': 'text',
                  'isRead': false,
                  'timestamp': FieldValue.serverTimestamp(),
                });
                await FirebaseFirestore.instance.collection('chats').doc(chatId).set({
                  'participants': ids,
                  'lastMsg': text,
                  'lastMsgTime': FieldValue.serverTimestamp(),
                  'unreadCount.$fromUid': FieldValue.increment(1),
                }, SetOptions(merge: true));
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Reply sent to $fromName ✓'),
                      backgroundColor: const Color(0xFF0284C7),
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      duration: const Duration(seconds: 2),
                    ),
                  );
                }
              },
              child: Container(
                width: 44, height: 44,
                decoration: const BoxDecoration(
                  color: Color(0xFF0284C7),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.send_rounded, color: Colors.white, size: 20),
              ),
            ),
          ]),
        ]),
      ),
    );
  }
}

// ── Friends Horizontal Row ───────────────────────────────────────────
class _FriendsRow extends StatelessWidget {
  final String myUid;
  const _FriendsRow({required this.myUid});

  @override
  Widget build(BuildContext context) {
    if (myUid.isEmpty) return const SizedBox.shrink();
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('users').doc(myUid)
          .collection('friends')
          .where('status', isEqualTo: 'friends')
          .limit(20)
          .snapshots(),
      builder: (ctx, snap) {
        final docs = snap.data?.docs ?? [];
        if (docs.isEmpty) return const SizedBox.shrink();
        return SizedBox(
          height: 88,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            itemCount: docs.length,
            addAutomaticKeepAlives: false,
            separatorBuilder: (_, __) => const SizedBox(width: 14),
            itemBuilder: (ctx, i) {
              final uid = docs[i].id;
              return StreamBuilder<DocumentSnapshot>(
                stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
                builder: (_, uSnap) {
                  final d = uSnap.data?.data() as Map<String, dynamic>? ?? {};
                  final photo = d['photoURL'] as String? ?? '';
                  final name = d['username'] as String? ?? '?';
                  final online = d['isOnline'] == true;
                  return GestureDetector(
                    onTap: () => _openChat(ctx, uid, name, photo, myUid),
                    child: Column(children: [
                      Stack(children: [
                        CircleAvatar(
                          radius: 28,
                          backgroundColor: const Color(0xFF0284C7),
                          backgroundImage: photo.isNotEmpty && (photo.startsWith('http://') || photo.startsWith('https://')) ? NetworkImage(photo) : null,
                          child: photo.isEmpty
                            ? Text(name[0].toUpperCase(),
                                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18))
                            : null,
                        ),
                        if (online)
                          Positioned(bottom: 1, right: 1,
                            child: Container(width: 13, height: 13,
                              decoration: BoxDecoration(
                                color: const Color(0xFF10B981),
                                shape: BoxShape.circle,
                                border: Border.all(color: Colors.white, width: 2)))),
                      ]),
                      const SizedBox(height: 4),
                      SizedBox(width: 56,
                        child: Text(name,
                          style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: Color(0xFF374151)),
                          textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis)),
                    ]),
                  );
                },
              );
            },
          ),
        );
      },
    );
  }

  void _openChat(BuildContext ctx, String uid, String name, String photo, String myUid) {
    Navigator.push(ctx, MaterialPageRoute(
      builder: (_) => ChatRoomScreen(
        targetId: uid,
        targetName: name,
      ),
    ));
  }
}

// ── Lock Setup Sheet ──────────────────────────────────────────────────────────
class _LockSetupSheet extends StatefulWidget {
  final String chatId, chatName;
  final bool canBio;
  final VoidCallback onLocked;
  const _LockSetupSheet({required this.chatId, required this.chatName, required this.canBio, required this.onLocked});
  @override State<_LockSetupSheet> createState() => _LockSetupSheetState();
}

class _LockSetupSheetState extends State<_LockSetupSheet> {
  bool _useBio = false;
  String _pin = '';
  bool _pinMode = false;
  bool _loading = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom + 16),
      decoration: const BoxDecoration(color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(margin: const EdgeInsets.only(top: 10, bottom: 8), width: 40, height: 4,
          decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
        const SizedBox(height: 8),
        Container(padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: const Color(0xFF0284C7).withValues(alpha: 0.08), shape: BoxShape.circle),
          child: const Icon(Icons.lock_rounded, color: Color(0xFF0284C7), size: 36)),
        const SizedBox(height: 12),
        Text('Lock "${widget.chatName}"', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
        const SizedBox(height: 6),
        Text('Choose how to protect this chat', style: TextStyle(color: Colors.grey[500], fontSize: 13)),
        const SizedBox(height: 20),
        if (widget.canBio && !_pinMode) ...[
          Padding(padding: const EdgeInsets.symmetric(horizontal: 20),
            child: GestureDetector(
              onTap: () async {
                setState(() => _loading = true);
                final ok = await ChatLockService.authenticateBiometric();
                if (ok) {
                  await ChatLockService.setLock(widget.chatId, true);
                  Navigator.pop(context);
                  widget.onLocked();
                }
                setState(() => _loading = false);
              },
              child: Container(
                width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF0284C7), Color(0xFF7C3AED)],
                    begin: Alignment.centerLeft, end: Alignment.centerRight),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [BoxShadow(color: const Color(0xFF0284C7).withValues(alpha: 0.3), blurRadius: 12, offset: const Offset(0, 4))]),
                child: _loading
                  ? const Center(child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.fingerprint, color: Colors.white, size: 22),
                      SizedBox(width: 10),
                      Text('Use Biometrics', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16)),
                    ])))),
          const SizedBox(height: 12),
          TextButton(
            onPressed: () => setState(() => _pinMode = true),
            child: const Text('Use PIN instead', style: TextStyle(color: Color(0xFF0284C7), fontWeight: FontWeight.w700))),
        ] else ...[
          Padding(padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(children: [
              const Text('Set a 4-digit PIN', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
              const SizedBox(height: 12),
              TextField(
                keyboardType: TextInputType.number, maxLength: 4, obscureText: true,
                textAlign: TextAlign.center, autofocus: true,
                style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: 12),
                onChanged: (v) => setState(() => _pin = v),
                decoration: InputDecoration(
                  hintText: '••••', counterText: '',
                  filled: true, fillColor: const Color(0xFFF1F5F9),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none))),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    backgroundColor: _pin.length == 4 ? const Color(0xFF0284C7) : Colors.grey[300],
                    foregroundColor: Colors.white, elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                  onPressed: _pin.length == 4 ? () async {
                    await ChatLockService.setPin(widget.chatId, _pin);
                    await ChatLockService.setLock(widget.chatId, true);
                    Navigator.pop(context);
                    widget.onLocked();
                  } : null,
                  child: const Text('Set PIN & Lock', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)))),
            ])),
        ],
        const SizedBox(height: 8),
      ]),
    );
  }
}

// ── Quick Create Post (from chatlist) ─────────────────────────────────────────
class _QuickCreatePost extends StatefulWidget {
  final String myUid; final AuthService auth;
  const _QuickCreatePost({required this.myUid, required this.auth});
  @override State<_QuickCreatePost> createState() => _QuickCreatePostState();
}

class _QuickCreatePostState extends State<_QuickCreatePost> {
  final _ctrl = TextEditingController();
  final List<File> _images = [];
  bool _posting = false;

  @override void dispose() { _ctrl.dispose(); super.dispose(); }

  Future<void> _pickImages() async {
    if (_images.length >= 4) return;
    final picker = ImagePicker();
    final picked = await picker.pickMultiImage(imageQuality: 80, limit: 4 - _images.length);
    if (picked.isNotEmpty) setState(() => _images.addAll(picked.map((x) => File(x.path))));
  }

  Future<void> _post() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty && _images.isEmpty) return;
    setState(() => _posting = true);
    try {
      final imageUrls = <String>[];
      for (final img in _images) {
        final url = await FileService.uploadFile(img, 'post_author');
        if (url.isNotEmpty) imageUrls.add(url);
      }
      await FirebaseFirestore.instance.collection('posts').add({
        'authorId': widget.myUid,
        'authorName': widget.auth.userName ?? 'user',
        'authorPhoto': widget.auth.photoURL ?? '',
        'text': text, 'images': imageUrls, 'likes': [], 'commentCount': 0,
        'createdAt': FieldValue.serverTimestamp(),
      });
      if (mounted) { Navigator.pop(context); ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('✅ Post shared to Feed!'), backgroundColor: const Color(0xFF0284C7),
        behavior: SnackBarBehavior.floating, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)))); }
    } catch (_) { setState(() => _posting = false); }
  }

  @override
  Widget build(BuildContext context) {
    final auth = widget.auth;
    final photo = auth.photoURL ?? '';
    final name = auth.userName ?? 'user';
    final canPost = _ctrl.text.trim().isNotEmpty || _images.isNotEmpty;

    return Container(
      height: MediaQuery.of(context).size.height * 0.75,
      decoration: const BoxDecoration(color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      child: Column(children: [
        Container(margin: const EdgeInsets.only(top: 10), width: 40, height: 4,
          decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
        Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 0), child: Row(children: [
          ZyloAvatar(photoUrl: photo, radius: 18),
          const SizedBox(width: 10),
          Expanded(child: Text('@$name', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15))),
          _posting
            ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF0284C7)))
            : GestureDetector(onTap: canPost ? _post : null,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                  decoration: BoxDecoration(
                    gradient: canPost ? const LinearGradient(colors: [Color(0xFF0284C7), Color(0xFF7C3AED)]) : null,
                    color: canPost ? null : Colors.grey[200],
                    borderRadius: BorderRadius.circular(20)),
                  child: Text('Post', style: TextStyle(
                    fontWeight: FontWeight.w800, fontSize: 14,
                    color: canPost ? Colors.white : Colors.grey[400])))),
        ])),
        Expanded(child: Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(child: TextField(
              controller: _ctrl, maxLines: null, maxLength: 500,
              onChanged: (_) => setState(() {}),
              style: const TextStyle(fontSize: 15, color: Colors.black87, height: 1.5),
              decoration: InputDecoration(
                hintText: "What's on your mind?",
                hintStyle: TextStyle(color: Colors.grey[400], fontSize: 15),
                border: InputBorder.none,
                counterStyle: TextStyle(color: Colors.grey[400], fontSize: 11)))),
            if (_images.isNotEmpty) SizedBox(height: 90,
              child: ListView.separated(
                scrollDirection: Axis.horizontal, itemCount: _images.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (_, i) => Stack(children: [
                  ClipRRect(borderRadius: BorderRadius.circular(12),
                    child: Image.file(_images[i], width: 90, height: 90, fit: BoxFit.cover)),
                  Positioned(top: 4, right: 4, child: GestureDetector(
                    onTap: () => setState(() => _images.removeAt(i)),
                    child: Container(width: 22, height: 22,
                      decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                      child: const Icon(Icons.close, size: 14, color: Colors.white)))),
                ]))),
          ]))),
        Container(
          padding: EdgeInsets.only(left: 16, right: 16, top: 8, bottom: MediaQuery.of(context).viewInsets.bottom + 12),
          decoration: BoxDecoration(border: Border(top: BorderSide(color: Colors.grey.withValues(alpha: 0.12))), color: Colors.white),
          child: Row(children: [
            GestureDetector(onTap: _pickImages,
              child: Container(padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: const Color(0xFF0284C7).withValues(alpha: 0.08), borderRadius: BorderRadius.circular(10)),
                child: Row(children: [
                  const Icon(Icons.image_outlined, color: Color(0xFF0284C7), size: 20),
                  const SizedBox(width: 5),
                  Text('${_images.length}/4', style: const TextStyle(color: Color(0xFF0284C7), fontWeight: FontWeight.w700, fontSize: 12)),
                ]))),
            const Spacer(),
            Text('${_ctrl.text.length}/500', style: TextStyle(fontSize: 11, color: Colors.grey[400])),
          ])),
      ]),
    );
  }
}


// ── Admin Banner Widget ───────────────────────────────────────────────────────
class _AdminBannerWidget extends StatelessWidget {
  const _AdminBannerWidget();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance.collection('appConfig').doc('banner').snapshots(),
      builder: (context, snap) {
        if (!snap.hasData) return const SizedBox.shrink();
        final d = snap.data?.data() as Map<String, dynamic>? ?? {};
        if (d['active'] != true) return const SizedBox.shrink();
        final mediaUrl = d['mediaUrl'] as String? ?? '';
        final title    = d['title']    as String? ?? '';
        final linkUrl  = d['linkUrl']  as String? ?? '';
        final type     = d['type']     as String? ?? 'image';
        if (mediaUrl.isEmpty) return const SizedBox.shrink();

        return GestureDetector(
          onTap: () async {
            if (linkUrl.isNotEmpty) {
              final uri = Uri.tryParse(linkUrl);
              if (uri != null) await launchUrl(uri, mode: LaunchMode.externalApplication);
            }
          },
          child: Container(
            margin: const EdgeInsets.fromLTRB(12, 4, 12, 4),
            height: 120,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              color: const Color(0xFF1A1A1A),
            ),
            clipBehavior: Clip.hardEdge,
            child: Stack(fit: StackFit.expand, children: [
              // Media
              if (type == 'image')
                ZyloCachedImage(url: mediaUrl, fit: BoxFit.cover,
                  errorWidget: Container(color: const Color(0xFF1A1A1A))),
              // Gradient overlay
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter, end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Colors.black.withValues(alpha: 0.55)]))),
              // Title
              if (title.isNotEmpty)
                Positioned(bottom: 12, left: 14, right: 14,
                  child: Text(title, style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14,
                    shadows: [Shadow(color: Colors.black54, blurRadius: 4)]))),
              // Official badge
              Positioned(top: 10, right: 10,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.5),
                    borderRadius: BorderRadius.circular(20)),
                  child: const Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.verified, color: Color(0xFF0284C7), size: 12),
                    SizedBox(width: 4),
                    Text('Official', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700)),
                  ]))),
            ]),
          ),
        );
      },
    );
  }
}


// ── WhatsApp-style Skeleton Loader ────────────────────────────────────────────
class _ChatSkeletonLoader extends StatefulWidget {
  const _ChatSkeletonLoader();
  @override State<_ChatSkeletonLoader> createState() => _ChatSkeletonLoaderState();
}

class _ChatSkeletonLoaderState extends State<_ChatSkeletonLoader>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))
      ..repeat(reverse: true);
    _anim = Tween<double>(begin: 0.3, end: 0.9).animate(
        CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  Widget _shimmerBox({double width = double.infinity, double height = 14, double radius = 8}) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, __) => Container(
        width: width, height: height,
        decoration: BoxDecoration(
          color: Colors.grey.withValues(alpha: _anim.value),
          borderRadius: BorderRadius.circular(radius),
        ),
      ),
    );
  }

  Widget _skeletonTile() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(children: [
        // Avatar circle
        AnimatedBuilder(
          animation: _anim,
          builder: (_, __) => Container(
            width: 52, height: 52,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.grey.withValues(alpha: _anim.value),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            _shimmerBox(width: 120, height: 13),
            _shimmerBox(width: 40, height: 11),
          ]),
          const SizedBox(height: 8),
          _shimmerBox(width: double.infinity, height: 11),
          const SizedBox(height: 4),
          _shimmerBox(width: 100, height: 11),
        ])),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.only(top: 8),
      itemCount: 10,
      separatorBuilder: (_, __) => const Divider(height: 1, indent: 80, endIndent: 16),
      itemBuilder: (_, __) => _skeletonTile(),
    );
  }
}
