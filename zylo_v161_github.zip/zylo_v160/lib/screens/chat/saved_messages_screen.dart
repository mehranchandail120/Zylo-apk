import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../widgets/zylo_cached_image.dart';
import 'package:intl/intl.dart';
import '../../services/firestore_service.dart';

class SavedMessagesScreen extends StatefulWidget {
  const SavedMessagesScreen({super.key});
  @override State<SavedMessagesScreen> createState() => _SavedMessagesScreenState();
}

class _SavedMessagesScreenState extends State<SavedMessagesScreen> {
  final FirestoreService _fs = FirestoreService();
  String _search = '';
  final _searchCtrl = TextEditingController();

  static const _blue = Color(0xFF0284C7);
  static const _bg   = Color(0xFFF0F4F8);

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Saved Messages',
          style: TextStyle(color: _blue, fontSize: 18, fontWeight: FontWeight.w900)),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(56),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: TextField(
              controller: _searchCtrl,
              onChanged: (v) => setState(() => _search = v.toLowerCase()),
              decoration: InputDecoration(
                hintText: 'Search saved messages...',
                hintStyle: TextStyle(color: Colors.grey[400], fontSize: 13),
                filled: true,
                fillColor: const Color(0xFFF0F4F8),
                prefixIcon: Icon(Icons.search_rounded, color: Colors.grey[400], size: 20),
                suffixIcon: _search.isNotEmpty
                    ? IconButton(
                        icon: Icon(Icons.close_rounded, color: Colors.grey[400], size: 18),
                        onPressed: () { _searchCtrl.clear(); setState(() => _search = ''); })
                    : null,
                contentPadding: const EdgeInsets.symmetric(vertical: 10),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
          ),
        ),
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: _fs.savedMessagesStream(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: _blue));
          }
          final all = snap.data ?? [];
          final filtered = _search.isEmpty ? all : all.where((m) {
            final text = (m['text'] as String? ?? '').toLowerCase();
            final partner = (m['chatPartnerName'] as String? ?? '').toLowerCase();
            return text.contains(_search) || partner.contains(_search);
          }).toList();

          if (filtered.isEmpty) {
            return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.bookmark_border_rounded, size: 72, color: Colors.grey[300]),
              const SizedBox(height: 12),
              Text(_search.isNotEmpty ? 'No results found' : 'No saved messages yet',
                style: TextStyle(color: Colors.grey[500], fontSize: 15, fontWeight: FontWeight.w600)),
              if (_search.isEmpty) ...[
                const SizedBox(height: 6),
                Text('Long-press any message → Save',
                  style: TextStyle(color: Colors.grey[400], fontSize: 13)),
              ],
            ]));
          }

          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
            itemCount: filtered.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, i) => _SavedTile(
              msg: filtered[i],
              onUnsave: () => _unsave(filtered[i]),
            ),
          );
        },
      ),
    );
  }

  Future<void> _unsave(Map<String, dynamic> msg) async {
    final fid = msg['firestoreId'] as String?;
    if (fid == null) return;
    await _fs.unsaveMessage(fid);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Removed from saved'), duration: Duration(seconds: 2)));
    }
  }
}

// ─── Single saved message tile ────────────────────────────────────────────────
class _SavedTile extends StatelessWidget {
  final Map<String, dynamic> msg;
  final VoidCallback onUnsave;
  const _SavedTile({required this.msg, required this.onUnsave});

  static const _blue = Color(0xFF0284C7);

  String get _partnerName => msg['chatPartnerName'] as String? ?? 'Unknown';
  bool get _isMe => msg['isMe'] as bool? ?? false;
  String? get _text => msg['text'] as String?;
  String? get _imageUrl => msg['imageUrl'] as String?;
  String? get _audioPath => msg['audioPath'] as String?;
  String? get _docName => msg['docName'] as String?;
  String? get _videoUrl => msg['videoUrl'] as String?;
  DateTime? get _savedAt {
    final ts = msg['savedAt'];
    if (ts == null) return null;
    try {
      // Firestore Timestamp has .toDate()
      return (ts as dynamic).toDate() as DateTime;
    } catch (_) { return null; }
  }
  DateTime? get _originalTs => msg['timestamp'] as DateTime?;

  String _formatDate(DateTime? dt) {
    if (dt == null) return '';
    final now = DateTime.now();
    if (now.difference(dt).inDays == 0) return DateFormat('HH:mm').format(dt);
    if (now.difference(dt).inDays < 7) return DateFormat('EEE').format(dt);
    return DateFormat('dd MMM').format(dt);
  }

  @override
  Widget build(BuildContext context) {
    return Dismissible(
      key: Key(msg['firestoreId'] as String? ?? UniqueKey().toString()),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(
          color: Colors.red.shade50, borderRadius: BorderRadius.circular(16)),
        child: const Icon(Icons.bookmark_remove_rounded, color: Colors.red, size: 26),
      ),
      confirmDismiss: (_) async {
        onUnsave();
        return true;
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 8, offset: const Offset(0, 2))],
        ),
        child: Material(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(16),
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onLongPress: () => _showOptions(context),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                // Header: from who + time
                Row(children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: _blue.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(20)),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(_isMe ? Icons.person_rounded : Icons.chat_rounded,
                        size: 12, color: _blue),
                      const SizedBox(width: 4),
                      Text(_isMe ? 'You → $_partnerName' : '$_partnerName → You',
                        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: _blue)),
                    ]),
                  ),
                  const Spacer(),
                  if (_savedAt != null)
                    Text(_formatDate(_savedAt),
                      style: TextStyle(fontSize: 11, color: Colors.grey[400])),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: onUnsave,
                    child: Icon(Icons.bookmark_rounded, color: _blue, size: 18)),
                ]),
                const SizedBox(height: 10),

                // Content
                if (_imageUrl != null) _ImageContent(url: _imageUrl!),
                if (_videoUrl != null && _imageUrl == null) _MediaChip(
                  icon: Icons.videocam_rounded, label: 'Video', color: Colors.purple),
                if (_audioPath != null) _MediaChip(
                  icon: Icons.mic_rounded, label: 'Voice Message', color: Colors.orange),
                if (_docName != null) _MediaChip(
                  icon: Icons.insert_drive_file_rounded, label: _docName!, color: Colors.indigo),
                if (_text != null && _text!.isNotEmpty)
                  Text(_text!,
                    maxLines: 4, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 14, height: 1.4, color: Color(0xFF1A1A1A))),
                if (_text == null && _imageUrl == null && _audioPath == null && _docName == null && _videoUrl == null)
                  Text('Media message', style: TextStyle(fontSize: 13, color: Colors.grey[400])),

                // Original time
                if (_originalTs != null) ...[
                  const SizedBox(height: 8),
                  Text('Sent ${_formatDate(_originalTs)} · ${DateFormat('HH:mm').format(_originalTs!)}',
                    style: TextStyle(fontSize: 11, color: Colors.grey[400])),
                ],
              ]),
            ),
          ),
        ),
      ),
    );
  }

  void _showOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 36, height: 4, margin: const EdgeInsets.only(bottom: 16),
            decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2))),
          if (_text != null && _text!.isNotEmpty)
            ListTile(
              leading: const Icon(Icons.copy_rounded, color: Colors.blue),
              title: const Text('Copy Text', style: TextStyle(fontWeight: FontWeight.w600)),
              onTap: () {
                Navigator.pop(context);
                Clipboard.setData(ClipboardData(text: _text!));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Copied!')));
              },
            ),
          ListTile(
            leading: const Icon(Icons.bookmark_remove_rounded, color: Colors.red),
            title: const Text('Remove from Saved', style: TextStyle(fontWeight: FontWeight.w600, color: Colors.red)),
            onTap: () { Navigator.pop(context); onUnsave(); },
          ),
        ]),
      ),
    );
  }
}

class _ImageContent extends StatelessWidget {
  final String url;
  const _ImageContent({required this.url});
  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(10),
    child: ZyloCachedImage(
      url: url,
      height: 160, width: null,
      fit: BoxFit.cover,
      placeholder: (_, __) => Container(height: 160, color: Colors.grey[200],
        child: const Center(child: CircularProgressIndicator(strokeWidth: 2))),
      errorWidget: Container(height: 160, color: Colors.grey[200],
        child: const Icon(Icons.broken_image_rounded, color: Colors.grey)),
    ),
  );
}

class _MediaChip extends StatelessWidget {
  final IconData icon; final String label; final Color color;
  const _MediaChip({required this.icon, required this.label, required this.color});
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 6),
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(
      color: color.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(8)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 14, color: color),
      const SizedBox(width: 6),
      Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: color)),
    ]),
  );
}
