import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../widgets/zylo_cached_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../../services/firestore_service.dart';
import '../profile/view_profile_screen.dart';

class ChatInfoScreen extends StatefulWidget {
  final String targetName;
  final String targetId;
  final String? targetPhoto;
  final Map<String, dynamic>? userData;

  const ChatInfoScreen({
    super.key,
    required this.targetName,
    required this.targetId,
    this.targetPhoto,
    this.userData,
  });

  @override
  State<ChatInfoScreen> createState() => _ChatInfoScreenState();
}

class _ChatInfoScreenState extends State<ChatInfoScreen>
    with SingleTickerProviderStateMixin {
  bool _isMuted = false;
  bool _isBlocked = false;
  bool _screenshotAllowed = true;
  bool _mediaAccessAllowed = true;
  late TabController _tabController;
  final FirestoreService _fs = FirestoreService();

  // No more hardcoded demo files — files are loaded from real chat messages

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    // Load real block state from Firestore
    _fs.isUserBlocked(widget.targetId).listen((blocked) {
      if (mounted) setState(() => _isBlocked = blocked);
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _toggleBlock() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(_isBlocked ? 'Unblock ${widget.targetName}?' : 'Block ${widget.targetName}?'),
        content: Text(
          _isBlocked
              ? 'They will be able to message you again.'
              : 'They won\'t be able to send you messages.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              if (_isBlocked) {
                await _fs.unblockUser(widget.targetId);
              } else {
                await _fs.blockUser(widget.targetId);
              }
              if (!mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(_isBlocked ? '${widget.targetName} unblocked' : '${widget.targetName} blocked'),
                  backgroundColor: _isBlocked ? Colors.green : Colors.red,
                  behavior: SnackBarBehavior.floating,
                ),
              );
            },
            child: Text(
              _isBlocked ? 'Unblock' : 'Block',
              style: TextStyle(color: _isBlocked ? Colors.green : Colors.red, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

  void _openUserMap(BuildContext context) {
    showModalBottomSheet(
      context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.9, maxChildSize: 0.95, minChildSize: 0.5,
        builder: (ctx, sc) => Container(
          decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
          child: Column(children: [
            Container(margin: const EdgeInsets.only(top: 10, bottom: 8), width: 40, height: 4,
              decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
            Padding(padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
              child: Row(children: [
                const Icon(Icons.location_on, color: Color(0xFF0284C7), size: 20),
                const SizedBox(width: 8),
                Text("${widget.targetName}'s Location",
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                const Spacer(),
                GestureDetector(onTap: () => Navigator.pop(ctx),
                  child: const Icon(Icons.close, color: Colors.grey)),
              ])),
            const Divider(height: 1),
            Expanded(child: StreamBuilder<DocumentSnapshot>(
              stream: FirebaseFirestore.instance.collection('users').doc(widget.targetId).snapshots(),
              builder: (context, snap) {
                final ud = snap.data?.data() as Map<String, dynamic>? ?? {};
                final lat = ud['lat'] as double?;
                final lng = ud['lng'] as double?;
                final locationEnabled = ud['locationSharingEnabled'] == true && lat != null && lng != null;
                final photo = ud['photoURL'] as String? ?? '';
                if (!locationEnabled) {
                  return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(Icons.location_off_outlined, size: 60, color: Colors.grey[300]),
                    const SizedBox(height: 12),
                    Text('${widget.targetName} hasn\'t shared their location',
                      style: const TextStyle(color: Colors.grey, fontSize: 15, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 8),
                    Text('Location sharing is disabled', style: TextStyle(color: Colors.grey[400], fontSize: 13)),
                  ]));
                }
                return _UserMapView(name: widget.targetName, photo: photo, lat: lat!, lng: lng!);
              },
            )),
          ]),
        ),
      ),
    );
  }

  void _removeFriend() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Remove ${widget.targetName}?'),
        content: const Text('This person will be removed from your friends list.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('${widget.targetName} removed from friends'),
                  behavior: SnackBarBehavior.floating,
                ),
              );
            },
            child: const Text('Remove', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final photo = widget.targetPhoto ?? widget.userData?['photoURL'] ?? '';
    final bio = widget.userData?['bio'] ?? 'Hey there! I am using Zylo.';
    final phone = widget.userData?['phone'] ?? 'Not added';

    return Scaffold(
      backgroundColor: const Color(0xFFF2F2F7),
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 280,
            pinned: true,
            backgroundColor: const Color(0xFF0284C7),
            titleSpacing: 0,
            title: Row(
              children: [
                CircleAvatar(
                  radius: 16,
                  backgroundColor: Colors.white24,
                  child: ClipOval(
                    child: photo.isNotEmpty
                        ? ZyloCachedImage(
                            url: photo, width: 32, height: 32, fit: BoxFit.cover,
                            errorWidget: const Icon(Icons.person, size: 16, color: Colors.white))
                        : const Icon(Icons.person, size: 16, color: Colors.white),
                  ),
                ),
                const SizedBox(width: 10),
                Text('@${widget.targetName}',
                  style: const TextStyle(
                    color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800)),
              ],
            ),
            flexibleSpace: FlexibleSpaceBar(
              collapseMode: CollapseMode.parallax,
              background: Stack(
                fit: StackFit.expand,
                children: [
                  photo.isNotEmpty
                      ? ZyloCachedImage(url: photo, fit: BoxFit.cover)
                      : Container(
                          decoration: const BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Color(0xFF0284C7), Color(0xFF0EA5E9)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                          ),
                        ),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.transparent, Colors.black.withValues(alpha: 0.6)],
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 20,
                    left: 20,
                    right: 20,
                    child: Row(
                      children: [
                        GestureDetector(
                          onTap: photo.isNotEmpty ? () => Navigator.push(context, MaterialPageRoute(
                            builder: (_) => _FullPhotoView(photoUrl: photo, name: widget.targetName))) : null,
                          child: CircleAvatar(
                            radius: 36,
                            backgroundColor: Colors.white,
                            child: ClipOval(
                              child: photo.isNotEmpty
                                  ? ZyloCachedImage(url: photo, width: 68, height: 68, fit: BoxFit.cover,
                                      errorWidget: const Icon(Icons.person, size: 36))
                                  : const Icon(Icons.person, size: 36, color: Colors.grey),
                            ),
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '@${widget.targetName}',
                                style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 4),
                              if (_isBlocked)
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                  decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(20)),
                                  child: const Text('BLOCKED',
                                      style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                                )
                              else
                                const Text('Active recently',
                                    style: TextStyle(color: Colors.white70, fontSize: 13)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: Column(
              children: [
                const SizedBox(height: 20),

                const SizedBox(height: 4),

                // Bio + Phone + Friends (realtime from Firestore)
                StreamBuilder<DocumentSnapshot>(
                  stream: FirebaseFirestore.instance.collection('users').doc(widget.targetId).snapshots(),
                  builder: (context, liveSnap) {
                    final liveUd = liveSnap.data?.data() as Map<String, dynamic>? ?? {};
                    final liveBio = (liveUd['bio'] as String? ?? '').isNotEmpty
                        ? liveUd['bio'] as String
                        : bio;
                    final livePhone = (liveUd['phone'] as String? ?? '').isNotEmpty
                        ? liveUd['phone'] as String
                        : phone;
                    return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('BIO', style: TextStyle(color: Colors.grey, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1)),
                        const SizedBox(height: 6),
                        Text(liveBio, style: const TextStyle(fontSize: 15, height: 1.5)),
                        const Divider(height: 24),
                        Row(
                          children: [
                            const Icon(Icons.phone_outlined, color: Colors.grey, size: 18),
                            const SizedBox(width: 10),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('Phone', style: TextStyle(color: Colors.grey, fontSize: 11)),
                                Text(livePhone, style: const TextStyle(fontWeight: FontWeight.w600)),
                              ],
                            ),
                          ],
                        ),
                        const Divider(height: 24),
                        // Distance row (only if location enabled)
                        StreamBuilder<DocumentSnapshot>(
                          stream: FirebaseFirestore.instance.collection('users').doc(widget.targetId).snapshots(),
                          builder: (context, snap) {
                            final ud = snap.data?.data() as Map<String, dynamic>? ?? {};
                            final lat = ud['lat'] as double?;
                            final lng = ud['lng'] as double?;
                            final locationEnabled = ud['locationSharingEnabled'] == true && lat != null && lng != null;
                            if (!locationEnabled) return const SizedBox.shrink();
                            return Column(children: [
                              const Divider(height: 24),
                              Row(children: [
                                const Icon(Icons.near_me_outlined, color: Colors.teal, size: 18),
                                const SizedBox(width: 10),
                                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  const Text('Distance', style: TextStyle(color: Colors.grey, fontSize: 11)),
                                  Text('Location shared 📍', style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.teal)),
                                ]),
                              ]),
                            ]);
                          },
                        ),
                        StreamBuilder<DocumentSnapshot>(
                          stream: FirebaseFirestore.instance
                              .collection('users').doc(widget.targetId).snapshots(),
                          builder: (context, fSnap) {
                            return GestureDetector(
                              onTap: () => Navigator.push(context,
                                MaterialPageRoute(builder: (_) => ViewProfileScreen(targetUid: widget.targetId))),
                              child: Row(
                                children: [
                                  const Icon(Icons.person_outline_rounded, color: Colors.grey, size: 18),
                                  const SizedBox(width: 10),
                                  const Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text('Profile', style: TextStyle(color: Colors.grey, fontSize: 11)),
                                      Text('View public profile', style: TextStyle(fontWeight: FontWeight.w600)),
                                    ],
                                  ),
                                  const Spacer(),
                                  const Text('View', style: TextStyle(color: Color(0xFF0284C7), fontWeight: FontWeight.bold, fontSize: 13)),
                                  const Icon(Icons.chevron_right, color: Color(0xFF0284C7), size: 18),
                                ],
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  ); // end live StreamBuilder
                  },
                ),

                const SizedBox(height: 20),

                // Settings Toggles
                _buildSectionLabel('SETTINGS'),
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                  child: Column(
                    children: [
                      _switchTile(Icons.notifications_none, 'Mute Notifications', Colors.red, _isMuted,
                          (v) => setState(() => _isMuted = v)),
                      const Divider(height: 1, indent: 56),
                      _switchTile(Icons.screenshot_monitor, 'Allow Screenshots', Colors.purple, _screenshotAllowed, (v) {
                        setState(() => _screenshotAllowed = v);
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text(v ? 'Screenshots enabled' : 'Screenshots disabled'),
                          behavior: SnackBarBehavior.floating,
                        ));
                      }),
                      const Divider(height: 1, indent: 56),
                      _switchTile(Icons.perm_media_outlined, 'Allow Media Access', Colors.teal, _mediaAccessAllowed,
                          (v) => setState(() => _mediaAccessAllowed = v)),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // Media Section
                _buildMediaSection(),

                const SizedBox(height: 20),

                // Block / Remove / Report
                _buildSectionLabel('ACTIONS'),
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                  child: Column(
                    children: [
                      _isBlocked
                          ? _actionTile(Icons.lock_open, 'Unblock ${widget.targetName}', Colors.green, _toggleBlock)
                          : _actionTile(Icons.block, 'Block ${widget.targetName}', Colors.red, _toggleBlock),
                      const Divider(height: 1, indent: 56),
                      _actionTile(Icons.flag_outlined, 'Report ${widget.targetName}', Colors.red, () => _showReportSheet()),
                    ],
                  ),
                ),

                const SizedBox(height: 40),
              ],
            ),
          ),
        ],
      ),
    );
  }


  Widget _buildMediaSection() {
    return StreamBuilder<QuerySnapshot>(
      stream: _fs.getMessages(widget.targetId),
      builder: (context, snap) {
        final docs = snap.data?.docs ?? [];
        final photos = <String>[];
        final videos = <String>[];
        final files = <Map<String, dynamic>>[];
        for (final doc in docs) {
          final d = doc.data() as Map<String, dynamic>;
          if (d['mediaType'] == 'image' && d['imageUrl'] != null) photos.add(d['imageUrl'] as String);
          if (d['mediaType'] == 'video' && d['videoUrl'] != null) videos.add(d['videoUrl'] as String);
          if (d['mediaType'] == 'file' && d['fileUrl'] != null) {
            files.add({
              'name': d['fileName'] as String? ?? 'File',
              'size': d['fileSize'] as String? ?? '',
              'url':  d['fileUrl']  as String? ?? '',
            });
          }
        }
        final totalCount = photos.length + videos.length + files.length;

        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Media, Links & Docs',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    Text('$totalCount', style: const TextStyle(color: Colors.grey)),
                  ],
                ),
              ),
              TabBar(
                controller: _tabController,
                labelColor: const Color(0xFF0284C7),
                unselectedLabelColor: Colors.grey,
                indicatorColor: const Color(0xFF0284C7),
                tabs: const [
                  Tab(text: 'Photos'),
                  Tab(text: 'Videos'),
                  Tab(text: 'Files'),
                ],
              ),
              SizedBox(
                height: 220,
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    // Photos tab - real images from chat
                    !_mediaAccessAllowed
                        ? _mediaLockedWidget('Photos')
                        : photos.isEmpty
                            ? _emptyMediaWidget('No photos yet')
                            : Padding(
                                padding: const EdgeInsets.all(8),
                                child: GridView.builder(
                                  physics: const NeverScrollableScrollPhysics(),
                                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 3, crossAxisSpacing: 4, mainAxisSpacing: 4),
                                  itemCount: photos.length,
                                  itemBuilder: (_, i) => ClipRRect(
                                    borderRadius: BorderRadius.circular(8),
                                    child: ZyloCachedImage(
                                      url: photos[i],
                                      fit: BoxFit.cover,
                                      placeholder: (_, __) => Container(color: Colors.grey[200]),
                                      errorWidget: Container(color: Colors.grey[200], child: const Icon(Icons.image)),
                                    ),
                                  ),
                                ),
                              ),
                    // Videos tab - real videos from chat
                    !_mediaAccessAllowed
                        ? _mediaLockedWidget('Videos')
                        : videos.isEmpty
                            ? _emptyMediaWidget('No videos yet')
                            : Padding(
                                padding: const EdgeInsets.all(8),
                                child: GridView.builder(
                                  physics: const NeverScrollableScrollPhysics(),
                                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 3, crossAxisSpacing: 4, mainAxisSpacing: 4),
                                  itemCount: videos.length,
                                  itemBuilder: (_, i) => Stack(
                                    fit: StackFit.expand,
                                    children: [
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(8),
                                        child: Container(color: Colors.black87,
                                          child: const Center(child: Icon(Icons.videocam, color: Colors.white54, size: 30))),
                                      ),
                                      Center(
                                        child: Container(
                                          padding: const EdgeInsets.all(6),
                                          decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
                                          child: const Icon(Icons.play_arrow, color: Colors.white, size: 18),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                    // Files tab — real files sent in chat
                    files.isEmpty
                        ? _emptyMediaWidget('No files yet')
                        : ListView.separated(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      itemCount: files.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        final f = files[i];
                        final name = f['name'] as String? ?? 'File';
                        final size = f['size'] as String? ?? '';
                        final ext  = name.contains('.') ? name.split('.').last.toLowerCase() : '';
                        IconData icon; Color color;
                        if (ext == 'pdf') { icon = Icons.picture_as_pdf; color = Colors.red; }
                        else if (['zip','rar','7z'].contains(ext)) { icon = Icons.folder_zip; color = Colors.orange; }
                        else if (['doc','docx'].contains(ext)) { icon = Icons.description; color = Colors.blue; }
                        else { icon = Icons.insert_drive_file; color = Colors.grey; }
                        return ListTile(
                          dense: true,
                          leading: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: color.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Icon(icon, color: color, size: 22),
                          ),
                          title: Text(name,
                              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                          subtitle: size.isNotEmpty ? Text(size,
                              style: const TextStyle(color: Colors.grey, fontSize: 11)) : null,
                          trailing: const Icon(Icons.download_outlined, color: Color(0xFF0284C7)),
                        );
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }

  Widget _emptyMediaWidget(String msg) {
    return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(Icons.perm_media_outlined, size: 40, color: Colors.grey[300]),
      const SizedBox(height: 8),
      Text(msg, style: TextStyle(color: Colors.grey[400], fontSize: 13)),
    ]));
  }

  Widget _mediaLockedWidget(String type) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.lock_outline, color: Colors.grey[400], size: 36),
          const SizedBox(height: 8),
          Text('$type access disabled', style: TextStyle(color: Colors.grey[500])),
          TextButton(
            onPressed: () => setState(() => _mediaAccessAllowed = true),
            child: const Text('Enable Media Access'),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionLabel(String label) {
    return Padding(
      padding: const EdgeInsets.only(left: 24, bottom: 8),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Text(label,
            style: const TextStyle(color: Colors.grey, fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1)),
      ),
    );
  }

  Widget _switchTile(IconData icon, String title, Color color, bool value, Function(bool) onChanged) {
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(7),
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(8)),
        child: Icon(icon, color: Colors.white, size: 18),
      ),
      title: Text(title, style: const TextStyle(fontSize: 15)),
      trailing: Switch(value: value, onChanged: onChanged, activeColor: const Color(0xFF0284C7)),
    );
  }

  Widget _actionTile(IconData icon, String title, Color color, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, color: color),
      title: Text(title, style: TextStyle(color: color, fontWeight: FontWeight.w600)),
      onTap: onTap,
    );
  }

  Widget _actionBtn(IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: color.withValues(alpha: 0.1), shape: BoxShape.circle),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(height: 6),
          Text(label, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  void _showReportSheet() {
    final reasons = ['Spam or Unwanted Messages', 'Harassment or Bullying',
      'Fake Profile', 'Inappropriate Content', 'Threats or Violence', 'Other'];
    int? selected;
    showModalBottomSheet(
      context: context, backgroundColor: Colors.white, isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => StatefulBuilder(builder: (ctx, setS) => SafeArea(
        child: Padding(padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10)))),
            Row(children: [
              Container(width: 42, height: 42,
                decoration: BoxDecoration(color: Colors.red.withValues(alpha: 0.1), shape: BoxShape.circle),
                child: const Icon(Icons.flag_rounded, color: Colors.red, size: 22)),
              const SizedBox(width: 12),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Report ${widget.targetName}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                Text('Help us keep Zylo safe', style: TextStyle(fontSize: 12, color: Colors.grey[500])),
              ]),
            ]),
            const SizedBox(height: 16),
            ...reasons.asMap().entries.map((e) {
              final i = e.key; final r = e.value;
              return GestureDetector(
                onTap: () => setS(() => selected = i),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    color: selected == i ? const Color(0xFF0284C7).withValues(alpha: 0.06) : Colors.grey[50],
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: selected == i ? const Color(0xFF0284C7) : Colors.grey[200]!)),
                  child: Row(children: [
                    Expanded(child: Text(r, style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13,
                      color: selected == i ? const Color(0xFF0284C7) : Colors.black87))),
                    if (selected == i) const Icon(Icons.check_circle_rounded, color: Color(0xFF0284C7), size: 18),
                  ])));
            }),
            const SizedBox(height: 12),
            SizedBox(width: double.infinity, child: ElevatedButton(
              onPressed: selected != null ? () {
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                  content: Text('✅ Report submitted. We will review within 24 hours.'),
                  backgroundColor: Colors.green, behavior: SnackBarBehavior.floating));
              } : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                disabledBackgroundColor: Colors.grey[300],
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
              child: const Text('Submit Report', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)))),
          ])),
      )));
  }

  void _showFriendsList(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.55,
        maxChildSize: 0.90,
        minChildSize: 0.35,
        builder: (ctx, sc) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: Column(children: [
            const SizedBox(height: 8),
            Container(width: 40, height: 4,
                decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2))),
            const SizedBox(height: 12),
            Text('Friends of ${widget.targetName}',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 8),
            const Divider(height: 1),
            Expanded(child: StreamBuilder<DocumentSnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('users')
                  .doc(widget.targetId)
                  .snapshots(),
              builder: (context, snap) {
                final ud = snap.data?.data() as Map<String, dynamic>? ?? {};
                final friendIds = (ud['friends'] as List?)?.cast<String>() ?? [];
                if (snap.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator(color: Color(0xFF0284C7)));
                }
                if (friendIds.isEmpty) {
                  return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(Icons.people_outline, size: 48, color: Colors.grey[300]),
                    const SizedBox(height: 10),
                    Text('No friends yet', style: TextStyle(color: Colors.grey[400], fontSize: 14)),
                  ]));
                }
                return StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('users')
                      .where(FieldPath.documentId, whereIn: friendIds.take(30).toList())
                      .snapshots(),
                  builder: (context, fSnap) {
                    if (!fSnap.hasData) {
                      return const Center(child: CircularProgressIndicator(color: Color(0xFF0284C7)));
                    }
                    final friends = fSnap.data!.docs;
                    if (friends.isEmpty) {
                      return Center(child: Text('No friends found',
                          style: TextStyle(color: Colors.grey[400], fontSize: 14)));
                    }
                    return ListView.separated(
                      controller: sc,
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      itemCount: friends.length,
                      separatorBuilder: (_, __) => const Divider(height: 1, indent: 56),
                      itemBuilder: (_, i) {
                        final f = friends[i].data() as Map<String, dynamic>;
                        final fname = f['username'] as String? ?? 'User';
                        final fphoto = f['photoURL'] as String? ?? '';
                        final fbio = f['bio'] as String? ?? '';
                        final isOnline = f['isOnline'] == true;
                        return ListTile(
                          leading: Stack(children: [
                            CircleAvatar(
                              radius: 22,
                              backgroundColor: const Color(0xFF0284C7),
                              backgroundImage: fphoto.isNotEmpty ? NetworkImage(fphoto) : null,
                              child: fphoto.isEmpty
                                  ? Text(fname[0].toUpperCase(),
                                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700))
                                  : null,
                            ),
                            if (isOnline) Positioned(bottom: 0, right: 0,
                              child: Container(width: 10, height: 10,
                                decoration: BoxDecoration(color: const Color(0xFF10B981), shape: BoxShape.circle,
                                    border: Border.all(color: Colors.white, width: 1.5)))),
                          ]),
                          title: Text('@$fname',
                              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                          subtitle: fbio.isNotEmpty
                              ? Text(fbio, maxLines: 1, overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 12))
                              : Text(isOnline ? '🟢 Active now' : 'Offline',
                                  style: TextStyle(fontSize: 12,
                                      color: isOnline ? Colors.green : Colors.grey[400])),
                          trailing: const Icon(Icons.person_add_outlined,
                              color: Color(0xFF0284C7), size: 20),
                        );
                      },
                    );
                  },
                );
              },
            )),
          ]),
        ),
      ),
    );
  }
}

// ── User Map View ─────────────────────────────────────────────────────────────
class _UserMapView extends StatelessWidget {
  final String name, photo;
  final double lat, lng;
  const _UserMapView({required this.name, required this.photo, required this.lat, required this.lng});

  @override
  Widget build(BuildContext context) {
    final point = LatLng(lat, lng);
    return Scaffold(
      appBar: AppBar(
        title: Text('$name on Map', style: const TextStyle(fontWeight: FontWeight.w700)),
        backgroundColor: Colors.white, foregroundColor: Colors.black87, elevation: 0,
      ),
      body: FlutterMap(
        options: MapOptions(initialCenter: point, initialZoom: 14),
        children: [
          TileLayer(
            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            userAgentPackageName: 'com.zylopages.app',
          ),
          MarkerLayer(markers: [
            Marker(
              point: point, width: 64, height: 80,
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(
                  width: 48, height: 48,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: const Color(0xFF0284C7), width: 3),
                    image: photo.isNotEmpty
                        ? DecorationImage(image: NetworkImage(photo), fit: BoxFit.cover)
                        : null,
                    color: const Color(0xFF0284C7),
                  ),
                  child: photo.isEmpty ? Text(name[0].toUpperCase(),
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)) : null,
                ),
                Container(width: 3, height: 12, color: const Color(0xFF0284C7)),
              ]),
            ),
          ]),
        ],
      ),
    );
  }
}

// ── Full Photo View ───────────────────────────────────────────────────────────
class _FullPhotoView extends StatelessWidget {
  final String photoUrl, name;
  const _FullPhotoView({required this.photoUrl, required this.name});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.pop(context),
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(children: [
          Center(child: InteractiveViewer(
            child: Image.network(photoUrl, fit: BoxFit.contain,
              loadingBuilder: (_, c, p) => p == null ? c : const Center(child: CircularProgressIndicator(color: Colors.white)),
              errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white, size: 80)),
          )),
          Positioned(top: 48, left: 16,
            child: GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.2), shape: BoxShape.circle),
                child: const Icon(Icons.close, color: Colors.white, size: 22)))),
        ]),
      ),
    );
  }
}
