// ══════════════════════════════════════════════════════════════════════════════
// ZyloCapsule — Time Capsule Messages Feature
// Send messages/photos to your future self or friends. Locked until target date.
// ══════════════════════════════════════════════════════════════════════════════

import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../../services/cloudflare_service.dart';
import '../../widgets/zylo_cached_image.dart';

// ─── Theme constants ─────────────────────────────────────────────────────────
const _kGold   = Color(0xFFE8B85A);
const _kDeep   = Color(0xFF0F0C29);
const _kPurple = Color(0xFF4A2080);
const _kCream  = Color(0xFFFDF6E7);
const _kBrand  = Color(0xFF0284C7);

// ─── Firestore capsule model ──────────────────────────────────────────────────
class TimeCapsule {
  final String id;
  final String senderUid;
  final String senderName;
  final String senderAvatar;
  final String message;
  final String? mediaUrl;
  final String mediaType; // 'text' | 'image' | 'video'
  final DateTime unlockAt;
  final DateTime createdAt;
  final String capsuleType; // 'personal' | 'group' | 'letter'
  final List<String> recipientUids;
  final List<String> openedBy;
  final String title;
  final String? groupId;

  bool get isUnlocked => DateTime.now().isAfter(unlockAt);
  bool get hasMedia => mediaUrl != null && mediaUrl!.isNotEmpty;

  TimeCapsule({
    required this.id,
    required this.senderUid,
    required this.senderName,
    required this.senderAvatar,
    required this.message,
    this.mediaUrl,
    required this.mediaType,
    required this.unlockAt,
    required this.createdAt,
    required this.capsuleType,
    required this.recipientUids,
    required this.openedBy,
    required this.title,
    this.groupId,
  });

  factory TimeCapsule.fromDoc(DocumentSnapshot doc) {
    final d = doc.data() as Map<String, dynamic>;
    return TimeCapsule(
      id:            doc.id,
      senderUid:     d['senderUid'] ?? '',
      senderName:    d['senderName'] ?? 'Unknown',
      senderAvatar:  d['senderAvatar'] ?? '',
      message:       d['message'] ?? '',
      mediaUrl:      d['mediaUrl'],
      mediaType:     d['mediaType'] ?? 'text',
      unlockAt:      (d['unlockAt'] as Timestamp).toDate(),
      createdAt:     (d['createdAt'] as Timestamp).toDate(),
      capsuleType:   d['capsuleType'] ?? 'personal',
      recipientUids: List<String>.from(d['recipientUids'] ?? []),
      openedBy:      List<String>.from(d['openedBy'] ?? []),
      title:         d['title'] ?? 'My Capsule',
      groupId:       d['groupId'],
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// Main Screen
// ══════════════════════════════════════════════════════════════════════════════
class TimeCapsuleScreen extends StatefulWidget {
  final String? groupId;
  final String? groupName;
  const TimeCapsuleScreen({super.key, this.groupId, this.groupName});

  @override
  State<TimeCapsuleScreen> createState() => _TimeCapsuleScreenState();
}

class _TimeCapsuleScreenState extends State<TimeCapsuleScreen>
    with TickerProviderStateMixin {
  final _myUid  = FirebaseAuth.instance.currentUser?.uid ?? '';
  final _db     = FirebaseFirestore.instance;
  late final AnimationController _floatCtrl;
  late final Animation<double>    _floatAnim;

  @override
  void initState() {
    super.initState();
    _floatCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))
      ..repeat(reverse: true);
    _floatAnim = Tween<double>(begin: -6, end: 6).animate(
      CurvedAnimation(parent: _floatCtrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _floatCtrl.dispose();
    super.dispose();
  }

  Stream<List<TimeCapsule>> _capsulesStream() {
    Query q = _db.collection('time_capsules')
        .where('recipientUids', arrayContains: _myUid)
        .orderBy('unlockAt');
    if (widget.groupId != null) {
      q = _db.collection('time_capsules')
          .where('groupId', isEqualTo: widget.groupId)
          .orderBy('unlockAt');
    }
    return q.snapshots().map((s) =>
        s.docs.map((d) => TimeCapsule.fromDoc(d)).toList());
  }

  void _openCreateSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _CreateCapsuleSheet(
        myUid: _myUid,
        groupId: widget.groupId,
        groupName: widget.groupName,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kDeep,
      body: Stack(children: [
        // ── Starfield background ──────────────────────────────────────────
        const _StarfieldBg(),
        // ── Content ───────────────────────────────────────────────────────
        SafeArea(
          child: Column(children: [
            _buildHeader(),
            Expanded(
              child: StreamBuilder<List<TimeCapsule>>(
                stream: _capsulesStream(),
                builder: (ctx, snap) {
                  if (snap.connectionState == ConnectionState.waiting) {
                    return _buildLoading();
                  }
                  final caps = snap.data ?? [];
                  if (caps.isEmpty) return _buildEmpty();
                  final locked   = caps.where((c) => !c.isUnlocked).toList();
                  final unlocked = caps.where((c) => c.isUnlocked).toList();
                  return ListView(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                    children: [
                      if (unlocked.isNotEmpty) ...[
                        _sectionLabel('✨ Ready to Open', _kGold),
                        ...unlocked.map((c) => _CapsuleCard(
                          capsule: c, myUid: _myUid, floatAnim: _floatAnim,
                          onTap: () => _openCapsule(c))),
                        const SizedBox(height: 16),
                      ],
                      if (locked.isNotEmpty) ...[
                        _sectionLabel('🔒 Sealed Capsules', Colors.white60),
                        ...locked.map((c) => _CapsuleCard(
                          capsule: c, myUid: _myUid, floatAnim: _floatAnim,
                          onTap: () => _showLockedDialog(c))),
                      ],
                    ],
                  );
                },
              ),
            ),
          ]),
        ),
        // ── FAB ───────────────────────────────────────────────────────────
        Positioned(
          bottom: 28, right: 24,
          child: GestureDetector(
            onTap: _openCreateSheet,
            child: AnimatedBuilder(
              animation: _floatAnim,
              builder: (_, child) => Transform.translate(
                offset: Offset(0, _floatAnim.value * 0.3),
                child: child,
              ),
              child: Container(
                width: 62, height: 62,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [_kGold, Color(0xFFD4A030)],
                    begin: Alignment.topLeft, end: Alignment.bottomRight),
                  boxShadow: [
                    BoxShadow(color: _kGold.withValues(alpha: 0.5), blurRadius: 20, spreadRadius: 2),
                  ]),
                child: const Icon(Icons.add_rounded, color: Colors.white, size: 30),
              ),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
      child: Row(children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.1),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white24)),
            child: const Icon(Icons.arrow_back_rounded, color: Colors.white70, size: 20)),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.groupName != null
                ? '${widget.groupName} Capsule'
                : 'Zylo Capsule',
              style: GoogleFonts.playfairDisplay(
                fontSize: 22, fontWeight: FontWeight.w700,
                color: _kGold, letterSpacing: 0.3)),
            Text('Messages from the past, for the future',
              style: GoogleFonts.lato(
                fontSize: 11, color: Colors.white38, letterSpacing: 0.3)),
          ]),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            color: _kGold.withValues(alpha: 0.15),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _kGold.withValues(alpha: 0.3))),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.hourglass_empty_rounded, color: _kGold, size: 13),
            const SizedBox(width: 4),
            Text('TIME', style: GoogleFonts.spaceMono(
              fontSize: 10, color: _kGold, fontWeight: FontWeight.w700)),
          ]),
        ),
      ]),
    );
  }

  Widget _buildLoading() => Center(
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      SizedBox(width: 40, height: 40,
        child: CircularProgressIndicator(color: _kGold, strokeWidth: 2)),
      const SizedBox(height: 14),
      Text('Unlocking time...', style: GoogleFonts.lato(color: Colors.white38, fontSize: 13)),
    ]),
  );

  Widget _buildEmpty() => Center(
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      AnimatedBuilder(
        animation: _floatAnim,
        builder: (_, child) => Transform.translate(
          offset: Offset(0, _floatAnim.value), child: child),
        child: const Text('⏳', style: TextStyle(fontSize: 64)),
      ),
      const SizedBox(height: 20),
      Text('No Capsules Yet', style: GoogleFonts.playfairDisplay(
        fontSize: 22, color: _kGold, fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      Text('Create a time capsule for your\nfuture self or friends!',
        style: GoogleFonts.lato(color: Colors.white38, fontSize: 13, height: 1.6),
        textAlign: TextAlign.center),
      const SizedBox(height: 28),
      GestureDetector(
        onTap: _openCreateSheet,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [_kGold, Color(0xFFD4A030)]),
            borderRadius: BorderRadius.circular(30),
            boxShadow: [BoxShadow(color: _kGold.withValues(alpha: 0.4), blurRadius: 16)]),
          child: Text('Create First Capsule',
            style: GoogleFonts.lato(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14)),
        ),
      ),
    ]),
  );

  Widget _sectionLabel(String text, Color color) => Padding(
    padding: const EdgeInsets.only(bottom: 10, top: 4),
    child: Text(text, style: GoogleFonts.lato(
      fontSize: 12, fontWeight: FontWeight.w800,
      color: color, letterSpacing: 0.8)),
  );

  void _openCapsule(TimeCapsule c) {
    // Mark as opened
    if (!c.openedBy.contains(_myUid)) {
      _db.collection('time_capsules').doc(c.id).update({
        'openedBy': FieldValue.arrayUnion([_myUid]),
      });
    }
    Navigator.push(context, PageRouteBuilder(
      pageBuilder: (_, a, __) => _CapsuleOpenScreen(capsule: c),
      transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: child),
    ));
  }

  void _showLockedDialog(TimeCapsule c) {
    final remaining = c.unlockAt.difference(DateTime.now());
    final days  = remaining.inDays;
    final hours = remaining.inHours % 24;
    final mins  = remaining.inMinutes % 60;
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1040),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _kGold.withValues(alpha: 0.3))),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('🔒', style: TextStyle(fontSize: 48)),
            const SizedBox(height: 14),
            Text(c.title, style: GoogleFonts.playfairDisplay(
              fontSize: 18, color: _kGold, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text('This capsule is still sealed', style: GoogleFonts.lato(
              color: Colors.white60, fontSize: 12)),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              decoration: BoxDecoration(
                color: _kGold.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: _kGold.withValues(alpha: 0.2))),
              child: Column(children: [
                Text('Opens in', style: GoogleFonts.lato(color: Colors.white38, fontSize: 11)),
                const SizedBox(height: 6),
                Text(days > 0 ? '$days days $hours hrs' : '$hours hrs $mins min',
                  style: GoogleFonts.spaceMono(
                    color: _kGold, fontSize: 22, fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text('on ${_formatDate(c.unlockAt)}',
                  style: GoogleFonts.lato(color: Colors.white54, fontSize: 12)),
              ]),
            ),
            const SizedBox(height: 20),
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white10,
                  borderRadius: BorderRadius.circular(20)),
                child: Text('Got it', style: GoogleFonts.lato(
                  color: Colors.white70, fontWeight: FontWeight.w600)),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  String _formatDate(DateTime dt) =>
    '${_month(dt.month)} ${dt.day}, ${dt.year}';

  String _month(int m) => ['Jan','Feb','Mar','Apr','May','Jun',
    'Jul','Aug','Sep','Oct','Nov','Dec'][m - 1];
}

// ══════════════════════════════════════════════════════════════════════════════
// Capsule Card Widget
// ══════════════════════════════════════════════════════════════════════════════
class _CapsuleCard extends StatefulWidget {
  final TimeCapsule capsule;
  final String myUid;
  final Animation<double> floatAnim;
  final VoidCallback onTap;
  const _CapsuleCard({
    required this.capsule, required this.myUid,
    required this.floatAnim, required this.onTap});

  @override
  State<_CapsuleCard> createState() => _CapsuleCardState();
}

class _CapsuleCardState extends State<_CapsuleCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _shimCtrl;
  late Animation<double> _shimAnim;

  @override
  void initState() {
    super.initState();
    _shimCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: false);
    _shimAnim = Tween<double>(begin: -1, end: 2).animate(
      CurvedAnimation(parent: _shimCtrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() { _shimCtrl.dispose(); super.dispose(); }

  String _timeLeft() {
    final r = widget.capsule.unlockAt.difference(DateTime.now());
    if (r.inDays > 365) return '${(r.inDays / 365).floor()}y left';
    if (r.inDays > 0) return '${r.inDays}d left';
    if (r.inHours > 0) return '${r.inHours}h left';
    return '${r.inMinutes}min left';
  }

  String _formatUnlock() {
    final dt = widget.capsule.unlockAt;
    final months = ['Jan','Feb','Mar','Apr','May','Jun',
      'Jul','Aug','Sep','Oct','Nov','Dec'];
    return '${months[dt.month-1]} ${dt.day}, ${dt.year}';
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.capsule;
    final isUnlocked = c.isUnlocked;
    final isNew = isUnlocked && !c.openedBy.contains(widget.myUid);

    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: isUnlocked
                ? [const Color(0xFF2A1A60), const Color(0xFF1A0F40)]
                : [const Color(0xFF181530), const Color(0xFF0F0C29)]),
          border: Border.all(
            color: isUnlocked
                ? _kGold.withValues(alpha: 0.6)
                : Colors.white.withValues(alpha: 0.08),
            width: isUnlocked ? 1.5 : 1),
          boxShadow: isUnlocked ? [
            BoxShadow(color: _kGold.withValues(alpha: 0.2), blurRadius: 20, spreadRadius: 1),
          ] : [],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Stack(children: [
            // Shimmer on unlocked cards
            if (isUnlocked)
              AnimatedBuilder(
                animation: _shimAnim,
                builder: (_, __) => Positioned.fill(
                  child: Transform.translate(
                    offset: Offset(_shimAnim.value * 400, 0),
                    child: Container(
                      width: 60,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.transparent,
                            _kGold.withValues(alpha: 0.05),
                            Colors.transparent,
                          ])),
                    ),
                  ),
                ),
              ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  // Type icon
                  Container(
                    width: 40, height: 40,
                    decoration: BoxDecoration(
                      color: isUnlocked
                          ? _kGold.withValues(alpha: 0.15)
                          : Colors.white.withValues(alpha: 0.05),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: isUnlocked ? _kGold.withValues(alpha: 0.4) : Colors.white12)),
                    child: Center(child: Text(
                      c.capsuleType == 'letter' ? '💌'
                      : c.capsuleType == 'group' ? '👥' : '🕰️',
                      style: const TextStyle(fontSize: 18))),
                  ),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Expanded(child: Text(c.title,
                        style: GoogleFonts.playfairDisplay(
                          fontSize: 15, fontWeight: FontWeight.w700,
                          color: isUnlocked ? _kGold : Colors.white70),
                        maxLines: 1, overflow: TextOverflow.ellipsis)),
                      if (isNew)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: _kGold, borderRadius: BorderRadius.circular(10)),
                          child: Text('NEW', style: GoogleFonts.spaceMono(
                            fontSize: 9, color: Colors.white, fontWeight: FontWeight.w700))),
                    ]),
                    const SizedBox(height: 2),
                    Text('from ${c.senderName}',
                      style: GoogleFonts.lato(fontSize: 11, color: Colors.white38)),
                  ])),
                  const SizedBox(width: 8),
                  // Lock / unlock icon
                  Container(
                    width: 34, height: 34,
                    decoration: BoxDecoration(
                      color: isUnlocked
                          ? _kGold.withValues(alpha: 0.2)
                          : Colors.white.withValues(alpha: 0.05),
                      shape: BoxShape.circle),
                    child: Icon(
                      isUnlocked ? Icons.lock_open_rounded : Icons.lock_rounded,
                      color: isUnlocked ? _kGold : Colors.white24, size: 16)),
                ]),
                const SizedBox(height: 12),
                // Message preview (blurred if locked)
                Stack(children: [
                  Text(c.message.isEmpty ? '📷 Contains media' : c.message,
                    style: GoogleFonts.lato(
                      fontSize: 13, color: Colors.white54, height: 1.5),
                    maxLines: 2, overflow: TextOverflow.ellipsis),
                  if (!isUnlocked)
                    Positioned.fill(
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.transparent, const Color(0xFF0F0C29)],
                            begin: Alignment.centerLeft, end: Alignment.centerRight)),
                      ),
                    ),
                ]),
                const SizedBox(height: 10),
                Row(children: [
                  Icon(
                    isUnlocked ? Icons.event_available_rounded : Icons.schedule_rounded,
                    color: isUnlocked ? _kGold : Colors.white24, size: 13),
                  const SizedBox(width: 5),
                  Text(
                    isUnlocked
                        ? 'Unlocked on ${_formatUnlock()}'
                        : _timeLeft(),
                    style: GoogleFonts.spaceMono(
                      fontSize: 10,
                      color: isUnlocked ? _kGold.withValues(alpha: 0.8) : Colors.white30,
                      fontWeight: FontWeight.w700)),
                  const Spacer(),
                  if (c.hasMedia)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.05),
                        borderRadius: BorderRadius.circular(8)),
                      child: Row(children: [
                        Icon(
                          c.mediaType == 'video' ? Icons.videocam_rounded : Icons.image_rounded,
                          color: Colors.white30, size: 11),
                        const SizedBox(width: 4),
                        Text(c.mediaType == 'video' ? 'Video' : 'Photo',
                          style: GoogleFonts.lato(fontSize: 10, color: Colors.white30)),
                      ])),
                  if (isUnlocked)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [_kGold, Color(0xFFD4A030)]),
                        borderRadius: BorderRadius.circular(12)),
                      child: Text('Tap to Open',
                        style: GoogleFonts.lato(
                          fontSize: 10, color: Colors.white, fontWeight: FontWeight.w800))),
                ]),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// Capsule Open Screen — dramatic reveal animation
// ══════════════════════════════════════════════════════════════════════════════
class _CapsuleOpenScreen extends StatefulWidget {
  final TimeCapsule capsule;
  const _CapsuleOpenScreen({required this.capsule});

  @override
  State<_CapsuleOpenScreen> createState() => _CapsuleOpenScreenState();
}

class _CapsuleOpenScreenState extends State<_CapsuleOpenScreen>
    with TickerProviderStateMixin {
  late AnimationController _openCtrl;
  late AnimationController _particleCtrl;
  late Animation<double>   _scaleAnim;
  late Animation<double>   _fadeAnim;
  late Animation<double>   _particleAnim;
  bool _revealed = false;

  @override
  void initState() {
    super.initState();
    _openCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));
    _particleCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))
      ..repeat();
    _scaleAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _openCtrl, curve: const Interval(0.3, 1.0, curve: Curves.elasticOut)));
    _fadeAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _openCtrl, curve: const Interval(0.5, 1.0, curve: Curves.easeOut)));
    _particleAnim = _particleCtrl;
  }

  @override
  void dispose() {
    _openCtrl.dispose();
    _particleCtrl.dispose();
    super.dispose();
  }

  void _tapToReveal() {
    HapticFeedback.heavyImpact();
    setState(() => _revealed = true);
    _openCtrl.forward();
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.capsule;
    return Scaffold(
      backgroundColor: _kDeep,
      body: Stack(children: [
        const _StarfieldBg(),
        // Gold particles when revealed
        if (_revealed)
          AnimatedBuilder(
            animation: _particleAnim,
            builder: (_, __) => CustomPaint(
              painter: _ParticlePainter(_particleAnim.value),
              size: MediaQuery.of(context).size,
            ),
          ),
        SafeArea(
          child: Column(children: [
            // Header
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: Row(children: [
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.08),
                      shape: BoxShape.circle),
                    child: const Icon(Icons.close_rounded, color: Colors.white54, size: 18)),
                ),
                const Spacer(),
                Text('Zylo Capsule', style: GoogleFonts.playfairDisplay(
                  fontSize: 16, color: _kGold.withValues(alpha: 0.8))),
                const Spacer(),
                const SizedBox(width: 36),
              ]),
            ),
            Expanded(
              child: _revealed ? _buildRevealedContent(c) : _buildSealedContent(c),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _buildSealedContent(TimeCapsule c) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        // Animated capsule
        TweenAnimationBuilder<double>(
          tween: Tween(begin: 0, end: 1),
          duration: const Duration(milliseconds: 800),
          curve: Curves.elasticOut,
          builder: (_, v, child) => Transform.scale(scale: v, child: child),
          child: GestureDetector(
            onTap: _tapToReveal,
            child: Container(
              width: 160, height: 200,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(80),
                gradient: const LinearGradient(
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                  colors: [Color(0xFF3A2070), Color(0xFF1A0F40)]),
                border: Border.all(color: _kGold.withValues(alpha: 0.6), width: 2),
                boxShadow: [
                  BoxShadow(color: _kGold.withValues(alpha: 0.3), blurRadius: 40, spreadRadius: 5),
                ]),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Text('⏳', style: TextStyle(fontSize: 52)),
                const SizedBox(height: 8),
                Text('TAP\nTO OPEN', textAlign: TextAlign.center,
                  style: GoogleFonts.spaceMono(
                    fontSize: 12, color: _kGold, fontWeight: FontWeight.w700,
                    letterSpacing: 2)),
              ]),
            ),
          ),
        ),
        const SizedBox(height: 30),
        Text(c.title, style: GoogleFonts.playfairDisplay(
          fontSize: 24, color: _kGold, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        Text('A message from ${c.senderName}',
          style: GoogleFonts.lato(color: Colors.white38, fontSize: 13)),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.05),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white12)),
          child: Text('Sealed on ${_fmtDate(c.createdAt)}',
            style: GoogleFonts.spaceMono(fontSize: 10, color: Colors.white30)),
        ),
      ],
    );
  }

  Widget _buildRevealedContent(TimeCapsule c) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 40),
      child: ScaleTransition(
        scale: _scaleAnim,
        child: FadeTransition(
          opacity: _fadeAnim,
          child: Column(children: [
            // Capsule type badge
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [_kGold, Color(0xFFD4A030)]),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [BoxShadow(color: _kGold.withValues(alpha: 0.5), blurRadius: 16)]),
              child: Text(
                c.capsuleType == 'letter' ? '💌 Letter to Future Self'
                : c.capsuleType == 'group' ? '👥 Group Time Capsule'
                : '🕰️ Personal Capsule',
                style: GoogleFonts.lato(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13)),
            ),
            const SizedBox(height: 24),
            // Title
            Text(c.title, style: GoogleFonts.playfairDisplay(
              fontSize: 28, color: _kGold, fontWeight: FontWeight.w700,
              height: 1.2), textAlign: TextAlign.center),
            const SizedBox(height: 6),
            Text('from ${c.senderName} · ${_fmtDate(c.createdAt)}',
              style: GoogleFonts.lato(color: Colors.white38, fontSize: 12)),
            const SizedBox(height: 28),
            // Media
            if (c.hasMedia && c.mediaType == 'image')
              Container(
                margin: const EdgeInsets.only(bottom: 20),
                height: 240,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _kGold.withValues(alpha: 0.3))),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: ZyloCachedImage(url: c.mediaUrl!, fit: BoxFit.cover, width: double.infinity, height: 240)),
              ),
            // Message
            if (c.message.isNotEmpty)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: const Color(0xFF1A1040),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _kGold.withValues(alpha: 0.2)),
                  boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.3), blurRadius: 20)]),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('"', style: GoogleFonts.playfairDisplay(
                    fontSize: 48, color: _kGold.withValues(alpha: 0.4), height: 0.5)),
                  const SizedBox(height: 8),
                  Text(c.message, style: GoogleFonts.lato(
                    fontSize: 16, color: Colors.white.withValues(alpha: 0.88),
                    height: 1.7, letterSpacing: 0.2)),
                  const SizedBox(height: 12),
                  Align(alignment: Alignment.bottomRight,
                    child: Text('"', style: GoogleFonts.playfairDisplay(
                      fontSize: 48, color: _kGold.withValues(alpha: 0.4), height: 0.5))),
                ]),
              ),
            const SizedBox(height: 24),
            // Timestamp footer
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.04),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white.withValues(alpha: 0.08))),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Icon(Icons.lock_clock_rounded, color: Colors.white30, size: 14),
                const SizedBox(width: 8),
                Text('Locked for ${_duration(c.createdAt, c.unlockAt)}',
                  style: GoogleFonts.spaceMono(fontSize: 11, color: Colors.white30)),
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  String _fmtDate(DateTime dt) {
    final m = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    return '${m[dt.month-1]} ${dt.day}, ${dt.year}';
  }

  String _duration(DateTime from, DateTime to) {
    final d = to.difference(from);
    if (d.inDays >= 365) return '${(d.inDays / 365).floor()} year(s)';
    if (d.inDays >= 30)  return '${(d.inDays / 30).floor()} month(s)';
    return '${d.inDays} day(s)';
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// Create Capsule Sheet
// ══════════════════════════════════════════════════════════════════════════════
class _CreateCapsuleSheet extends StatefulWidget {
  final String myUid;
  final String? groupId;
  final String? groupName;
  const _CreateCapsuleSheet({
    required this.myUid,
    this.groupId, this.groupName});

  @override
  State<_CreateCapsuleSheet> createState() => _CreateCapsuleSheetState();
}

class _CreateCapsuleSheetState extends State<_CreateCapsuleSheet> {
  final _db      = FirebaseFirestore.instance;
  final _msgCtrl = TextEditingController();
  final _titleCtrl = TextEditingController();

  String _capsuleType = 'personal'; // 'personal' | 'group' | 'letter'
  DateTime? _unlockDate;
  File? _mediaFile;
  bool _uploading = false;
  int _selectedPreset = -1; // preset durations

  static const _presets = [
    ('1 Week', Duration(days: 7)),
    ('1 Month', Duration(days: 30)),
    ('6 Months', Duration(days: 183)),
    ('1 Year', Duration(days: 365)),
    ('5 Years', Duration(days: 1825)),
  ];

  @override
  void initState() {
    super.initState();
    if (widget.groupId != null) _capsuleType = 'group';
  }

  @override
  void dispose() {
    _msgCtrl.dispose();
    _titleCtrl.dispose();
    super.dispose();
  }

  void _pickPreset(int i) {
    setState(() {
      _selectedPreset = i;
      _unlockDate = DateTime.now().add(_presets[i].$2);
    });
  }

  Future<void> _pickCustomDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: DateTime.now().add(const Duration(days: 30)),
      firstDate: DateTime.now().add(const Duration(days: 1)),
      lastDate: DateTime.now().add(const Duration(days: 365 * 20)),
      builder: (ctx, child) => Theme(
        data: ThemeData.dark().copyWith(
          colorScheme: const ColorScheme.dark(
            primary: _kGold, onPrimary: Colors.black,
            surface: Color(0xFF1A1040))),
        child: child!),
    );
    if (d != null) setState(() { _unlockDate = d; _selectedPreset = -1; });
  }

  Future<void> _pickImage() async {
    final p = ImagePicker();
    final f = await p.pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (f != null) setState(() => _mediaFile = File(f.path));
  }

  Future<void> _createCapsule() async {
    if (_titleCtrl.text.trim().isEmpty) {
      _snack('Give your capsule a title!'); return;
    }
    if (_msgCtrl.text.trim().isEmpty && _mediaFile == null) {
      _snack('Add a message or photo!'); return;
    }
    if (_unlockDate == null) {
      _snack('Set an unlock date!'); return;
    }

    setState(() => _uploading = true);

    try {
      final userDoc = await _db.collection('users').doc(widget.myUid).get();
      final userName = userDoc.data()?['displayName'] ?? userDoc.data()?['name'] ?? 'You';
      final userAvatar = userDoc.data()?['photoURL'] ?? '';

      String? mediaUrl;
      String mediaType = 'text';

      if (_mediaFile != null) {
        mediaType = 'image';
        // Upload via Cloudflare worker (stores on Telegram)
        final result = await CloudflareService.uploadFile(_mediaFile!);
        // Resolve Telegram CDN URL for display
        final tgToken = CloudflareService.tgToken;
        String resolvedUrl = result.fileId; // fallback to fileId
        try {
          final metaRes = await http.get(Uri.parse(
            'https://api.telegram.org/bot$tgToken/getFile?file_id=${result.fileId}'));
          final meta = jsonDecode(metaRes.body) as Map<String, dynamic>;
          if (meta['ok'] == true) {
            final filePath = meta['result']['file_path'] as String;
            resolvedUrl = 'https://api.telegram.org/file/bot$tgToken/$filePath';
          }
        } catch (_) {}
        mediaUrl = resolvedUrl;
      }

      // Determine recipients
      List<String> recipientUids = [widget.myUid];
      if (_capsuleType == 'group' && widget.groupId != null) {
        // Get group members
        final groupDoc = await _db.collection('chats').doc(widget.groupId).get();
        final members = List<String>.from(groupDoc.data()?['participants'] ?? []);
        recipientUids = members;
      }

      await _db.collection('time_capsules').add({
        'senderUid':     widget.myUid,
        'senderName':    userName,
        'senderAvatar':  userAvatar,
        'message':       _msgCtrl.text.trim(),
        'mediaUrl':      mediaUrl,
        'mediaType':     mediaType,
        'unlockAt':      Timestamp.fromDate(_unlockDate!),
        'createdAt':     FieldValue.serverTimestamp(),
        'capsuleType':   _capsuleType,
        'recipientUids': recipientUids,
        'openedBy':      [],
        'title':         _titleCtrl.text.trim(),
        'groupId':       widget.groupId,
      });

      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('⏳ Capsule sealed! It will unlock on the chosen date.'),
            backgroundColor: _kPurple,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
      }
    } catch (e) {
      setState(() => _uploading = false);
      _snack('Error creating capsule: $e');
    }
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating));
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.92,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      builder: (_, ctrl) => Container(
        decoration: const BoxDecoration(
          color: Color(0xFF0F0C29),
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
          border: Border(top: BorderSide(color: Color(0xFF2A2050), width: 1))),
        child: Column(children: [
          // Handle
          Container(
            margin: const EdgeInsets.only(top: 12),
            width: 40, height: 4,
            decoration: BoxDecoration(
              color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          // Header
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            child: Row(children: [
              Text('Seal a Capsule', style: GoogleFonts.playfairDisplay(
                fontSize: 20, color: _kGold, fontWeight: FontWeight.w700)),
              const Spacer(),
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: const Icon(Icons.close_rounded, color: Colors.white38, size: 22)),
            ]),
          ),
          Expanded(
            child: ListView(
              controller: ctrl,
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
              children: [
                // Type selector (only if not in group)
                if (widget.groupId == null) ...[
                  _label('Capsule Type'),
                  const SizedBox(height: 8),
                  Row(children: [
                    _typeBtn('personal', '🕰️', 'Personal'),
                    const SizedBox(width: 8),
                    _typeBtn('letter', '💌', 'To Future Me'),
                  ]),
                  const SizedBox(height: 20),
                ],
                // Title
                _label('Title'),
                const SizedBox(height: 8),
                _darkTextField(_titleCtrl, 'e.g. "My 2025 Dreams"', maxLines: 1),
                const SizedBox(height: 20),
                // Message
                _label('Message'),
                const SizedBox(height: 8),
                _darkTextField(_msgCtrl, 'Write something to your future self...', maxLines: 6),
                const SizedBox(height: 20),
                // Photo
                _label('Attach Photo (optional)'),
                const SizedBox(height: 8),
                GestureDetector(
                  onTap: _pickImage,
                  child: Container(
                    height: _mediaFile != null ? 180 : 80,
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1040),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: _mediaFile != null ? _kGold.withValues(alpha: 0.5) : Colors.white12,
                        style: BorderStyle.solid, width: 1.5)),
                    child: _mediaFile != null
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(14),
                            child: Stack(fit: StackFit.expand, children: [
                              Image.file(_mediaFile!, fit: BoxFit.cover),
                              Positioned(top: 8, right: 8,
                                child: GestureDetector(
                                  onTap: () => setState(() => _mediaFile = null),
                                  child: Container(
                                    padding: const EdgeInsets.all(4),
                                    decoration: const BoxDecoration(
                                      color: Colors.black54, shape: BoxShape.circle),
                                    child: const Icon(Icons.close_rounded, color: Colors.white, size: 14)))),
                            ]))
                        : Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                            const Icon(Icons.add_photo_alternate_rounded, color: Colors.white24, size: 28),
                            const SizedBox(height: 6),
                            Text('Add a photo memory', style: GoogleFonts.lato(
                              color: Colors.white30, fontSize: 12)),
                          ]),
                  ),
                ),
                const SizedBox(height: 20),
                // Unlock date
                _label('Unlock Date'),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8, runSpacing: 8,
                  children: List.generate(_presets.length, (i) {
                    final selected = _selectedPreset == i;
                    return GestureDetector(
                      onTap: () => _pickPreset(i),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          color: selected ? _kGold.withValues(alpha: 0.2) : const Color(0xFF1A1040),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: selected ? _kGold : Colors.white12,
                            width: selected ? 1.5 : 1)),
                        child: Text(_presets[i].$1,
                          style: GoogleFonts.lato(
                            fontSize: 13,
                            color: selected ? _kGold : Colors.white54,
                            fontWeight: selected ? FontWeight.w700 : FontWeight.w400))),
                    );
                  }),
                ),
                const SizedBox(height: 10),
                GestureDetector(
                  onTap: _pickCustomDate,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1040),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: _unlockDate != null && _selectedPreset == -1
                            ? _kGold : Colors.white12)),
                    child: Row(children: [
                      const Icon(Icons.calendar_today_rounded, color: Colors.white30, size: 16),
                      const SizedBox(width: 10),
                      Text(
                        _unlockDate != null && _selectedPreset == -1
                            ? 'Custom: ${_fmtDate(_unlockDate!)}'
                            : 'Pick custom date...',
                        style: GoogleFonts.lato(
                          color: _unlockDate != null && _selectedPreset == -1
                              ? _kGold : Colors.white30,
                          fontSize: 13)),
                    ])),
                ),
                if (_unlockDate != null) ...[
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      color: _kGold.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _kGold.withValues(alpha: 0.2))),
                    child: Row(children: [
                      const Text('⏳', style: TextStyle(fontSize: 16)),
                      const SizedBox(width: 10),
                      Text('Will unlock on ${_fmtDate(_unlockDate!)}',
                        style: GoogleFonts.lato(color: _kGold, fontSize: 13)),
                    ]),
                  ),
                ],
                const SizedBox(height: 28),
                // Seal button
                GestureDetector(
                  onTap: _uploading ? null : _createCapsule,
                  child: Container(
                    height: 56,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [_kGold, Color(0xFFD4A030)],
                        begin: Alignment.topLeft, end: Alignment.bottomRight),
                      borderRadius: BorderRadius.circular(18),
                      boxShadow: [
                        BoxShadow(color: _kGold.withValues(alpha: 0.4), blurRadius: 16, spreadRadius: 1),
                      ]),
                    child: Center(
                      child: _uploading
                          ? const SizedBox(width: 24, height: 24,
                              child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                          : Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                              const Text('🔒', style: TextStyle(fontSize: 20)),
                              const SizedBox(width: 10),
                              Text('Seal the Capsule', style: GoogleFonts.lato(
                                fontSize: 16, color: Colors.white,
                                fontWeight: FontWeight.w800, letterSpacing: 0.3)),
                            ]),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ]),
      ),
    );
  }

  Widget _typeBtn(String type, String emoji, String label) {
    final sel = _capsuleType == type;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _capsuleType = type),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: sel ? _kGold.withValues(alpha: 0.15) : const Color(0xFF1A1040),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: sel ? _kGold : Colors.white12, width: sel ? 1.5 : 1)),
          child: Column(children: [
            Text(emoji, style: const TextStyle(fontSize: 22)),
            const SizedBox(height: 4),
            Text(label, style: GoogleFonts.lato(
              fontSize: 12, color: sel ? _kGold : Colors.white38,
              fontWeight: sel ? FontWeight.w700 : FontWeight.w400)),
          ]),
        ),
      ),
    );
  }

  Widget _label(String text) => Text(text,
    style: GoogleFonts.lato(
      fontSize: 12, fontWeight: FontWeight.w700,
      color: Colors.white38, letterSpacing: 0.8));

  Widget _darkTextField(TextEditingController ctrl, String hint, {int maxLines = 1}) =>
    TextField(
      controller: ctrl,
      maxLines: maxLines,
      style: GoogleFonts.lato(color: Colors.white.withValues(alpha: 0.88), fontSize: 14),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: GoogleFonts.lato(color: Colors.white24, fontSize: 14),
        filled: true,
        fillColor: const Color(0xFF1A1040),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Colors.white12)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Colors.white12)),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: _kGold, width: 1.5)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14)),
    );

  String _fmtDate(DateTime dt) {
    final m = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    return '${m[dt.month-1]} ${dt.day}, ${dt.year}';
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// Background: Starfield
// ══════════════════════════════════════════════════════════════════════════════
class _StarfieldBg extends StatelessWidget {
  const _StarfieldBg();

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _StarsPainter(),
      child: Container(),
    );
  }
}

class _StarsPainter extends CustomPainter {
  final _rng = Random(42);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white;
    for (int i = 0; i < 120; i++) {
      final x = _rng.nextDouble() * size.width;
      final y = _rng.nextDouble() * size.height;
      final r = _rng.nextDouble() * 1.2 + 0.3;
      paint.color = Colors.white.withValues(alpha: _rng.nextDouble() * 0.5 + 0.1);
      canvas.drawCircle(Offset(x, y), r, paint);
    }
    // subtle gradient overlay
    final grad = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter, end: Alignment.bottomCenter,
        colors: [Color(0x40301860), Color(0x00000000)],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height * 0.4));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height * 0.4), grad);
  }

  @override
  bool shouldRepaint(_) => false;
}

// ══════════════════════════════════════════════════════════════════════════════
// Gold Particle Painter (shown when capsule opens)
// ══════════════════════════════════════════════════════════════════════════════
class _ParticlePainter extends CustomPainter {
  final double t;
  _ParticlePainter(this.t);

  final _rng = Random(99);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint();
    for (int i = 0; i < 60; i++) {
      final seed = i * 7919;
      final rng = Random(seed);
      final startX = rng.nextDouble() * size.width;
      final speed = rng.nextDouble() * 0.8 + 0.2;
      final progress = (t * speed) % 1.0;
      final x = startX + sin(progress * pi * 2 + i) * 40;
      final y = size.height - progress * size.height * 1.2;
      final opacity = (1 - progress).clamp(0.0, 1.0);
      final sz = rng.nextDouble() * 5 + 2;
      paint.color = (i % 3 == 0 ? _kGold : i % 3 == 1 ? Colors.amber : Colors.white)
          .withValues(alpha: opacity * 0.7);
      canvas.drawCircle(Offset(x, y), sz, paint);
    }
  }

  @override
  bool shouldRepaint(_ParticlePainter old) => old.t != t;
}
