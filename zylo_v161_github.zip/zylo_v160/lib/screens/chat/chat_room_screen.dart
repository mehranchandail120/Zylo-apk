import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:io';
import 'dart:async';
import 'dart:convert';
import 'dart:ui' as ui;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;
import '../../services/auth_service.dart';
import '../../services/cache_service.dart';
import '../../services/local_db_service.dart';
import '../../services/file_service.dart';
import '../../widgets/media_picker_sheet.dart';
import '../../services/firestore_service.dart';
import '../../services/ai_chat_service.dart';
import 'chat_info_screen.dart';
import '../../services/notification_service.dart';
import '../../services/chat_lock_service.dart';
import '../../services/cloudflare_service.dart';
import '../../widgets/voice_recorder_widget.dart';
import '../../widgets/link_preview_card.dart';
import '../../widgets/contact_card_widget.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../widgets/share_sheet.dart';
import '../map/location_picker_screen.dart';
import '../../widgets/zylo_avatar.dart';
import 'package:open_filex/open_filex.dart';
import '../feed/post_deep_link_screen.dart';
import '../../services/translation_service.dart';
import '../../services/remote_config_service.dart';
import '../../widgets/language_picker_sheet.dart';
import '../../widgets/zylo_chat_design.dart';
import '../video_player_screen.dart';
// screenshot_callback removed — using native MethodChannel approach
// photo_editor_screen removed — photos send directly

/// Returns a valid NetworkImage only for http/https URLs, else null.
NetworkImage? _safeNetworkImage(String? url) {
  if (url == null || url.isEmpty) return null;
  if (url.startsWith('http://') || url.startsWith('https://')) {
    return NetworkImage(url);
  }
  return null;
}


class ChatRoomScreen extends StatefulWidget {
  final String targetId;
  final String targetName;
  const ChatRoomScreen({super.key, required this.targetId, required this.targetName});
  @override
  State<ChatRoomScreen> createState() => _ChatRoomScreenState();
}

class _ChatRoomScreenState extends State<ChatRoomScreen> with WidgetsBindingObserver {
  final TextEditingController _msgController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final TextEditingController _searchController = TextEditingController();
  final List<Map<String, dynamic>> _messages = [];
  late String myName;
  bool _isUploading = false;
  bool _showSend = false;
  Duration? _timerDuration;
  Map<String, dynamic>? _replyTo;
  bool _isSelectMode = false;
  final Set<String> _selectedIds = {};
  final Map<String, String> _selectedFirestoreIds = {}; // localId -> firestoreId
  bool _isSearching = false;
  String _searchQuery = '';
  int _searchMatchIndex = 0; // current highlighted match (0-based, from bottom since list is reversed)
  int _searchMatchCount = 0;
  bool _showPinnedPanel = false;
  // @ mention suggestions
  List<Map<String, dynamic>> _mentionSuggestions = [];
  bool _showMentions = false;
  String _mentionQuery = '';
  // ── @zylo AI ───────────────────────────────────────────────────────────────
  bool _zyloAiTyping = false;
  bool _showZyloSuggest = false; // show "@zylo" chip when user types @
  // final CloudinaryService _cloudinaryService = CloudinaryService();
  final FirestoreService _fs = FirestoreService();
  final NotificationService _ns = NotificationService();
  static const _blue = Color(0xFF0284C7);

  // ── Cached target user stream (avoid recreating on every build) ──────────
  late final Stream<DocumentSnapshot> _targetUserStream;

  // ── Lock / Mute state ─────────────────────────────────────────────────────
  bool _isChatLocked = false;
  bool _isChatMuted = false;

  // ── Block state ───────────────────────────────────────────────────────────
  bool _iBlockedThem = false;
  bool _theyBlockedMe = false;
  StreamSubscription? _blockSub;
  StreamSubscription? _blockedBySub;

  // ── Pagination ────────────────────────────────────────────────────────────
  final List<Map<String, dynamic>> _olderMessages = []; // loaded via loadMore
  List<QueryDocumentSnapshot> _firestoreDocs = []; // live docs from stream
  DocumentSnapshot? _lastDoc;     // cursor for next page
  bool _isLoadingMore = false;
  bool _hasMoreMessages = true;   // false when server returns < 30

  // ── Typing indicator ──────────────────────────────────────────────────────
  bool _isOtherTyping = false;
  StreamSubscription? _typingSub;
  Timer? _typingTimer;
  bool _isSendingTyping = false;

  // ── Target user real photo ─────────────────────────────────────────────────
  String _targetRealPhoto = '';

  // ── Voice recording ───────────────────────────────────────────────────────
  bool _isRecording = false;

  // ── Send guard — prevents double-send on rapid taps ───────────────────────
  bool _isSending = false;

  // ── SQLite local messages (loaded instantly before Firestore) ───────────
  List<Map<String, dynamic>> _sqliteMessages = [];
  bool _sqliteLoaded = false;

  // ── Bubble pop animation ──────────────────────────────────────────────────
  String? _lastSentId; // ID of the most recently sent bubble to trigger pop

  // ── Translation ───────────────────────────────────────────────────────────
  // Map of message localId -> translated text (null = not yet translated)
  final Map<String, String?> _translatedTexts = {};
  // Which messages are showing original (toggled by user)
  final Set<String> _showOriginal = {};

  // ── Snapchat-style Screenshot Detection ───────────────────────────────────
  // Native screenshot detection via MethodChannel (replaces screenshot_callback plugin)
  static const _screenshotChannel = MethodChannel('com.zylopages.app/screenshot');
  bool _screenshotCallbackActive = false;
  bool _showScreenshotPreview = false;   // show the taken screenshot back to taker
  String? _lastScreenshotPath;           // path of the captured screenshot image
  Timer? _screenshotPreviewTimer;        // auto-dismiss after 3s

  @override
  void initState() {
    super.initState();
    _targetUserStream = FirebaseFirestore.instance
        .collection('users').doc(widget.targetId).snapshots();
    // Listen for real photo updates
    _targetUserStream.listen((snap) {
      final data = snap.data() as Map<String, dynamic>? ?? {};
      final photo = data['photoURL'] as String? ?? '';
      if (photo != _targetRealPhoto && mounted) {
        setState(() => _targetRealPhoto = photo);
      }
    });
    WidgetsBinding.instance.addObserver(this);
    _fs.updateOnlineStatus(true).catchError((_) {});
    final authService = Provider.of<AuthService>(context, listen: false);
    myName = authService.userName ?? 'User';
    // Listen to translation service changes — clear cache on language switch
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final tSvc = Provider.of<TranslationService>(context, listen: false);
      tSvc.addListener(() {
        if (mounted) setState(() => _translatedTexts.clear());
      });
    });
    _msgController.addListener(() {
      final show = _msgController.text.trim().isNotEmpty;
      if (show != _showSend) setState(() => _showSend = show);
      // Typing indicator
      _onTypingChanged(show);
    });
    _searchController.addListener(() {
      setState(() {
        _searchQuery = _searchController.text.toLowerCase();
        _searchMatchIndex = 0;
      });
    });
    _msgController.addListener(_handleMentionTyping);
    _msgController.addListener(_handleZyloDetect);
    _fs.ensureChatExists(widget.targetId, widget.targetName, '').catchError((_) {});
    _fs.markAsRead(widget.targetId).catchError((_) {});
    LocalDbService.instance.markChatRead(
      Provider.of<AuthService>(context, listen: false).user?.uid ?? '',
      widget.targetId,
    ).catchError((_) {});
    // Subscribe to block state
    _blockSub = _fs.isUserBlocked(widget.targetId).listen((blocked) {
      if (mounted) setState(() => _iBlockedThem = blocked);
    });
    _blockedBySub = _fs.amIBlockedBy(widget.targetId).listen((blocked) {
      if (mounted) setState(() => _theyBlockedMe = blocked);
    });
    // Subscribe to other user typing
    _typingSub = _fs.isOtherTyping(widget.targetId).listen((typing) {
      if (mounted) setState(() => _isOtherTyping = typing);
    });
    // ── Pagination scroll listener ────────────────────────────────────────
    // ListView is reversed: maxScrollExtent = oldest messages (top of screen)
    _scrollController.addListener(() {
      if (_scrollController.position.pixels >=
              _scrollController.position.maxScrollExtent - 200 &&
          !_isLoadingMore &&
          _hasMoreMessages) {
        _loadMoreMessages();
      }
    });
    // Load lock/mute state
    _loadLockMuteState();
    // SQLite: load messages instantly before Firestore stream arrives
    _loadSqliteMessages();
    // ── Snapchat-style Screenshot Detection ───────────────────────────────
    _initScreenshotDetection();
  }

  Future<void> _loadSqliteMessages() async {
    try {
      final myUid = Provider.of<AuthService>(context, listen: false).user?.uid ?? '';
      final rows = await LocalDbService.instance.loadMessages(
        myUid: myUid,
        otherUid: widget.targetId,
        limit: 50,
      );
      if (mounted && rows.isNotEmpty) {
        setState(() {
          _sqliteMessages = rows;
          _sqliteLoaded = true;
        });
      } else {
        if (mounted) setState(() => _sqliteLoaded = true);
      }
    } catch (_) {
      if (mounted) setState(() => _sqliteLoaded = true);
    }
  }

  Future<void> _loadLockMuteState() async {
    final locked = await ChatLockService.isLocked(widget.targetId);
    final myUid = Provider.of<AuthService>(context, listen: false).user?.uid ?? '';
    final muteDoc = await FirebaseFirestore.instance
        .collection('users').doc(myUid)
        .collection('mutedChats').doc(widget.targetId).get();
    if (mounted) setState(() {
      _isChatLocked = locked;
      _isChatMuted = muteDoc.exists;
    });
  }

  // ── Snapchat-style Screenshot Detection ─────────────────────────────────
  void _initScreenshotDetection() {
    try {
      _screenshotChannel.setMethodCallHandler((call) async {
        if (call.method == 'onScreenshot') {
          await _onScreenshotDetected();
        }
      });
      _screenshotCallbackActive = true;
    } catch (_) {
      // Screenshot detection not supported on this platform — silently ignore
    }
  }

  /// Called when the OS detects a screenshot was taken.
  /// 1. Notifies the OTHER user with a screenshot_alert message.
  /// 2. Shows the screenshot image back to the TAKER as a centered overlay (Snapchat-style).
  Future<void> _onScreenshotDetected() async {
    if (!mounted) return;
    final myUid = Provider.of<AuthService>(context, listen: false).user?.uid ?? '';

    // 1. Send screenshot_alert to the OTHER user (they see "X took a screenshot")
    _sendMessage(
      text: '$myName took a screenshot 📸',
      mediaType: 'screenshot_alert',
    );

    // 2. Find the latest screenshot in gallery and show it as a preview to the TAKER
    try {
      // Try to find the most recent screenshot saved by the OS
      String? screenshotPath;
      final dirs = <Directory?>[];
      if (Platform.isAndroid) {
        // Common Android screenshot locations
        dirs.addAll([
          Directory('/storage/emulated/0/Pictures/Screenshots'),
          Directory('/storage/emulated/0/DCIM/Screenshots'),
          Directory('/sdcard/Pictures/Screenshots'),
        ]);
      } else if (Platform.isIOS) {
        // On iOS the photo is in the photo library — path_provider gives us a temp dir
        final temp = await getTemporaryDirectory();
        dirs.add(temp);
      }

      for (final dir in dirs) {
        if (dir == null || !dir.existsSync()) continue;
        final files = dir
            .listSync()
            .whereType<File>()
            .where((f) =>
                f.path.toLowerCase().endsWith('.png') ||
                f.path.toLowerCase().endsWith('.jpg'))
            .toList();
        if (files.isEmpty) continue;
        files.sort((a, b) =>
            b.statSync().modified.compareTo(a.statSync().modified));
        final newest = files.first;
        // Only use if modified within last 5 seconds
        if (DateTime.now().difference(newest.statSync().modified).inSeconds < 5) {
          screenshotPath = newest.path;
          break;
        }
      }

      if (mounted) {
        setState(() {
          _showScreenshotPreview = true;
          _lastScreenshotPath = screenshotPath;
        });
      }
    } catch (_) {
      // Preview failed — alert already sent, just continue
      if (mounted) {
        setState(() {
          _showScreenshotPreview = true;
          _lastScreenshotPath = null;
        });
      }
    }
  }

  /// Builds the Snapchat-style screenshot preview overlay shown to the TAKER.
  Widget _buildScreenshotPreviewOverlay() {
    if (!_showScreenshotPreview) return const SizedBox.shrink();
    return AnimatedOpacity(
      opacity: _showScreenshotPreview ? 1.0 : 0.0,
      duration: const Duration(milliseconds: 250),
      child: Container(
          color: Colors.black.withValues(alpha: 0.82),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Screenshot image (if found)
                if (_lastScreenshotPath != null) ...[
                  ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: Image.file(
                      File(_lastScreenshotPath!),
                      width: MediaQuery.of(context).size.width * 0.82,
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => _screenshotPlaceholder(),
                    ),
                  ),
                ] else
                  _screenshotPlaceholder(),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Icon(Icons.screenshot_monitor_rounded, color: Colors.white, size: 18),
                      SizedBox(width: 8),
                      Text(
                        'Screenshot sent to chat',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 14,
                          letterSpacing: 0.2,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
  }

  Widget _screenshotPlaceholder() {
    return Container(
      width: MediaQuery.of(context).size.width * 0.72,
      height: MediaQuery.of(context).size.width * 0.72,
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white24, width: 1.5),
      ),
      child: const Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.camera_alt_rounded, color: Colors.white38, size: 56),
          SizedBox(height: 12),
          Text('Screenshot captured', style: TextStyle(color: Colors.white54, fontSize: 14)),
        ],
      ),
    );
  }


    if (hasText && !_isSendingTyping) {
      _isSendingTyping = true;
      _fs.setTyping(widget.targetId, true).catchError((_) {});
    }
    _typingTimer?.cancel();
    _typingTimer = Timer(const Duration(seconds: 3), () {
      _isSendingTyping = false;
      _fs.setTyping(widget.targetId, false).catchError((_) {});
    });
  }

  // ── Load older messages (pagination) ──────────────────────────────────
  Future<void> _loadMoreMessages() async {
    if (_isLoadingMore || !_hasMoreMessages || _lastDoc == null) return;
    setState(() => _isLoadingMore = true);
    try {
      final myUid = Provider.of<AuthService>(context, listen: false).user?.uid ?? '';
      final snap = await _fs.loadMoreMessages(widget.targetId, _lastDoc!);
      final newDocs = snap.docs;
      if (newDocs.length < 30) _hasMoreMessages = false;
      if (newDocs.isNotEmpty) {
        _lastDoc = newDocs.last;
        final older = <Map<String, dynamic>>[];
        for (final doc in newDocs) {
          final data = doc.data() as Map<String, dynamic>;
          final deletedFor = (data['deletedFor'] as List?)?.cast<String>() ?? [];
          if (deletedFor.contains(myUid)) continue;
          older.add({
            'id': doc.id, 'firestoreId': doc.id,
            'text': data['text']?.isNotEmpty == true ? data['text'] : null,
            'imageUrl': data['imageUrl'], 'videoUrl': data['videoUrl'],
            'audioPath': data['audioUrl'],
            'docPath': data['docUrl'], 'docName': data['docName'],
            'mediaType': data['mediaType'],
            'isMe': data['senderId'] == myUid,
            'isLiked': false, 'isPinned': data['isPinned'] ?? false,
            'reaction': data['reaction'],
            'reactions': data['reactions'] as Map<String, dynamic>? ?? {},
            'isRead': data['isRead'] ?? false,
            'timestamp': (data['timestamp'] as dynamic)?.toDate() ?? DateTime.now(),
            'replyTo': data['replyTo'], 'storyReply': data['storyReply'],
            'contactUid': data['contactUid'], 'contactName': data['contactName'],
            'contactPhoto': data['contactPhoto'], 'contactUsername': data['contactUsername'],
            'lat': data['lat'], 'lng': data['lng'],
            'pollOptions': data['pollOptions'], 'pollVotes': data['pollVotes'],
            'gameType': data['gameType'], 'gameId': data['gameId'],
            'senderName': data['senderName'],
            'sharedPost': data['sharedPost'], 'sharedPostId': data['sharedPostId'],
            '_idx': _olderMessages.length + older.length,
          });
        }
        if (mounted) setState(() => _olderMessages.addAll(older));
      }
    } catch (_) {} finally {
      if (mounted) setState(() => _isLoadingMore = false);
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _fs.updateOnlineStatus(false).catchError((_) {});
    _msgController.dispose();
    _scrollController.dispose();
    _searchController.dispose();
    _typingSub?.cancel();
    _typingTimer?.cancel();
    _blockSub?.cancel();
    _blockedBySub?.cancel();
    _screenshotCallbackActive = false;
    _screenshotPreviewTimer?.cancel();
    _fs.setTyping(widget.targetId, false).catchError((_) {});
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _fs.markAsRead(widget.targetId).catchError((_) {});
      _fs.updateOnlineStatus(true).catchError((_) {});
    } else if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive || state == AppLifecycleState.detached) {
      _fs.updateOnlineStatus(false).catchError((_) {});
    }
  }

  void _handleMentionTyping() {
    final text = _msgController.text;
    final cursor = _msgController.selection.baseOffset;
    if (cursor < 0) return;
    final sub = text.substring(0, cursor);
    final atIdx = sub.lastIndexOf('@');
    if (atIdx >= 0 && (atIdx == 0 || sub[atIdx - 1] == ' ')) {
      final query = sub.substring(atIdx + 1);
      if (!query.contains(' ') && query.length <= 20) {
        setState(() { _mentionQuery = query; _showMentions = true; });
        _fetchMentionUsers(query);
        return;
      }
    }
    if (_showMentions) setState(() { _showMentions = false; _mentionSuggestions = []; });
  }

  void _handleZyloDetect() {
    final text = _msgController.text;
    // Show @zylo chip when user just typed '@'
    final showChip = text.endsWith('@') || text.endsWith('@z') ||
        text.endsWith('@zy') || text.endsWith('@zyl') || text.endsWith('@zylo');
    if (showChip != _showZyloSuggest) setState(() => _showZyloSuggest = showChip);
  }

  Future<void> _triggerZyloAi(String userMsg) async {
    // Replace @zylo mention from the message
    final clean = userMsg.replaceAll(RegExp(r'@zylo\b', caseSensitive: false), '').trim();
    if (clean.isEmpty) return;
    setState(() => _zyloAiTyping = true);
    try {
      final aiResponse = await AiChatService.sendMessage(
        message: clean,
        sessionId: _fs.myUid,
        customInstruction: 'You are Zylo AI, a friendly smart assistant inside Zylo chat app. Reply concisely and helpfully. If asked in Hindi/Hinglish, reply in Hinglish.',
      );
      final reply = aiResponse['reply'] ?? aiResponse['message'] ?? '🤖 Kuch problem aayi';
      if (mounted) {
        // Insert AI reply as a special 'zylo_ai' message
        final ids = [_fs.myUid, widget.targetId]..sort();
        final cid = '${ids[0]}_${ids[1]}';
        await FirebaseFirestore.instance
            .collection('chats').doc(cid).collection('messages')
            .add({
          'text': reply,
          'mediaType': 'zylo_ai',
          'senderId': _fs.myUid,
          'senderName': 'Zylo AI',
          'timestamp': FieldValue.serverTimestamp(),
          'isRead': false,
        });
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Zylo AI error: $e'), backgroundColor: Colors.red));
    }
    if (mounted) setState(() => _zyloAiTyping = false);
  }

  void _showPollCreator() {
    final questionCtrl = TextEditingController();
    final opt1Ctrl = TextEditingController(text: 'Yes');
    final opt2Ctrl = TextEditingController(text: 'No');
    final opt3Ctrl = TextEditingController();
    showModalBottomSheet(
      context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: StatefulBuilder(builder: (ctx2, setSt) => Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(child: Container(width: 36, height: 4,
                decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10)))),
              const SizedBox(height: 16),
              Row(children: [
                Container(width: 36, height: 36,
                  decoration: const BoxDecoration(color: Color(0xFF0284C7), shape: BoxShape.circle),
                  child: const Icon(Icons.poll_rounded, color: Colors.white, size: 20)),
                const SizedBox(width: 10),
                const Text('Create Poll', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
              ]),
              const SizedBox(height: 16),
              TextField(
                controller: questionCtrl, autofocus: true,
                decoration: InputDecoration(
                  hintText: 'Poll question likhein...', filled: true, fillColor: const Color(0xFFF8FAFF),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)),
              ),
              const SizedBox(height: 12),
              const Text('Options', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: Colors.grey)),
              const SizedBox(height: 8),
              _pollOptionField(opt1Ctrl, 'Option 1'),
              const SizedBox(height: 8),
              _pollOptionField(opt2Ctrl, 'Option 2'),
              const SizedBox(height: 8),
              _pollOptionField(opt3Ctrl, 'Option 3 (optional)'),
              const SizedBox(height: 20),
              SizedBox(width: double.infinity,
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.send_rounded, size: 18),
                  label: const Text('Send Poll', style: TextStyle(fontWeight: FontWeight.w700)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF0284C7), foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                  onPressed: () {
                    final q = questionCtrl.text.trim();
                    if (q.isEmpty) return;
                    final opts = [opt1Ctrl.text.trim(), opt2Ctrl.text.trim(), opt3Ctrl.text.trim()]
                        .where((o) => o.isNotEmpty).toList();
                    if (opts.length < 2) {
                      ScaffoldMessenger.of(ctx2).showSnackBar(
                        const SnackBar(content: Text('Kam se kam 2 options chahiye')));
                      return;
                    }
                    Navigator.pop(ctx);
                    _sendMessage(
                      text: q,
                      mediaType: 'poll',
                      extraData: {
                        'pollOptions': opts,
                        'pollVotes': <String, String>{}, // uid -> option
                      },
                    );
                  },
                )),
            ],
          )),
        ),
      ),
    );
  }

  // ── Cached message list (shown while Firebase loads or offline) ─────────────
  /// SQLite-backed message list — shown instantly before Firestore arrives
  /// Messages already in proper format from LocalDbService._rowToMessage
  Widget _buildSqliteMessageList(List<Map<String, dynamic>> msgs, String myUid) {
    return ListView.builder(
      controller: _scrollController,
      reverse: true,
      padding: const EdgeInsets.only(top: 4, bottom: 4, left: 6, right: 6),
      itemCount: msgs.length,
      addAutomaticKeepAlives: false,
      addRepaintBoundaries: true,
      cacheExtent: 500,
      itemBuilder: (ctx, i) {
        final m = msgs[i];
        final isMe = (m['senderId'] as String? ?? '') == myUid;
        final text = m['text'] as String? ?? '';
        final ts = m['timestamp'] as DateTime? ?? DateTime.now();
        final timeStr = '${ts.hour.toString().padLeft(2,'0')}:${ts.minute.toString().padLeft(2,'0')}';
        final mediaType = m['mediaType'] as String? ?? 'text';

        return Align(
          alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            margin: EdgeInsets.only(
              top: 2, bottom: 2,
              left: isMe ? 60 : 8,
              right: isMe ? 8 : 60,
            ),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: isMe ? const Color(0xFF0284C7) : Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: const Radius.circular(16),
                topRight: const Radius.circular(16),
                bottomLeft: Radius.circular(isMe ? 16 : 4),
                bottomRight: Radius.circular(isMe ? 4 : 16),
              ),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.06), blurRadius: 4, offset: const Offset(0,2))],
            ),
            child: Column(
              crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                if (text.isNotEmpty)
                  Text(text, style: TextStyle(color: isMe ? Colors.white : Colors.black87, fontSize: 14.5)),
                if (mediaType == 'image' && (m['imageUrl'] as String? ?? '').isNotEmpty)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.network(m['imageUrl'] as String, width: 200, height: 160, fit: BoxFit.cover)),
                if (mediaType != 'text' && mediaType != 'image' && text.isEmpty)
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(_mediaIcon(mediaType), size: 16, color: isMe ? Colors.white70 : Colors.grey),
                    const SizedBox(width: 4),
                    Text(_mediaLabel(mediaType), style: TextStyle(color: isMe ? Colors.white70 : Colors.grey, fontSize: 13)),
                  ]),
                const SizedBox(height: 2),
                Text(timeStr, style: TextStyle(
                  color: isMe ? Colors.white60 : Colors.grey[400], fontSize: 10, fontWeight: FontWeight.w500)),
              ],
            ),
          ),
        );
      },
    );
  }

  IconData _mediaIcon(String type) {
    switch (type) {
      case 'image': return Icons.image_rounded;
      case 'video': return Icons.videocam_rounded;
      case 'audio': return Icons.mic_rounded;
      case 'document': return Icons.insert_drive_file_rounded;
      case 'location': return Icons.location_on_rounded;
      case 'poll': return Icons.poll_rounded;
      default: return Icons.attach_file_rounded;
    }
  }

  Widget _buildCachedMessageList(List<Map<String, dynamic>> cached, String myUid) {
    final msgs = cached.take(50).toList(); // show up to 50 cached messages
    return ListView.builder(
      controller: _scrollController,
      reverse: true,
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
      itemCount: msgs.length,
      itemBuilder: (ctx, i) {
        final data = msgs[i];
        final isMe = data['senderId'] == myUid;
        final text = data['text'] as String? ?? '';
        final tsRaw = data['timestamp'];
        DateTime ts = DateTime.now();
        if (tsRaw is int) ts = DateTime.fromMillisecondsSinceEpoch(tsRaw);
        final timeStr = '${ts.hour.toString().padLeft(2,'0')}:${ts.minute.toString().padLeft(2,'0')}';

        return Align(
          alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 2, horizontal: 4),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            constraints: BoxConstraints(maxWidth: MediaQuery.of(ctx).size.width * 0.72),
            decoration: BoxDecoration(
              color: isMe ? const Color(0xFF0284C7) : Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: const Radius.circular(16),
                topRight: const Radius.circular(16),
                bottomLeft: Radius.circular(isMe ? 16 : 4),
                bottomRight: Radius.circular(isMe ? 4 : 16),
              ),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.06), blurRadius: 4, offset: const Offset(0, 2))],
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
              if (text.isNotEmpty)
                Text(text, style: TextStyle(color: isMe ? Colors.white : Colors.black87, fontSize: 14)),
              if (text.isEmpty)
                Icon(Icons.image_rounded, color: isMe ? Colors.white70 : Colors.grey, size: 20),
              const SizedBox(height: 2),
              Text(timeStr, style: TextStyle(color: isMe ? Colors.white60 : Colors.grey[400], fontSize: 10)),
            ]),
          ),
        );
      },
    );
  }

  Widget _pollOptionField(TextEditingController ctrl, String hint) {
    return TextField(
      controller: ctrl,
      decoration: InputDecoration(
        hintText: hint, filled: true, fillColor: const Color(0xFFF0F7FF),
        prefixIcon: const Icon(Icons.radio_button_unchecked, color: Color(0xFF0284C7), size: 18),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
        contentPadding: const EdgeInsets.symmetric(vertical: 10)),
    );
  }



  Future<void> _fetchMentionUsers(String query) async {
    if (query.isEmpty) {
      // Show recent users — just fetch all users (limit 8)
      final snap = await FirebaseFirestore.instance
          .collection('users')
          .limit(8)
          .get();
      if (mounted) {
        setState(() {
          _mentionSuggestions = snap.docs
              .where((d) => d.id != _fs.myUid)
              .map((d) => {'uid': d.id, ...d.data() as Map<String, dynamic>})
              .toList();
        });
      }
      return;
    }
    final snap = await FirebaseFirestore.instance
        .collection('users')
        .where('username', isGreaterThanOrEqualTo: query)
        .where('username', isLessThan: query + '\uf8ff')
        .limit(6)
        .get();
    if (mounted) {
      setState(() {
        _mentionSuggestions = snap.docs
            .where((d) => d.id != _fs.myUid)
            .map((d) => {'uid': d.id, ...d.data() as Map<String, dynamic>})
            .toList();
      });
    }
  }

  void _insertMention(String username) {
    final text = _msgController.text;
    final cursor = _msgController.selection.baseOffset;
    final sub = text.substring(0, cursor);
    final atIdx = sub.lastIndexOf('@');
    if (atIdx < 0) return;
    final before = text.substring(0, atIdx);
    final after = text.substring(cursor);
    final newText = '$before@$username $after';
    _msgController.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: before.length + username.length + 2),
    );
    setState(() { _showMentions = false; _mentionSuggestions = []; });
  }

  Future<void> _sendMessage({String? text, String? imageUrl, String? videoUrl,
      String? audioPath, String? docPath, String? docName, String? mediaType,
      Duration? timerDuration, Map<String, dynamic>? extraData}) async {
    if ((text == null || text.trim().isEmpty) && imageUrl == null &&
        videoUrl == null && audioPath == null && docPath == null &&
        mediaType != 'screenshot_alert' && mediaType != 'location') return;

    // ── Double-send guard ────────────────────────────────────────────────────
    if (_isSending) return;
    setState(() => _isSending = true); // immediate UI feedback on button

    // ── Outgoing translation ─────────────────────────────────────────────────
    String? _outOriginalText; // original text before translation (for bubble toggle)
    if (text != null && text.trim().isNotEmpty && mediaType != 'screenshot_alert') {
      final tSvc = Provider.of<TranslationService>(context, listen: false);
      if (tSvc.outEnabled) {
        final translated = await tSvc.translateOutgoing(text.trim());
        // Guard: ignore sentinel (model not downloaded) and identity translations
        if (translated != null &&
            translated.isNotEmpty &&
            translated != TranslationResult.modelNotDownloaded &&
            translated != text.trim()) {
          _outOriginalText = text.trim(); // save original
          text = translated;             // send translated
        }
      }
    }

    final timerEnds = timerDuration != null ? DateTime.now().add(timerDuration) : null;
    final tempId = DateTime.now().millisecondsSinceEpoch.toString();
    // Capture replyTo BEFORE clearing it
    final capturedReply = _replyTo != null ? {
      'text': _replyTo!['text'], 'mediaType': _replyTo!['mediaType'], 'isMe': _replyTo!['isMe'],
    } : null;
    final myUid = Provider.of<AuthService>(context, listen: false).user?.uid ?? '';
    setState(() {
      _messages.insert(0, {
        'id': tempId, 'text': text?.trim(), 'imageUrl': imageUrl, 'videoUrl': videoUrl,
        'audioPath': audioPath, 'docPath': docPath, 'docName': docName,
        'mediaType': mediaType ?? 'text', 'isMe': true, 'isLiked': false, 'isPinned': false,
        'timestamp': DateTime.now(), 'timerEnds': timerEnds,
        'replyTo': capturedReply,
        if (extraData != null) ...extraData,
      });
      _replyTo = null;
      _lastSentId = tempId;
    });
    // SQLite: optimistic insert (instantly saved locally)
    LocalDbService.instance.insertMessage(
      localId: tempId,
      myUid: myUid,
      otherUid: widget.targetId,
      senderId: myUid,
      text: text?.trim(),
      mediaType: mediaType ?? 'text',
      imageUrl: imageUrl,
      videoUrl: videoUrl,
      audioUrl: audioPath,
      docUrl: docPath,
      docName: docName,
      replyTo: capturedReply,
      extraData: extraData,
      synced: false,
    ).catchError((_) {});
    // If outgoing translation happened, store mapping for bubble toggle
    if (_outOriginalText != null && text != null) {
      _translatedTexts[tempId] = text.trim();
      _translatedTexts['${tempId}_orig'] = _outOriginalText;
    }
    // Haptic: distinct send pattern
    HapticFeedback.lightImpact();
    Future.delayed(const Duration(milliseconds: 60), () => HapticFeedback.lightImpact());
    _msgController.clear();
    // ── Release send guard after optimistic insert ─────────────────────────
    if (mounted) setState(() => _isSending = false);
    // ── @zylo AI trigger ──────────────────────────────────────────────────────
    if (text != null && RegExp(r'@zylo\b', caseSensitive: false).hasMatch(text)) {
      _triggerZyloAi(text);
    }
    _fs.sendMessage(otherUid: widget.targetId, text: text?.trim(), imageUrl: imageUrl,
      videoUrl: videoUrl, audioUrl: audioPath, docUrl: docPath, docName: docName,
      mediaType: mediaType ?? 'text', replyTo: capturedReply, extraData: extraData).then((_) async {
      if (mounted) setState(() { _messages.removeWhere((m) => m['id'] == tempId); });
      // SQLite: mark as synced (tempId -> firestoreId)
      // Note: we don't have firestoreId here directly, so we mark by tempId
      LocalDbService.instance.markSynced(tempId, tempId).catchError((_) {});

      // ── AI Chat Integration ──────────────────────────────────────────────────
      if (widget.targetId == 'AI_CHAT_BOT_ID' && text != null && text.trim().isNotEmpty) {
        try {
          final aiResponse = await AiChatService.sendMessage(
            message: text.trim(),
            sessionId: _fs.myUid,
          );
          final botReply = aiResponse['reply'] ?? aiResponse['message'] ?? 'No response from AI.';
          // Send bot reply into this chat only (once — no duplicate)
          await _fs.sendMessage(
            otherUid: widget.targetId,
            text: botReply,
            mediaType: 'text',
          );
        } catch (e) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('AI Error: ${e.toString()}'), backgroundColor: Colors.red),
            );
          }
        }
      }
      // ─────────────────────────────────────────────────────────────────────────
      if (mediaType != 'screenshot_alert') {
        final notifText = text?.trim().isNotEmpty == true ? text!.trim()
            : imageUrl != null ? 'Photo' : videoUrl != null ? 'Video'
            : audioPath != null ? 'Audio' : 'Document';
        _ns.sendMessageNotification(toUid: widget.targetId, fromName: myName,
          messageText: notifText, chatId: ([widget.targetId, _fs.myUid]..sort()).join('_'),
          mediaType: imageUrl != null ? 'image' : videoUrl != null ? 'video' : audioPath != null ? 'audio' : null).catchError((_) {});
      }
    }).catchError((_) {
      if (mounted) setState(() => _isSending = false); // release on error too
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to send.'), backgroundColor: Colors.red));
    });
  }

  Future<void> _handleMediaSelected(List<File> files, bool isVideo) async {
    if (!isVideo && files.isNotEmpty) {
      if (!mounted) return;
      await _uploadAndSendImages(files);
      return;
    }
    setState(() => _isUploading = true);
    final authService = Provider.of<AuthService>(context, listen: false);
    final userId = authService.user?.uid ?? 'unknown';
    for (final file in files) {
      try {
        final url = await FileService.uploadFile(file, userId);
        _sendMessage(videoUrl: url, mediaType: 'video');
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Upload failed: $e'), backgroundColor: Colors.red));
        }
      }
    }
    if (mounted) setState(() => _isUploading = false);
  }

  Future<void> _uploadAndSendImages(List<File> files) async {
    setState(() => _isUploading = true);
    final authService = Provider.of<AuthService>(context, listen: false);
    final userId = authService.user?.uid ?? 'unknown';
    // Add local pending bubbles immediately
    final now = DateTime.now();
    final pendingIds = <String>[];
    for (int i = 0; i < files.length; i++) {
      final pid = 'pending_${now.millisecondsSinceEpoch}_$i';
      pendingIds.add(pid);
      setState(() => _messages.insert(0, {
        'id': pid,
        'firestoreId': null,
        'senderId': userId,
        'mediaType': 'image',
        'imageUrl': null,
        'localPath': files[i].path,
        'isUploading': true,
        'isMe': true,
        'timestamp': now,
      }));
    }
    try {
      if (files.length == 1) {
        final url = await FileService.uploadFile(files.first, userId);
        // Remove pending bubble
        if (mounted) setState(() => _messages.removeWhere((m) => m['id'] == pendingIds[0]));
        _sendMessage(imageUrl: url, mediaType: 'image');
      } else {
        final List<String> urls = [];
        for (int i = 0; i < files.length; i++) {
          final url = await FileService.uploadFile(files[i], userId);
          urls.add(url);
          if (mounted) setState(() => _messages.removeWhere((m) => m['id'] == pendingIds[i]));
        }
        _sendMessage(
          imageUrl: urls.first,
          mediaType: 'image',
          extraData: urls.length > 1 ? {'imageUrls': urls} : null,
        );
      }
    } catch (e) {
      // Remove pending bubbles on failure
      for (final pid in pendingIds) {
        if (mounted) setState(() => _messages.removeWhere((m) => m['id'] == pid));
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Upload failed: $e'), backgroundColor: Colors.red));
      }
    }
    if (mounted) setState(() => _isUploading = false);
  }

  void _handleDocumentSelected(File file) async {
    setState(() => _isUploading = true);
    final authService = Provider.of<AuthService>(context, listen: false);
    final userId = authService.user?.uid ?? 'unknown';
    try {
      final url = await FileService.uploadFile(file, userId);
      _sendMessage(docPath: url, docName: p.basename(file.path), mediaType: 'document');
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Upload failed: $e'), backgroundColor: Colors.red),
        );
      }
    }
    if (mounted) setState(() => _isUploading = false);
  }

  void _handleAudioSelected(File file) async {
    setState(() => _isUploading = true);
    final authService = Provider.of<AuthService>(context, listen: false);
    final userId = authService.user?.uid ?? 'unknown';
    try {
      final url = await FileService.uploadFile(file, userId);
      _sendMessage(audioPath: url, docName: p.basename(file.path), mediaType: 'audio');
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Upload failed: $e'), backgroundColor: Colors.red),
        );
      }
    }
    setState(() => _isUploading = false);
  }

  void _handleLocationSelected(double lat, double lng) {
    _sendMessage(
      text: '📍 Location',
      mediaType: 'location',
      extraData: {'lat': lat, 'lng': lng},
    );
  }

  void _openMediaPicker() {
    showMediaPicker(
      context,
      onMediaSelected: _handleMediaSelected,
      onDocumentSelected: _handleDocumentSelected,
      onAudioSelected: _handleAudioSelected,
      onContactSelected: _showShareContactSheet,
      onLocationSelected: _handleLocationSelected,
      opponentId: widget.targetId,
      opponentName: widget.targetName,
    );
  }

  void _showShareContactSheet() {
    // Show bottom sheet with two tabs: Phone Contacts + Zylo Users
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _ContactShareBottomSheet(
        myUid: _fs.myUid,
        onShareZyloUser: (contact) async {
          await _fs.sendContactCard(
            otherUid: widget.targetId,
            contactUid: contact['contactUid'],
            contactName: contact['contactName'],
            contactPhoto: contact['contactPhoto'],
            contactUsername: contact['contactUsername'],
          );
        },
        onSharePhoneContact: (name, phone) {
          _sendMessage(
            text: '📱 $name\n$phone',
            mediaType: 'text',
          );
        },
      ),
    );
  }

  // ── Update reaction in Firestore ─────────────────────────────────────────
  Future<void> _updateReaction(String? firestoreId, String emoji) async {
    if (firestoreId == null) return;
    final ids = [_fs.myUid, widget.targetId]..sort();
    final cid = '${ids[0]}_${ids[1]}';
    try {
      await FirebaseFirestore.instance
          .collection('chats').doc(cid).collection('messages').doc(firestoreId)
          .update({'reactions.${_fs.myUid}': emoji});
    } catch (_) {}
  }

  Future<void> _toggleLikeFirestore(String? firestoreId, bool liked) async {
    if (firestoreId == null) return;
    final ids = [_fs.myUid, widget.targetId]..sort();
    final cid = '${ids[0]}_${ids[1]}';
    try {
      await FirebaseFirestore.instance
          .collection('chats').doc(cid).collection('messages').doc(firestoreId)
          .update({'reactions.${_fs.myUid}': liked ? '❤️' : FieldValue.delete()});
    } catch (_) {}
  }

  // ── Forward message ──────────────────────────────────────────────────────
  void _showForwardSheet(Map<String, dynamic> msg) {
    showModalBottomSheet(
      context: context, backgroundColor: Colors.white, isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => _ForwardSheet(msg: msg, myUid: _fs.myUid),
    );
  }

  // ── In-App Share ─────────────────────────────────────────────────────────
  void _showInAppShare(Map<String, dynamic> msg) {
    ShareItem? item;
    final text = msg['text'] as String?;
    final imageUrl = msg['imageUrl'] as String?;
    final videoUrl = msg['videoUrl'] as String?;
    final audioPath = msg['audioPath'] as String?;
    final docPath = msg['docPath'] as String?;
    final docName = msg['docName'] as String?;
    final mediaType = msg['mediaType'] as String?;

    if (imageUrl != null) {
      item = ShareItem(type: 'photo', url: imageUrl, fileName: 'Image');
    } else if (videoUrl != null) {
      item = ShareItem(type: 'video', url: videoUrl, fileName: 'Video');
    } else if (audioPath != null || mediaType == 'audio') {
      item = ShareItem(type: 'audio', url: audioPath, fileName: docName ?? 'Voice Message');
    } else if (docPath != null) {
      final ext = (docName ?? '').split('.').last.toLowerCase();
      item = ShareItem(type: ext == 'pdf' ? 'pdf' : 'file', url: docPath, fileName: docName ?? 'Document');
    } else if (text != null && text.isNotEmpty) {
      final isLink = text.startsWith('http://') || text.startsWith('https://');
      item = ShareItem(type: isLink ? 'link' : 'text', text: text, url: isLink ? text : null);
    }

    showAppShareSheet(
      context,
      item: item,
      onShare: (shareItem, uid, name) async {
        // Build message params from share item
        String? shareText = shareItem.text;
        String? shareImageUrl;
        String? shareVideoUrl;
        String? shareAudioPath;
        String? shareDocPath;
        String? shareDocName;
        String? shareMType;

        switch (shareItem.type) {
          case 'photo':
            shareImageUrl = shareItem.url ?? shareItem.file?.path;
            shareMType = 'image';
            break;
          case 'video':
            shareVideoUrl = shareItem.url ?? shareItem.file?.path;
            shareMType = 'video';
            break;
          case 'audio':
            shareAudioPath = shareItem.url ?? shareItem.file?.path;
            shareDocName = shareItem.fileName;
            shareMType = 'audio';
            break;
          case 'pdf':
          case 'file':
            shareDocPath = shareItem.url ?? shareItem.file?.path;
            shareDocName = shareItem.fileName;
            shareMType = 'document';
            break;
          case 'link':
          case 'text':
            shareText = shareItem.text ?? shareItem.url;
            shareMType = 'text';
            break;
        }

        await _fs.sendMessage(
          otherUid: uid,
          text: shareText,
          imageUrl: shareImageUrl,
          videoUrl: shareVideoUrl,
          audioUrl: shareAudioPath,
          docUrl: shareDocPath,
          docName: shareDocName,
          mediaType: shareMType ?? 'text',
        );
      },
    );
  }

  // ── Save image to Zylo folder ────────────────────────────────────────────
  Future<void> _saveImageToZylo(String url) async {
    try {
      // Download image to temp file
      final response = await http.get(Uri.parse(url));
      final dir = await getTemporaryDirectory();
      final fileName = 'zylo_${DateTime.now().millisecondsSinceEpoch}.jpg';
      final tmpFile = File('${dir.path}/$fileName');
      await tmpFile.writeAsBytes(response.bodyBytes);
      // Use Gal to save to gallery (works Android 10+)
      final hasAccess = await Gal.hasAccess();
      if (!hasAccess) {
        final granted = await Gal.requestAccess();
        if (!granted) {
          if (mounted) ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Gallery permission denied'), backgroundColor: Colors.red));
          return;
        }
      }
      await Gal.putImage(tmpFile.path, album: 'Zylo');
      await tmpFile.delete();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: const Text('✅ Saved to Gallery'),
          backgroundColor: Colors.green,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to save: $e'), backgroundColor: Colors.red));
    }
  }

  // ── Save any media/file to Zylo Cloud (Telegram unlimited storage) ────────
  Future<void> _saveToZyloCloud(Map<String, dynamic> msg) async {
    final imageUrl  = msg['imageUrl']  as String?;
    final videoUrl  = msg['videoUrl']  as String?;
    final audioPath = msg['audioPath'] as String?;
    final docPath   = msg['docPath']   as String?;
    final docName   = msg['docName']   as String? ?? 'file';

    String? downloadUrl;
    String  fileName = 'zylo_file';

    if (imageUrl != null && imageUrl.isNotEmpty) {
      downloadUrl = imageUrl;
      fileName = 'img_${DateTime.now().millisecondsSinceEpoch}.jpg';
    } else if (videoUrl != null && videoUrl.isNotEmpty) {
      downloadUrl = videoUrl;
      fileName = 'vid_${DateTime.now().millisecondsSinceEpoch}.mp4';
    } else if (audioPath != null && audioPath.isNotEmpty) {
      if (audioPath.startsWith('tg:')) { _showCloudResult('☁️ Already in Zylo Cloud!', Colors.blue); return; }
      downloadUrl = audioPath;
      fileName = 'audio_${DateTime.now().millisecondsSinceEpoch}.mp3';
    } else if (docPath != null && docPath.isNotEmpty) {
      if (docPath.startsWith('tg:')) { _showCloudResult('☁️ Already in Zylo Cloud!', Colors.blue); return; }
      downloadUrl = docPath;
      fileName = docName;
    } else {
      _showCloudResult('⚠️ No media to save', Colors.orange);
      return;
    }

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        const SizedBox(width: 18, height: 18,
          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)),
        const SizedBox(width: 12),
        const Text('Saving to Zylo Cloud...', style: TextStyle(fontWeight: FontWeight.w600)),
      ]),
      duration: const Duration(seconds: 60),
      backgroundColor: const Color(0xFF0284C7),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));

    try {
      final resp    = await http.get(Uri.parse(downloadUrl!)).timeout(const Duration(minutes: 5));
      final dir     = await getTemporaryDirectory();
      final tmpFile = File('${dir.path}/$fileName');
      await tmpFile.writeAsBytes(resp.bodyBytes);
      await CloudflareService.uploadFile(tmpFile);
      await tmpFile.delete();
      if (!mounted) return;
      ScaffoldMessenger.of(context).hideCurrentSnackBar();
      _showCloudResult('☁️ Saved to Zylo Cloud!', Colors.green);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).hideCurrentSnackBar();
      _showCloudResult('❌ Failed: $e', Colors.red);
    }
  }

  void _showCloudResult(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontWeight: FontWeight.w600)),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 3),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }

  // ── Long press with position — overlay popup near message ────────────────
  void _handleLongPressWithPosition(Map<String, dynamic> msg, int index, Offset globalPos) {
    if (msg['mediaType'] == 'screenshot_alert') return;
    // Distinct 2-pulse haptic for long press
    HapticFeedback.heavyImpact();
    Future.delayed(const Duration(milliseconds: 80), () => HapticFeedback.mediumImpact());

    final screenH = MediaQuery.of(context).size.height;
    final screenW = MediaQuery.of(context).size.width;
    final isMe = msg['isMe'] as bool? ?? false;

    showDialog(
      context: context,
      barrierColor: Colors.black26,
      barrierDismissible: true,
      builder: (ctx) {
        // Emoji bar dimensions: ~290 wide, ~56 tall
        // Action menu: ~210 wide, ~280 tall (est)
        const emojiBarW = 290.0;
        const emojiBarH = 56.0;
        const menuW = 210.0;
        const menuH = 290.0;
        const gap = 8.0;

        // Try to anchor emoji bar just above the tap point
        double emojiTop = globalPos.dy - emojiBarH - gap;
        // If too close to top, put it below
        if (emojiTop < 60) emojiTop = globalPos.dy + gap;

        // Menu goes right below emoji bar
        double menuTop = emojiTop + emojiBarH + gap;
        // If menu overflows bottom, push both upward
        if (menuTop + menuH > screenH - 40) {
          menuTop = screenH - 40 - menuH;
          emojiTop = menuTop - gap - emojiBarH;
        }

        // Horizontal: align to message side
        double emojiLeft = (screenW - emojiBarW) / 2;
        double menuLeft = isMe ? (screenW - menuW - 8) : 8.0;

        // Clamp
        emojiLeft = emojiLeft.clamp(8.0, screenW - emojiBarW - 8);
        menuLeft = menuLeft.clamp(8.0, screenW - menuW - 8);

        return Stack(children: [
          // Emoji bubble bar
          Positioned(
            top: emojiTop,
            left: emojiLeft,
            child: Material(
              color: Colors.transparent,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.18), blurRadius: 16, offset: const Offset(0, 4))],
                ),
                child: Row(mainAxisSize: MainAxisSize.min,
                  children: ['❤️', '😂', '😮', '😢', '🔥', '👍'].map((e) {
                    // Highlight if current user reacted with this
                    final myReaction = (msg['reactions'] as Map? ?? {})[_fs.myUid];
                    final isActive = myReaction == e;
                    return GestureDetector(
                      onTap: () {
                        Navigator.pop(ctx);
                        final newEmoji = isActive ? null : e;
                        setState(() {
                          final reactions = Map<String, dynamic>.from(msg['reactions'] as Map? ?? {});
                          if (newEmoji == null) reactions.remove(_fs.myUid);
                          else reactions[_fs.myUid] = newEmoji;
                          // Update in _messages list
                          final idx = _messages.indexWhere((m) => m['id'] == msg['id']);
                          if (idx >= 0) _messages[idx]['reactions'] = reactions;
                        });
                        if (newEmoji != null) {
                          _updateReaction(msg['firestoreId'] as String?, newEmoji);
                        } else {
                          // Remove reaction
                          final fid = msg['firestoreId'] as String?;
                          if (fid != null) {
                            final ids = [_fs.myUid, widget.targetId]..sort();
                            final cid = '${ids[0]}_${ids[1]}';
                            FirebaseFirestore.instance
                                .collection('chats').doc(cid).collection('messages').doc(fid)
                                .update({'reactions.${_fs.myUid}': FieldValue.delete()})
                                .catchError((_) {});
                          }
                        }
                      },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 120),
                        width: isActive ? 42 : 36,
                        height: isActive ? 42 : 36,
                        margin: const EdgeInsets.symmetric(horizontal: 2),
                        decoration: BoxDecoration(
                          color: isActive ? _blue.withValues(alpha: 0.12) : Colors.transparent,
                          shape: BoxShape.circle,
                        ),
                        child: Center(child: Text(e, style: TextStyle(fontSize: isActive ? 22 : 20))),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
          ),

          // Action menu
          Positioned(
            top: menuTop,
            left: menuLeft,
            child: Material(
              color: Colors.transparent,
              child: Container(
                width: 210,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.15), blurRadius: 16, offset: const Offset(0, 4))],
                ),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  // Sent time header in popup
                  if (msg['timestamp'] != null)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      child: Row(children: [
                        const Icon(Icons.access_time, size: 13, color: Colors.grey),
                        const SizedBox(width: 6),
                        Text(
                          _formatFullTime(msg['timestamp'] as DateTime),
                          style: const TextStyle(fontSize: 11, color: Colors.grey, fontWeight: FontWeight.w500),
                        ),
                      ]),
                    ),
                  const Divider(height: 1, thickness: 0.4),
                  _popupItem(ctx, Icons.reply_outlined, Colors.teal, 'Reply',
                    () => setState(() => _replyTo = msg)),
                  _popDivider(),
                  _popupItem(ctx, Icons.forward_rounded, Colors.indigo, 'Forward',
                    () => _showForwardSheet(msg)),
                  if (msg['text'] != null) ...[
                    _popDivider(),
                    _popupItem(ctx, Icons.copy_outlined, Colors.blue, 'Copy',
                      () { Clipboard.setData(ClipboardData(text: msg['text']));
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Copied!'))); }),
                  ],
                  if (msg['imageUrl'] != null) ...[
                    _popDivider(),
                    _popupItem(ctx, Icons.save_alt_rounded, Colors.green, 'Save Image',
                      () => _saveImageToZylo(msg['imageUrl'])),
                  ],
                  if (msg['imageUrl'] != null || msg['videoUrl'] != null || msg['audioPath'] != null || msg['docPath'] != null) ...[
                    _popDivider(),
                    _popupItem(ctx, Icons.cloud_upload_rounded, const Color(0xFF0284C7), 'Zylo Cloud ☁️',
                      () => _saveToZyloCloud(msg)),
                  ],
                  _popDivider(),
                  _popupItem(ctx, Icons.push_pin_outlined, Colors.orange,
                    (msg['isPinned'] ?? false) ? 'Unpin' : 'Pin',
                    () {
                      final idx = _messages.indexWhere((m) => m['id'] == msg['id']);
                      if (idx >= 0) {
                        final newPinState = !(msg['isPinned'] ?? false);
                        setState(() => _messages[idx]['isPinned'] = newPinState);
                        final firestoreId = msg['firestoreId'] as String?;
                        if (firestoreId != null) {
                          _fs.togglePinMessage(widget.targetId, firestoreId, newPinState).catchError((_) {});
                        }
                      }
                    }),
                  _popDivider(),
                  _popupItem(ctx, Icons.bookmark_add_outlined, const Color(0xFF0284C7), 'Save Message',
                    () async {
                      await _fs.saveMessage(msg, widget.targetName);
                      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('✅ Message saved!'), duration: Duration(seconds: 2)));
                    }),
                  _popDivider(),
                  _popupItem(ctx, Icons.check_circle_outline, Colors.blueGrey, 'Select',
                    () => setState(() {
                      _isSelectMode = true;
                      _selectedIds.add(msg['id']);
                      final fid = msg['firestoreId'] as String?;
                      if (fid != null) _selectedFirestoreIds[msg['id']] = fid;
                    })),
                ]),
              ),
            ),
          ),
        ]);
      },
    );
  }

  Widget _popupItem(BuildContext ctx, IconData icon, Color iconColor, String label, VoidCallback onTap, {Color? textColor}) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () { Navigator.pop(ctx); onTap(); },
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        child: Row(children: [
          Icon(icon, color: iconColor, size: 18),
          const SizedBox(width: 10),
          Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: textColor ?? Colors.black87)),
        ]),
      ),
    );
  }

  Widget _popDivider() => const Divider(height: 1, thickness: 0.4, indent: 14, endIndent: 14);

  // ── Long press menu (kept for fallback) ──────────────────────────────────
  void _handleLongPress(Map<String, dynamic> msg, int index) {
    if (msg['mediaType'] == 'screenshot_alert') return;
    HapticFeedback.mediumImpact();
    showModalBottomSheet(
      context: context, backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(margin: const EdgeInsets.only(top: 10, bottom: 6), width: 40, height: 4,
            decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
          // Reaction row
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: ['❤️', '😂', '😮', '😢', '🔥'].map((e) => GestureDetector(
                onTap: () { Navigator.pop(ctx); setState(() { _messages[index]['reaction'] = e; }); _updateReaction(msg['firestoreId'] as String?, e); },
                child: Container(width: 48, height: 48, decoration: BoxDecoration(color: Colors.grey[100], shape: BoxShape.circle),
                  child: Center(child: Text(e, style: const TextStyle(fontSize: 26)))),
              )).toList()),
          ),
          const Divider(height: 1, thickness: 0.5),
          _menuItem(icon: Icons.reply_outlined, iconColor: Colors.teal, label: 'Reply',
            onTap: () { Navigator.pop(ctx); setState(() => _replyTo = msg); }),
          _menuItem(icon: Icons.forward_rounded, iconColor: Colors.indigo, label: 'Forward',
            onTap: () { Navigator.pop(ctx); _showForwardSheet(msg); }),
          if (msg['imageUrl'] != null)
            _menuItem(icon: Icons.save_alt_rounded, iconColor: Colors.green, label: 'Save to Zylo Images',
              onTap: () { Navigator.pop(ctx); _saveImageToZylo(msg['imageUrl']); }),
          // ── Zylo Cloud — save image/video/audio/doc ──
          if (msg['imageUrl'] != null || msg['videoUrl'] != null || msg['audioPath'] != null || msg['docPath'] != null)
            _menuItem(
              icon: Icons.cloud_upload_rounded,
              iconColor: const Color(0xFF0284C7),
              label: 'Save to Zylo Cloud ☁️',
              onTap: () { Navigator.pop(ctx); _saveToZyloCloud(msg); },
            ),
          if (msg['text'] != null)
            _menuItem(icon: Icons.copy_outlined, iconColor: Colors.blue, label: 'Copy Text',
              onTap: () { Clipboard.setData(ClipboardData(text: msg['text'])); Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Copied!'))); }),
          _menuItem(icon: Icons.check_circle_outline, iconColor: Colors.blueGrey, label: 'Select Message',
            onTap: () { Navigator.pop(ctx); setState(() {
                      _isSelectMode = true;
                      _selectedIds.add(msg['id']);
                      final fid = msg['firestoreId'] as String?;
                      if (fid != null) _selectedFirestoreIds[msg['id']] = fid;
                    }); }),
          _menuItem(
            icon: (msg['isPinned'] ?? false) ? Icons.push_pin : Icons.push_pin_outlined,
            iconColor: Colors.orange,
            label: (msg['isPinned'] ?? false) ? 'Unpin Message' : 'Pin Message',
            onTap: () {
              Navigator.pop(ctx);
              final newPinState = !(msg['isPinned'] ?? false);
              setState(() { _messages[index]['isPinned'] = newPinState; });
              final firestoreId = msg['firestoreId'] as String?;
              if (firestoreId != null) {
                _fs.togglePinMessage(widget.targetId, firestoreId, newPinState).catchError((_) {});
              }
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text(newPinState ? 'Message pinned 📌' : 'Message unpinned'),
                backgroundColor: Colors.orange, behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
            }),
          _menuItem(icon: Icons.info_outline, iconColor: Colors.grey, label: 'Info',
            onTap: () { Navigator.pop(ctx); _showMessageInfo(msg); }),
          _menuItem(icon: Icons.delete_outline, iconColor: Colors.red, label: 'Delete', textColor: Colors.red,
            onTap: () {
              Navigator.pop(ctx);
              _showSingleDeleteDialog(msg);
            }),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  Widget _menuItem({required IconData icon, required Color iconColor, required String label, Color? textColor, required VoidCallback onTap}) {
    return InkWell(onTap: onTap,
      child: Padding(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 11),
        child: Row(children: [
          Container(width: 36, height: 36, decoration: BoxDecoration(color: iconColor.withValues(alpha: 0.1), shape: BoxShape.circle),
            child: Icon(icon, color: iconColor, size: 20)),
          const SizedBox(width: 16),
          Text(label, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500, color: textColor ?? Colors.black87)),
        ])));
  }

  void _showMessageInfo(Map<String, dynamic> msg) {
    final sentTime = msg['timestamp'] as DateTime?;
    final readTime = msg['readAt'] as DateTime? ?? (msg['isRead'] == true ? sentTime : null);
    showModalBottomSheet(
      context: context, backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10)))),
            const Text('Message Info', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
            const SizedBox(height: 16),
            if (sentTime != null) _infoRow(Icons.send_rounded, 'Sent', _formatFullTime(sentTime), Colors.blue),
            if (readTime != null)
              _infoRow(Icons.done_all_rounded, 'Read', _formatFullTime(readTime), const Color(0xFF53BDEB))
            else if (msg['isMe'] == true)
              _infoRow(Icons.done_rounded, 'Delivered', 'Not read yet', Colors.grey),
            if (msg['isPinned'] == true) _infoRow(Icons.push_pin, 'Status', 'Pinned 📌', Colors.orange),
            _infoRow(Icons.category_outlined, 'Type', _mediaLabel(msg['mediaType']), Colors.grey),
          ]),
        ),
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(children: [
        Container(width: 36, height: 36,
          decoration: BoxDecoration(color: color.withValues(alpha: 0.1), shape: BoxShape.circle),
          child: Icon(icon, color: color, size: 18)),
        const SizedBox(width: 12),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.black45, fontSize: 11)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
        ]),
      ]),
    );
  }

  String _formatFullTime(DateTime dt) {
    final now = DateTime.now();
    final isToday = dt.day == now.day && dt.month == now.month && dt.year == now.year;
    final isYesterday = dt.day == now.day - 1 && dt.month == now.month && dt.year == now.year;
    final h = dt.hour > 12 ? dt.hour - 12 : dt.hour == 0 ? 12 : dt.hour;
    final m = dt.minute.toString().padLeft(2, '0');
    final ampm = dt.hour >= 12 ? 'PM' : 'AM';
    final timeStr = '$h:$m $ampm';
    if (isToday) return 'Today, $timeStr';
    if (isYesterday) return 'Yesterday, $timeStr';
    return '${dt.day}/${dt.month}/${dt.year}, $timeStr';
  }

  void _showReportUserSheet() {
    final reasons = ['Spam or Unwanted Messages', 'Harassment or Bullying', 'Fake Profile', 'Inappropriate Content', 'Other'];
    int? selected;
    showModalBottomSheet(
      context: context, backgroundColor: Colors.white, isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => StatefulBuilder(builder: (ctx, setS) => SafeArea(
        child: Padding(padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10)))),
            Row(children: [
              Container(width: 40, height: 40, decoration: BoxDecoration(color: Colors.red.withValues(alpha: 0.1), shape: BoxShape.circle),
                child: const Icon(Icons.flag_outlined, color: Colors.red, size: 22)),
              const SizedBox(width: 12),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Report User', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                Text('Select a reason below', style: TextStyle(fontSize: 12, color: Colors.grey[500])),
              ]),
            ]),
            const SizedBox(height: 16),
            ...reasons.asMap().entries.map((e) {
              final i = e.key; final r = e.value;
              return GestureDetector(
                onTap: () => setS(() => selected = i),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    color: selected == i ? _blue.withValues(alpha: 0.08) : Colors.grey[50],
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: selected == i ? _blue : Colors.grey[200]!),
                  ),
                  child: Row(children: [
                    Expanded(child: Text(r, style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13,
                      color: selected == i ? _blue : Colors.black87))),
                    if (selected == i) const Icon(Icons.check_circle, color: _blue, size: 16),
                  ]),
                ),
              );
            }),
            const SizedBox(height: 8),
            SizedBox(width: double.infinity, child: ElevatedButton(
              onPressed: selected != null ? () { Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                  content: Text('User reported. We will review.'), backgroundColor: Colors.green));
              } : null,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red, padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
              child: const Text('Report', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
            )),
          ]),
        ),
      )),
    );
  }

  void _openFullScreenImage(String url, {VoidCallback? onSave, VoidCallback? onForward}) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => _FullScreenImageViewer(
      imageUrl: url, onSave: onSave, onForward: onForward)));
  }

  // ── Multi-image grid bubble ────────────────────────────────────────
  Widget _buildMultiImageGrid(List<String> urls, Map<String, dynamic> msg, bool isMe) {
    final count  = urls.length;
    final show   = count.clamp(1, 4); // show max 4 slots
    final extra  = count - 4;          // +N overlay on 4th
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: count == 2
        // ── 2 images side-by-side ──────────────────────────────────────
        ? Row(children: [
            for (int i = 0; i < 2; i++) ...[
              if (i > 0) const SizedBox(width: 2),
              Expanded(child: GestureDetector(
                onTap: () => _openMultiImageViewer(urls, i),
                child: _gridThumb(urls[i], null, 130))),
            ],
          ])
        // ── 3 or 4+ images grid ────────────────────────────────────────
        : SizedBox(
            height: count == 3 ? 190 : 200,
            child: count == 3
              ? Row(children: [
                  // Left: big image
                  Expanded(flex: 2, child: GestureDetector(
                    onTap: () => _openMultiImageViewer(urls, 0),
                    child: _gridThumb(urls[0], null, double.infinity))),
                  const SizedBox(width: 2),
                  // Right: 2 stacked
                  Expanded(child: Column(children: [
                    Expanded(child: GestureDetector(
                      onTap: () => _openMultiImageViewer(urls, 1),
                      child: _gridThumb(urls[1], null, double.infinity))),
                    const SizedBox(height: 2),
                    Expanded(child: GestureDetector(
                      onTap: () => _openMultiImageViewer(urls, 2),
                      child: _gridThumb(urls[2], null, double.infinity))),
                  ])),
                ])
              // 4+ grid 2x2
              : GridView.count(
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  crossAxisCount: 2,
                  mainAxisSpacing: 2,
                  crossAxisSpacing: 2,
                  children: [
                    for (int i = 0; i < show; i++)
                      GestureDetector(
                        onTap: () => _openMultiImageViewer(urls, i),
                        child: _gridThumb(urls[i],
                          i == 3 && extra > 0 ? '+$extra' : null,
                          double.infinity)),
                  ],
                )),
    );
  }

  Widget _gridThumb(String url, String? overlay, double height) {
    return Stack(fit: StackFit.expand, children: [
      Image.network(url, fit: BoxFit.cover, height: height,
        loadingBuilder: (_, c, p) => p == null ? c
          : Container(color: Colors.grey[200], child: const Center(
              child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF0284C7)))),
        errorBuilder: (_, __, ___) => Container(color: Colors.grey[200],
          child: const Icon(Icons.broken_image_rounded, color: Colors.grey))),
      if (overlay != null)
        Container(
          color: Colors.black54,
          child: Center(child: Text(overlay,
            style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)))),
    ]);
  }

  void _openMultiImageViewer(List<String> urls, int startIndex) {
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => _MultiImageViewer(urls: urls, initialIndex: startIndex)));
  }

  void _showFullScreenAvatar(String url) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Center(child: InteractiveViewer(child: Image.network(url, fit: BoxFit.contain,
          errorBuilder: (_, __, ___) => const Icon(Icons.person, color: Colors.white, size: 80)))),
      ),
    )));
  }

  void _handleDoubleTap(Map<String, dynamic> msg, int index) {
    final newLiked = !(msg['isLiked'] ?? false);
    setState(() { _messages[index]['isLiked'] = newLiked; });
    HapticFeedback.mediumImpact();
    _toggleLikeFirestore(msg['firestoreId'] as String?, newLiked);
  }

  Widget _buildReactionBubble(Map<String, dynamic> msg) {
    final reactions = Map<String, String>.from(msg['reactions'] as Map? ?? {});
    // Merge legacy single reaction
    if (msg['reaction'] != null && reactions.isEmpty) {
      reactions['__legacy__'] = msg['reaction'] as String;
    }
    // Merge local like
    if ((msg['isLiked'] ?? false) && !reactions.containsKey(_fs.myUid)) {
      reactions[_fs.myUid] = '❤️';
    }
    if (reactions.isEmpty) return const SizedBox.shrink();

    // Count per emoji
    final counts = <String, int>{};
    for (final e in reactions.values) counts[e] = (counts[e] ?? 0) + 1;
    final sorted = counts.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final total = reactions.length;

    return GestureDetector(
      onTap: () => _showReactionDetails(reactions),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.12), blurRadius: 6, offset: const Offset(0, 2))],
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          ...sorted.take(3).map((e) => Text(e.key, style: const TextStyle(fontSize: 13))),
          if (total > 1) ...[
            const SizedBox(width: 3),
            Text('+$total', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: Colors.black54)),
          ],
        ]),
      ),
    );
  }

  void _showReactionDetails(Map<String, String> reactions) {
    final groups = <String, List<String>>{};
    reactions.forEach((uid, emoji) { groups.putIfAbsent(emoji, () => []).add(uid); });

    showModalBottomSheet(context: context, backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => FutureBuilder<Map<String, String>>(
        future: _fs.fetchUsernames(reactions.keys.toList()),
        builder: (ctx, snap) {
          final names = snap.data ?? {};
          return SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(margin: const EdgeInsets.only(top: 10, bottom: 12), width: 40, height: 4,
              decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Text('Reactions', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(color: _blue.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
                child: Text('${reactions.length}', style: const TextStyle(color: _blue, fontWeight: FontWeight.w700, fontSize: 13))),
            ]),
            const Divider(height: 20),
            ...groups.entries.map((g) {
              final peopleNames = g.value.map((uid) {
                if (uid == _fs.myUid) return 'You';
                return names[uid] ?? widget.targetName;
              }).toList();
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                child: Row(children: [
                  Text(g.key, style: const TextStyle(fontSize: 24)),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${g.value.length} ${g.value.length == 1 ? 'person' : 'people'} reacted ${g.key}',
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                    const SizedBox(height: 2),
                    Text(peopleNames.join(', '),
                      style: TextStyle(color: Colors.grey[600], fontSize: 12),
                      maxLines: 2, overflow: TextOverflow.ellipsis),
                  ])),
                ]),
              );
            }),
            const SizedBox(height: 16),
          ]));
        }
      ),
    );
  }

  Future<void> _doLockChat() async {
    final canBio = await ChatLockService.canUseBiometrics();
    if (!mounted) return;
    showModalBottomSheet(
      context: context, backgroundColor: Colors.transparent, isScrollControlled: true,
      builder: (_) => _ChatLockSetupSheet(
        chatId: widget.targetId, chatName: widget.targetName, canBio: canBio,
        onLocked: () {
          if (mounted) {
            setState(() => _isChatLocked = true);
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('🔒 Chat locked!'),
              backgroundColor: const Color(0xFF0284C7),
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
          }
        }));
  }

  Future<void> _doUnlockChat() async {
    final canBio = await ChatLockService.canUseBiometrics();
    final hasPin = await ChatLockService.getPin(widget.targetId) != null;
    if (!mounted) return;
    bool ok = false;
    if (canBio) ok = await ChatLockService.authenticateBiometric();
    if (!ok && hasPin && mounted) {
      final ctrl = TextEditingController();
      ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Row(children: [
          Icon(Icons.lock_rounded, color: Color(0xFF0284C7), size: 20),
          SizedBox(width: 8),
          Text('Enter PIN', style: TextStyle(fontWeight: FontWeight.w900))]),
        content: TextField(
          controller: ctrl, keyboardType: TextInputType.number,
          maxLength: 4, obscureText: true, textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: 8),
          decoration: InputDecoration(
            hintText: '••••', counterText: '',
            filled: true, fillColor: const Color(0xFFF1F5F9),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0284C7), foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () async {
              final saved = await ChatLockService.getPin(widget.targetId);
              Navigator.pop(context, ctrl.text == saved);
            },
            child: const Text('Unlock')),
        ],
      )) ?? false;
    }
    if (ok) {
      await ChatLockService.removeLock(widget.targetId);
      if (mounted) {
        setState(() => _isChatLocked = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: const Text('🔓 Chat unlocked'),
          backgroundColor: Colors.green,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
      }
    }
  }

  void _confirmClearChat() {
    showDialog(context: context, builder: (_) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: const Text('Clear Chat', style: TextStyle(fontWeight: FontWeight.bold)),
      content: Text('Delete all messages with ${widget.targetName}?'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        TextButton(
          onPressed: () async {
            Navigator.pop(context);
            await _fs.clearChat(widget.targetId);
            if (mounted) {
              setState(() => _messages.clear());
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: const Text('Chat cleared'),
                backgroundColor: Colors.orange,
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
            }
          },
          child: const Text('Clear', style: TextStyle(color: Colors.red, fontWeight: FontWeight.w700)),
        ),
      ],
    ));
  }

  void _showInfo() => Navigator.push(context, MaterialPageRoute(
    builder: (_) => ChatInfoScreen(targetName: widget.targetName, targetId: widget.targetId)));

  void _deleteSelected() {
    final toDelete = List<String>.from(_selectedIds);
    final firestoreIds = _selectedFirestoreIds.values.toList();
    _showDeleteConfirmDialog(toDelete, firestoreIds);
  }

  // ── Single message delete dialog ────────────────────────────────────────────
  void _showSingleDeleteDialog(Map<String, dynamic> msg) {
    final isMe = msg['isMe'] as bool? ?? false;
    final firestoreId = msg['firestoreId'] as String?;
    showModalBottomSheet(
      context: context,
      useRootNavigator: false,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 36, height: 4,
            decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
          const SizedBox(height: 16),
          const Text('Delete Message', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
          const SizedBox(height: 6),
          Text('Choose who to delete this message for',
            style: TextStyle(color: Colors.grey[500], fontSize: 13)),
          const SizedBox(height: 20),
          // Delete for Me
          _deleteOption(
            icon: Icons.person_outline_rounded,
            color: Colors.orange,
            title: 'Delete for Me',
            subtitle: 'Remove this message only from your view',
            onTap: () async {
              Navigator.of(ctx).pop(); // close only the bottom sheet
              if (mounted) setState(() => _messages.removeWhere((m) => m['id'] == msg['id']));
              try {
                if (firestoreId != null) await _fs.deleteMessage(widget.targetId, firestoreId);
              } catch (_) {}
              HapticFeedback.mediumImpact();
            },
          ),
          const SizedBox(height: 10),
          // Delete for Everyone (only if sender)
          _deleteOption(
            icon: Icons.people_outline_rounded,
            color: Colors.red,
            title: 'Delete for Everyone',
            subtitle: isMe
                ? 'Remove this message for all participants'
                : 'You can only delete your own messages for everyone',
            enabled: isMe,
            onTap: isMe ? () async {
              Navigator.of(ctx).pop(); // close only the bottom sheet
              if (mounted) setState(() => _messages.removeWhere((m) => m['id'] == msg['id']));
              try {
                if (firestoreId != null) await _fs.deleteMessageForEveryone(widget.targetId, firestoreId);
              } catch (_) {}
              HapticFeedback.mediumImpact();
            } : null,
          ),
          const SizedBox(height: 10),
          // Cancel
          GestureDetector(
            onTap: () => Navigator.pop(ctx),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(16)),
              child: const Center(
                child: Text('Cancel',
                  style: TextStyle(fontWeight: FontWeight.w600, color: Colors.black54, fontSize: 15))),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _deleteOption({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    bool enabled = true,
    VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: enabled ? onTap : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
        decoration: BoxDecoration(
          color: enabled ? color.withValues(alpha: 0.07) : Colors.grey[50],
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: enabled ? color.withValues(alpha: 0.25) : Colors.grey[200]!,
          ),
        ),
        child: Row(children: [
          Container(
            width: 40, height: 40,
            decoration: BoxDecoration(
              color: enabled ? color.withValues(alpha: 0.15) : Colors.grey[200],
              shape: BoxShape.circle),
            child: Icon(icon,
              color: enabled ? color : Colors.grey[400], size: 20)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: TextStyle(
              fontWeight: FontWeight.w700, fontSize: 14,
              color: enabled ? Colors.black87 : Colors.grey[400])),
            Text(subtitle, style: TextStyle(
              fontSize: 11, color: enabled ? Colors.black45 : Colors.grey[300])),
          ])),
          if (enabled)
            Icon(Icons.chevron_right_rounded, color: color.withValues(alpha: 0.5), size: 20),
        ]),
      ),
    );
  }

  // ── Multi-select delete dialog ────────────────────────────────────────────
  void _showDeleteConfirmDialog(List<String> localIds, List<String> firestoreIds) {
    // Check if ALL selected messages are mine
    final allMsgs = _messages.where((m) => localIds.contains(m['id'])).toList();
    final allMine = allMsgs.every((m) => m['isMe'] == true);
    final count = localIds.length;

    showModalBottomSheet(
      context: context,
      useRootNavigator: false,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 36, height: 4,
            decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
          const SizedBox(height: 16),
          Text('Delete $count Message${count > 1 ? 's' : ''}',
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
          const SizedBox(height: 6),
          Text('Choose who to delete ${count > 1 ? 'these messages' : 'this message'} for',
            style: TextStyle(color: Colors.grey[500], fontSize: 13)),
          const SizedBox(height: 20),
          // Delete for Me
          _deleteOption(
            icon: Icons.person_outline_rounded,
            color: Colors.orange,
            title: 'Delete for Me',
            subtitle: 'Remove from your view only',
            onTap: () async {
              Navigator.pop(ctx);
              setState(() {
                _messages.removeWhere((m) => localIds.contains(m['id']));
                _selectedIds.clear();
                _selectedFirestoreIds.clear();
                _isSelectMode = false;
              });
              HapticFeedback.mediumImpact();
              if (firestoreIds.isNotEmpty) {
                await _fs.deleteSelectedMessages(widget.targetId, firestoreIds);
              }
            },
          ),
          const SizedBox(height: 10),
          // Delete for Everyone
          _deleteOption(
            icon: Icons.people_outline_rounded,
            color: Colors.red,
            title: 'Delete for Everyone',
            subtitle: allMine
                ? 'Remove for all participants'
                : 'Some selected messages are not yours',
            enabled: allMine,
            onTap: allMine ? () async {
              Navigator.pop(ctx);
              setState(() {
                _messages.removeWhere((m) => localIds.contains(m['id']));
                _selectedIds.clear();
                _selectedFirestoreIds.clear();
                _isSelectMode = false;
              });
              HapticFeedback.mediumImpact();
              if (firestoreIds.isNotEmpty) {
                await _fs.deleteSelectedMessagesForEveryone(widget.targetId, firestoreIds);
              }
            } : null,
          ),
          const SizedBox(height: 10),
          GestureDetector(
            onTap: () => Navigator.pop(ctx),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(16)),
              child: const Center(
                child: Text('Cancel',
                  style: TextStyle(fontWeight: FontWeight.w600, color: Colors.black54, fontSize: 15))),
            ),
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final authService = Provider.of<AuthService>(context, listen: false);
    final targetAvatar = authService.getDicebearUrl(widget.targetName, 'boy');
    return Scaffold(
      backgroundColor: kBgPage,
      extendBodyBehindAppBar: true,
      resizeToAvoidBottomInset: false,
      appBar: _isSearching ? _buildSearchAppBar() : _buildNormalAppBar(targetAvatar),
      body: ZyloChatBackground(child: Stack(children: [
        Column(children: [
          // Top spacer for translucent appbar
          SizedBox(height: MediaQuery.of(context).padding.top + kToolbarHeight),
        // Block banner
        if (_iBlockedThem) Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
          color: Colors.red.shade50,
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.block, color: Colors.red, size: 14),
            const SizedBox(width: 6),
            Text('You blocked ${widget.targetName}. Unblock to chat.',
              style: const TextStyle(fontSize: 12, color: Colors.red, fontWeight: FontWeight.w600)),
          ])),
        if (_theyBlockedMe && !_iBlockedThem) Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
          color: Colors.grey.shade100,
          child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.info_outline, color: Colors.grey, size: 14),
            SizedBox(width: 6),
            Text('You can\'t send messages to this user.',
              style: TextStyle(fontSize: 12, color: Colors.grey, fontWeight: FontWeight.w600)),
          ])),
        if (_isUploading) Container(
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: const Color(0xFF0284C7).withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFF0284C7).withValues(alpha: 0.2)),
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(children: [
              const SizedBox(width: 14, height: 14,
                child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF0284C7))),
              const SizedBox(width: 10),
              const Expanded(
                child: Text('Uploading file...', style: TextStyle(
                  fontSize: 12, color: Color(0xFF0284C7), fontWeight: FontWeight.w700))),
              const Icon(Icons.cloud_upload_rounded, size: 16, color: Color(0xFF0284C7)),
            ]),
            const SizedBox(height: 6),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                backgroundColor: const Color(0xFF0284C7).withValues(alpha: 0.15),
                color: const Color(0xFF0284C7),
                minHeight: 3,
              ),
            ),
          ])),
        if (_isSelectMode) Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8), color: Colors.white,
          child: Row(children: [
            Text('${_selectedIds.length} selected', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
            const Spacer(),
            TextButton.icon(
              onPressed: _selectedIds.isEmpty ? null : _deleteSelected,
              icon: const Icon(Icons.delete_outline, color: Colors.red, size: 20),
              label: const Text('Delete', style: TextStyle(color: Colors.red, fontWeight: FontWeight.w700))),
            TextButton(
              onPressed: () => setState(() { _isSelectMode = false; _selectedIds.clear(); _selectedFirestoreIds.clear(); }),
              child: Text('Cancel', style: TextStyle(color: Colors.grey[600]))),
          ])),
        if (_showPinnedPanel) _buildPinnedPanel(),
        Expanded(child: StreamBuilder(
          stream: _fs.getMessages(widget.targetId),
          builder: (context, snap) {
            if (snap.connectionState == ConnectionState.waiting && !snap.hasData) {
              // SQLite-first: instant load from local DB (WhatsApp style)
              if (_sqliteMessages.isNotEmpty) {
                final myUid2 = Provider.of<AuthService>(context, listen: false).user?.uid ?? '';
                return Stack(children: [
                  _buildSqliteMessageList(_sqliteMessages, myUid2),
                  const Positioned(
                    top: 8, right: 16,
                    child: SizedBox(width: 14, height: 14,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF0284C7))),
                  ),
                ]);
              }
              // Hive fallback if SQLite empty
              final myUid2 = Provider.of<AuthService>(context, listen: false).user?.uid ?? '';
              final cached = CacheService.getStaleCachedMessages(myUid2, widget.targetId);
              if (cached != null && cached.isNotEmpty) {
                return Stack(children: [
                  _buildCachedMessageList(cached, myUid2),
                  const Positioned(
                    top: 8, right: 16,
                    child: SizedBox(width: 14, height: 14,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF0284C7))),
                  ),
                ]);
              }
              return const Center(child: ZyloLoader());
            }
            final myUid = Provider.of<AuthService>(context, listen: false).user?.uid ?? '';
            final docs = snap.data?.docs ?? [];
            final firestoreIds = docs.map((d) => d.id).toSet();
            final optimistic = _messages.where((m) => !firestoreIds.contains(m['id'])).toList();
            if (docs.isEmpty && optimistic.isEmpty)
              return _EmptyChatState(onSayHello: () => _sendMessage(text: 'Hello! 👋'));
            List<Map<String, dynamic>> allMsgs = [
              ...optimistic.asMap().entries.map((e) => {...e.value, '_idx': e.key}),
            ];
            for (int i = 0; i < docs.length; i++) {
              final doc = docs[i]; final data = doc.data() as Map<String, dynamic>;
              final deletedFor = (data['deletedFor'] as List?)?.cast<String>() ?? [];
              if (deletedFor.contains(myUid)) continue;
              final isMe = data['senderId'] == myUid;
              allMsgs.add({
                'id': doc.id, 'firestoreId': doc.id,
                'text': data['text']?.isNotEmpty == true ? data['text'] : null,
                'imageUrl': data['imageUrl'], 'videoUrl': data['videoUrl'], 'audioPath': data['audioUrl'],
                'docPath': data['docUrl'], 'docName': data['docName'], 'mediaType': data['mediaType'],
                'isMe': isMe, 'isLiked': false, 'isPinned': data['isPinned'] ?? false,
                'reaction': data['reaction'], 'reactions': data['reactions'] as Map<String, dynamic>? ?? {}, 'isRead': data['isRead'] ?? false,
                'timestamp': (data['timestamp'] as dynamic)?.toDate() ?? DateTime.now(),
                'replyTo': data['replyTo'],
                'storyReply': data['storyReply'],
                'contactUid': data['contactUid'],
                'contactName': data['contactName'],
                'contactPhoto': data['contactPhoto'],
                'contactUsername': data['contactUsername'],
                'lat': data['lat'],
                'lng': data['lng'],
                // Poll fields
                'pollOptions': data['pollOptions'],
                'pollVotes': data['pollVotes'],
                // Game fields
                'gameType': data['gameType'],
                'gameId': data['gameId'],
                'senderName': data['senderName'],
                'sharedPost': data['sharedPost'],
                'sharedPostId': data['sharedPostId'],
                '_idx': optimistic.length + i,
              });
            }
            // Cache write-through: persist to Hive + SQLite
            if (docs.isNotEmpty) {
              final toCache = docs.map((d) {
                final data = d.data() as Map<String, dynamic>;
                final m = Map<String, dynamic>.from(data);
                m['_docId'] = d.id;
                m['firestoreId'] = d.id;
                m.forEach((k, v) { if (v is Timestamp) m[k] = v.millisecondsSinceEpoch; });
                return m;
              }).toList();
              // Hive (existing fast cache)
              CacheService.cacheMessages(myUid, widget.targetId, toCache);
              // SQLite (persistent, paginated local store)
              LocalDbService.instance.upsertFirestoreMessages(
                myUid: myUid,
                otherUid: widget.targetId,
                fsMessages: toCache,
              ).catchError((_) {});
            }

            // ── Pagination: set cursor to oldest live doc ─────────────────
            if (docs.isNotEmpty) {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (mounted && _lastDoc == null) {
                  setState(() => _lastDoc = docs.last);
                }
              });
            }

            // ── Merge live messages + older loaded pages ───────────────────
            // Remove duplicates: older msgs already in live stream
            final liveIds = docs.map((d) => d.id).toSet();
            final deduped = _olderMessages.where((m) => !liveIds.contains(m['id'])).toList();
            allMsgs = [...allMsgs, ...deduped];

            if (_searchQuery.isNotEmpty)
              allMsgs = allMsgs.where((m) => (m['text'] ?? '').toString().toLowerCase().contains(_searchQuery)).toList();
            // Update match count (post-frame to avoid setState during build)
            final newCount = _searchQuery.isNotEmpty ? allMsgs.length : 0;
            if (newCount != _searchMatchCount) {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (mounted) setState(() { _searchMatchCount = newCount; if (_searchMatchIndex >= newCount) _searchMatchIndex = 0; });
              });
            }

            // Total items = messages + optional loader at end (top of screen)
            final totalItems = allMsgs.length + (_hasMoreMessages ? 1 : 0);

            return ListView.builder(
              controller: _scrollController, reverse: true,
              padding: const EdgeInsets.only(top: 4, bottom: 4, left: 6, right: 6),
              itemCount: totalItems,
              addAutomaticKeepAlives: false,
              addRepaintBoundaries: true,
              cacheExtent: 500,
              itemBuilder: (context, index) {
                // Last item (visually top) = loading indicator
                if (index == allMsgs.length) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    child: Center(
                      child: _isLoadingMore
                          ? const SizedBox(
                              width: 20, height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF0284C7)))
                          : const SizedBox.shrink(),
                    ),
                  );
                }
                return RepaintBoundary(
                  child: _buildBubble(allMsgs[index], allMsgs[index]['isMe'] as bool, index, targetAvatar,
                    isSearchActive: _searchQuery.isNotEmpty && index == _searchMatchIndex),
                );
              },
            );
          },
        )),
        if (_showMentions && _mentionSuggestions.isNotEmpty) _buildMentionSuggestions(),
        // @zylo chip suggestion
        if (_showZyloSuggest)
          GestureDetector(
            onTap: () {
              final cur = _msgController.text;
              final atIdx = cur.lastIndexOf('@');
              if (atIdx >= 0) {
                _msgController.text = '${cur.substring(0, atIdx)}@zylo ';
                _msgController.selection = TextSelection.collapsed(offset: _msgController.text.length);
              }
              setState(() => _showZyloSuggest = false);
            },
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.08), blurRadius: 8)]),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Container(width: 24, height: 24,
                  decoration: const BoxDecoration(color: Color(0xFF0284C7), shape: BoxShape.circle),
                  child: const Icon(Icons.auto_awesome, color: Colors.white, size: 13)),
                const SizedBox(width: 8),
                const Text('@zylo', style: TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF0284C7))),
                const SizedBox(width: 6),
                const Text('Ask Zylo AI', style: TextStyle(color: Colors.grey, fontSize: 12)),
              ]),
            ),
          ),
        // Other user typing indicator
        if (_isOtherTyping)
          Container(
            margin: const EdgeInsets.only(left: 16, bottom: 4),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              const SizedBox(width: 2),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: const Color(0xFFE8EEF4), width: 0.8),
                  boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 6, offset: const Offset(0,2))]),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Text('${widget.targetName} ', style: const TextStyle(color: Color(0xFF475569), fontSize: 12, fontWeight: FontWeight.w600)),
                  const Text('is typing', style: TextStyle(color: Color(0xFF94A3B8), fontSize: 12, fontStyle: FontStyle.italic)),
                  const SizedBox(width: 6),
                  _TypingDotsWidget(),
                ]),
              ),
            ]),
          ),
        // Zylo AI typing indicator
        if (_zyloAiTyping)
          Container(
            margin: const EdgeInsets.only(left: 16, bottom: 4),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Container(width: 22, height: 22,
                decoration: const BoxDecoration(color: Color(0xFF0284C7), shape: BoxShape.circle),
                child: const Icon(Icons.auto_awesome, color: Colors.white, size: 12)),
              const SizedBox(width: 8),
              const Text('Zylo AI is thinking...', style: TextStyle(color: Colors.grey, fontSize: 12, fontStyle: FontStyle.italic)),
            ]),
          ),
        _buildReplyBar(),
        _buildInputBar(),
      ]),
      // ── Snapchat-style Screenshot Preview Overlay ──────────────────────
      if (_showScreenshotPreview)
        Positioned.fill(child: _buildScreenshotPreviewOverlay()),
      ])),
    );
  }

  Widget _buildPinnedPanel() {
    final pinned = _messages.where((m) => m['isPinned'] == true).toList();
    if (pinned.isEmpty) {
      return Container(
        color: Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(children: [
          const Icon(Icons.push_pin, color: Colors.orange, size: 16),
          const SizedBox(width: 8),
          const Expanded(child: Text('No pinned messages', style: TextStyle(color: Colors.grey, fontSize: 13))),
          GestureDetector(onTap: () => setState(() => _showPinnedPanel = false),
            child: const Icon(Icons.close, size: 18, color: Colors.grey)),
        ]),
      );
    }
    return Container(
      color: Colors.white,
      constraints: const BoxConstraints(maxHeight: 200),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
          child: Row(children: [
            const Icon(Icons.push_pin, color: Colors.orange, size: 16),
            const SizedBox(width: 8),
            Text('${pinned.length} Pinned Message${pinned.length > 1 ? 's' : ''}',
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: Colors.orange)),
            const Spacer(),
            GestureDetector(onTap: () => setState(() => _showPinnedPanel = false),
              child: const Icon(Icons.close, size: 18, color: Colors.grey)),
          ]),
        ),
        const Divider(height: 1),
        Flexible(child: ListView.builder(
          shrinkWrap: true, itemCount: pinned.length,
          itemBuilder: (_, i) {
            final m = pinned[i];
            final pinnedBy = m['pinnedBy'] as String?;
            final isPinnedByMe = pinnedBy == _fs.myUid;
            return ListTile(
              dense: true,
              leading: const Icon(Icons.push_pin, color: Colors.orange, size: 16),
              title: Text(m['text'] ?? _mediaLabel(m['mediaType']),
                maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
              subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(
                  (m['isMe'] == true ? 'You' : widget.targetName) + ' • ' + _formatTime(m['timestamp'] as DateTime),
                  style: const TextStyle(fontSize: 11)),
                if (pinnedBy != null) Text(
                  'Pinned by ${isPinnedByMe ? 'you' : widget.targetName}',
                  style: TextStyle(fontSize: 10, color: Colors.grey[500], fontStyle: FontStyle.italic)),
              ]),
              trailing: PopupMenuButton(
                itemBuilder: (ctx) => [
                  PopupMenuItem(
                    child: const Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.close, size: 16, color: Colors.grey), SizedBox(width: 8), Text('Unpin', style: TextStyle(fontSize: 12))]),
                    onTap: () {
                      final idx = _messages.indexWhere((x) => x['id'] == m['id']);
                      if (idx >= 0) {
                        setState(() => _messages[idx]['isPinned'] = false);
                        final firestoreId = m['firestoreId'] as String?;
                        if (firestoreId != null) {
                          _fs.togglePinMessage(widget.targetId, firestoreId, false).catchError((_) {});
                        }
                      }
                    },
                  ),
                ],
                child: const Icon(Icons.more_vert, size: 16, color: Colors.grey),
              ),
            );
          },
        )),
      ]),
    );
  }

  PreferredSizeWidget _buildNormalAppBar(String targetAvatar) {
    final pinnedCount = _messages.where((m) => m['isPinned'] == true).length;
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0, titleSpacing: 0,
      flexibleSpace: ClipRect(
        child: BackdropFilter(
          filter: ui.ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            decoration: const BoxDecoration(
              color: Color(0xD0FFFFFF),
              border: Border(bottom: BorderSide(color: Color(0x18000000), width: 0.5))),
          ),
        ),
      ),
      title: StreamBuilder<DocumentSnapshot>(
        stream: _targetUserStream,
        builder: (context, userSnap) {
          final ud = userSnap.data?.data() as Map<String, dynamic>? ?? {};
          final isOnline = ud['isOnline'] == true;
          final lastSeen = ud['lastSeen'] as Timestamp?;
          final realPhoto = ud['photoURL'] as String? ?? '';
          String statusText = 'Offline';
          if (isOnline) statusText = 'Active now';
          else if (lastSeen != null) {
            final diff = DateTime.now().difference(lastSeen.toDate());
            if (diff.inMinutes < 1) statusText = 'Just now';
            else if (diff.inMinutes < 60) statusText = '${diff.inMinutes}m ago';
            else if (diff.inHours < 24) statusText = '${diff.inHours}h ago';
            else statusText = '${diff.inDays}d ago';
          }
          return GestureDetector(onTap: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => ChatInfoScreen(targetName: widget.targetName, targetId: widget.targetId, targetPhoto: realPhoto.isNotEmpty ? realPhoto : null))),
            child: Row(children: [
              Stack(children: [
                CircleAvatar(radius: 18,
                  backgroundColor: kBrand.withValues(alpha: 0.12),
                  backgroundImage: realPhoto.isNotEmpty ? _safeNetworkImage(realPhoto) ?? _safeNetworkImage(targetAvatar) : _safeNetworkImage(targetAvatar)),
                // Online dot removed — status shown in subtitle text only
              ]),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(widget.targetName, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: Color(0xFF0F172A), letterSpacing: -0.3)),
                _isOtherTyping
                  ? Row(mainAxisSize: MainAxisSize.min, children: [
                      const _TypingDots(),
                      const SizedBox(width: 5),
                      const Text('typing...', style: TextStyle(fontSize: 10.5, color: kBrand, fontWeight: FontWeight.w600, fontStyle: FontStyle.italic)),
                    ])
                  : Text(statusText, style: TextStyle(
                        fontSize: 10.5,
                        color: isOnline ? kOnlineDot : const Color(0xFF94A3B8),
                        fontWeight: FontWeight.w500)),
              ])),
            ]));
        }),
      actions: [
        // Translate button — shows IN/OUT badges when active
        Consumer<TranslationService>(builder: (ctx, svc, _) {
          final anyActive = svc.inEnabled || svc.outEnabled;
          return GestureDetector(
            onTap: () => LanguagePickerSheet.show(context),
            onLongPress: () => LanguagePickerSheet.show(context, initialTab: 1),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: EdgeInsets.symmetric(horizontal: anyActive ? 7 : 4, vertical: 4),
                decoration: BoxDecoration(
                  color: anyActive ? const Color(0xFF0284C7) : Colors.transparent,
                  borderRadius: BorderRadius.circular(8)),
                child: anyActive
                    ? Row(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.translate_rounded, color: Colors.white, size: 14),
                        const SizedBox(width: 3),
                        Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                          if (svc.inEnabled) Row(mainAxisSize: MainAxisSize.min, children: [
                            const Icon(Icons.download_rounded, color: Colors.white70, size: 9),
                            const SizedBox(width: 1),
                            Text(svc.inLang.toUpperCase(),
                              style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w800)),
                          ]),
                          if (svc.outEnabled) Row(mainAxisSize: MainAxisSize.min, children: [
                            const Icon(Icons.upload_rounded, color: Colors.orangeAccent, size: 9),
                            const SizedBox(width: 1),
                            Text(svc.outLang.toUpperCase(),
                              style: const TextStyle(color: Colors.orangeAccent, fontSize: 8, fontWeight: FontWeight.w800)),
                          ]),
                        ]),
                      ])
                    : const Icon(Icons.translate_rounded, color: Colors.grey, size: 22),
              ),
            ),
          );
        }),
        IconButton(icon: const Icon(Icons.search, color: Colors.grey), onPressed: () => setState(() => _isSearching = true)),
        if (pinnedCount > 0)
          Stack(alignment: Alignment.topRight, children: [
            IconButton(icon: const Icon(Icons.push_pin_outlined, color: Colors.orange),
              onPressed: () => setState(() => _showPinnedPanel = !_showPinnedPanel)),
            Positioned(top: 6, right: 6,
              child: Container(width: 16, height: 16,
                decoration: const BoxDecoration(color: Colors.orange, shape: BoxShape.circle),
                child: Center(child: Text('$pinnedCount',
                    style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w800))))),
          ]),
        PopupMenuButton<String>(
          icon: const Icon(Icons.more_vert, color: Colors.grey),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          onSelected: (v) async {
            if (v == 'info') _showInfo();
            if (v == 'report') _showReportUserSheet();
            if (v == 'pinned') setState(() => _showPinnedPanel = !_showPinnedPanel);
            if (v == 'clear') _confirmClearChat();
            if (v == 'lock') {
              if (_isChatLocked) {
                await _doUnlockChat();
              } else {
                await _doLockChat();
              }
            }
            if (v == 'mute') {
              final myUid = Provider.of<AuthService>(context, listen: false).user?.uid ?? '';
              if (_isChatMuted) {
                await _ns.unmuteChat(widget.targetId);
                if (mounted) {
                  setState(() => _isChatMuted = false);
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text('🔔 ${widget.targetName} unmuted'),
                    backgroundColor: Colors.green,
                    behavior: SnackBarBehavior.floating,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
                }
              } else {
                await _ns.muteChat(widget.targetId);
                if (mounted) {
                  setState(() => _isChatMuted = true);
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text('🔕 ${widget.targetName} muted'),
                    backgroundColor: Colors.orange[700],
                    behavior: SnackBarBehavior.floating,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
                }
              }
            }
          },
          itemBuilder: (_) => [
            PopupMenuItem(value: 'lock', child: Row(children: [
              Icon(_isChatLocked ? Icons.lock_open_rounded : Icons.lock_rounded,
                size: 18, color: _isChatLocked ? Colors.green[600] : const Color(0xFF0284C7)),
              const SizedBox(width: 10),
              Text(_isChatLocked ? 'Unlock Chat' : 'Lock Chat',
                style: TextStyle(color: _isChatLocked ? Colors.green[600] : const Color(0xFF0284C7)))])),
            PopupMenuItem(value: 'mute', child: Row(children: [
              Icon(_isChatMuted ? Icons.notifications_active_outlined : Icons.notifications_off_outlined,
                size: 18, color: _isChatMuted ? Colors.green[600] : Colors.orange[700]),
              const SizedBox(width: 10),
              Text(_isChatMuted ? 'Unmute Notifications' : 'Mute Notifications',
                style: TextStyle(color: _isChatMuted ? Colors.green[600] : Colors.orange[700]))])),
            const PopupMenuItem(value: 'info', child: Row(children: [
              Icon(Icons.info_outline, size: 18, color: Colors.grey), SizedBox(width: 10), Text('Chat Info')])),
            const PopupMenuItem(value: 'pinned', child: Row(children: [
              Icon(Icons.push_pin_outlined, size: 18, color: Colors.orange), SizedBox(width: 10),
              Text('Pinned Messages', style: TextStyle(color: Colors.orange))])),
            const PopupMenuItem(value: 'clear', child: Row(children: [
              Icon(Icons.cleaning_services_outlined, size: 18, color: Color(0xFFD97706)), SizedBox(width: 10),
              Text('Clear Chat', style: TextStyle(color: Color(0xFFD97706)))])),
            const PopupMenuItem(value: 'report', child: Row(children: [
              Icon(Icons.flag_outlined, size: 18, color: Colors.red), SizedBox(width: 10),
              Text('Report User', style: TextStyle(color: Colors.red))])),
          ]),
      ]);
  }

  PreferredSizeWidget _buildSearchAppBar() {
    final hasResults = _searchQuery.isNotEmpty && _searchMatchCount > 0;
    return AppBar(
      backgroundColor: Colors.white, elevation: 0,
      leading: IconButton(icon: const Icon(Icons.arrow_back, color: Colors.black87),
        onPressed: () => setState(() { _isSearching = false; _searchQuery = ''; _searchController.clear(); _searchMatchIndex = 0; _searchMatchCount = 0; })),
      title: TextField(controller: _searchController, autofocus: true,
        decoration: const InputDecoration(hintText: 'Search messages...', border: InputBorder.none,
          hintStyle: TextStyle(color: Colors.grey)),
        style: const TextStyle(fontSize: 16, color: Colors.black87)),
      actions: [
        if (_searchQuery.isNotEmpty && _searchMatchCount > 0)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 12),
            child: Text('${_searchMatchIndex + 1}/$_searchMatchCount',
              style: const TextStyle(color: Colors.grey, fontSize: 13, fontWeight: FontWeight.w600)),
          ),
        if (hasResults) IconButton(
          icon: const Icon(Icons.keyboard_arrow_up, color: Colors.black87),
          tooltip: 'Previous',
          onPressed: () => setState(() {
            _searchMatchIndex = (_searchMatchIndex + 1) % _searchMatchCount;
          })),
        if (hasResults) IconButton(
          icon: const Icon(Icons.keyboard_arrow_down, color: Colors.black87),
          tooltip: 'Next',
          onPressed: () => setState(() {
            _searchMatchIndex = (_searchMatchIndex - 1 + _searchMatchCount) % _searchMatchCount;
          })),
        if (_searchQuery.isNotEmpty) IconButton(
          icon: const Icon(Icons.close, color: Colors.grey),
          onPressed: () => setState(() { _searchQuery = ''; _searchController.clear(); _searchMatchIndex = 0; _searchMatchCount = 0; })),
      ],
    );
  }

  Widget _buildReplyBar() {
    if (_replyTo == null) return const SizedBox.shrink();
    final isMe = _replyTo!['isMe'] as bool? ?? false;
    final text = _replyTo!['text'] as String?;
    final mediaType = _replyTo!['mediaType'] as String? ?? 'text';
    final preview = text?.isNotEmpty == true ? text! : _mediaLabel(mediaType);
    return ZyloGlassReplyBar(
      senderLabel: isMe ? 'You' : widget.targetName,
      preview: preview,
      onDismiss: () => setState(() => _replyTo = null),
    );
  }

  Widget _buildBubble(Map<String, dynamic> msg, bool isMe, int index, String targetAvatar, {bool isSearchActive = false}) {
    if (msg['mediaType'] == 'screenshot_alert') {
      final alertText = msg['text'] as String? ?? 'Screenshot taken 📸';
      return Center(
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 9),
          decoration: BoxDecoration(
            color: Colors.deepPurple.withValues(alpha: 0.10),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.deepPurple.withValues(alpha: 0.18), width: 1),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 26, height: 26,
                decoration: BoxDecoration(
                  color: Colors.deepPurple.withValues(alpha: 0.13),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.screenshot_monitor_rounded,
                    color: Colors.deepPurple, size: 15),
              ),
              const SizedBox(width: 8),
              Flexible(
                child: Text(
                  alertText,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: Colors.deepPurple,
                    letterSpacing: 0.1,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
      );
    }
    // Zylo AI bubble — full width, no standard bubble wrapper
    if (msg['mediaType'] == 'zylo_ai') {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        child: _ZyloAiBubble(text: msg['text'] as String? ?? ''),
      );
    }
    final timerEnds = msg['timerEnds'] as DateTime?;
    final timerExpired = timerEnds != null && DateTime.now().isAfter(timerEnds);
    final hasTimer = timerEnds != null;
    final isSelected = _selectedIds.contains(msg['id']);
    final replyTo = msg['replyTo'] as Map<String, dynamic>?;
    final storyReply = msg['storyReply'] as Map<String, dynamic>?;
    final isHighlighted = _searchQuery.isNotEmpty && (msg['text'] ?? '').toString().toLowerCase().contains(_searchQuery);
    final rawIdx = msg['_idx'] as int? ?? index;
    final isPinned = msg['isPinned'] ?? false;
    final caption = msg['text'] as String?;
    final hasImage = msg['imageUrl'] != null || msg['localPath'] != null;
    final localPath = msg['localPath'] as String?;
    final isUploadingBubble = msg['isUploading'] == true;
    final imageUrls = (msg['imageUrls'] as List?)?.cast<String>() ?? (msg['imageUrl'] != null ? [msg['imageUrl'] as String] : <String>[]);
    final isMultiImage = imageUrls.length > 1;
    final msgText = msg['text'] as String? ?? '';
    final firstUrl = msg['mediaType'] == 'text' ? extractFirstUrl(msgText) : null;

    final shouldPop = isMe && msg['id'] == _lastSentId;
    return _BubblePopWrapper(
      animate: shouldPop,
      child: _SwipeToReply(
      isMe: isMe,
      onReply: () { HapticFeedback.mediumImpact(); setState(() => _replyTo = msg); },
      child: GestureDetector(
      onLongPressStart: (details) => _handleLongPressWithPosition(msg, rawIdx, details.globalPosition),
      onDoubleTap: () => _handleDoubleTap(msg, rawIdx),
      onTap: _isSelectMode ? () => setState(() {
        if (isSelected) {
          _selectedIds.remove(msg['id']);
          _selectedFirestoreIds.remove(msg['id']);
        } else {
          _selectedIds.add(msg['id']);
          final fid = msg['firestoreId'] as String?;
          if (fid != null) _selectedFirestoreIds[msg['id']] = fid;
        }
      }) : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        color: isSelected ? _blue.withValues(alpha: 0.08) : isSearchActive ? Colors.orange.withValues(alpha: 0.25) : isHighlighted ? Colors.yellow.withValues(alpha: 0.25) : Colors.transparent,
        child: Padding(
          // Both sides: left-aligned. isMe gets slight right margin, no left push
          padding: EdgeInsets.only(top: 0, bottom: 2, left: isMe ? 56 : 6, right: isMe ? 6 : 56),
          child: Align(
            alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                // Select mode checkbox for received
                if (_isSelectMode && !isMe) Padding(
                  padding: const EdgeInsets.only(right: 6, bottom: 8),
                  child: Icon(isSelected ? Icons.check_circle : Icons.circle_outlined,
                    color: isSelected ? _blue : Colors.grey[400], size: 22)),
                // Received: circular avatar BEFORE the bubble
                if (!isMe) Padding(
                  padding: const EdgeInsets.only(right: 6, bottom: 2),
                  child: CircleAvatar(
                    radius: 16,
                    backgroundColor: const Color(0xFFE0F0FF),
                    backgroundImage: _targetRealPhoto.isNotEmpty
                      ? _safeNetworkImage(_targetRealPhoto) as ImageProvider?
                      : targetAvatar.isNotEmpty
                        ? NetworkImage(targetAvatar) as ImageProvider?
                        : null,
                    child: (_targetRealPhoto.isEmpty && targetAvatar.isEmpty)
                      ? Text(widget.targetName.isNotEmpty ? widget.targetName[0].toUpperCase() : '?',
                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Color(0xFF0284C7)))
                      : null,
                  ),
                ),
                Flexible(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                  Stack(clipBehavior: Clip.none, children: [
                  IntrinsicWidth(
                    child: Container(
                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.72),
                    decoration: isMe
                      ? sentBubbleDecoration(isPinned: isPinned)
                      : recvBubbleDecoration(isPinned: isPinned),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      // Reply preview
                      if (replyTo != null) GestureDetector(
                        onTap: () => HapticFeedback.selectionClick(),
                        child: Container(
                          margin: const EdgeInsets.fromLTRB(8, 8, 8, 0),
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF0F8FF),
                            borderRadius: BorderRadius.circular(10),
                            border: Border(left: BorderSide(color: _blue, width: 3))),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(replyTo['isMe'] == true ? 'You' : widget.targetName,
                              style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
                                color: Color(0xFF0284C7))),
                            const SizedBox(height: 2),
                            Text(
                              replyTo['text'] != null && (replyTo['text'] as String).isNotEmpty
                                  ? replyTo['text']
                                  : _mediaLabel(replyTo['mediaType']),
                              maxLines: 1, overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 12, color: Colors.black54)),
                          ]),
                        )),
                      // Story reply preview
                      if (storyReply != null) Container(
                        margin: const EdgeInsets.fromLTRB(8, 8, 8, 0),
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF5F0FF),
                          borderRadius: BorderRadius.circular(10),
                          border: const Border(left: BorderSide(color: Colors.purple, width: 3))),
                        child: Row(children: [
                          if (storyReply['storyType'] == 'image' && (storyReply['storyMediaUrl'] as String? ?? '').isNotEmpty)
                            ClipRRect(
                              borderRadius: BorderRadius.circular(6),
                              child: Image.network(storyReply['storyMediaUrl'], width: 40, height: 40, fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => const SizedBox.shrink())),
                          const SizedBox(width: 6),
                          Flexible(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Row(children: [
                              Icon(Icons.auto_stories, size: 11, color: Colors.purple),
                              const SizedBox(width: 3),
                              Text('Replied to story', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: Colors.purple)),
                            ]),
                            const SizedBox(height: 2),
                            Text(storyReply['storyType'] == 'text' ? '📝 Text story' : '📸 Photo story',
                              style: const TextStyle(fontSize: 11, color: Colors.black45)),
                          ])),
                        ]),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(10, 6, 10, 4),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          if (timerExpired) ...[
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                              decoration: BoxDecoration(color: Colors.grey[100], borderRadius: BorderRadius.circular(10)),
                              child: const Row(mainAxisSize: MainAxisSize.min, children: [
                                Icon(Icons.timer_off_rounded, size: 14, color: Colors.grey),
                                SizedBox(width: 4),
                                Text('Time ended', style: TextStyle(fontSize: 11, color: Colors.grey, fontStyle: FontStyle.italic)),
                              ])),
                          ] else ...[
                            if (hasImage) ...[
                              if (isMultiImage)
                                _buildMultiImageGrid(imageUrls, msg, isMe)
                              else
                              GestureDetector(
                                onTap: isUploadingBubble ? null : () {
                                  if (msg['imageUrl'] != null) {
                                    _openFullScreenImage(msg['imageUrl'],
                                      onSave: () => _saveImageToZylo(msg['imageUrl']),
                                      onForward: () => _showForwardSheet(msg));
                                  }
                                },
                                child: Stack(children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: isUploadingBubble && localPath != null
                                      ? Stack(alignment: Alignment.center, children: [
                                          Image.file(
                                            File(localPath),
                                            fit: BoxFit.cover, width: double.infinity, height: 180),
                                          Container(
                                            width: double.infinity, height: 180,
                                            color: Colors.black38,
                                            child: const Center(
                                              child: Column(mainAxisSize: MainAxisSize.min, children: [
                                                CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                                                SizedBox(height: 8),
                                                Text('Uploading...', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600)),
                                              ]),
                                            )),
                                        ])
                                      : hasTimer && !timerExpired
                                      ? ImageFiltered(
                                          imageFilter: ui.ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                                          child: Image.network(msg['imageUrl'],
                                            fit: BoxFit.cover, width: double.infinity, height: 180,
                                            errorBuilder: (_, __, ___) => Container(height: 180,
                                              color: Colors.grey[300])))
                                      : Image.network(msg['imageUrl'],
                                          fit: BoxFit.cover, width: double.infinity,
                                          loadingBuilder: (_, c, p) => p == null ? c : Container(
                                            width: double.infinity, height: 180,
                                            color: Colors.grey[200],
                                            child: const Center(child: CircularProgressIndicator(strokeWidth: 2))),
                                          errorBuilder: (_, __, ___) => Container(
                                            width: double.infinity, height: 100,
                                            color: Colors.grey[100],
                                            child: const Icon(Icons.broken_image_rounded, size: 32, color: Colors.grey))),
                                  ),
                                  if (hasTimer && !timerExpired)
                                    Positioned.fill(child: Container(
                                      decoration: BoxDecoration(
                                        color: Colors.black26,
                                        borderRadius: BorderRadius.circular(10)),
                                      child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                                        Icon(Icons.touch_app_rounded, color: Colors.white, size: 32),
                                        SizedBox(height: 6),
                                        Text('Tap to view', style: TextStyle(
                                          color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700,
                                          shadows: [Shadow(blurRadius: 8, color: Colors.black)])),
                                      ]))),
                                ]),
                              ),
                              // Caption below image
                              if (caption != null && caption.isNotEmpty) ...[
                                const SizedBox(height: 4),
                                _TranslatableBubbleText(
                                  msgId: '${msg['id']}_cap',
                                  text: caption,
                                  isMe: isMe,
                                  translatedTexts: _translatedTexts,
                                  showOriginal: _showOriginal,
                                  onToggleOriginal: (id) => setState(() {
                                    if (_showOriginal.contains(id)) {
                                      _showOriginal.remove(id);
                                    } else {
                                      _showOriginal.add(id);
                                    }
                                  }),
                                  onTranslated: (id, text) {
                                    if (!mounted) return;
                                    if (_translatedTexts[id] == null) {
                                      setState(() => _translatedTexts[id] = text);
                                    }
                                  },
                                ),
                              ],
                            ],
                            if (msg['videoUrl'] != null) GestureDetector(
                              onTap: () => Navigator.push(context, MaterialPageRoute(
                                builder: (_) => VideoPlayerScreen(url: msg['videoUrl'] as String, title: 'Video'))),
                              child: Container(width: double.infinity, height: 180,
                                decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(10)),
                                child: Stack(children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: Container(color: Colors.black87)),
                                  const Center(child: Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 56)),
                                  Positioned(bottom: 8, left: 10,
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                      decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(12)),
                                      child: const Row(mainAxisSize: MainAxisSize.min, children: [
                                        Icon(Icons.videocam_rounded, color: Colors.white70, size: 12),
                                        SizedBox(width: 4),
                                        Text('Tap to play', style: TextStyle(color: Colors.white70, fontSize: 10, fontWeight: FontWeight.w500)),
                                      ]))),
                                  Positioned(bottom: 6, right: 6,
                                    child: GestureDetector(
                                      onTap: () => _showForwardSheet(msg),
                                      child: Container(padding: const EdgeInsets.all(6),
                                        decoration: BoxDecoration(color: Colors.black45, borderRadius: BorderRadius.circular(20)),
                                        child: const Icon(Icons.forward_rounded, color: Colors.white, size: 16)))),
                                ]))),
                            if (msg['mediaType'] == 'contact_card') ContactCardBubble(
                              contactUid: msg['contactUid'] ?? '',
                              contactName: msg['contactName'] ?? msg['text'] ?? 'User',
                              contactPhoto: msg['contactPhoto'] ?? '',
                              contactUsername: msg['contactUsername'] ?? '',
                              isMe: isMe,
                              onViewProfile: () {
                                final uid = msg['contactUid'] as String?;
                                if (uid != null && uid.isNotEmpty) {
                                  Navigator.pushNamed(context, '/profile', arguments: uid);
                                }
                              },
                            ),
                            if (msg['audioPath'] != null && msg['mediaType'] == 'audio')
                              WaveformAudioBubble(audioUrl: msg['audioPath']!, isMe: isMe, name: msg['docName']),
                            if (msg['docPath'] != null && msg['mediaType'] == 'document') _DocBubble(name: msg['docName'] ?? 'Document', url: msg['docPath'] ?? '', isMe: isMe),
                            // Location bubble
                            if (msg['mediaType'] == 'location' && msg['lat'] != null && msg['lng'] != null)
                              Padding(
                                padding: const EdgeInsets.only(bottom: 4),
                                child: LocationMessageWidget(
                                  lat: (msg['lat'] as num).toDouble(),
                                  lng: (msg['lng'] as num).toDouble(),
                                  isMe: isMe,
                                ),
                              ),
                            // Poll bubble
                            if (msg['mediaType'] == 'poll')
                              _PollBubble(
                                firestoreId: msg['firestoreId'] as String?,
                                chatId: () { final ids = [_fs.myUid, widget.targetId]..sort(); return '${ids[0]}_${ids[1]}'; }(),
                                question: msg['text'] as String? ?? '',
                                options: List<String>.from(msg['pollOptions'] as List? ?? []),
                                votes: Map<String, String>.from(msg['pollVotes'] as Map? ?? {}),
                                myUid: _fs.myUid,
                                isMe: isMe,
                              ),
                            // Zylo AI bubble
                            if (msg['mediaType'] == 'zylo_ai')
                              _ZyloAiBubble(text: msg['text'] as String? ?? ''),
                            // ── Post Share Card ──
                            if (msg['mediaType'] == 'post_share' && msg['sharedPost'] != null)
                              _PostShareBubble(
                                sharedPost: Map<String, dynamic>.from(msg['sharedPost'] as Map),
                                isMe: isMe),
                            // Text only (no image) — with translation support
                            if (!hasImage && msg['text'] != null && (msg['text'] as String).isNotEmpty && msg['mediaType'] != 'contact_card' && msg['mediaType'] != 'location' && msg['mediaType'] != 'poll' && msg['mediaType'] != 'zylo_ai' && msg['mediaType'] != 'post_share')
                              _TranslatableBubbleText(
                                msgId: msg['id'] as String? ?? '',
                                text: msg['text'] as String,
                                isMe: isMe,
                                translatedTexts: _translatedTexts,
                                showOriginal: _showOriginal,
                                onToggleOriginal: (id) => setState(() {
                                  if (_showOriginal.contains(id)) {
                                    _showOriginal.remove(id);
                                  } else {
                                    _showOriginal.add(id);
                                  }
                                }),
                                onTranslated: (id, text) {
                                  if (!mounted) return;
                                  if (_translatedTexts[id] == null) {
                                    setState(() => _translatedTexts[id] = text);
                                  }
                                },
                              ),
                            // Link preview
                            if (firstUrl != null) Padding(
                              padding: const EdgeInsets.only(top: 4),
                              child: LinkPreviewCard(url: firstUrl, isMe: isMe),
                            ),
                            if (hasTimer && !timerExpired) ...[
                              const SizedBox(height: 4),
                              _TimerCountdown(endsAt: timerEnds!, isMe: isMe),
                            ],
                          ],
                          const SizedBox(height: 2),
                          // ── Time + Viewed INSIDE bubble ──
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (isPinned) ...[
                                const Icon(Icons.push_pin, size: 9, color: Colors.orange),
                                const SizedBox(width: 2),
                              ],
                              Text(_formatTime(msg['timestamp'] as DateTime),
                                style: const TextStyle(fontSize: 9.5, color: Color(0xFF94A3B8), fontWeight: FontWeight.w400)),
                              if (isMe && msg['isRead'] == true) ...[
                                const SizedBox(width: 4),
                                GestureDetector(
                                  onTap: () {
                                    final ts = msg['timestamp'] as DateTime?;
                                    final sentStr = ts != null ? _formatFullTime(ts) : '?';
                                    final diff = ts != null ? DateTime.now().difference(ts) : null;
                                    final howLong = diff == null ? '' : diff.inMinutes < 60
                                      ? '${diff.inMinutes}m ago'
                                      : diff.inHours < 24
                                        ? '${diff.inHours}h ago'
                                        : '${diff.inDays}d ago';
                                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                      content: Text('✅ Sent: $sentStr  ($howLong)',
                                        style: const TextStyle(fontSize: 12)),
                                      duration: const Duration(seconds: 3),
                                      behavior: SnackBarBehavior.floating,
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                    ));
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFF0284C7).withValues(alpha: 0.12),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: const Text('Viewed',
                                      style: TextStyle(
                                        fontSize: 8, color: Color(0xFF0284C7),
                                        fontWeight: FontWeight.w600, letterSpacing: 0.1)),
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ]),
                      ),
                    ]),
                  ),
                  ),
                  if ((msg['reactions'] as Map? ?? {}).isNotEmpty || (msg['isLiked'] ?? false) || msg['reaction'] != null)
                    Positioned(bottom: -10, right: isMe ? 4 : null, left: isMe ? null : 4,
                      child: _buildReactionBubble(msg)),
                ]),
                ])), // Column + Flexible
                if (_isSelectMode && isMe) Padding(
                  padding: const EdgeInsets.only(left: 6, bottom: 8),
                  child: Icon(isSelected ? Icons.check_circle : Icons.circle_outlined,
                    color: isSelected ? _blue : Colors.grey[400], size: 22)),

              ],
            ),
          ),
        ),
      ),
    ), // GestureDetector
    ), // _SwipeToReply
    ); // _BubblePopWrapper
  }

  String _mediaLabel(String? type) {
    switch (type) {
      case 'image': return '📷 Photo'; case 'video': return '🎥 Video';
      case 'audio': return '🎵 Audio'; case 'document': return '📄 Document';
      default: return 'Message';
    }
  }


  void _showTimerPicker() {
    showModalBottomSheet(context: context, backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(margin: const EdgeInsets.only(top: 10, bottom: 6), width: 40, height: 4,
          decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
        const Padding(padding: EdgeInsets.symmetric(vertical: 12),
          child: Text('Self-Destruct Timer', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
        _timerOption(ctx, null, 'No Timer', Icons.timer_off_outlined, Colors.grey),
        _timerOption(ctx, const Duration(seconds: 10), '10 seconds', Icons.timer_outlined, Colors.teal),
        _timerOption(ctx, const Duration(seconds: 30), '30 seconds', Icons.timer_outlined, Colors.blue),
        _timerOption(ctx, const Duration(minutes: 1), '1 minute', Icons.timer_outlined, Colors.indigo),
        _timerOption(ctx, const Duration(minutes: 5), '5 minutes', Icons.timer_outlined, Colors.purple),
        ListTile(
          leading: Container(width: 36, height: 36, decoration: BoxDecoration(color: Colors.orange.withValues(alpha: 0.1), shape: BoxShape.circle),
            child: const Icon(Icons.edit_outlined, color: Colors.orange, size: 20)),
          title: const Text('Custom...', style: TextStyle(fontWeight: FontWeight.w600)),
          onTap: () { Navigator.pop(ctx); _showCustomTimerDialog(); }),
        const SizedBox(height: 8),
      ])));
  }

  Widget _timerOption(BuildContext ctx, Duration? dur, String label, IconData icon, Color color) {
    final isSelected = _timerDuration == dur;
    return ListTile(
      leading: Container(width: 36, height: 36,
        decoration: BoxDecoration(color: color.withValues(alpha: 0.1), shape: BoxShape.circle),
        child: Icon(icon, color: color, size: 20)),
      title: Text(label, style: TextStyle(fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600)),
      trailing: isSelected ? const Icon(Icons.check_circle, color: Color(0xFF0284C7)) : null,
      onTap: () { setState(() => _timerDuration = dur); Navigator.pop(ctx); });
  }

  void _showCustomTimerDialog() {
    final ctrl = TextEditingController();
    showDialog(context: context, builder: (_) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: const Text('Custom Timer', style: TextStyle(fontWeight: FontWeight.w800)),
      content: TextField(controller: ctrl, keyboardType: TextInputType.number,
        decoration: InputDecoration(hintText: 'Seconds (e.g. 30)', filled: true, fillColor: const Color(0xFFF1F5F9),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none))),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        ElevatedButton(
          onPressed: () {
            final secs = int.tryParse(ctrl.text.trim());
            if (secs != null && secs > 0) setState(() => _timerDuration = Duration(seconds: secs));
            Navigator.pop(context);
          },
          style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0284C7)),
          child: const Text('Set', style: TextStyle(color: Colors.white))),
      ]));
  }

  Widget _buildMentionSuggestions() {
    return Container(
      constraints: const BoxConstraints(maxHeight: 220),
      margin: const EdgeInsets.fromLTRB(8, 0, 8, 4),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.10), blurRadius: 12, offset: const Offset(0, -2))],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 4),
            child: Row(children: [
              const Icon(Icons.alternate_email, color: Color(0xFF0284C7), size: 14),
              const SizedBox(width: 6),
              Text(
                _mentionQuery.isEmpty ? 'Users' : 'Results for "@$_mentionQuery"',
                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: Color(0xFF0284C7)),
              ),
            ]),
          ),
          const Divider(height: 1, thickness: 0.5),
          Flexible(
            child: ListView.builder(
              shrinkWrap: true,
              padding: EdgeInsets.zero,
              itemCount: _mentionSuggestions.length,
              itemBuilder: (context, i) {
                final user = _mentionSuggestions[i];
                final username = user['username'] as String? ?? '';
                final photo = user['photoURL'] as String? ?? '';
                final bio = user['bio'] as String? ?? '';
                return InkWell(
                  onTap: () => _insertMention(username),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    child: Row(children: [
                      CircleAvatar(
                        radius: 18,
                        backgroundColor: const Color(0xFF0284C7),
                        backgroundImage: photo.isNotEmpty ? _safeNetworkImage(photo) : null,
                        child: photo.isEmpty
                            ? Text(username.isNotEmpty ? username[0].toUpperCase() : '?',
                                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13))
                            : null,
                      ),
                      const SizedBox(width: 10),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('@$username',
                            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: Color(0xFF0284C7))),
                        if (bio.isNotEmpty)
                          Text(bio, maxLines: 1, overflow: TextOverflow.ellipsis,
                              style: TextStyle(fontSize: 11, color: Colors.grey[500])),
                      ])),
                      const Icon(Icons.keyboard_return, size: 14, color: Colors.grey),
                    ]),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputBar() {
    final isBlocked = _iBlockedThem || _theyBlockedMe;
    if (isBlocked) {
      return Padding(
        padding: EdgeInsets.fromLTRB(10, 4, 10, MediaQuery.of(context).padding.bottom + 8),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: BackdropFilter(
            filter: ui.ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.85),
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: Colors.white.withValues(alpha: 0.6))),
              child: Text(
                _iBlockedThem ? 'Unblock ${widget.targetName} to send messages' : 'You cannot send messages',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 13, fontWeight: FontWeight.w500)),
            ),
          ),
        ));
    }
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom > 0
          ? MediaQuery.of(context).viewInsets.bottom
          : MediaQuery.of(context).padding.bottom),
      child: ZyloGlassInputBar(
      child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        GestureDetector(
          onTap: _openMediaPicker,
          onLongPress: _showShareContactSheet,
          child: Container(
            width: 40, height: 40,
            margin: const EdgeInsets.only(left: 8, bottom: 6),
            decoration: BoxDecoration(color: kBrand.withValues(alpha: 0.10), shape: BoxShape.circle),
            child: const Icon(Icons.add_rounded, color: kBrand, size: 21))),
        const SizedBox(width: 4),
        Expanded(child: TextField(
          controller: _msgController, maxLines: 5, minLines: 1,
          style: const TextStyle(fontSize: 15, color: Color(0xFF0F172A)),
          decoration: InputDecoration(
            hintText: 'FM...',
            hintStyle: TextStyle(color: Colors.grey.shade400, fontSize: 14.5),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4)),
          onSubmitted: (v) => _sendMessage(text: v, timerDuration: _timerDuration))),
        const SizedBox(width: 4),
        GestureDetector(onTap: _showPollCreator,
          child: AnimatedSize(
            duration: const Duration(milliseconds: 180),
            child: _showSend ? const SizedBox.shrink() : Container(
              width: 34, height: 34, margin: const EdgeInsets.only(bottom: 6),
              child: const Icon(Icons.poll_rounded, color: Color(0xFF94A3B8), size: 21)))),

        GestureDetector(
          onTap: _isSending ? null : () => _sendMessage(text: _msgController.text, timerDuration: _timerDuration),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 100),
            width: 42, height: 42,
            margin: const EdgeInsets.only(right: 6, bottom: 6),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: _isSending
                  ? [kBrand.withValues(alpha: 0.5), kBrandLight.withValues(alpha: 0.5)]
                  : const [kBrand, kBrandLight],
                begin: Alignment.topLeft, end: Alignment.bottomRight),
              shape: BoxShape.circle,
              boxShadow: _isSending ? [] : const [BoxShadow(color: kBrandGlow, blurRadius: 10, offset: Offset(0, 3))]),
            child: _isSending
              ? const Padding(padding: EdgeInsets.all(13),
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Icon(Icons.send_rounded, color: Colors.white, size: 19))),
      ]),
    ));
  }

  void _openGiphySheet() {
    showModalBottomSheet(
      context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (_) => _ChatGiphySheet(
        onSelect: (gifUrl) {
          _sendMessage(imageUrl: gifUrl, mediaType: 'gif');
        },
      ),
    );
  }

  String _formatTime(DateTime dt) {
    final h = dt.hour > 12 ? dt.hour - 12 : dt.hour == 0 ? 12 : dt.hour;
    final m = dt.minute.toString().padLeft(2, '0');
    return '$h:$m ${dt.hour >= 12 ? 'PM' : 'AM'}';
  }
}

// ── Forward Sheet ─────────────────────────────────────────────────────────────
class _ForwardSheet extends StatefulWidget {
  final Map<String, dynamic> msg;
  final String myUid;
  const _ForwardSheet({required this.msg, required this.myUid});
  @override
  State<_ForwardSheet> createState() => _ForwardSheetState();
}

class _ForwardSheetState extends State<_ForwardSheet> {
  final Set<String> _selected = {};
  static const _blue = Color(0xFF0284C7);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.7,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      child: Column(children: [
        Container(margin: const EdgeInsets.only(top: 10, bottom: 6), width: 40, height: 4,
            decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
        Padding(padding: const EdgeInsets.fromLTRB(20, 4, 20, 8),
          child: Row(children: [
            const Icon(Icons.forward_rounded, color: _blue, size: 20),
            const SizedBox(width: 8),
            const Text('Forward to', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const Spacer(),
            if (_selected.isNotEmpty)
              GestureDetector(
                onTap: _forwardNow,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
                  decoration: BoxDecoration(color: _blue, borderRadius: BorderRadius.circular(20)),
                  child: Text('Send (${_selected.length})',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)))),
          ])),
        const Divider(height: 1),
        Expanded(child: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance.collection('chats')
              .where('participants', arrayContains: widget.myUid).snapshots(),
          builder: (ctx, snap) {
            if (!snap.hasData) return const Center(child: ZyloLoader());
            final docs = snap.data!.docs;
            if (docs.isEmpty) return const Center(child: Text('No chats yet', style: TextStyle(color: Colors.grey)));
            return ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
              itemCount: docs.length,
              itemBuilder: (_, i) {
                final chat = docs[i].data() as Map<String, dynamic>;
                final participants = (chat['participants'] as List).cast<String>();
                final otherUid = participants.firstWhere((p) => p != widget.myUid, orElse: () => '');
                if (otherUid.isEmpty) return const SizedBox.shrink();
                final names = chat['participantNames'] as Map<String, dynamic>? ?? {};
                final photos = chat['participantPhotos'] as Map<String, dynamic>? ?? {};
                final name = names[otherUid] ?? 'User';
                final photo = photos[otherUid] ?? '';
                final isSelected = _selected.contains(otherUid);
                return GestureDetector(
                  onTap: () => setState(() {
                    if (isSelected) _selected.remove(otherUid); else _selected.add(otherUid);
                  }),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: isSelected ? _blue.withValues(alpha: 0.06) : Colors.grey[50],
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: isSelected ? _blue.withValues(alpha: 0.3) : Colors.transparent)),
                    child: Row(children: [
                      CircleAvatar(radius: 22, backgroundColor: _blue,
                        backgroundImage: photo.isNotEmpty ? _safeNetworkImage(photo) : null,
                        child: photo.isEmpty ? Text(name[0].toUpperCase(),
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)) : null),
                      const SizedBox(width: 12),
                      Expanded(child: Text(name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14))),
                      AnimatedContainer(duration: const Duration(milliseconds: 150),
                        width: 24, height: 24,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: isSelected ? _blue : Colors.transparent,
                          border: Border.all(color: isSelected ? _blue : Colors.grey[300]!)),
                        child: isSelected ? const Icon(Icons.check, color: Colors.white, size: 14) : null),
                    ]),
                  ),
                );
              },
            );
          },
        )),
      ]),
    );
  }

  Future<void> _forwardNow() async {
    final msg = widget.msg;
    final fs = FirestoreService();
    for (final targetUid in _selected) {
      await fs.sendMessage(
        otherUid: targetUid,
        text: msg['text'] as String?,
        imageUrl: msg['imageUrl'] as String?,
        videoUrl: msg['videoUrl'] as String?,
        audioUrl: msg['audioPath'] as String?,
        docUrl: msg['docPath'] as String?,
        docName: msg['docName'] as String?,
        mediaType: msg['mediaType'] as String? ?? 'text',
      );
    }
    if (mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Forwarded to ${_selected.length} chat${_selected.length > 1 ? 's' : ''}'),
        backgroundColor: Colors.green, behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
    }
  }
}

// ── Timer Countdown ───────────────────────────────────────────────────────────
class _TimerCountdown extends StatefulWidget {
  final DateTime endsAt; final bool isMe;
  const _TimerCountdown({required this.endsAt, required this.isMe});
  @override State<_TimerCountdown> createState() => _TimerCountdownState();
}
class _TimerCountdownState extends State<_TimerCountdown> {
  late Timer _timer; late Duration _remaining;
  @override void initState() { super.initState(); _remaining = widget.endsAt.difference(DateTime.now());
    _timer = Timer.periodic(const Duration(seconds: 1), (_) { if (mounted) setState(() => _remaining = widget.endsAt.difference(DateTime.now())); }); }
  @override void dispose() { _timer.cancel(); super.dispose(); }
  @override Widget build(BuildContext context) {
    final isExpired = _remaining.isNegative;
    final secs = isExpired ? 0 : _remaining.inSeconds;
    final color = secs > 30 ? const Color(0xFF0284C7) : (secs > 10 ? Colors.orange : Colors.red);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withValues(alpha: 0.35))),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(isExpired ? Icons.timer_off_rounded : Icons.timer_rounded, color: color, size: 13),
        const SizedBox(width: 4),
        Text(
          isExpired ? 'Expired' : secs >= 60
            ? '${secs ~/ 60}m ${(secs % 60).toString().padLeft(2, '0')}s'
            : '${secs}s',
          style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: color)),
      ]),
    );
  }
}

// ── Audio Bubble ──────────────────────────────────────────────────────────────
// ── Typing Dots Animation ─────────────────────────────────────────────────────
class _TypingDots extends StatefulWidget {
  const _TypingDots();
  @override State<_TypingDots> createState() => _TypingDotsState();
}
class _TypingDotsState extends State<_TypingDots> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  @override void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000))..repeat();
  }
  @override void dispose() { _ctrl.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) {
    return AnimatedBuilder(animation: _ctrl, builder: (_, __) {
      return Row(mainAxisSize: MainAxisSize.min, children: List.generate(3, (i) {
        // Wave: each dot peaks 120ms apart
        final t = (_ctrl.value - i * 0.18).clamp(0.0, 1.0);
        final wave = t < 0.5 ? (2 * t) : (2 * (1 - t));
        final dy = -4.0 * wave;
        return Transform.translate(
          offset: Offset(0, dy),
          child: Container(
            width: 5, height: 5, margin: const EdgeInsets.only(right: 3),
            decoration: BoxDecoration(
              color: const Color(0xFF0284C7).withValues(alpha: 0.5 + 0.5 * wave),
              shape: BoxShape.circle),
          ),
        );
      }));
    });
  }
}

// ── Bubble Pop Animation Wrapper ──────────────────────────────────────────────
class _BubblePopWrapper extends StatefulWidget {
  final Widget child;
  final bool animate;
  const _BubblePopWrapper({required this.child, required this.animate});
  @override State<_BubblePopWrapper> createState() => _BubblePopWrapperState();
}
class _BubblePopWrapperState extends State<_BubblePopWrapper> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _opacity;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 280));
    _opacity = Tween(begin: 0.0, end: 1.0)
        .chain(CurveTween(curve: Curves.easeOut))
        .animate(_ctrl);
    _slide = Tween(begin: const Offset(0.08, 0.0), end: Offset.zero)
        .chain(CurveTween(curve: Curves.easeOut))
        .animate(_ctrl);

    if (widget.animate) {
      _ctrl.forward();
    } else {
      _ctrl.value = 1.0;
    }
  }

  @override void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    if (!widget.animate) return widget.child;
    return FadeTransition(
      opacity: _opacity,
      child: SlideTransition(
        position: _slide,
        child: widget.child,
      ),
    );
  }
}

class _AudioBubble extends StatefulWidget {
  final String path, name; final bool isMe;
  const _AudioBubble({required this.path, required this.name, required this.isMe});
  @override State<_AudioBubble> createState() => _AudioBubbleState();
}
class _AudioBubbleState extends State<_AudioBubble> {
  bool _playing = false;
  @override Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        GestureDetector(
          onTap: () => setState(() => _playing = !_playing),
          child: Container(width: 36, height: 36, decoration: BoxDecoration(
            color: const Color(0xFF0284C7), shape: BoxShape.circle),
            child: Icon(_playing ? Icons.pause : Icons.play_arrow, color: Colors.white, size: 20))),
        const SizedBox(width: 8),
        Flexible(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(widget.name, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600,
            color: Colors.grey[700]), maxLines: 1, overflow: TextOverflow.ellipsis),
          Container(margin: const EdgeInsets.only(top: 4), height: 2,
            decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2))),
        ])),
      ]),
    );
  }
}

// ── Doc Bubble ────────────────────────────────────────────────────────────────
class _DocBubble extends StatefulWidget {
  final String name, url; final bool isMe;
  const _DocBubble({required this.name, required this.url, required this.isMe});
  @override State<_DocBubble> createState() => _DocBubbleState();
}

class _DocBubbleState extends State<_DocBubble> {
  bool _downloading = false;
  double _progress = 0;

  String get _ext => widget.name.contains('.') ? widget.name.split('.').last.toLowerCase() : '';

  IconData get _icon {
    switch (_ext) {
      case 'pdf': return Icons.picture_as_pdf_outlined;
      case 'doc': case 'docx': return Icons.description_outlined;
      case 'xls': case 'xlsx': return Icons.table_chart_outlined;
      case 'ppt': case 'pptx': return Icons.slideshow_outlined;
      case 'zip': case 'rar': case '7z': return Icons.folder_zip_outlined;
      case 'apk': return Icons.install_mobile_rounded;
      case 'mp3': case 'wav': case 'ogg': return Icons.audio_file_outlined;
      case 'mp4': case 'mov': return Icons.video_file_outlined;
      case 'jpg': case 'jpeg': case 'png': return Icons.image_outlined;
      default: return Icons.insert_drive_file_outlined;
    }
  }

  Color get _color {
    switch (_ext) {
      case 'pdf': return Colors.red;
      case 'doc': case 'docx': return const Color(0xFF2B579A);
      case 'xls': case 'xlsx': return const Color(0xFF217346);
      case 'ppt': case 'pptx': return const Color(0xFFD24726);
      case 'zip': case 'rar': case '7z': return Colors.orange;
      case 'apk': return Colors.green;
      default: return const Color(0xFF0284C7);
    }
  }

  Future<void> _onTap() async {
    if (widget.url.isEmpty) return;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => _FileOpenSheet(
        name: widget.name,
        url: widget.url,
        ext: _ext,
        icon: _icon,
        color: _color,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        decoration: BoxDecoration(
          color: widget.isMe
              ? Colors.white.withValues(alpha: 0.15)
              : Colors.grey.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _color.withValues(alpha: 0.25), width: 1),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 40, height: 40,
            decoration: BoxDecoration(
              color: _color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(_icon, color: _color, size: 22),
          ),
          const SizedBox(width: 10),
          Flexible(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
              Text(widget.name,
                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.black87),
                maxLines: 2, overflow: TextOverflow.ellipsis),
              const SizedBox(height: 2),
              Text(_ext.toUpperCase(),
                style: TextStyle(fontSize: 10, color: _color, fontWeight: FontWeight.w600)),
            ]),
          ),
          const SizedBox(width: 8),
          Icon(Icons.open_in_new_rounded, color: _color, size: 16),
        ]),
      ),
    );
  }
}

// ── File Open Sheet — WhatsApp style ─────────────────────────────────────────
class _FileOpenSheet extends StatefulWidget {
  final String name, url, ext; final IconData icon; final Color color;
  const _FileOpenSheet({required this.name, required this.url, required this.ext, required this.icon, required this.color});
  @override State<_FileOpenSheet> createState() => _FileOpenSheetState();
}

class _FileOpenSheetState extends State<_FileOpenSheet> {
  bool _loading = false;
  String _status = '';

  Future<File> _downloadFile() async {
    final dir = await getTemporaryDirectory();
    final safeName = widget.name.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
    final file = File('${dir.path}/$safeName');
    if (await file.exists()) return file; // already cached
    final resp = await http.get(Uri.parse(widget.url)).timeout(const Duration(minutes: 5));
    await file.writeAsBytes(resp.bodyBytes);
    return file;
  }

  bool get _isApk => widget.ext == 'apk';

  Future<void> _openFile() async {
    setState(() { _loading = true; _status = 'Downloading...'; });
    try {
      final file = await _downloadFile();
      setState(() => _status = _isApk ? 'Preparing install...' : 'Opening...');

      if (_isApk) {
        await _installApk(file);
        return;
      }

      final result = await OpenFilex.open(file.path);
      if (result.type != ResultType.done && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Could not open: ${result.message}'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
        ));
      }
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        setState(() { _loading = false; _status = ''; });
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Error: $e'), backgroundColor: Colors.red, behavior: SnackBarBehavior.floating));
      }
    }
  }

  Future<void> _installApk(File file) async {
    if (!mounted) return;
    // Check if "Install unknown apps" permission is granted for this app
    final canInstall = await Permission.requestInstallPackages.status;

    if (canInstall.isGranted) {
      // Directly trigger install via OpenFilex
      final result = await OpenFilex.open(file.path);
      if (mounted) {
        if (result.type != ResultType.done) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('Install failed: ${result.message}'),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
          ));
          setState(() { _loading = false; _status = ''; });
        } else {
          Navigator.pop(context);
        }
      }
    } else {
      // Permission not granted — show dialog to redirect to Settings
      setState(() { _loading = false; _status = ''; });
      if (!mounted) return;
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: const Color(0xFF1E1E2E),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Row(children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.orange.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.security_rounded, color: Colors.orange, size: 22),
            ),
            const SizedBox(width: 12),
            const Text('Allow Installation',
              style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800)),
          ]),
          content: const Text(
            'To install APK files, you need to allow Zylo to install unknown apps.\n\nGo to Settings → Install unknown apps → Enable for Zylo.',
            style: TextStyle(color: Colors.white70, fontSize: 13, height: 1.5),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel', style: TextStyle(color: Colors.white54)),
            ),
            ElevatedButton(
              onPressed: () async {
                Navigator.pop(ctx);
                // Request permission — Android will open Settings automatically
                await Permission.requestInstallPackages.request();
                // After returning from Settings, retry install
                if (mounted) {
                  final status = await Permission.requestInstallPackages.status;
                  if (status.isGranted) {
                    setState(() { _loading = true; _status = 'Installing...'; });
                    await _installApk(file);
                  }
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                elevation: 0,
              ),
              child: const Text('Open Settings', style: TextStyle(fontWeight: FontWeight.w700)),
            ),
          ],
        ),
      );
    }
  }

  Future<void> _saveToDownloads() async {
    setState(() { _loading = true; _status = 'Saving...'; });
    try {
      final file = await _downloadFile();
      // Copy to Downloads folder
      final downloads = Directory('/storage/emulated/0/Download');
      if (!await downloads.exists()) await downloads.create(recursive: true);
      final safeName = widget.name.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
      final dest = File('${downloads.path}/zylo_$safeName');
      await file.copy(dest.path);
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('✅ Saved to Downloads!'),
          backgroundColor: Colors.green, behavior: SnackBarBehavior.floating));
      }
    } catch (e) {
      if (mounted) {
        setState(() { _loading = false; _status = ''; });
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Error: $e'), backgroundColor: Colors.red, behavior: SnackBarBehavior.floating));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        // Handle bar
        Container(width: 40, height: 4,
          decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
        const SizedBox(height: 20),
        // File icon + name
        Row(children: [
          Container(width: 50, height: 50,
            decoration: BoxDecoration(color: widget.color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(14)),
            child: Icon(widget.icon, color: widget.color, size: 28)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.name,
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: Colors.black87),
              maxLines: 2, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 3),
            Text(widget.ext.toUpperCase(),
              style: TextStyle(fontSize: 11, color: widget.color, fontWeight: FontWeight.w700)),
          ])),
        ]),
        const SizedBox(height: 20),
        if (_loading) ...[
          LinearProgressIndicator(color: widget.color, backgroundColor: widget.color.withValues(alpha: 0.15)),
          const SizedBox(height: 8),
          Text(_status, style: TextStyle(color: widget.color, fontSize: 13, fontWeight: FontWeight.w600)),
          const SizedBox(height: 12),
        ] else ...[
          // Open With / Install APK button
          SizedBox(width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _openFile,
              icon: Icon(_isApk ? Icons.install_mobile_rounded : Icons.open_in_new_rounded, size: 18),
              label: Text(_isApk ? 'Install APK' : 'Open With',
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
              style: ElevatedButton.styleFrom(
                backgroundColor: _isApk ? Colors.orange : widget.color,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                elevation: 0,
              ),
            ),
          ),
          const SizedBox(height: 10),
          // Save to Downloads button
          SizedBox(width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _saveToDownloads,
              icon: Icon(Icons.download_rounded, size: 18, color: widget.color),
              label: Text('Save to Downloads', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: widget.color)),
              style: OutlinedButton.styleFrom(
                side: BorderSide(color: widget.color.withValues(alpha: 0.4)),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
            ),
          ),
        ],
      ]),
    );
  }
}

// ── Full Screen Image Viewer ──────────────────────────────────────────────────
class _FullScreenImageViewer extends StatelessWidget {
  final String imageUrl;
  final VoidCallback? onSave;
  final VoidCallback? onForward;
  const _FullScreenImageViewer({required this.imageUrl, this.onSave, this.onForward});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [
        Center(child: InteractiveViewer(
          minScale: 0.5, maxScale: 5.0,
          child: Image.network(imageUrl, fit: BoxFit.contain,
            loadingBuilder: (_, c, p) => p == null ? c
                : const Center(child: CircularProgressIndicator(color: Colors.white)),
            errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white, size: 80)),
        )),
        // Top gradient bar
        Positioned(top: 0, left: 0, right: 0,
          child: Container(
            padding: EdgeInsets.fromLTRB(8, MediaQuery.of(context).padding.top + 8, 8, 16),
            decoration: BoxDecoration(gradient: LinearGradient(
              colors: [Colors.black.withValues(alpha: 0.6), Colors.transparent],
              begin: Alignment.topCenter, end: Alignment.bottomCenter)),
            child: Row(children: [
              // Close
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.15), shape: BoxShape.circle),
                  child: const Icon(Icons.arrow_back_rounded, color: Colors.white, size: 22))),
              const Spacer(),
              // Save
              if (onSave != null)
                GestureDetector(
                  onTap: () { onSave!(); Navigator.pop(context); },
                  child: Container(
                    margin: const EdgeInsets.only(right: 10),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.white30)),
                    child: const Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.save_alt_rounded, color: Colors.white, size: 18),
                      SizedBox(width: 6),
                      Text('Save', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
                    ]))),
              // Forward
              if (onForward != null)
                GestureDetector(
                  onTap: () { Navigator.pop(context); onForward!(); },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0284C7).withValues(alpha: 0.85),
                      borderRadius: BorderRadius.circular(20)),
                    child: const Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.forward_rounded, color: Colors.white, size: 18),
                      SizedBox(width: 6),
                      Text('Forward', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
                    ]))),
            ]),
          )),
      ]),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// CHAT GIPHY SHEET
// ══════════════════════════════════════════════════════════════════════════════

class _ChatGiphySheet extends StatefulWidget {
  final ValueChanged<String> onSelect;
  const _ChatGiphySheet({required this.onSelect});
  @override State<_ChatGiphySheet> createState() => _ChatGiphySheetState();
}

class _ChatGiphySheetState extends State<_ChatGiphySheet> {
  static const _blue = Color(0xFF0284C7);
  // Key loaded from Firebase Remote Config — not hardcoded
  String get _giphyKey => RemoteConfigService.instance.getString('giphy_api_key');
  final _searchCtrl = TextEditingController();
  List<Map<String, String>> _gifs = []; // {thumb, original}
  bool _loading = true;

  @override
  void initState() { super.initState(); _fetchTrending(); }

  @override
  void dispose() { _searchCtrl.dispose(); super.dispose(); }

  Future<void> _fetchTrending() async {
    setState(() => _loading = true);
    try {
      final res = await http.get(Uri.parse(
        'https://api.giphy.com/v1/gifs/trending?api_key=$_giphyKey&limit=30&rating=g'))
        .timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final data = json.decode(res.body)['data'] as List;
        final list = data.map<Map<String, String>>((g) => {
          'thumb': g['images']['fixed_height']['url'] as String? ?? '',
          'original': g['images']['original']['url'] as String? ?? g['images']['fixed_height']['url'] as String? ?? '',
        }).where((m) => m['thumb']!.isNotEmpty).toList();
        if (mounted) setState(() { _gifs = list; _loading = false; });
        return;
      }
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _search(String q) async {
    if (q.trim().isEmpty) { _fetchTrending(); return; }
    setState(() => _loading = true);
    try {
      final res = await http.get(Uri.parse(
        'https://api.giphy.com/v1/gifs/search?api_key=$_giphyKey&q=${Uri.encodeComponent(q)}&limit=30&rating=g'))
        .timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final data = json.decode(res.body)['data'] as List;
        final list = data.map<Map<String, String>>((g) => {
          'thumb': g['images']['fixed_height']['url'] as String? ?? '',
          'original': g['images']['original']['url'] as String? ?? g['images']['fixed_height']['url'] as String? ?? '',
        }).where((m) => m['thumb']!.isNotEmpty).toList();
        if (mounted) setState(() { _gifs = list; _loading = false; });
        return;
      }
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.72,
      decoration: const BoxDecoration(color: Color(0xFF111827), borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      child: Column(children: [
        Container(margin: const EdgeInsets.only(top: 10, bottom: 4), width: 40, height: 4,
          decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(10))),
        const Padding(padding: EdgeInsets.symmetric(vertical: 10),
          child: Text('🎬 Send a GIF', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 17))),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.07), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.white12)),
            child: TextField(controller: _searchCtrl,
              style: const TextStyle(color: Colors.white, fontSize: 14),
              decoration: const InputDecoration(border: InputBorder.none, hintText: 'Search GIFs...', hintStyle: TextStyle(color: Colors.white38), icon: Icon(Icons.search, color: Colors.white38, size: 18)),
              onSubmitted: _search,
              onChanged: (v) { if (v.isEmpty) _fetchTrending(); }))),
        const SizedBox(height: 8),
        Expanded(child: _loading
          ? const Center(child: ZyloLoader())
          : _gifs.isEmpty
            ? const Center(child: Text('No GIFs found', style: TextStyle(color: Colors.white54)))
            : GridView.builder(
                padding: const EdgeInsets.all(10),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: 1.6),
                itemCount: _gifs.length,
                itemBuilder: (_, i) => GestureDetector(
                  onTap: () {
                    HapticFeedback.lightImpact();
                    Navigator.pop(context);
                    widget.onSelect(_gifs[i]['original']!);
                  },
                  child: ClipRRect(borderRadius: BorderRadius.circular(10),
                    child: Image.network(_gifs[i]['thumb']!, fit: BoxFit.cover,
                      loadingBuilder: (_, c, p) => p == null ? c : Container(color: Colors.white.withValues(alpha: 0.07), child: Center(child: CircularProgressIndicator(strokeWidth: 2, color: _blue))),
                      errorBuilder: (_, __, ___) => Container(color: Colors.white12, child: const Icon(Icons.gif, color: Colors.white38, size: 36)))))),
        ),
      ]),
    );
  }
}

// ── Contact Share Bottom Sheet (Phone Contacts + Zylo Users) ────────────────
class _ContactShareBottomSheet extends StatefulWidget {
  final String myUid;
  final Future<void> Function(Map<String, dynamic>) onShareZyloUser;
  final void Function(String name, String phone) onSharePhoneContact;

  const _ContactShareBottomSheet({
    required this.myUid,
    required this.onShareZyloUser,
    required this.onSharePhoneContact,
  });

  @override
  State<_ContactShareBottomSheet> createState() => _ContactShareBottomSheetState();
}

class _ContactShareBottomSheetState extends State<_ContactShareBottomSheet>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  static const _blue = Color(0xFF0284C7);

  // Phone contacts
  List<Map<String, String>> _phoneContacts = [];
  bool _loadingContacts = false;
  String _contactSearch = '';
  final TextEditingController _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
    _loadPhoneContacts();
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadPhoneContacts() async {
    setState(() => _loadingContacts = true);
    try {
      final status = await Permission.contacts.request();
      if (!status.isGranted) {
        setState(() => _loadingContacts = false);
        return;
      }
      final contacts = await FlutterContacts.getContacts(withProperties: true);
      final list = <Map<String, String>>[];
      for (final c in contacts) {
        final name = c.displayName.trim();
        if (name.isEmpty) continue;
        for (final p in c.phones) {
          final num = p.number.replaceAll(RegExp(r'\s|-'), '').trim();
          if (num.isNotEmpty) list.add({'name': name, 'phone': num});
        }
      }
      list.sort((a, b) => a['name']!.compareTo(b['name']!));
      if (mounted) setState(() { _phoneContacts = list; _loadingContacts = false; });
    } catch (_) {
      if (mounted) setState(() => _loadingContacts = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.80,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(children: [
        Container(margin: const EdgeInsets.only(top: 10, bottom: 6), width: 40, height: 4,
            decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 6, 20, 0),
          child: Row(children: [
            const Icon(Icons.contacts_rounded, color: _blue, size: 20),
            const SizedBox(width: 8),
            const Text('Share Contact', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          ]),
        ),
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: TextField(
            controller: _searchCtrl,
            decoration: InputDecoration(
              hintText: 'Search...',
              prefixIcon: const Icon(Icons.search, color: Colors.grey, size: 20),
              filled: true,
              fillColor: Colors.grey[100],
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
              contentPadding: const EdgeInsets.symmetric(vertical: 10),
            ),
            onChanged: (v) => setState(() => _contactSearch = v.toLowerCase()),
          ),
        ),
        const SizedBox(height: 8),
        TabBar(
          controller: _tabCtrl,
          labelColor: _blue,
          unselectedLabelColor: Colors.grey,
          indicatorColor: _blue,
          labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          tabs: const [
            Tab(text: 'Phone Contacts'),
            Tab(text: 'Zylo Users'),
          ],
        ),
        const Divider(height: 1),
        Expanded(
          child: TabBarView(
            controller: _tabCtrl,
            children: [
              // ── Phone Contacts tab ─────────────────────────────────────
              _loadingContacts
                  ? const Center(child: ZyloLoader())
                  : _phoneContacts.isEmpty
                      ? Center(child: Padding(
                          padding: const EdgeInsets.all(32),
                          child: Column(mainAxisSize: MainAxisSize.min, children: [
                            Icon(Icons.contacts_outlined, size: 48, color: Colors.grey[300]),
                            const SizedBox(height: 12),
                            const Text('No contacts found\nor permission denied',
                                textAlign: TextAlign.center,
                                style: TextStyle(color: Colors.grey)),
                            const SizedBox(height: 12),
                            ElevatedButton(
                              onPressed: _loadPhoneContacts,
                              style: ElevatedButton.styleFrom(backgroundColor: _blue),
                              child: const Text('Allow Access', style: TextStyle(color: Colors.white)),
                            ),
                          ]),
                        ))
                      : ListView.builder(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          itemCount: _phoneContacts
                              .where((c) => _contactSearch.isEmpty ||
                                  c['name']!.toLowerCase().contains(_contactSearch) ||
                                  c['phone']!.contains(_contactSearch))
                              .length,
                          itemBuilder: (_, i) {
                            final filtered = _phoneContacts
                                .where((c) => _contactSearch.isEmpty ||
                                    c['name']!.toLowerCase().contains(_contactSearch) ||
                                    c['phone']!.contains(_contactSearch))
                                .toList();
                            final contact = filtered[i];
                            return ListTile(
                              leading: CircleAvatar(
                                backgroundColor: _blue,
                                child: Text(contact['name']![0].toUpperCase(),
                                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                              ),
                              title: Text(contact['name']!,
                                  style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                              subtitle: Text(contact['phone']!,
                                  style: TextStyle(color: Colors.grey[500], fontSize: 12)),
                              trailing: ElevatedButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                  widget.onSharePhoneContact(contact['name']!, contact['phone']!);
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: _blue,
                                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                                  minimumSize: Size.zero,
                                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                                ),
                                child: const Text('Share', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
                              ),
                            );
                          },
                        ),
              // ── Zylo Users tab ──────────────────────────────────────────
              ShareContactSheet(
                myUid: widget.myUid,
                onShare: (contact) async {
                  Navigator.pop(context);
                  await widget.onShareZyloUser(contact);
                },
              ),
            ],
          ),
        ),
      ]),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// Chat Background Painter — subtle dot/circle pattern on gradient
// ══════════════════════════════════════════════════════════════════════════════
class _ChatBackgroundPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint();
    final rect = Offset.zero & size;
    paint.shader = const LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [Color(0xFFD6EAF8), Color(0xFFE8F4FD), Color(0xFFF0F8FF)],
      stops: [0.0, 0.5, 1.0],
    ).createShader(rect);
    canvas.drawRect(rect, paint);

    final dotPaint = Paint()
      ..color = const Color(0xFF0284C7).withValues(alpha: 0.045)
      ..style = PaintingStyle.fill;

    const spacing = 28.0;
    const dotRadius = 2.5;
    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), dotRadius, dotPaint);
      }
    }

    final circlePaint = Paint()
      ..color = const Color(0xFF0284C7).withValues(alpha: 0.025)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;

    canvas.drawCircle(Offset(size.width * 0.1, size.height * 0.15), 80, circlePaint);
    canvas.drawCircle(Offset(size.width * 0.9, size.height * 0.35), 120, circlePaint);
    canvas.drawCircle(Offset(size.width * 0.2, size.height * 0.7), 100, circlePaint);
    canvas.drawCircle(Offset(size.width * 0.8, size.height * 0.85), 90, circlePaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ═══════════════════════════════════════════════════════════════════════
// Game Invite Bubble
// ═══════════════════════════════════════════════════════════════════════
// ── Game Invite Bubble with Accept / Reject ─────────────────────────────────
// ── Poll Bubble ───────────────────────────────────────────────────────────────
class _PollBubble extends StatefulWidget {
  final String? firestoreId;
  final String chatId;
  final String question;
  final List<String> options;
  final Map<String, String> votes;
  final String myUid;
  final bool isMe;
  const _PollBubble({
    required this.firestoreId, required this.chatId, required this.question,
    required this.options, required this.votes, required this.myUid, required this.isMe,
  });
  @override State<_PollBubble> createState() => _PollBubbleState();
}

class _PollBubbleState extends State<_PollBubble> {
  late Map<String, String> _votes;
  bool _voting = false;

  @override
  void initState() {
    super.initState();
    _votes = Map<String, String>.from(widget.votes);
  }

  @override
  void didUpdateWidget(_PollBubble old) {
    super.didUpdateWidget(old);
    if (old.votes != widget.votes) setState(() => _votes = Map<String, String>.from(widget.votes));
  }

  String? get _myVote => _votes[widget.myUid];
  int _countFor(String opt) => _votes.values.where((v) => v == opt).length;
  int get _total => _votes.length;

  Future<void> _vote(String option) async {
    if (_voting || widget.firestoreId == null) return;
    setState(() { _voting = true; _votes[widget.myUid] = option; });
    try {
      await FirebaseFirestore.instance
          .collection('chats').doc(widget.chatId)
          .collection('messages').doc(widget.firestoreId)
          .update({'pollVotes.${widget.myUid}': option});
    } catch (_) {}
    if (mounted) setState(() => _voting = false);
  }

  @override
  Widget build(BuildContext context) {
    final voted = _myVote != null;
    return Container(
      constraints: const BoxConstraints(minWidth: 200, maxWidth: 260),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 18, height: 18,
            decoration: BoxDecoration(color: widget.isMe ? Colors.white24 : const Color(0xFF0284C7), shape: BoxShape.circle),
            child: Icon(Icons.poll_rounded, color: widget.isMe ? Colors.white : Colors.white, size: 11)),
          const SizedBox(width: 6),
          Text('Poll', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
            color: widget.isMe ? Colors.white70 : const Color(0xFF0284C7))),
        ]),
        const SizedBox(height: 6),
        Text(widget.question,
          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14,
            color: widget.isMe ? Colors.white : Colors.black87)),
        const SizedBox(height: 10),
        ...widget.options.map((opt) {
          final count = _countFor(opt);
          final pct = _total > 0 ? count / _total : 0.0;
          final isSelected = _myVote == opt;
          return GestureDetector(
            onTap: voted ? null : () => _vote(opt),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.only(bottom: 8),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: isSelected
                      ? (widget.isMe ? Colors.white : const Color(0xFF0284C7))
                      : (widget.isMe ? Colors.white30 : Colors.grey.shade300),
                  width: isSelected ? 2 : 1),
                color: widget.isMe ? Colors.white12 : Colors.grey.shade50),
              child: Stack(children: [
                if (voted)
                  Positioned.fill(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(9),
                      child: FractionallySizedBox(
                        widthFactor: pct, alignment: Alignment.centerLeft,
                        child: Container(
                          color: isSelected
                              ? (widget.isMe ? Colors.white24 : const Color(0xFF0284C7).withValues(alpha: 0.15))
                              : (widget.isMe ? Colors.white12 : Colors.grey.shade100)),
                      ),
                    ),
                  ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  child: Row(children: [
                    Expanded(child: Text(opt,
                      style: TextStyle(fontSize: 13, fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                        color: widget.isMe ? Colors.white : Colors.black87))),
                    if (voted) Text('${(pct * 100).round()}%',
                      style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
                        color: widget.isMe ? Colors.white70 : Colors.grey)),
                  ]),
                ),
              ]),
            ),
          );
        }),
        if (_total > 0)
          Padding(
            padding: const EdgeInsets.only(top: 2),
            child: Text('$_total vote${_total == 1 ? '' : 's'}',
              style: TextStyle(fontSize: 11, color: widget.isMe ? Colors.white54 : Colors.grey)),
          ),
      ]),
    );
  }
}

// ── Zylo AI Bubble ────────────────────────────────────────────────────────────
class _ZyloAiBubble extends StatelessWidget {
  final String text;
  const _ZyloAiBubble({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(left: 4, top: 2, bottom: 2),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
        Container(width: 26, height: 26,
          decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [Color(0xFF0284C7), Color(0xFF7C3AED)],
              begin: Alignment.topLeft, end: Alignment.bottomRight),
            shape: BoxShape.circle),
          child: const Icon(Icons.auto_awesome, color: Colors.white, size: 13)),
        const SizedBox(width: 8),
        Flexible(child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFFF0F7FF), Color(0xFFF5F0FF)],
              begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(4), topRight: Radius.circular(16),
              bottomLeft: Radius.circular(16), bottomRight: Radius.circular(16)),
            border: Border.all(color: const Color(0xFF0284C7).withValues(alpha: 0.2))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Text('Zylo AI', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Color(0xFF0284C7))),
              const SizedBox(width: 4),
              Container(padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF0284C7), Color(0xFF7C3AED)]),
                  borderRadius: BorderRadius.circular(6)),
                child: const Text('AI', style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w800))),
            ]),
            const SizedBox(height: 4),
            Text(text, style: const TextStyle(fontSize: 14, color: Color(0xFF1A1A1A), height: 1.4)),
          ]),
        )),
      ]),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  Multi-image full-screen swipe viewer
// ═══════════════════════════════════════════════════════════════════════
class _MultiImageViewer extends StatefulWidget {
  final List<String> urls;
  final int initialIndex;
  const _MultiImageViewer({required this.urls, required this.initialIndex});

  @override
  State<_MultiImageViewer> createState() => _MultiImageViewerState();
}

class _MultiImageViewerState extends State<_MultiImageViewer> {
  late PageController _pageCtrl;
  late int _current;

  @override
  void initState() {
    super.initState();
    _current  = widget.initialIndex;
    _pageCtrl = PageController(initialPage: widget.initialIndex);
  }

  @override
  void dispose() { _pageCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [
        // Swipeable pages
        PageView.builder(
          controller: _pageCtrl,
          itemCount: widget.urls.length,
          onPageChanged: (i) => setState(() => _current = i),
          itemBuilder: (_, i) => InteractiveViewer(
            minScale: 0.8, maxScale: 4.0,
            child: Center(child: Image.network(widget.urls[i],
              fit: BoxFit.contain,
              loadingBuilder: (_, c, p) => p == null ? c
                : const Center(child: ZyloLoader()),
              errorBuilder: (_, __, ___) => const Icon(Icons.broken_image_rounded,
                color: Colors.grey, size: 48))))),

        // Top bar
        Positioned(
          top: 0, left: 0, right: 0,
          child: SafeArea(child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.black87, Colors.transparent],
                begin: Alignment.topCenter, end: Alignment.bottomCenter)),
            child: Row(children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 36, height: 36,
                  decoration: BoxDecoration(color: Colors.white12, borderRadius: BorderRadius.circular(10)),
                  child: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 18))),
              const Spacer(),
              Text('${_current + 1} / ${widget.urls.length}',
                style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
              const Spacer(),
              const SizedBox(width: 36),
            ]),
          )),
        ),

        // Bottom dots
        if (widget.urls.length > 1)
          Positioned(
            bottom: 30, left: 0, right: 0,
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              for (int i = 0; i < widget.urls.length; i++)
                AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  width: i == _current ? 20 : 6, height: 6,
                  margin: const EdgeInsets.symmetric(horizontal: 2),
                  decoration: BoxDecoration(
                    color: i == _current ? const Color(0xFF0284C7) : Colors.white38,
                    borderRadius: BorderRadius.circular(3))),
            ])),

        // Swipe hint arrows
        if (_current > 0)
          Positioned(left: 10, top: 0, bottom: 0,
            child: Center(child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(color: Colors.black45, borderRadius: BorderRadius.circular(20)),
              child: const Icon(Icons.chevron_left_rounded, color: Colors.white, size: 28)))),
        if (_current < widget.urls.length - 1)
          Positioned(right: 10, top: 0, bottom: 0,
            child: Center(child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(color: Colors.black45, borderRadius: BorderRadius.circular(20)),
              child: const Icon(Icons.chevron_right_rounded, color: Colors.white, size: 28)))),
      ]),
    );
  }
}

// ── Typing Dots Widget ────────────────────────────────────────────────────────
class _TypingDotsWidget extends StatefulWidget {
  const _TypingDotsWidget();
  @override State<_TypingDotsWidget> createState() => _TypingDotsWidgetState();
}

class _TypingDotsWidgetState extends State<_TypingDotsWidget> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000))..repeat();
  }
  @override void dispose() { _ctrl.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) {
        return Row(mainAxisSize: MainAxisSize.min,
          children: List.generate(3, (i) {
            final t = (_ctrl.value - i * 0.18).clamp(0.0, 1.0);
            final wave = t < 0.5 ? (2 * t) : (2 * (1 - t));
            final dy = -5.0 * wave;
            return Transform.translate(
              offset: Offset(0, dy),
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 2),
                width: 6, height: 6,
                decoration: BoxDecoration(
                  color: const Color(0xFF0284C7).withValues(alpha: 0.45 + 0.55 * wave),
                  shape: BoxShape.circle),
              ),
            );
          }),
        );
      },
    );
  }
}

// ══════════════════════════════════════════════════════════════
//  Post Share Bubble — Instagram-style card shown in chat when a post is shared
// ══════════════════════════════════════════════════════════════
class _PostShareBubble extends StatelessWidget {
  final Map<String, dynamic> sharedPost;
  final bool isMe;
  const _PostShareBubble({required this.sharedPost, required this.isMe});

  @override
  Widget build(BuildContext context) {
    final postId     = sharedPost['postId']     as String? ?? '';
    final authorName = sharedPost['authorName'] as String? ?? 'Someone';
    final savedText  = sharedPost['text']       as String? ?? '';
    final savedImg   = sharedPost['imageUrl']   as String? ?? '';

    // If we have a postId, fetch live data from Firestore for richest display
    if (postId.isNotEmpty) {
      return FutureBuilder<DocumentSnapshot>(
        future: FirebaseFirestore.instance.collection('posts').doc(postId).get(),
        builder: (ctx, snap) {
          Map<String, dynamic> liveData = {};
          if (snap.hasData && snap.data!.exists) {
            liveData = snap.data!.data() as Map<String, dynamic>? ?? {};
          }
          final text     = (liveData['text'] as String? ?? savedText);
          // Prefer live images, fallback to saved images list, fallback to single savedImg
          final savedImages = (sharedPost['images'] as List?)?.cast<String>() ?? (savedImg.isNotEmpty ? [savedImg] : []);
          final images   = (liveData['images'] as List?)?.cast<String>() ?? savedImages;
          final imageUrl = images.isNotEmpty ? images[0] : savedImg;
          final likes    = (liveData['likes'] as List?)?.length ?? (sharedPost['likes'] as int? ?? 0);
          final authorPhoto = liveData['authorPhoto'] as String? ?? liveData['userPhoto'] as String? ?? sharedPost['authorPhoto'] as String? ?? '';
          final displayName = liveData['authorName'] as String? ?? liveData['username'] as String? ?? authorName;
          final postType = liveData['mediaType'] as String? ?? sharedPost['postType'] as String? ?? 'text';
          final hasHtml = (liveData['htmlContent'] ?? sharedPost['htmlContent']) != null;
          final hasPoll = (liveData['pollQuestion'] ?? sharedPost['pollQuestion']) != null;
          return _buildCard(context, postId, displayName, authorPhoto, text, imageUrl, likes,
              allImages: images, postType: postType, hasHtml: hasHtml, hasPoll: hasPoll);
        },
      );
    }
    // Fallback: use saved snapshot data
    final savedImages = (sharedPost['images'] as List?)?.cast<String>() ?? (savedImg.isNotEmpty ? [savedImg] : []);
    final hasHtml = sharedPost['htmlContent'] != null;
    final hasPoll = sharedPost['pollQuestion'] != null;
    return _buildCard(context, postId, authorName, sharedPost['authorPhoto'] as String? ?? '', savedText, savedImg, sharedPost['likes'] as int? ?? 0,
        allImages: savedImages, postType: sharedPost['postType'] as String? ?? 'text', hasHtml: hasHtml, hasPoll: hasPoll);
  }

  Widget _buildCard(BuildContext context, String postId, String authorName, String authorPhoto,
      String text, String imageUrl, int likes,
      {List<String> allImages = const [], String postType = 'text', bool hasHtml = false, bool hasPoll = false}) {
    final accentColor = isMe ? Colors.white : const Color(0xFF0284C7);
    final cardBg      = isMe ? Colors.white.withValues(alpha: 0.15) : Colors.white;
    final borderColor = isMe ? Colors.white.withValues(alpha: 0.25) : const Color(0xFF0284C7).withValues(alpha: 0.15);

    return GestureDetector(
      onTap: postId.isNotEmpty ? () => _openPost(context, postId) : null,
      child: Container(
        margin: const EdgeInsets.only(top: 4, bottom: 4),
        width: 260,
        decoration: BoxDecoration(
          color: cardBg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: borderColor),
          boxShadow: isMe ? [] : [BoxShadow(color: Colors.black.withValues(alpha: 0.06), blurRadius: 8, offset: const Offset(0, 2))],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // ── Author row (Instagram-style header) ──
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 6),
            child: Row(children: [
              // Author avatar
              Container(
                width: 28, height: 28,
                decoration: BoxDecoration(shape: BoxShape.circle,
                  border: Border.all(color: accentColor.withValues(alpha: 0.4), width: 1.5)),
                child: ClipOval(
                  child: authorPhoto.isNotEmpty
                    ? Image.network(authorPhoto, fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => _avatarFallback(authorName, accentColor))
                    : _avatarFallback(authorName, accentColor)),
              ),
              const SizedBox(width: 7),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('@$authorName',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800,
                    color: isMe ? Colors.white : const Color(0xFF0C1A2E)),
                  maxLines: 1, overflow: TextOverflow.ellipsis),
                Text('Shared a post',
                  style: TextStyle(fontSize: 10, color: isMe ? Colors.white60 : Colors.grey[400])),
              ])),
              Icon(Icons.open_in_new_rounded, size: 13,
                color: isMe ? Colors.white38 : Colors.grey[350]),
            ]),
          ),

          // ── Divider ──
          Divider(height: 1, color: isMe ? Colors.white12 : Colors.grey[100]),

          // ── Type badge (html/poll/video) ──
          if (hasHtml || hasPoll || postType == 'video')
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 0),
              child: Wrap(spacing: 6, children: [
                if (hasHtml) _typeBadge('🌐 Web', Colors.purple),
                if (hasPoll) _typeBadge('📊 Poll', Colors.orange),
                if (postType == 'video') _typeBadge('🎥 Video', Colors.red),
              ]),
            ),

          // ── Post images (carousel if multiple) ──
          if (allImages.isNotEmpty)
            allImages.length == 1
              ? ClipRRect(
                  borderRadius: BorderRadius.zero,
                  child: Image.network(
                    allImages[0], width: double.infinity, height: 180, fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const SizedBox.shrink()))
              : SizedBox(
                  height: 180,
                  child: Stack(children: [
                    PageView.builder(
                      itemCount: allImages.length,
                      itemBuilder: (_, j) => Image.network(
                        allImages[j], width: double.infinity, height: 180, fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => const SizedBox.shrink())),
                    // Multi-image indicator
                    Positioned(top: 8, right: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.55),
                          borderRadius: BorderRadius.circular(10)),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          const Icon(Icons.photo_library_outlined, size: 11, color: Colors.white),
                          const SizedBox(width: 3),
                          Text('${allImages.length}', style: const TextStyle(
                            color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
                        ]))),
                  ])),
          
          // Show imageUrl fallback if allImages empty
          if (allImages.isEmpty && imageUrl.isNotEmpty)
            ClipRRect(
              borderRadius: BorderRadius.zero,
              child: Image.network(
                imageUrl, width: double.infinity, height: 180, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const SizedBox.shrink())),

          // ── Post text ──
          if (text.isNotEmpty) Padding(
            padding: EdgeInsets.fromLTRB(10, (allImages.isNotEmpty || imageUrl.isNotEmpty) ? 8 : 10, 10, 4),
            child: Text(
              text.length > 100 ? '${text.substring(0, 100)}…' : text,
              style: TextStyle(fontSize: 13, height: 1.45,
                color: isMe ? Colors.white.withValues(alpha: 0.9) : const Color(0xFF1A1A2E)),
              maxLines: 3, overflow: TextOverflow.ellipsis)),

          // ── If nothing to show, show placeholder ──
          if (text.isEmpty && imageUrl.isEmpty && allImages.isEmpty) Padding(
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 4),
            child: Row(children: [
              Icon(Icons.photo_library_outlined, size: 16,
                color: isMe ? Colors.white54 : Colors.grey[400]),
              const SizedBox(width: 6),
              Text('View post', style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic,
                color: isMe ? Colors.white54 : Colors.grey[400])),
            ])),

          // ── Footer: likes + tap hint ──
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
            child: Row(children: [
              Icon(Icons.favorite_rounded, size: 13,
                color: isMe ? Colors.white54 : Colors.red.withValues(alpha: 0.7)),
              const SizedBox(width: 4),
              Text('$likes likes',
                style: TextStyle(fontSize: 11,
                  color: isMe ? Colors.white54 : Colors.grey[500])),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: isMe ? Colors.white.withValues(alpha: 0.12) : const Color(0xFF0284C7).withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(20)),
                child: Text('Tap to open',
                  style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700,
                    color: isMe ? Colors.white70 : const Color(0xFF0284C7)))),
            ])),
        ]),
      ),
    );
  }

  Widget _avatarFallback(String name, Color color) => Container(
    color: color.withValues(alpha: 0.12),
    child: Center(child: Text(
      name.isNotEmpty ? name[0].toUpperCase() : 'Z',
      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: color))));

  Widget _typeBadge(String label, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
    decoration: BoxDecoration(
      color: color.withValues(alpha: 0.12),
      borderRadius: BorderRadius.circular(8),
      border: Border.all(color: color.withValues(alpha: 0.3))),
    child: Text(label, style: TextStyle(fontSize: 10, color: color, fontWeight: FontWeight.w700)));

  void _openPost(BuildContext context, String postId) {
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => PostDeepLinkScreen(postId: postId),
    ));
  }

}

// ══════════════════════════════════════════════════════════════════════════════
// _SwipeToReply
// WhatsApp-style swipe: drag right (for received) or left (for sent) to reply.
// Shows an animated reply arrow icon that appears as user drags.
// No animation plays on the bubble itself — only the arrow icon slides in.
// ══════════════════════════════════════════════════════════════════════════════
class _SwipeToReply extends StatefulWidget {
  final Widget child;
  final bool isMe;
  final VoidCallback onReply;

  const _SwipeToReply({
    required this.child,
    required this.isMe,
    required this.onReply,
  });

  @override
  State<_SwipeToReply> createState() => _SwipeToReplyState();
}

class _SwipeToReplyState extends State<_SwipeToReply>
    with SingleTickerProviderStateMixin {
  double _dragX = 0.0;
  bool _triggered = false;

  static const double _threshold = 72.0;  // drag distance to trigger reply
  static const double _maxDrag   = 88.0;  // max visual drag

  late AnimationController _snapCtrl;
  late Animation<double> _snapAnim;
  double _snapFrom = 0.0;

  @override
  void initState() {
    super.initState();
    _snapCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 220));
    _snapAnim = CurvedAnimation(parent: _snapCtrl, curve: Curves.elasticOut);
    _snapCtrl.addListener(() {
      setState(() => _dragX = _snapFrom * (1 - _snapCtrl.value));
    });
  }

  @override
  void dispose() {
    _snapCtrl.dispose();
    super.dispose();
  }

  void _onDragUpdate(DragUpdateDetails d) {
    // Received messages (isMe=false): swipe RIGHT (+dx)
    // Sent messages (isMe=true): swipe LEFT (-dx) — same feel as WA
    final delta = widget.isMe ? -d.delta.dx : d.delta.dx;
    if (delta < 0) return; // wrong direction

    setState(() {
      _dragX = (_dragX + delta).clamp(0.0, _maxDrag);
    });

    if (_dragX >= _threshold && !_triggered) {
      _triggered = true;
      HapticFeedback.mediumImpact();
    }
  }

  void _onDragEnd(DragEndDetails d) {
    if (_triggered) {
      widget.onReply();
    }
    // Snap back
    _snapFrom = _dragX;
    _triggered = false;
    _snapCtrl.forward(from: 0);
  }

  @override
  Widget build(BuildContext context) {
    final progress = (_dragX / _threshold).clamp(0.0, 1.0);
    final iconOpacity = progress.clamp(0.0, 1.0);
    final iconScale = 0.5 + (progress * 0.6);
    final bubbleShift = widget.isMe ? -_dragX : _dragX;

    return GestureDetector(
      onHorizontalDragUpdate: _onDragUpdate,
      onHorizontalDragEnd: _onDragEnd,
      behavior: HitTestBehavior.translucent,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          // Reply arrow icon (appears on the side)
          Positioned.fill(
            child: Align(
              alignment:
                  widget.isMe ? Alignment.centerRight : Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.only(
                  right: widget.isMe ? 4 : 0,
                  left: widget.isMe ? 0 : 4,
                ),
                child: Opacity(
                  opacity: iconOpacity,
                  child: Transform.scale(
                    scale: iconScale,
                    child: Container(
                      width: 32, height: 32,
                      decoration: BoxDecoration(
                        color: const Color(0xFF0284C7).withValues(alpha: 0.15),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.reply_rounded,
                        color: Color(0xFF0284C7),
                        size: 18,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          // Bubble — slides with drag
          Transform.translate(
            offset: Offset(bubbleShift, 0),
            child: widget.child,
          ),
        ],
      ),
    );
  }
}

// ── Empty Chat State — Hello animation + E2E encrypted ──────────────────────
class _EmptyChatState extends StatefulWidget {
  final VoidCallback? onSayHello;
  const _EmptyChatState({this.onSayHello});
  @override
  State<_EmptyChatState> createState() => _EmptyChatStateState();
}


class _EmptyChatStateState extends State<_EmptyChatState>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _wave;
  late final Animation<double> _fadeIn;
  late final Animation<double> _slideUp;
  bool _helloBouncing = false;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);
    _wave    = Tween(begin: -0.3, end: 0.3).chain(CurveTween(curve: Curves.easeInOut)).animate(_ctrl);
    _fadeIn  = Tween(begin: 0.0,  end: 1.0).chain(CurveTween(curve: const Interval(0, 0.5, curve: Curves.easeOut))).animate(_ctrl);
    _slideUp = Tween(begin: 20.0, end: 0.0).chain(CurveTween(curve: const Interval(0, 0.5, curve: Curves.easeOut))).animate(_ctrl);
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  void _handleHello() async {
    setState(() => _helloBouncing = true);
    await Future.delayed(const Duration(milliseconds: 150));
    if (mounted) setState(() => _helloBouncing = false);
    widget.onSayHello?.call();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (_, __) => Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Transform.rotate(
              angle: _wave.value * 0.5,
              alignment: Alignment.bottomCenter,
              child: const Text('👋', style: TextStyle(fontSize: 56))),
            const SizedBox(height: 18),
            Transform.translate(
              offset: Offset(0, _slideUp.value),
              child: Opacity(
                opacity: _fadeIn.value.clamp(0.4, 1.0),
                child: const Text('Hello! 🤗',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Color(0xFF0C1A2E))))),
            const SizedBox(height: 8),
            Opacity(
              opacity: _fadeIn.value.clamp(0.3, 1.0),
              child: const Text('Say something to start the conversation',
                style: TextStyle(fontSize: 13, color: Colors.grey, fontWeight: FontWeight.w500))),
            const SizedBox(height: 28),
            // ── Say Hello button ──────────────────────────────────────────
            if (widget.onSayHello != null)
              GestureDetector(
                onTap: _handleHello,
                child: AnimatedScale(
                  scale: _helloBouncing ? 0.88 : 1.0,
                  duration: const Duration(milliseconds: 150),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 13),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF0284C7), Color(0xFF7C3AED)],
                        begin: Alignment.centerLeft, end: Alignment.centerRight),
                      borderRadius: BorderRadius.circular(30),
                      boxShadow: [BoxShadow(
                        color: const Color(0xFF0284C7).withValues(alpha: 0.4),
                        blurRadius: 18, offset: const Offset(0, 6))]),
                    child: const Row(mainAxisSize: MainAxisSize.min, children: [
                      Text('👋', style: TextStyle(fontSize: 18)),
                      SizedBox(width: 8),
                      Text('Say Hello',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800,
                          fontSize: 15, letterSpacing: 0.3)),
                    ])))),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0xFF059669).withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFF059669).withValues(alpha: 0.2))),
              child: const Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.lock_rounded, size: 13, color: Color(0xFF059669)),
                SizedBox(width: 6),
                Text('End-to-end encrypted',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700,
                    color: Color(0xFF059669), letterSpacing: 0.2)),
              ])),
          ])));
  }
}

// ── Chat Lock Setup Sheet (inline in chat room) ───────────────────────────────
class _ChatLockSetupSheet extends StatefulWidget {
  final String chatId, chatName;
  final bool canBio;
  final VoidCallback onLocked;
  const _ChatLockSetupSheet({required this.chatId, required this.chatName, required this.canBio, required this.onLocked});
  @override State<_ChatLockSetupSheet> createState() => _ChatLockSetupSheetState();
}

class _ChatLockSetupSheetState extends State<_ChatLockSetupSheet> {
  String _pin = '';
  bool _pinMode = false;
  bool _loading = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom + 16),
      decoration: const BoxDecoration(color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(margin: const EdgeInsets.only(top: 10, bottom: 8), width: 40, height: 4,
          decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
        const SizedBox(height: 8),
        Container(padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: const Color(0xFF0284C7).withValues(alpha: 0.08), shape: BoxShape.circle),
          child: const Icon(Icons.lock_rounded, color: Color(0xFF0284C7), size: 36)),
        const SizedBox(height: 12),
        Text('Lock "${widget.chatName}"', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
        const SizedBox(height: 6),
        Text('Choose how to protect this chat', style: TextStyle(color: Colors.grey[500], fontSize: 13)),
        const SizedBox(height: 20),
        if (widget.canBio && !_pinMode) ...[
          Padding(padding: const EdgeInsets.symmetric(horizontal: 20),
            child: GestureDetector(
              onTap: () async {
                setState(() => _loading = true);
                final ok = await ChatLockService.authenticateBiometric();
                if (ok) {
                  await ChatLockService.setLock(widget.chatId, true);
                  Navigator.pop(context);
                  widget.onLocked();
                }
                if (mounted) setState(() => _loading = false);
              },
              child: Container(
                width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF0284C7), Color(0xFF7C3AED)],
                    begin: Alignment.centerLeft, end: Alignment.centerRight),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [BoxShadow(color: const Color(0xFF0284C7).withValues(alpha: 0.3), blurRadius: 12, offset: const Offset(0, 4))]),
                child: _loading
                  ? const Center(child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.fingerprint, color: Colors.white, size: 22),
                      SizedBox(width: 10),
                      Text('Use Biometrics', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16))])))),
          const SizedBox(height: 12),
          TextButton(
            onPressed: () => setState(() => _pinMode = true),
            child: const Text('Use PIN instead', style: TextStyle(color: Color(0xFF0284C7), fontWeight: FontWeight.w700))),
        ] else ...[
          Padding(padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(children: [
              const Text('Set a 4-digit PIN', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
              const SizedBox(height: 12),
              TextField(
                keyboardType: TextInputType.number, maxLength: 4, obscureText: true,
                textAlign: TextAlign.center, autofocus: true,
                style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: 12),
                onChanged: (v) => setState(() => _pin = v),
                decoration: InputDecoration(
                  hintText: '••••', counterText: '',
                  filled: true, fillColor: const Color(0xFFF1F5F9),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none))),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    backgroundColor: _pin.length == 4 ? const Color(0xFF0284C7) : Colors.grey[300],
                    foregroundColor: Colors.white, elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                  onPressed: _pin.length == 4 ? () async {
                    await ChatLockService.setPin(widget.chatId, _pin);
                    await ChatLockService.setLock(widget.chatId, true);
                    Navigator.pop(context);
                    widget.onLocked();
                  } : null,
                  child: const Text('Set PIN & Lock', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)))),
            ])),
        ],
        const SizedBox(height: 8),
      ]),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Translatable bubble text widget
// Handles: auto-translate incoming messages, Show Original toggle
// ─────────────────────────────────────────────────────────────────────────────
class _TranslatableBubbleText extends StatefulWidget {
  final String msgId;
  final String text;
  final bool isMe;
  final Map<String, String?> translatedTexts;
  final Set<String> showOriginal;
  final void Function(String id) onToggleOriginal;
  final void Function(String id, String translated) onTranslated;

  const _TranslatableBubbleText({
    required this.msgId,
    required this.text,
    required this.isMe,
    required this.translatedTexts,
    required this.showOriginal,
    required this.onToggleOriginal,
    required this.onTranslated,
  });

  @override
  State<_TranslatableBubbleText> createState() => _TranslatableBubbleTextState();
}

class _TranslatableBubbleTextState extends State<_TranslatableBubbleText> {
  bool _translating = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _maybeTranslate();
  }

  @override
  void didUpdateWidget(_TranslatableBubbleText old) {
    super.didUpdateWidget(old);
    if (old.msgId != widget.msgId || old.text != widget.text) {
      _maybeTranslate();
    }
  }

  Future<void> _maybeTranslate() async {
    // ── INCOMING: translate received messages ──────────────────────────────
    if (!widget.isMe) {
      if (widget.translatedTexts.containsKey(widget.msgId)) return; // Already done or attempted
      if (_translating) return;
      final svc = context.read<TranslationService>();
      if (!svc.isEnabled) return;
      // Skip translation for Hinglish — user already understands Roman-script Hindi/Urdu
      if (svc.isHinglish(widget.text)) {
        widget.onTranslated(widget.msgId, ''); // mark as attempted
        return;
      }
      _translating = true;
      // Pre-mark as attempted to prevent duplicate calls during async gap
      widget.onTranslated(widget.msgId, '');
      if (mounted) setState(() {});
      final result = await svc.translate(widget.text);
      if (!mounted) return;
      _translating = false;
      if (result != null &&
          result.isNotEmpty &&
          result != TranslationResult.modelNotDownloaded &&
          result != widget.text) {
        widget.onTranslated(widget.msgId, result);
      }
      return;
    }
    // OUTGOING: no async translation here
  }

  @override
  Widget build(BuildContext context) {
    final svc = context.watch<TranslationService>();

    // ── Re-trigger for INCOMING if service just enabled ────────────────────
    if (!widget.isMe && svc.isEnabled && !widget.translatedTexts.containsKey(widget.msgId) && !_translating) {
      WidgetsBinding.instance.addPostFrameCallback((_) { if (mounted) _maybeTranslate(); });
    }

    final showingOriginal = widget.showOriginal.contains(widget.msgId);
    final textColor = const Color(0xFF1A1A1A);
    final subColor  = Colors.grey[500];

    // ── OUTGOING bubble logic ──────────────────────────────────────────────
    if (widget.isMe) {
      final translatedText = widget.translatedTexts[widget.msgId];
      final originalText   = widget.translatedTexts['${widget.msgId}_orig'];
      final hasOutTranslation = translatedText != null && translatedText.isNotEmpty &&
          originalText != null && originalText.isNotEmpty;

      String displayText;
      if (hasOutTranslation && !showingOriginal) {
        displayText = translatedText!; // show translated (what was sent)
      } else if (hasOutTranslation && showingOriginal) {
        displayText = originalText!;   // show what user originally typed
      } else {
        displayText = widget.text;     // no translation, show as-is
      }

      return Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            displayText,
            style: TextStyle(color: textColor, fontSize: 14.5, height: 1.35),
          ),
          if (hasOutTranslation)
            GestureDetector(
              onTap: () => widget.onToggleOriginal(widget.msgId),
              child: Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.translate_rounded, size: 10, color: subColor),
                  const SizedBox(width: 3),
                  Text(
                    showingOriginal ? 'Show Translated' : 'Show Original',
                    style: TextStyle(
                      fontSize: 10.5,
                      color: subColor,
                      fontWeight: FontWeight.w600,
                      decoration: TextDecoration.underline,
                      decorationColor: subColor,
                    ),
                  ),
                ]),
              ),
            ),
        ],
      );
    }

    // ── INCOMING bubble logic ──────────────────────────────────────────────
    final translated = widget.translatedTexts[widget.msgId];
    final hasTranslation = translated != null && translated.isNotEmpty;
    final displayText = (hasTranslation && !showingOriginal) ? translated : widget.text;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          displayText,
          style: TextStyle(color: textColor, fontSize: 14.5, height: 1.35),
        ),
        if (svc.isEnabled) ...[
          if (_translating && !hasTranslation)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                SizedBox(
                  width: 10, height: 10,
                  child: CircularProgressIndicator(strokeWidth: 1.5, color: subColor),
                ),
                const SizedBox(width: 4),
                Text('Translating...', style: TextStyle(fontSize: 10, color: subColor)),
              ]),
            )
          else if (hasTranslation)
            GestureDetector(
              onTap: () => widget.onToggleOriginal(widget.msgId),
              child: Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.translate_rounded, size: 10, color: subColor),
                  const SizedBox(width: 3),
                  Text(
                    showingOriginal ? 'Show Translation' : 'Show Original',
                    style: TextStyle(
                      fontSize: 10.5,
                      color: subColor,
                      fontWeight: FontWeight.w600,
                      decoration: TextDecoration.underline,
                      decorationColor: subColor,
                    ),
                  ),
                ]),
              ),
            ),
        ],
      ],
    );
  }
}
