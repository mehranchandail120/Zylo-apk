import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:io';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../widgets/media_picker_sheet.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';
import '../../services/file_service.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});
  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final _nameCtrl = TextEditingController();
  final _bioCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _userCtrl = TextEditingController();
  bool _isCheckingUser = false;
  bool _userAvailable = true;
  bool _isLoading = false;
  bool _isUploadingPhoto = false;
  bool _isGeneratingBio = false;
  File? _newPhotoFile;
  String? _currentPhotoUrl;
  int _bioCharCount = 0;
  static const _blue = Color(0xFF0284C7);
  static const _maxBio = 60;

  @override
  void initState() {
    super.initState();
    final auth = Provider.of<AuthService>(context, listen: false);
    _nameCtrl.text = auth.displayName ?? auth.userName ?? '';
    _bioCtrl.text = auth.bio ?? '';
    _bioCharCount = _bioCtrl.text.length;
    _phoneCtrl.text = auth.phone ?? '';
    _userCtrl.text = auth.userName ?? '';
    _currentPhotoUrl = auth.photoURL;
    _bioCtrl.addListener(() {
      setState(() => _bioCharCount = _bioCtrl.text.length);
    });
  }

  void _checkUsername(String val) async {
    if (val.trim().length < 3) return;
    setState(() => _isCheckingUser = true);
    final taken = await FirestoreService().isUsernameTaken(val.trim());
    final auth = Provider.of<AuthService>(context, listen: false);
    final isSame = val.trim().toLowerCase() == (auth.userName ?? '').toLowerCase();
    setState(() { _userAvailable = isSame || !taken; _isCheckingUser = false; });
  }

  Future<void> _pickPhoto() async {
    showModalBottomSheet(
      context: context, backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(margin: const EdgeInsets.only(top: 10, bottom: 8), width: 40, height: 4,
            decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
        const Padding(padding: EdgeInsets.fromLTRB(20, 4, 20, 12),
          child: Align(alignment: Alignment.centerLeft,
            child: Text('Change Profile Photo', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)))),
        ListTile(
          leading: Container(width: 40, height: 40,
              decoration: BoxDecoration(color: _blue.withValues(alpha: 0.1), shape: BoxShape.circle),
              child: const Icon(Icons.photo_library_rounded, color: _blue, size: 22)),
          title: const Text('Choose from Gallery', style: TextStyle(fontWeight: FontWeight.w600)),
          onTap: () async {
            Navigator.pop(ctx);
            await _pickFromMediaSheet();
          }),
        ListTile(
          leading: Container(width: 40, height: 40,
              decoration: BoxDecoration(color: Colors.orange.withValues(alpha: 0.1), shape: BoxShape.circle),
              child: const Icon(Icons.camera_alt_rounded, color: Colors.orange, size: 22)),
          title: const Text('Take a Photo', style: TextStyle(fontWeight: FontWeight.w600)),
          onTap: () async { Navigator.pop(ctx); await _pickFromSource(ImageSource.camera); }),
        if (_currentPhotoUrl != null && _currentPhotoUrl!.isNotEmpty)
          ListTile(
            leading: Container(width: 40, height: 40,
                decoration: BoxDecoration(color: Colors.red.withValues(alpha: 0.1), shape: BoxShape.circle),
                child: const Icon(Icons.delete_outline, color: Colors.red, size: 22)),
            title: const Text('Remove Photo', style: TextStyle(fontWeight: FontWeight.w600, color: Colors.red)),
            onTap: () { Navigator.pop(ctx); setState(() { _newPhotoFile = null; _currentPhotoUrl = ''; }); }),
        const SizedBox(height: 8),
      ])),
    );
  }

  Future<void> _pickFromMediaSheet() async {
    if (!mounted) return;
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => MediaPickerSheet(
        onMediaSelected: (files, isVideo) {
          if (files.isNotEmpty && !isVideo && mounted) {
            setState(() => _newPhotoFile = files.first);
          }
        },
      ),
    );
  }

  Future<void> _pickFromSource(ImageSource source) async {
    if (source == ImageSource.camera) {
      final status = await Permission.camera.request();
      if (!status.isGranted) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Camera permission required')));
        return;
      }
    }
    final picker = ImagePicker();
    final f = await picker.pickImage(source: source, imageQuality: 85, maxWidth: 800);
    if (f != null && mounted) setState(() => _newPhotoFile = File(f.path));
  }

  Future<void> _generateAiBio() async {
    // Ask user for keywords
    final keyCtrl = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(children: [
          Container(width: 32, height: 32,
            decoration: const BoxDecoration(color: Color(0xFF0284C7), shape: BoxShape.circle),
            child: const Icon(Icons.auto_awesome, color: Colors.white, size: 16)),
          const SizedBox(width: 10),
          const Text('Zylo AI Bio', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        ]),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Add a few keywords about yourself', style: TextStyle(fontSize: 13, color: Colors.grey)),
          const SizedBox(height: 12),
          TextField(
            controller: keyCtrl, autofocus: true,
            decoration: InputDecoration(
              hintText: 'e.g. coder, music lover, gamer...',
              filled: true, fillColor: const Color(0xFFF8FAFF),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0284C7), foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () => Navigator.pop(ctx, keyCtrl.text.trim()),
            child: const Text('Generate')),
        ],
      ),
    );
    if (result == null || result.isEmpty) return;
    setState(() => _isGeneratingBio = true);
    try {
      final resp = await http.post(
        Uri.parse('https://intubotixevlfxxgyiup.supabase.co/functions/v1/ai-chat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'message': 'Write a short, catchy social media bio in 1-2 sentences (max 60 characters) for someone who is: $result. Write in a cool, casual tone. No hashtags. No quotes. Just the bio text.',
          'session_id': 'bio_gen_${DateTime.now().millisecondsSinceEpoch}',
        }),
      );
      if (resp.statusCode == 200) {
        final data = jsonDecode(resp.body);
        final bio = (data['reply'] ?? data['message'] ?? '').toString().trim();
        final truncated = bio.length > _maxBio ? bio.substring(0, _maxBio) : bio;
        _bioCtrl.text = truncated;
        _bioCtrl.selection = TextSelection.collapsed(offset: truncated.length);
      } else {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not generate AI bio, please try again'), backgroundColor: Colors.red));
      }
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Connection error'), backgroundColor: Colors.red));
    }
    if (mounted) setState(() => _isGeneratingBio = false);
  }

  Future<void> _save() async {
    setState(() => _isLoading = true);
    String? photoUrl = _currentPhotoUrl;
    if (_newPhotoFile != null) {
      setState(() => _isUploadingPhoto = true);
      final auth = Provider.of<AuthService>(context, listen: false);
      final userId = auth.user?.uid ?? 'unknown';
      final url = await FileService.uploadFile(_newPhotoFile!, userId);
      setState(() => _isUploadingPhoto = false);
      if (url.isNotEmpty) { photoUrl = url; }
      else {
        setState(() => _isLoading = false);
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Photo upload failed. Try again.'), backgroundColor: Colors.red));
        return;
      }
    }
    final error = await FirestoreService().updateProfileData(
      name: _nameCtrl.text.trim(), bio: _bioCtrl.text.trim(),
      phone: _phoneCtrl.text.trim(), username: _userCtrl.text.trim(), photoURL: photoUrl);
    setState(() => _isLoading = false);
    if (error == null) {
      if (mounted) { Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profile Updated! ✅'), backgroundColor: Colors.green)); }
    } else {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error), backgroundColor: Colors.red));
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthService>(context, listen: false);
    final displayPhoto = _newPhotoFile != null ? null
        : (_currentPhotoUrl?.isNotEmpty == true ? _currentPhotoUrl : null);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white, elevation: 0,
        title: const Text('Edit Profile', style: TextStyle(color: Colors.black87, fontWeight: FontWeight.w800, fontSize: 18)),
        actions: [
          if (_isLoading || _isUploadingPhoto)
            const Center(child: Padding(padding: EdgeInsets.all(16),
                child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: _blue))))
          else
            TextButton(onPressed: _save,
                child: const Text('SAVE', style: TextStyle(fontWeight: FontWeight.w800, color: _blue, fontSize: 14))),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Profile Photo
          Center(child: SizedBox(
            width: 120, height: 120,
            child: GestureDetector(
              onTap: _pickPhoto,
              child: Stack(clipBehavior: Clip.none, children: [
                CircleAvatar(
                  radius: 54, backgroundColor: _blue.withValues(alpha: 0.1),
                  backgroundImage: _newPhotoFile != null ? FileImage(_newPhotoFile!) as ImageProvider
                      : (displayPhoto != null ? NetworkImage(displayPhoto) : null),
                  child: (_newPhotoFile == null && displayPhoto == null)
                      ? Text((auth.userName ?? 'U')[0].toUpperCase(),
                          style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w900, color: _blue))
                      : null,
                ),
                Positioned(bottom: 2, right: 2,
                  child: Container(
                    width: 32, height: 32,
                    decoration: BoxDecoration(color: _blue, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2.5),
                      boxShadow: [BoxShadow(color: _blue.withValues(alpha: 0.4), blurRadius: 8)]),
                    child: const Icon(Icons.camera_alt_rounded, color: Colors.white, size: 16))),
                if (_isUploadingPhoto)
                  Positioned.fill(child: Container(
                    decoration: const BoxDecoration(color: Colors.black38, shape: BoxShape.circle),
                    child: const Center(child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)))),
              ]),
            ),
          )),
          const SizedBox(height: 8),
          Center(child: TextButton.icon(
            onPressed: _pickPhoto,
            icon: const Icon(Icons.edit, size: 14, color: _blue),
            label: const Text('Change Photo', style: TextStyle(color: _blue, fontWeight: FontWeight.w700, fontSize: 13)))),
          const SizedBox(height: 20),
          _label('Username'),
          TextField(
            controller: _userCtrl, onChanged: _checkUsername,
            decoration: InputDecoration(
              hintText: 'Unique handle', filled: true, fillColor: const Color(0xFFF8FAFF),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              suffixIcon: _isCheckingUser
                  ? const Padding(padding: EdgeInsets.all(12), child: SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)))
                  : Icon(_userAvailable ? Icons.check_circle : Icons.error, color: _userAvailable ? Colors.green : Colors.red))),
          const SizedBox(height: 16),
          _label('Full Name'),
          TextField(controller: _nameCtrl, decoration: InputDecoration(
            hintText: 'Your name', filled: true, fillColor: const Color(0xFFF8FAFF),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none))),
          const SizedBox(height: 16),
          _label('Bio'),
          Stack(children: [
            TextField(
              controller: _bioCtrl, maxLines: 3, maxLength: _maxBio,
              buildCounter: (_, {required currentLength, required isFocused, maxLength}) => const SizedBox.shrink(),
              decoration: InputDecoration(
                hintText: 'Tell us about yourself', filled: true, fillColor: const Color(0xFFF8FAFF),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                contentPadding: const EdgeInsets.fromLTRB(14, 12, 80, 12))),
            Positioned(right: 8, bottom: 8, child: Row(mainAxisSize: MainAxisSize.min, children: [
              Text('$_bioCharCount/$_maxBio',
                style: TextStyle(fontSize: 11, color: _bioCharCount >= _maxBio ? Colors.red : Colors.grey[400],
                  fontWeight: FontWeight.w600)),
              const SizedBox(width: 6),
              GestureDetector(
                onTap: _isGeneratingBio ? null : _generateAiBio,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0284C7).withValues(alpha: _isGeneratingBio ? 0.5 : 1),
                    borderRadius: BorderRadius.circular(20)),
                  child: _isGeneratingBio
                    ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.auto_awesome, color: Colors.white, size: 12),
                        SizedBox(width: 3),
                        Text('AI', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800)),
                      ]),
                )),
            ])),
          ]),
          const SizedBox(height: 16),
          _label('Phone Number'),
          TextField(controller: _phoneCtrl, keyboardType: TextInputType.phone, decoration: InputDecoration(
            hintText: '+91 98765...', filled: true, fillColor: const Color(0xFFF8FAFF),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none))),
          const SizedBox(height: 32),
          const Text('Note: Username changes are limited to 5 times per month.',
              style: TextStyle(color: Colors.grey, fontSize: 12)),
          const SizedBox(height: 40),
        ]),
      ),
    );
  }

  Widget _label(String text) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Text(text, style: const TextStyle(fontWeight: FontWeight.w700, color: Colors.black54, fontSize: 13)));
}
