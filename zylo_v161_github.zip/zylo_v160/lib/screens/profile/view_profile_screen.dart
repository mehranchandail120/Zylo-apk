import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../widgets/zylo_cached_image.dart';
import '../../services/firestore_service.dart';
import '../../services/notification_service.dart';
import '../../services/auth_service.dart';
import '../../services/chat_lock_service.dart';
import '../../utils/share_utils.dart';
import '../chat/chat_room_screen.dart';
import '../feed/post_comments_screen.dart';
import '../../widgets/zylo_avatar.dart';
import '../../widgets/zylo_achievements.dart';

class ViewProfileScreen extends StatefulWidget {
  final String targetUid;
  const ViewProfileScreen({super.key, required this.targetUid});
  @override
  State<ViewProfileScreen> createState() => _ViewProfileScreenState();
}

final _profileViewNotifSent = <String>{};

class _ViewProfileScreenState extends State<ViewProfileScreen>
    with SingleTickerProviderStateMixin {
  static const _blue   = Color(0xFF0284C7);
  static const _purple = Color(0xFF7C3AED);

  final String myUid = FirebaseAuth.instance.currentUser?.uid ?? '';
  final _ns = NotificationService();

  bool _isFollowing    = false;
  bool _isBlockedCache = false;
  bool _isMuted        = false;
  bool _isLocked       = false;
  bool _toggling       = false;
  List<Map<String, dynamic>> _mutualFriends = [];

  StreamSubscription? _blockSub, _muteSub, _circleSub;
  late TabController _tabCtrl;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
    _blockSub = FirestoreService().isUserBlocked(widget.targetUid).listen((b) {
      if (mounted) setState(() => _isBlockedCache = b);
    });
    _muteSub = _ns.mutedStream(widget.targetUid).listen((m) {
      if (mounted) setState(() => _isMuted = m);
    });
    if (widget.targetUid != myUid) {
      _circleSub = FirestoreService().isFollowingStream(widget.targetUid).listen((v) {
        if (mounted && !_toggling) setState(() => _isFollowing = v);
      });
      FirestoreService().recordProfileView(widget.targetUid).catchError((_) {});
      _sendProfileViewNotif();
      _loadMutualFriends();
    }
    ChatLockService.isLocked(widget.targetUid).then((v) {
      if (mounted) setState(() => _isLocked = v);
    });
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    _blockSub?.cancel();
    _muteSub?.cancel();
    _circleSub?.cancel();
    super.dispose();
  }

  Future<void> _sendProfileViewNotif() async {
    if (myUid.isEmpty) return;
    final key = '${myUid}_${widget.targetUid}';
    if (_profileViewNotifSent.contains(key)) return;
    _profileViewNotifSent.add(key);
    final recent = await FirebaseFirestore.instance
        .collection('users').doc(widget.targetUid).collection('notifications')
        .where('type', isEqualTo: 'profile_view').where('fromUid', isEqualTo: myUid)
        .orderBy('createdAt', descending: true).limit(1).get();
    if (recent.docs.isNotEmpty) {
      final ts = recent.docs.first.data()['createdAt'] as Timestamp?;
      if (ts != null && DateTime.now().difference(ts.toDate()).inHours < 24) return;
    }
    final myDoc  = await FirebaseFirestore.instance.collection('users').doc(myUid).get();
    final myName = myDoc.data()?['username'] as String? ?? 'Someone';
    final myPic  = myDoc.data()?['photoURL']  as String? ?? '';
    FirebaseFirestore.instance.collection('users').doc(widget.targetUid)
        .collection('notifications').add({
      'type': 'profile_view', 'text': '@$myName viewed your profile',
      'fromUid': myUid, 'fromName': myName, 'fromPhoto': myPic,
      'read': false, 'createdAt': FieldValue.serverTimestamp(),
    });

    // ── Profile view milestone check ─────────────────────────────────────
    // Har view par count increment + milestone par owner ko notify karo
    NotificationService().checkAndSendProfileViewMilestone(
      profileOwnerUid: widget.targetUid,
    ).catchError((_) {});
  }

  Future<void> _loadMutualFriends() async {
    if (myUid.isEmpty) return;
    try {
      final myFollowingSnap = await FirebaseFirestore.instance
          .collection('users').doc(myUid).collection('following').get();
      final myFollowingIds = myFollowingSnap.docs.map((d) => d.id).toSet();
      final theirFollowingSnap = await FirebaseFirestore.instance
          .collection('users').doc(widget.targetUid).collection('following').get();
      final theirFollowingIds = theirFollowingSnap.docs.map((d) => d.id).toSet();
      final mutualIds = myFollowingIds
          .intersection(theirFollowingIds)
          .where((id) => id != myUid && id != widget.targetUid)
          .take(5).toList();
      if (mutualIds.isEmpty) return;
      final List<Map<String, dynamic>> mutual = [];
      for (final uid in mutualIds) {
        final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
        if (doc.exists) {
          final d = doc.data() as Map<String, dynamic>;
          mutual.add({'uid': uid, 'username': d['username'] ?? '', 'photoURL': d['photoURL'] ?? ''});
        }
      }
      if (mounted) setState(() => _mutualFriends = mutual);
    } catch (_) {}
  }

  Future<void> _toggleFollow(String name) async {
    if (_toggling || myUid.isEmpty) return;
    final wasFollowing = _isFollowing;
    setState(() { _toggling = true; _isFollowing = !wasFollowing; });
    final fs = FirestoreService();
    try {
      if (wasFollowing) {
        await fs.unfollowUser(widget.targetUid);
        _snack('Unfollowed @$name');
      } else {
        await fs.followUser(widget.targetUid);
        _snack('Following @$name', color: _purple);
        Future.microtask(() async {
          try {
            final me = FirebaseAuth.instance.currentUser;
            if (me == null) return;
            // Prefer Firestore username over Firebase displayName
            final doc = await FirebaseFirestore.instance
                .collection('users').doc(me.uid).get();
            final meName = doc.data()?['username'] as String?
                ?? me.displayName
                ?? me.email?.split('@').first
                ?? 'Someone';
            NotificationService().sendFollowNotification(
                toUid: widget.targetUid, fromName: meName);
          } catch (_) {}
        });
      }
    } catch (_) {
      if (mounted) setState(() => _isFollowing = wasFollowing);
      _snack('Something went wrong', color: Colors.red);
    } finally {
      if (mounted) setState(() => _toggling = false);
    }
  }

  Future<void> _handleBlock(Map<String, dynamic> u) async {
    final name = u['username'] as String? ?? 'User';
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Text('Block $name?'),
      content: Text('$name won\'t be able to message you.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        TextButton(onPressed: () => Navigator.pop(context, true),
          child: const Text('Block', style: TextStyle(color: Colors.red, fontWeight: FontWeight.w700))),
      ]));
    if (ok == true) {
      await FirestoreService().blockUser(widget.targetUid);
      _snack('$name blocked', color: Colors.red);
    }
  }

  Future<void> _handleUnblock(Map<String, dynamic> u) async {
    final name = u['username'] as String? ?? 'User';
    await FirestoreService().unblockUser(widget.targetUid);
    _snack('$name unblocked', color: Colors.green);
  }

  Future<void> _reportUser(Map<String, dynamic> u) async {
    final reason = await showDialog<String>(context: context,
      builder: (_) => _ReportDialog(name: u['username'] as String? ?? 'User'));
    if (reason == null) return;
    await FirebaseFirestore.instance.collection('profileReports').add({
      'reportedUid': widget.targetUid, 'reportedBy': myUid,
      'reason': reason, 'resolved': false, 'timestamp': FieldValue.serverTimestamp(),
    });
    _snack('User reported', color: Colors.green);
  }

  void _snack(String msg, {Color? color}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.white)),
      backgroundColor: color ?? _blue,
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.all(16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))));
  }

  void _openFullPhoto(String url, String name) => Navigator.push(context,
    MaterialPageRoute(builder: (_) => Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black,
        leading: IconButton(icon: const Icon(Icons.close, color: Colors.white),
          onPressed: () => Navigator.pop(context)),
        title: Text(name, style: const TextStyle(color: Colors.white))),
      body: Center(child: InteractiveViewer(
        child: ZyloCachedImage(url: url, fit: BoxFit.contain))))));

  // ── BUILD ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    // Force light theme for this screen
    const bgColor       = Color(0xFFFFFFFF);
    const surfaceColor  = Color(0xFFF4F4F6);
    const textPrimary   = Color(0xFF0D0D0D);
    const textSecondary = Color(0xFF8A8A8E);
    const dividerColor  = Color(0xFFEAEAEF);

    if (widget.targetUid.isEmpty) {
      return const Scaffold(
        backgroundColor: bgColor,
        body: Center(child: Text('Profile not found',
          style: TextStyle(color: textSecondary))));
    }

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark.copyWith(
        statusBarColor: Colors.transparent,
        systemNavigationBarColor: bgColor),
      child: Scaffold(
        backgroundColor: bgColor,
        body: StreamBuilder<DocumentSnapshot>(
          stream: FirebaseFirestore.instance
              .collection('users').doc(widget.targetUid).snapshots(),
          builder: (ctx, snap) {
            if (snap.connectionState == ConnectionState.waiting && !snap.hasData) {
              return const Scaffold(
                backgroundColor: bgColor,
                body: Center(child: CircularProgressIndicator(
                  color: _blue, strokeWidth: 2)));
            }
            if (!snap.hasData || snap.data?.exists != true) {
              return const Scaffold(
                backgroundColor: bgColor,
                body: Center(child: Text('Profile not found',
                  style: TextStyle(color: textSecondary))));
            }

            final data         = snap.data!.data() as Map<String, dynamic>;
            final name         = data['username']     as String? ?? 'User';
            final bio          = data['bio']          as String? ?? '';
            final photoURL     = data['photoURL']     as String? ?? '';
            final isPrivate    = data['isPublic']     == false;
            final isOnline     = data['isOnline']     as bool?   ?? false;
            final lastSeenTs   = data['lastSeen']     as Timestamp?;
            final showLastSeen = data['showLastSeen'] as bool?   ?? true;
            final isOwn        = widget.targetUid == myUid;

            final followersCount = data['followersCount'] as int? ?? 0;
            final followingCount = data['followingCount'] as int? ?? 0;
            final postsCount     = data['postsCount']     as int? ?? 0;

            // Build last seen text
            String lastSeenText = '';
            if (!isOnline && showLastSeen && lastSeenTs != null) {
              final diff = DateTime.now().difference(lastSeenTs.toDate());
              if (diff.inSeconds < 60)      lastSeenText = 'last seen just now';
              else if (diff.inMinutes < 60) lastSeenText = 'last seen ${diff.inMinutes}m ago';
              else if (diff.inHours < 24)   lastSeenText = 'last seen ${diff.inHours}h ago';
              else if (diff.inDays == 1)    lastSeenText = 'last seen yesterday';
              else                          lastSeenText = 'last seen ${diff.inDays}d ago';
            }

            return NestedScrollView(
              headerSliverBuilder: (ctx, _) => [
                // ── App Bar ──────────────────────────────────────────────
                SliverAppBar(
                  backgroundColor: bgColor,
                  elevation: 0,
                  surfaceTintColor: Colors.transparent,
                  pinned: true,
                  expandedHeight: 0,
                  systemOverlayStyle: SystemUiOverlayStyle.dark,
                  leading: GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      margin: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: surfaceColor, shape: BoxShape.circle,
                        boxShadow: [BoxShadow(
                          color: Colors.black.withValues(alpha: 0.06),
                          blurRadius: 6, offset: const Offset(0, 2))]),
                      child: const Icon(Icons.arrow_back_ios_new_rounded,
                        color: textPrimary, size: 18))),
                  title: Text('@$name',
                    style: const TextStyle(
                      color: textPrimary, fontWeight: FontWeight.w800,
                      fontSize: 16, letterSpacing: -0.3)),
                  centerTitle: true,
                  actions: [
                    if (!isOwn)
                      PopupMenuButton<String>(
                        icon: Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: surfaceColor, shape: BoxShape.circle,
                            boxShadow: [BoxShadow(
                              color: Colors.black.withValues(alpha: 0.06),
                              blurRadius: 6, offset: const Offset(0, 2))]),
                          child: const Icon(Icons.more_horiz_rounded,
                            color: textPrimary, size: 20)),
                        color: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16)),
                        onSelected: (v) async {
                          if (v == 'report') await _reportUser(data);
                          if (v == 'block')  await _handleBlock(data);
                          if (v == 'unblock') await _handleUnblock(data);
                        },
                        itemBuilder: (_) => [
                          PopupMenuItem(value: _isBlockedCache ? 'unblock' : 'block',
                            child: Row(children: [
                              Icon(_isBlockedCache
                                ? Icons.lock_open_outlined : Icons.block_outlined,
                                size: 17, color: Colors.red),
                              const SizedBox(width: 10),
                              Text(_isBlockedCache ? 'Unblock' : 'Block',
                                style: const TextStyle(color: Colors.red,
                                  fontWeight: FontWeight.w600, fontSize: 14)),
                            ])),
                          PopupMenuItem(value: 'report',
                            child: Row(children: [
                              Icon(Icons.flag_outlined, size: 17,
                                color: Colors.orange[700]),
                              const SizedBox(width: 10),
                              const Text('Report', style: TextStyle(
                                fontWeight: FontWeight.w600, fontSize: 14,
                                color: textPrimary)),
                            ])),
                        ]),
                    GestureDetector(
                      onTap: () => ZyloShareUtils.shareProfile(
                        username: name, displayName: name),
                      child: Container(
                        margin: const EdgeInsets.only(right: 12),
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: surfaceColor, shape: BoxShape.circle,
                          boxShadow: [BoxShadow(
                            color: Colors.black.withValues(alpha: 0.06),
                            blurRadius: 6, offset: const Offset(0, 2))]),
                        child: const Icon(Icons.ios_share_rounded,
                          color: textPrimary, size: 18))),
                  ],
                ),

                // ── Magazine Split Hero ───────────────────────────────────
                SliverToBoxAdapter(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // 3/5 photo | 2/5 info
                    SizedBox(
                      height: 260,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          // Left — full bleed photo
                          Expanded(flex: 3,
                            child: GestureDetector(
                              onTap: photoURL.isNotEmpty
                                ? () => _openFullPhoto(photoURL, name) : null,
                              child: Stack(fit: StackFit.expand, children: [
                                photoURL.isNotEmpty
                                  ? ZyloCachedImage(
                                      url: photoURL, fit: BoxFit.cover,
                                      errorWidget: _DefaultAvatar(name: name))
                                  : _DefaultAvatar(name: name),
                                // Subtle bottom fade
                                Positioned(bottom: 0, left: 0, right: 0,
                                  child: Container(height: 50,
                                    decoration: const BoxDecoration(
                                      gradient: LinearGradient(
                                        begin: Alignment.bottomCenter,
                                        end: Alignment.topCenter,
                                        colors: [Colors.black38, Colors.transparent])))),
                              ]))),

                          // Right — info
                          Expanded(flex: 2,
                            child: Container(
                              color: bgColor,
                              padding: const EdgeInsets.fromLTRB(12, 14, 12, 14),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  // Username
                                  Text('@$name',
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w900,
                                      fontSize: 14,
                                      color: textPrimary,
                                      letterSpacing: -0.3),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis),

                                  const SizedBox(height: 8),

                                  // Online / last seen pill
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 7, vertical: 3),
                                    decoration: BoxDecoration(
                                      color: isOnline
                                        ? const Color(0xFFDCFCE7)
                                        : surfaceColor,
                                      borderRadius: BorderRadius.circular(20)),
                                    child: Row(mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Container(width: 6, height: 6,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: isOnline
                                              ? const Color(0xFF16A34A)
                                              : textSecondary)),
                                        const SizedBox(width: 5),
                                        Flexible(child: Text(
                                          isOnline ? 'Online'
                                            : (lastSeenText.isNotEmpty
                                                ? lastSeenText : 'Offline'),
                                          style: TextStyle(
                                            fontSize: 9.5,
                                            fontWeight: FontWeight.w600,
                                            color: isOnline
                                              ? const Color(0xFF16A34A)
                                              : textSecondary),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis)),
                                      ])),

                                  const SizedBox(height: 12),
                                  Container(height: 1, color: dividerColor),
                                  const SizedBox(height: 12),

                                  // Stats
                                  _MiniStat(value: _fmt(postsCount), label: 'Posts'),
                                  const SizedBox(height: 7),
                                  // Live follower count from subcollection
                                  StreamBuilder<AggregateQuerySnapshot>(
                                    stream: Stream.fromFuture(
                                      FirebaseFirestore.instance
                                          .collection('users').doc(widget.targetUid)
                                          .collection('followers').count().get(),
                                    ),
                                    builder: (_, cSnap) {
                                      final cnt = cSnap.data?.count ?? followersCount;
                                      return _MiniStat(value: _fmt(cnt), label: 'Followers');
                                    },
                                  ),
                                  const SizedBox(height: 7),
                                  // Live following count from subcollection
                                  StreamBuilder<AggregateQuerySnapshot>(
                                    stream: Stream.fromFuture(
                                      FirebaseFirestore.instance
                                          .collection('users').doc(widget.targetUid)
                                          .collection('following').count().get(),
                                    ),
                                    builder: (_, cSnap) {
                                      final cnt = cSnap.data?.count ?? followingCount;
                                      return _MiniStat(value: _fmt(cnt), label: 'Following');
                                    },
                                  ),

                                  if (isPrivate) ...[
                                    const SizedBox(height: 10),
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 7, vertical: 2),
                                      decoration: BoxDecoration(
                                        color: surfaceColor,
                                        borderRadius: BorderRadius.circular(20),
                                        border: Border.all(color: dividerColor)),
                                      child: const Row(mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Icon(Icons.lock_outline_rounded,
                                            size: 9, color: textSecondary),
                                          SizedBox(width: 3),
                                          Text('Private', style: TextStyle(
                                            fontSize: 9, fontWeight: FontWeight.w700,
                                            color: textSecondary)),
                                        ])),
                                  ],
                                ]))),
                        ])),

                    // Bio
                    if (bio.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
                        child: Text(bio,
                          style: const TextStyle(
                            fontSize: 13.5, color: textPrimary,
                            height: 1.55, fontWeight: FontWeight.w400))),

                    // Achievements
                    ZyloAchievements(
                      userData: data,
                      followersCount: followersCount,
                      postsCount: postsCount,
                    ),

                    // Mutual friends
                    if (_mutualFriends.isNotEmpty && !isOwn)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                        child: Row(children: [
                          SizedBox(
                            width: _mutualFriends.take(3).length * 18.0 + 14,
                            height: 24,
                            child: Stack(children: List.generate(
                              _mutualFriends.take(3).length, (i) {
                                final photo = _mutualFriends[i]['photoURL'] as String;
                                return Positioned(left: i * 18.0,
                                  child: Container(
                                    decoration: const BoxDecoration(
                                      shape: BoxShape.circle, color: bgColor),
                                    padding: const EdgeInsets.all(1.5),
                                    child: CircleAvatar(
                                      radius: 10, backgroundColor: surfaceColor,
                                      backgroundImage: photo.isNotEmpty
                                        ? NetworkImage(photo) : null,
                                      child: photo.isEmpty
                                        ? Text(
                                            (_mutualFriends[i]['username'] as String).isNotEmpty
                                              ? (_mutualFriends[i]['username'] as String)[0].toUpperCase()
                                              : '?',
                                            style: const TextStyle(fontSize: 8,
                                              color: _blue, fontWeight: FontWeight.w800))
                                        : null)));
                              }))),
                          const SizedBox(width: 8),
                          Expanded(child: Text(
                            _mutualFriends.length == 1
                              ? 'Followed by ${_mutualFriends[0]['username']}'
                              : 'Followed by ${_mutualFriends[0]['username']} and ${_mutualFriends.length - 1} other${_mutualFriends.length > 2 ? 's' : ''}',
                            style: const TextStyle(fontSize: 11.5, color: textSecondary),
                            maxLines: 1, overflow: TextOverflow.ellipsis)),
                        ])),

                    // Action Buttons
                    if (!isOwn)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
                        child: Row(children: [
                          Expanded(child: GestureDetector(
                            onTap: _toggling ? null : () => _toggleFollow(name),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 220),
                              height: 44,
                              decoration: BoxDecoration(
                                gradient: _isFollowing ? null : const LinearGradient(
                                  colors: [_blue, _purple],
                                  begin: Alignment.centerLeft,
                                  end: Alignment.centerRight),
                                color: _isFollowing ? surfaceColor : null,
                                borderRadius: BorderRadius.circular(14),
                                border: _isFollowing
                                  ? Border.all(color: dividerColor) : null,
                                boxShadow: _isFollowing ? null : [
                                  BoxShadow(color: _blue.withValues(alpha: 0.28),
                                    blurRadius: 12, offset: const Offset(0, 4))]),
                              child: Center(child: _toggling
                                ? SizedBox(width: 16, height: 16,
                                    child: CircularProgressIndicator(strokeWidth: 2,
                                      color: _isFollowing ? textPrimary : Colors.white))
                                : Row(mainAxisSize: MainAxisSize.min, children: [
                                    if (_isFollowing)
                                      const Icon(Icons.check_rounded,
                                        size: 15, color: textPrimary),
                                    if (_isFollowing) const SizedBox(width: 4),
                                    Text(_isFollowing ? 'Following' : 'Follow',
                                      style: TextStyle(fontWeight: FontWeight.w700,
                                        fontSize: 14,
                                        color: _isFollowing ? textPrimary : Colors.white)),
                                  ]))))),
                          const SizedBox(width: 10),
                          Expanded(child: GestureDetector(
                            onTap: () => Navigator.push(context,
                              MaterialPageRoute(builder: (_) =>
                                ChatRoomScreen(
                                  targetId: widget.targetUid, targetName: name))),
                            child: Container(
                              height: 44,
                              decoration: BoxDecoration(
                                color: surfaceColor,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: dividerColor)),
                              child: const Center(child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.chat_bubble_outline_rounded,
                                    size: 15, color: textPrimary),
                                  SizedBox(width: 6),
                                  Text('Message', style: TextStyle(
                                    fontWeight: FontWeight.w700, fontSize: 14,
                                    color: textPrimary)),
                                ]))))),
                        ])),

                    const SizedBox(height: 16),
                  ])),

                // ── Sticky Tab Bar ───────────────────────────────────────────
                SliverPersistentHeader(
                  pinned: true,
                  delegate: _StickyTabDelegate(
                    Container(
                      color: bgColor,
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Container(height: 1, color: dividerColor),
                        TabBar(
                          controller: _tabCtrl,
                          indicatorColor: _blue,
                          indicatorWeight: 2.5,
                          indicatorSize: TabBarIndicatorSize.label,
                          labelColor: _blue,
                          unselectedLabelColor: textSecondary,
                          labelStyle: const TextStyle(
                            fontWeight: FontWeight.w700, fontSize: 12),
                          tabs: const [
                            Tab(icon: Icon(Icons.grid_view_rounded, size: 20),
                              text: 'Posts'),
                            Tab(icon: Icon(Icons.bookmark_outline_rounded, size: 20),
                              text: 'Saved'),
                          ]),
                      ])))),
              ],
            body: TabBarView(
              controller: _tabCtrl,
              children: [
                isPrivate && !_isFollowing && !isOwn
                  ? _PrivateLock(name: name)
                  : _PostsGrid(uid: widget.targetUid, userData: data, myUid: myUid),
                const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.bookmark_outline_rounded, size: 40,
                      color: Color(0xFF8A8A8E)),
                    SizedBox(height: 14),
                    Text('Saved posts coming soon',
                      style: TextStyle(color: Color(0xFF8A8A8E),
                        fontWeight: FontWeight.w600, fontSize: 14)),
                  ])),
              ],
            ),
          );
        }),
      ),
    );
  }

  String _fmt(int n) {
    if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}M';
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
    return '$n';
  }
}

// ── Mini stat row ─────────────────────────────────────────────────────────────
class _MiniStat extends StatelessWidget {
  final String value, label;
  const _MiniStat({required this.value, required this.label});
  @override
  Widget build(BuildContext context) => Row(
    mainAxisSize: MainAxisSize.min,
    crossAxisAlignment: CrossAxisAlignment.baseline,
    textBaseline: TextBaseline.alphabetic,
    children: [
      Text(value, style: const TextStyle(
        fontWeight: FontWeight.w800, fontSize: 16,
        color: Color(0xFF0D0D0D))),
      const SizedBox(width: 5),
      Text(label, style: const TextStyle(
        fontSize: 10.5, color: Color(0xFF8A8A8E),
        fontWeight: FontWeight.w500)),
    ]);
}

// ── Default Avatar ────────────────────────────────────────────────────────────
class _DefaultAvatar extends StatelessWidget {
  final String name;
  const _DefaultAvatar({required this.name});
  @override
  Widget build(BuildContext context) => Container(
    decoration: const BoxDecoration(
      gradient: LinearGradient(
        colors: [Color(0xFF0284C7), Color(0xFF7C3AED)],
        begin: Alignment.topLeft, end: Alignment.bottomRight)),
    child: Center(child: Text(
      name.isNotEmpty ? name[0].toUpperCase() : 'Z',
      style: const TextStyle(
        fontSize: 80, fontWeight: FontWeight.w900,
        color: Colors.white))));
}

// ── Sticky Tab Delegate ──────────────────────────────────────────────────────
class _StickyTabDelegate extends SliverPersistentHeaderDelegate {
  final Widget child;
  const _StickyTabDelegate(this.child);
  @override double get minExtent => 54;
  @override double get maxExtent => 54;
  @override Widget build(BuildContext ctx, double shrink, bool overlap) => child;
  @override bool shouldRebuild(_StickyTabDelegate o) => o.child != child;
}

// ── Private Lock ──────────────────────────────────────────────────────────────
class _PrivateLock extends StatelessWidget {
  final String name;
  const _PrivateLock({required this.name});
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(padding: const EdgeInsets.symmetric(vertical: 60, horizontal: 40),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(width: 72, height: 72,
          decoration: BoxDecoration(
            color: const Color(0xFFF4F4F6), shape: BoxShape.circle,
            border: Border.all(color: const Color(0xFFEAEAEF))),
          child: const Icon(Icons.lock_outline_rounded,
            size: 30, color: Color(0xFF8A8A8E))),
        const SizedBox(height: 18),
        const Text('This account is private',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15,
            color: Color(0xFF0D0D0D))),
        const SizedBox(height: 8),
        Text('Follow @$name to see their posts.',
          style: const TextStyle(fontSize: 13, color: Color(0xFF8A8A8E), height: 1.5),
          textAlign: TextAlign.center),
      ])));
}

// ── Posts Grid ────────────────────────────────────────────────────────────────
class _PostsGrid extends StatelessWidget {
  final String uid, myUid;
  final Map<String, dynamic> userData;

  const _PostsGrid({required this.uid, required this.userData, required this.myUid});

  static const _blue    = Color(0xFF0284C7);
  static const _surface = Color(0xFFF4F4F6);
  static const _textSub = Color(0xFF8A8A8E);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('posts')
          .where('authorId', isEqualTo: uid).snapshots(),
      builder: (ctx, snap) {
        if (snap.connectionState == ConnectionState.waiting && !snap.hasData) {
          return const Center(child: CircularProgressIndicator(
            color: _blue, strokeWidth: 2));
        }
        final docs = snap.data?.docs ?? [];
        final sorted = List<QueryDocumentSnapshot>.of(docs)..sort((a, b) {
          final aT = (a.data() as Map)['createdAt'];
          final bT = (b.data() as Map)['createdAt'];
          if (aT == null && bT == null) return 0;
          if (aT == null) return 1;
          if (bT == null) return -1;
          return (bT as dynamic).compareTo(aT as dynamic);
        });

        if (sorted.isEmpty) {
          return const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.photo_outlined, size: 40, color: _textSub),
              SizedBox(height: 14),
              Text('No posts yet', style: TextStyle(
                color: _textSub, fontWeight: FontWeight.w600, fontSize: 14)),
            ]));
        }

        return GridView.builder(
          padding: const EdgeInsets.all(1),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3, crossAxisSpacing: 1.5, mainAxisSpacing: 1.5),
          itemCount: sorted.length,
          itemBuilder: (_, i) {
            final data     = sorted[i].data() as Map<String, dynamic>;
            final images   = data['images'] as List? ?? [];
            final text     = data['text']   as String? ?? '';
            final imgUrl   = images.isNotEmpty ? images[0] as String : '';
            final hasMulti = images.length > 1;

            return GestureDetector(
              onTap: () => Navigator.push(context, MaterialPageRoute(
                builder: (_) => _PostDetailScreen(
                  docs: sorted, initialIndex: i, userData: userData,
                  myUid: myUid, isDark: false))),
              child: Stack(fit: StackFit.expand, children: [
                imgUrl.isNotEmpty
                  ? ZyloCachedImage(url: imgUrl, fit: BoxFit.cover,
                      errorWidget: _thumb(text))
                  : _thumb(text),
                if (hasMulti)
                  Positioned(top: 6, right: 6,
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.5),
                        borderRadius: BorderRadius.circular(6)),
                      child: const Icon(Icons.collections_rounded,
                        color: Colors.white, size: 12))),
              ]));
          });
      });
  }

  Widget _thumb(String text) => Container(
    color: _surface,
    child: Center(child: Padding(padding: const EdgeInsets.all(8),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(Icons.article_outlined, color: _blue.withValues(alpha: 0.6), size: 22),
        const SizedBox(height: 4),
        Text(text, maxLines: 3, overflow: TextOverflow.ellipsis,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 9, color: _textSub,
            fontWeight: FontWeight.w500)),
      ]))));
}

// ── Post Detail Screen ────────────────────────────────────────────────────────
class _PostDetailScreen extends StatefulWidget {
  final List<QueryDocumentSnapshot> docs;
  final int initialIndex;
  final Map<String, dynamic> userData;
  final String myUid;
  final bool isDark;
  const _PostDetailScreen({required this.docs, required this.initialIndex,
    required this.userData, required this.myUid, required this.isDark});
  @override
  State<_PostDetailScreen> createState() => _PostDetailScreenState();
}

class _PostDetailScreenState extends State<_PostDetailScreen> {
  late PageController _pageCtrl;
  late int _current;

  static const _blue   = Color(0xFF0284C7);
  static const _purple = Color(0xFF7C3AED);

  final Map<String, bool> _likedMap    = {};
  final Map<String, bool> _savedMap    = {};
  final Map<String, bool> _likeLoading = {};

  Color get _bg      => widget.isDark ? const Color(0xFF0D1117) : Colors.white;
  Color get _surface => widget.isDark ? const Color(0xFF161B22) : const Color(0xFFF4F4F6);
  Color get _textMain => widget.isDark ? Colors.white : const Color(0xFF0D0D0D);
  Color get _textSub => widget.isDark ? Colors.grey[400]! : const Color(0xFF8A8A8E);
  Color get _border  => widget.isDark ? Colors.white.withValues(alpha: 0.08) : const Color(0xFFEAEAEF);

  @override
  void initState() {
    super.initState();
    _current = widget.initialIndex;
    _pageCtrl = PageController(initialPage: widget.initialIndex);
    _initStates();
  }

  @override void dispose() { _pageCtrl.dispose(); super.dispose(); }

  Future<void> _initStates() async {
    if (widget.myUid.isEmpty) return;
    for (final doc in widget.docs) {
      final postId = doc.id;
      final data = doc.data() as Map<String, dynamic>;
      final likes = (data['likes'] as List?)?.cast<String>() ?? [];
      if (mounted) setState(() => _likedMap[postId] = likes.contains(widget.myUid));
      try {
        final saved = await FirebaseFirestore.instance
            .collection('users').doc(widget.myUid)
            .collection('savedPosts').doc(postId).get();
        if (mounted) setState(() => _savedMap[postId] = saved.exists);
      } catch (_) {}
    }
  }

  Future<void> _toggleLike(String postId, String authorId, bool wasLiked) async {
    if (_likeLoading[postId] == true) return;
    setState(() { _likeLoading[postId] = true; _likedMap[postId] = !wasLiked; });
    HapticFeedback.lightImpact();
    try {
      final ref = FirebaseFirestore.instance.collection('posts').doc(postId);
      if (wasLiked) {
        await ref.update({'likes': FieldValue.arrayRemove([widget.myUid])});
      } else {
        await ref.update({'likes': FieldValue.arrayUnion([widget.myUid])});
        if (authorId.isNotEmpty && authorId != widget.myUid) {
          final me = await FirebaseFirestore.instance
              .collection('users').doc(widget.myUid).get();
          final myName = me.data()?['username'] as String? ?? 'Someone';
          FirebaseFirestore.instance.collection('users').doc(authorId)
              .collection('notifications').add({
            'type': 'post_like', 'text': '@$myName liked your post',
            'fromUid': widget.myUid, 'fromName': myName,
            'postId': postId, 'read': false,
            'createdAt': FieldValue.serverTimestamp(),
          });
        }
      }
    } catch (_) {
      if (mounted) setState(() => _likedMap[postId] = wasLiked);
    } finally {
      if (mounted) setState(() => _likeLoading[postId] = false);
    }
  }

  Future<void> _toggleSave(String postId, bool wasSaved) async {
    setState(() => _savedMap[postId] = !wasSaved);
    HapticFeedback.lightImpact();
    try {
      final ref = FirebaseFirestore.instance
          .collection('users').doc(widget.myUid)
          .collection('savedPosts').doc(postId);
      wasSaved ? await ref.delete() : await ref.set({'savedAt': FieldValue.serverTimestamp()});
    } catch (_) {
      if (mounted) setState(() => _savedMap[postId] = wasSaved);
    }
  }

  @override
  Widget build(BuildContext context) {
    final name     = widget.userData['username'] as String? ?? 'User';
    final photoURL = widget.userData['photoURL']  as String? ?? '';

    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: _surface, shape: BoxShape.circle),
            child: Icon(Icons.arrow_back_ios_new_rounded, color: _textMain, size: 18))),
        title: Row(mainAxisSize: MainAxisSize.min, children: [
          CircleAvatar(radius: 16, backgroundColor: _surface,
            backgroundImage: photoURL.isNotEmpty ? NetworkImage(photoURL) : null,
            child: photoURL.isEmpty
              ? Text(name.isNotEmpty ? name[0].toUpperCase() : 'Z',
                  style: const TextStyle(fontSize: 13,
                    fontWeight: FontWeight.w900, color: _blue))
              : null),
          const SizedBox(width: 8),
          Text('@$name', style: TextStyle(
            color: _textMain, fontWeight: FontWeight.w700, fontSize: 14)),
        ]),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 14),
            child: Center(child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: _surface, borderRadius: BorderRadius.circular(20)),
              child: Text('${_current + 1} / ${widget.docs.length}',
                style: TextStyle(fontSize: 12,
                  fontWeight: FontWeight.w700, color: _textSub))))),
        ],
      ),
      body: PageView.builder(
        controller: _pageCtrl,
        itemCount: widget.docs.length,
        onPageChanged: (i) => setState(() => _current = i),
        itemBuilder: (_, i) {
          final doc      = widget.docs[i];
          final postId   = doc.id;
          final data     = doc.data() as Map<String, dynamic>;
          final authorId = data['authorId'] as String? ?? '';
          final images   = (data['images'] as List?)?.cast<String>() ?? [];
          final text     = data['text']    as String? ?? '';
          final createdAt = data['createdAt'] as Timestamp?;

          return StreamBuilder<DocumentSnapshot>(
            stream: FirebaseFirestore.instance
              .collection('posts').doc(postId).snapshots(),
            builder: (ctx, snap) {
              final live = snap.hasData && snap.data!.exists
                  ? snap.data!.data() as Map<String, dynamic>
                  : data;
              final likes     = (live['likes'] as List?)?.cast<String>() ?? [];
              final isLiked   = _likedMap.containsKey(postId)
                  ? _likedMap[postId]! : likes.contains(widget.myUid);
              final isSaved   = _savedMap[postId] ?? false;
              final likeCount = likes.length;
              final comments  = live['commentCount'] as int? ?? 0;
              final views     = live['views'] ?? 0;

              return SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  if (images.isNotEmpty)
                    _ImageCarousel(images: images, isDark: widget.isDark),
                  if (text.isNotEmpty)
                    Padding(padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                      child: Text(text, style: TextStyle(
                        fontSize: 14.5, height: 1.65, color: _textMain))),
                  if (createdAt != null)
                    Padding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                      child: Text(_fmt(createdAt),
                        style: TextStyle(fontSize: 11, color: _textSub))),
                  const SizedBox(height: 6),
                  Divider(height: 1, thickness: 1,
                    color: _border, indent: 16, endIndent: 16),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(8, 2, 8, 2),
                    child: Row(children: [
                      _ABtn(
                        icon: isLiked
                          ? Icons.favorite_rounded
                          : Icons.favorite_outline_rounded,
                        label: '$likeCount',
                        iconColor: isLiked ? Colors.red : _textSub,
                        labelColor: _textSub,
                        onTap: () => _toggleLike(postId, authorId, isLiked)),
                      _ABtn(
                        icon: Icons.chat_bubble_outline_rounded,
                        label: '$comments',
                        iconColor: _textSub, labelColor: _textSub,
                        onTap: () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => PostCommentsScreen(
                            postId: postId, myUid: widget.myUid,
                            auth: AuthService())))),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 6),
                        child: Row(children: [
                          Icon(Icons.visibility_outlined, size: 19, color: _textSub),
                          const SizedBox(width: 5),
                          Text('$views', style: TextStyle(
                            fontSize: 13, fontWeight: FontWeight.w600,
                            color: _textSub)),
                        ])),
                      const Spacer(),
                      GestureDetector(
                        onTap: () => _toggleSave(postId, isSaved),
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: AnimatedSwitcher(
                            duration: const Duration(milliseconds: 200),
                            child: Icon(
                              isSaved
                                ? Icons.bookmark_rounded
                                : Icons.bookmark_outline_rounded,
                              key: ValueKey(isSaved),
                              color: isSaved ? _blue : _textSub,
                              size: 22)))),
                    ])),
                  const SizedBox(height: 40),
                ]));
            });
        }),
    );
  }

  String _fmt(Timestamp ts) {
    final dt = ts.toDate();
    const m = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    final h = dt.hour % 12 == 0 ? 12 : dt.hour % 12;
    final min = dt.minute.toString().padLeft(2, '0');
    return '${m[dt.month-1]} ${dt.day} · $h:$min ${dt.hour < 12 ? 'AM' : 'PM'}';
  }
}

// ── Compact Action Button ────────────────────────────────────────────────────
class _ABtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color iconColor, labelColor;
  final VoidCallback onTap;
  const _ABtn({required this.icon, required this.label,
    required this.iconColor, required this.labelColor, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 180),
          child: Icon(icon, key: ValueKey(icon), color: iconColor, size: 22)),
        const SizedBox(width: 5),
        Text(label, style: TextStyle(
          fontSize: 13, fontWeight: FontWeight.w600, color: labelColor)),
      ])));
}

// ── Image Carousel ────────────────────────────────────────────────────────────
class _ImageCarousel extends StatefulWidget {
  final List<String> images;
  final bool isDark;
  const _ImageCarousel({required this.images, required this.isDark});
  @override State<_ImageCarousel> createState() => _ImageCarouselState();
}

class _ImageCarouselState extends State<_ImageCarousel> {
  int _page = 0;
  static const _blue = Color(0xFF0284C7);
  @override
  Widget build(BuildContext context) => AspectRatio(
    aspectRatio: 1,
    child: Stack(children: [
      PageView.builder(
        itemCount: widget.images.length,
        onPageChanged: (i) => setState(() => _page = i),
        itemBuilder: (_, j) => ZyloCachedImage(
          url: widget.images[j], fit: BoxFit.cover,
          errorWidget: Container(
            color: widget.isDark
              ? const Color(0xFF1E2530) : const Color(0xFFF4F4F6),
            child: const Icon(Icons.image_not_supported_outlined, color: _blue)))),
      if (widget.images.length > 1)
        Positioned(bottom: 12, left: 0, right: 0,
          child: Row(mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(widget.images.length, (i) => AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: i == _page ? 16 : 6, height: 6,
              decoration: BoxDecoration(
                color: i == _page ? _blue : Colors.white.withValues(alpha: 0.55),
                borderRadius: BorderRadius.circular(3)))))),
    ]));
}

// ── Report Dialog ──────────────────────────────────────────────────────────────
class _ReportDialog extends StatefulWidget {
  final String name;
  const _ReportDialog({required this.name});
  @override State<_ReportDialog> createState() => _ReportDialogState();
}

class _ReportDialogState extends State<_ReportDialog> {
  String? _selected;
  final _reasons = ['Spam or fake account', 'Inappropriate content',
    'Harassment or bullying', 'Hate speech', 'Impersonation', 'Other'];
  @override
  Widget build(BuildContext context) => AlertDialog(
    backgroundColor: Colors.white,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    title: Text('Report @${widget.name}', style: const TextStyle(
      fontWeight: FontWeight.w800, fontSize: 16, color: Color(0xFF0D0D0D))),
    content: Column(mainAxisSize: MainAxisSize.min,
      children: _reasons.map((r) => RadioListTile<String>(
        value: r, groupValue: _selected, dense: true,
        activeColor: const Color(0xFF0284C7),
        title: Text(r, style: const TextStyle(fontSize: 13, color: Colors.black87)),
        onChanged: (v) => setState(() => _selected = v))).toList()),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context),
        child: const Text('Cancel', style: TextStyle(color: Colors.grey))),
      ElevatedButton(
        style: ElevatedButton.styleFrom(backgroundColor: Colors.red,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
        onPressed: _selected == null ? null : () => Navigator.pop(context, _selected),
        child: const Text('Report')),
    ]);
}
