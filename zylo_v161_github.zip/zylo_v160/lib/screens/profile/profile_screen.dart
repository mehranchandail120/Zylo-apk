import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../widgets/zylo_cached_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../services/auth_service.dart';
import '../../services/cache_service.dart';
import '../../services/firestore_service.dart';
import '../../utils/share_utils.dart';
import 'edit_profile_screen.dart';
import 'view_profile_screen.dart';
import '../settings_screen.dart';
import '../../widgets/zylo_avatar.dart';
import '../../widgets/zylo_achievements.dart';
import '../../widgets/account_switcher_sheet.dart';

const _kBlue  = Color(0xFF0284C7);
const _kBg    = Color(0xFFF0F4F8);
const _kCard  = Colors.white;
const _kGreen = Color(0xFF10B981);

Color _fileGridColor(String type) {
  switch (type) {
    case 'audio':    return const Color(0xFF8B5CF6);
    case 'pdf':      return Colors.red;
    case 'apk':      return const Color(0xFF3DDC84);
    case 'document': return _kBlue;
    case 'archive':  return Colors.orange;
    default:         return Colors.grey;
  }
}

IconData _fileGridIcon(String type) {
  switch (type) {
    case 'audio':    return Icons.audiotrack_rounded;
    case 'pdf':      return Icons.picture_as_pdf_rounded;
    case 'apk':      return Icons.android_rounded;
    case 'document': return Icons.description_rounded;
    case 'archive':  return Icons.folder_zip_rounded;
    default:         return Icons.insert_drive_file_rounded;
  }
}

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen>
    with SingleTickerProviderStateMixin {
  final FirestoreService _fs = FirestoreService();
  late TabController _tabCtrl;
  bool _showPhone = false;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 3, vsync: this);
    _loadPrefs();
  }

  Future<void> _loadPrefs() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
    if (mounted) setState(() => _showPhone = (doc.data()?['showPhone'] as bool?) ?? false);
  }

  @override void dispose() { _tabCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthService>(context);
    final myUid = auth.user?.uid ?? '';

    // Guard: if not logged in, show loading
    if (myUid.isEmpty) {
      return const Scaffold(
        backgroundColor: _kBg,
        body: Center(child: CircularProgressIndicator(color: _kBlue)),
      );
    }

    return Scaffold(
      backgroundColor: _kBg,
      body: NestedScrollView(
        headerSliverBuilder: (ctx, _) => [
          SliverToBoxAdapter(child: _ProfileHeader(
            auth: auth, myUid: myUid, fs: _fs, showPhone: _showPhone,
            onSettings: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen())),
            onEdit: () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => const EditProfileScreen()));
              await auth.refreshUserData();
            },

            onShowViewers: () => _showProfileViewers(context, myUid),
            onSwitchAccount: () => showAccountSwitcher(context),
          )),
        ],
        body: Column(children: [
          Container(
            decoration: BoxDecoration(
              color: _kCard,
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 8, offset: const Offset(0, 2))]),
            child: TabBar(
              controller: _tabCtrl,
              indicatorColor: _kBlue, indicatorWeight: 2.5,
              labelColor: _kBlue, unselectedLabelColor: Colors.grey[600],
              labelStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12),
              tabs: const [
                Tab(icon: Icon(Icons.grid_on_rounded, size: 16), text: 'My Posts'),
                Tab(icon: Icon(Icons.history_rounded, size: 16), text: 'History'),
                Tab(icon: Icon(Icons.settings_outlined, size: 16), text: 'Settings'),
              ])),
          Expanded(child: TabBarView(controller: _tabCtrl, children: [
            _MyPosts(myUid: myUid),
            _HistoryTab(myUid: myUid),
            _SettingsTab(onNavigate: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()))),
          ])),
        ]),
      ),
    );
  }

  void _showProfileViewers(BuildContext ctx, String myUid) =>
    showModalBottomSheet(context: ctx, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (_) => _ProfileViewersSheet(myUid: myUid));

}

// ═══════════════════════════════════════════════════════════
//  Profile Header — avatar fixed, settings on cover
// ═══════════════════════════════════════════════════════════
class _ProfileHeader extends StatelessWidget {
  final AuthService auth;
  final String myUid;
  final FirestoreService fs;
  final bool showPhone;
  final VoidCallback onSettings, onEdit, onShowViewers, onSwitchAccount;

  const _ProfileHeader({
    required this.auth, required this.myUid, required this.fs,
    required this.showPhone, required this.onSettings, required this.onEdit, required this.onSwitchAccount,
    required this.onShowViewers,
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot>(
      stream: myUid.isNotEmpty
        ? FirebaseFirestore.instance.collection('users').doc(myUid).snapshots()
        : const Stream.empty(),
      builder: (_, snap) {
        // Cache write-through: persist profile data whenever we get a fresh snapshot
        Map<String, dynamic> data = snap.data?.data() as Map<String, dynamic>? ?? {};
        if (data.isNotEmpty && myUid.isNotEmpty) {
          CacheService.cacheProfile(myUid, data);
        }
        // Cache-first fallback: use cached data if Firebase hasn't responded yet
        if (data.isEmpty && myUid.isNotEmpty) {
          final cached = CacheService.getStaleProfile(myUid);
          if (cached != null) data = cached;
        }
        final bio           = data['bio']         as String? ?? auth.bio        ?? '';
        final phone         = data['phone']        as String? ?? auth.phone      ?? '';
        final totalViews    = data['profileViews'] ?? 0;
        final showPhonePublic = (data['showPhone'] as bool?) ?? showPhone;
        final photoURL      = data['photoURL']     as String? ?? auth.photoURL  ?? '';
        final username      = data['username']     as String? ?? auth.userName  ?? 'username';

        return Column(children: [
          // ── Cover with avatar overlapping bottom ──────────────────────────
          SizedBox(
            height: 188,   // cover 140 + avatar half (48 px)
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                // Cover gradient — full width, 140 px tall
                Positioned(top: 0, left: 0, right: 0,
                  child: Container(
                    height: 140,
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Color(0xFF0C4A6E), Color(0xFF0284C7), Color(0xFF38BDF8)],
                        begin: Alignment.topLeft, end: Alignment.bottomRight)))),

                // Decorative bubbles
                Positioned(top: -20, right: -20,
                  child: Container(width: 120, height: 120,
                    decoration: BoxDecoration(shape: BoxShape.circle,
                      color: Colors.white.withValues(alpha: 0.06)))),
                Positioned(top: 30, left: 110,
                  child: Container(width: 60, height: 60,
                    decoration: BoxDecoration(shape: BoxShape.circle,
                      color: Colors.white.withValues(alpha: 0.04)))),

                // Settings + Edit + Share on cover — top right
                Positioned(top: 0, right: 0,
                  child: SafeArea(child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Row(children: [
                      _HdrBtn(icon: Icons.switch_account_rounded, onTap: onSwitchAccount),
                      const SizedBox(width: 8),
                      _HdrBtn(icon: Icons.settings_outlined, onTap: onSettings),
                      const SizedBox(width: 8),
                      _HdrBtn(icon: Icons.edit_outlined,     onTap: onEdit),
                      const SizedBox(width: 8),
                      _HdrBtn(
                        icon: Icons.share_rounded,
                        onTap: () => ZyloShareUtils.shareProfile(
                          username: username,
                          displayName: auth.userName ?? username,
                        ),
                      ),
                    ])))),

                // Zylo badge — top left
                Positioned(top: 0, left: 0,
                  child: SafeArea(child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.white.withValues(alpha: 0.25))),
                      child: const Text('zylo.pages',
                        style: TextStyle(color: Colors.white, fontSize: 12,
                          fontWeight: FontWeight.w800, fontStyle: FontStyle.italic)))))),

                // ── Avatar: positioned so its centre sits at cover bottom ──
                // bottom=0 → bottom of SizedBox (188). Avatar radius=48 → top of avatar at 188-96=92
                // Cover is 140 tall → avatar overlaps by 140-92=48 px ✓
                Positioned(left: 16, bottom: 0,
                  child: GestureDetector(
                    onTap: onEdit,
                    child: Container(
                      width: 96, height: 96,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 3.5),
                        color: Colors.white,
                        boxShadow: [BoxShadow(
                          color: Colors.black.withValues(alpha: 0.18),
                          blurRadius: 14, offset: const Offset(0, 4))]),
                      child: ZyloAvatar(
                        photoUrl: photoURL.isNotEmpty ? photoURL : null,
                        radius: 48,
                      )))),

                // Camera badge
                Positioned(left: 78, bottom: 4,
                  child: GestureDetector(
                    onTap: onEdit,
                    child: Container(
                      width: 26, height: 26,
                      decoration: BoxDecoration(
                        color: _kBlue, shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 2),
                        boxShadow: [BoxShadow(color: _kBlue.withValues(alpha: 0.4), blurRadius: 6)]),
                      child: const Icon(Icons.camera_alt_rounded, size: 13, color: Colors.white)))),
              ]),
          ),

          // ── Info card ─────────────────────────────────────────────────────
          Container(
            color: _kCard,
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('@$username',
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: -0.3)),
                  const SizedBox(height: 2),
                  Text(auth.user?.email ?? '',
                    style: TextStyle(color: Colors.grey[600], fontSize: 12)),
                ])),
                const SizedBox(width: 10),
                GestureDetector(
                  onTap: onEdit,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                    decoration: BoxDecoration(
                      color: _kBlue.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _kBlue.withValues(alpha: 0.3))),
                    child: const Text('Edit Profile',
                      style: TextStyle(color: _kBlue, fontWeight: FontWeight.w700, fontSize: 12)))),
              ]),

              if (bio.isNotEmpty) ...[
                const SizedBox(height: 10),
                Text(bio, maxLines: 3, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 13, height: 1.5, color: const Color(0xFF0D1B2A))),
              ],

              if (showPhonePublic && phone.isNotEmpty) ...[
                const SizedBox(height: 6),
                Row(children: [
                  Icon(Icons.phone_outlined, size: 13, color: Colors.grey[600]),
                  const SizedBox(width: 4),
                  Text(phone, style: TextStyle(color: Colors.grey[800], fontSize: 12)),
                ]),
              ],

              const SizedBox(height: 16),

              // Public / Private badge — uses data already loaded from parent stream
              Builder(builder: (ctx) {
                  final isPublic = data['isPublic'] != false;
                  return GestureDetector(
                    onTap: () async {
                      final newVal = !isPublic;
                      await FirebaseFirestore.instance.collection('users').doc(myUid)
                          .update({'isPublic': newVal});
                    },
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: isPublic ? const Color(0xFFEFF6FF) : Colors.grey[100],
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: isPublic ? _kBlue.withValues(alpha: 0.3) : Colors.grey.withValues(alpha: 0.3))),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(isPublic ? Icons.public_rounded : Icons.lock_outline_rounded,
                          size: 14, color: isPublic ? _kBlue : Colors.grey[600]),
                        const SizedBox(width: 6),
                        Text(isPublic ? 'Public Account' : 'Private Account',
                          style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700,
                            color: isPublic ? _kBlue : Colors.grey[600])),
                        const SizedBox(width: 6),
                        Icon(Icons.swap_horiz_rounded, size: 13,
                          color: isPublic ? _kBlue.withValues(alpha: 0.6) : Colors.grey[600]),
                      ])));
                }),

              // Stats row — Followers + Following
              StreamBuilder<int>(
                stream: myUid.isNotEmpty
                    ? FirestoreService().followersCountStream(myUid)
                    : const Stream.empty(),
                builder: (_, flerSnap) {
                  final followersCount = flerSnap.data ?? 0;
                  return StreamBuilder<int>(
                    stream: myUid.isNotEmpty
                        ? FirestoreService().followingCountStream()
                        : const Stream.empty(),
                    builder: (_, cSnap) {
                      final followingCount = cSnap.data ?? 0;
                      return Row(children: [
                        Expanded(child: _StatCard(
                          value: '$followersCount',
                          label: 'Followers',
                          icon: Icons.people_rounded,
                          color: const Color(0xFF7C3AED),
                          onTap: () => _showFollowersSheet(context, myUid),
                        )),
                        const SizedBox(width: 10),
                        Expanded(child: _StatCard(
                          value: '$followingCount',
                          label: 'Following',
                          icon: Icons.person_add_rounded,
                          color: const Color(0xFF0284C7),
                          onTap: () => _showFollowingSheet(context, myUid),
                        )),
                      ]);
                    },
                  );
                },
              ),
            ])),

          // Achievements
          StreamBuilder<int>(
            stream: myUid.isNotEmpty ? FirestoreService().followersCountStream(myUid) : const Stream.empty(),
            builder: (_, fSnap) {
              final fc = fSnap.data ?? (data['followersCount'] as int? ?? 0);
              final pc = data['postsCount'] as int? ?? 0;
              return ZyloAchievements(userData: data, followersCount: fc, postsCount: pc);
            },
          ),

          const SizedBox(height: 8),
        ]);
      });
  }
}

// ── Tiny widgets ──────────────────────────────────────────────────────────────
// Avatar placeholder now uses ZyloAvatar with initials fallback

class _HdrBtn extends StatelessWidget {
  final IconData icon; final VoidCallback onTap;
  const _HdrBtn({required this.icon, required this.onTap});
  @override Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.18),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.white.withValues(alpha: 0.2))),
      child: Icon(icon, color: Colors.white, size: 20)));
}

class _StatCard extends StatelessWidget {
  final String value, label; final IconData icon; final Color color; final VoidCallback onTap;
  const _StatCard({required this.value, required this.label, required this.icon, required this.color, required this.onTap});
  @override Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.06),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.18))),
      child: Column(children: [
        value.startsWith('🎮')
          ? Text(value, style: const TextStyle(fontSize: 22))
          : Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: color)),
        const SizedBox(height: 3),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, size: 11, color: color.withValues(alpha: 0.7)),
          const SizedBox(width: 3),
          Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: color.withValues(alpha: 0.7))),
        ]),
      ])));
}

// ═══════════════════════════════════════════════════════════
//  Posts & Saved Tab
// ═══════════════════════════════════════════════════════════
class _PostsAndSavedTab extends StatefulWidget {
  final String myUid;
  const _PostsAndSavedTab({required this.myUid});
  @override State<_PostsAndSavedTab> createState() => _PostsAndSavedTabState();
}
class _PostsAndSavedTabState extends State<_PostsAndSavedTab> {
  bool _showSaved = false;
  @override
  Widget build(BuildContext context) => Column(children: [
    Container(color: Colors.white,
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
      child: Row(children: [
        _TabToggle(label: 'My Posts',   icon: Icons.grid_on_rounded,    selected: !_showSaved,
          onTap: () => setState(() => _showSaved = false)),
        const SizedBox(width: 10),
        _TabToggle(label: 'Saved',      icon: Icons.bookmark_rounded,   selected: _showSaved,
          onTap: () => setState(() => _showSaved = true)),
      ])),
    Expanded(child: _showSaved ? _SavedPosts(myUid: widget.myUid) : _MyPosts(myUid: widget.myUid)),
  ]);
}

class _TabToggle extends StatelessWidget {
  final String label; final IconData icon; final bool selected; final VoidCallback onTap;
  const _TabToggle({required this.label, required this.icon, required this.selected, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(onTap: onTap,
    child: AnimatedContainer(duration: const Duration(milliseconds: 200),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: selected ? _kBlue : Colors.grey[100],
        borderRadius: BorderRadius.circular(20)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 14, color: selected ? Colors.white : Colors.grey),
        const SizedBox(width: 6),
        Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700,
          color: selected ? Colors.white : Colors.grey[600])),
      ])));
}

// My Posts grid ───────────────────────────────────────────────────────────────
class _MyPosts extends StatelessWidget {
  final String myUid;
  const _MyPosts({required this.myUid});
  @override
  Widget build(BuildContext context) {
    if (myUid.isEmpty) return const Center(child: ZyloLoader());
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('posts')
          .where('authorId', isEqualTo: myUid).snapshots(),
      builder: (_, snap) {
        if (snap.connectionState == ConnectionState.waiting)
          return const Center(child: ZyloLoader());
        if (snap.hasError) return _EmptyGrid(
          icon: Icons.error_outline, color: Colors.red,
          title: 'Error loading posts', sub: snap.error.toString());
        final docs = snap.data?.docs ?? [];
        // Sort in memory by createdAt descending (avoids Firestore composite index)
        final sorted = List.of(docs)..sort((a, b) {
          final aT = (a.data() as Map)['createdAt'];
          final bT = (b.data() as Map)['createdAt'];
          if (aT == null && bT == null) return 0;
          if (aT == null) return 1;
          if (bT == null) return -1;
          return (bT as dynamic).compareTo(aT as dynamic);
        });
        if (sorted.isEmpty) return _EmptyGrid(
          icon: Icons.grid_on_outlined, color: _kBlue,
          title: 'No posts yet', sub: 'Go to Feed to create your first post',
          imagePath: 'assets/images/no_posts.png');
        return GridView.builder(
          padding: const EdgeInsets.all(2),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3, crossAxisSpacing: 2, mainAxisSpacing: 2),
          itemCount: sorted.length,
          itemBuilder: (_, i) {
            final post = sorted[i].data() as Map<String, dynamic>;
            return _PostGridItem(post: post, postId: sorted[i].id, myUid: myUid, isSaved: false);
          });
      });
  }
}

// ── History Tab — likes, comments, views, saved posts ─────────────────────────
class _HistoryTab extends StatefulWidget {
  final String myUid;
  const _HistoryTab({required this.myUid});
  @override State<_HistoryTab> createState() => _HistoryTabState();
}

class _HistoryTabState extends State<_HistoryTab> with SingleTickerProviderStateMixin {
  late final TabController _tab;
  int _sel = 0;
  static const _blue = Color(0xFF0284C7);

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 4, vsync: this)
      ..addListener(() { if (_tab.indexIsChanging) setState(() => _sel = _tab.index); });
  }
  @override
  void dispose() { _tab.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final labels = ['Saved', 'Liked', 'Commented', 'Viewed'];
    final icons  = [Icons.bookmark_rounded, Icons.favorite_rounded, Icons.chat_bubble_rounded, Icons.visibility_rounded];
    final colors = [Colors.amber[700]!, Colors.red, Colors.green, Colors.blue];

    return Column(children: [
      Container(
        margin: const EdgeInsets.fromLTRB(12, 10, 12, 0),
        height: 38,
        decoration: BoxDecoration(color: const Color(0xFFF1F5F9), borderRadius: BorderRadius.circular(20)),
        child: TabBar(
          controller: _tab,
          indicator: BoxDecoration(
            color: colors[_sel],
            borderRadius: BorderRadius.circular(20),
            boxShadow: [BoxShadow(color: colors[_sel].withValues(alpha: 0.3), blurRadius: 6, offset: const Offset(0, 2))]),
          indicatorSize: TabBarIndicatorSize.tab,
          dividerColor: Colors.transparent,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.grey[800],
          labelStyle: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800),
          tabs: List.generate(4, (i) => Tab(
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(icons[i], size: 12),
              const SizedBox(width: 3),
              Text(labels[i]),
            ])))),
      ),
      Expanded(child: TabBarView(
        controller: _tab,
        children: [
          _HistoryPostList(myUid: widget.myUid, type: 'saved'),
          _HistoryPostList(myUid: widget.myUid, type: 'liked'),
          _HistoryPostList(myUid: widget.myUid, type: 'commented'),
          _HistoryPostList(myUid: widget.myUid, type: 'viewed'),
        ],
      )),
    ]);
  }
}

class _HistoryPostList extends StatelessWidget {
  final String myUid, type;
  const _HistoryPostList({required this.myUid, required this.type});

  @override
  Widget build(BuildContext context) {
    if (myUid.isEmpty) return const Center(child: ZyloLoader());

    final _iconMap = {
      'saved':     [Icons.bookmark_rounded,    Colors.amber[700]!,  'No saved posts',    'Tap 🔖 on posts to save them'],
      'liked':     [Icons.favorite_rounded,     Colors.red,          'No liked posts',    'Tap ❤️ on posts you enjoy'],
      'commented': [Icons.chat_bubble_rounded,  Colors.green,        'No comments yet',   'Comment on posts to see history'],
      'viewed':    [Icons.visibility_rounded,   Colors.blue,         'No viewed posts',   'Posts you\'ve opened will show here'],
    };
    final meta = _iconMap[type]!;

    // Saved: uses savedPosts subcollection
    if (type == 'saved') {
      return StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('users').doc(myUid)
            .collection('savedPosts').orderBy('savedAt', descending: true).snapshots(),
        builder: (_, snap) {
          if (snap.connectionState == ConnectionState.waiting) return const Center(child: ZyloLoader());
          final ids = snap.data?.docs.map((d) => d.id).toList() ?? [];
          if (ids.isEmpty) return _EmptyGrid(icon: meta[0] as IconData, color: meta[1] as Color, title: meta[2] as String, sub: meta[3] as String);
          return _buildGrid(ids, context);
        });
    }

    // Liked: posts where myUid reacted with heart or fire
    if (type == 'liked') {
      return FutureBuilder<List<Map<String, dynamic>>>(
        future: () async {
          final hearts = await FirebaseFirestore.instance.collection('posts')
              .where('reactions_heart', arrayContains: myUid)
              .orderBy('createdAt', descending: true).limit(50).get();
          final fires = await FirebaseFirestore.instance.collection('posts')
              .where('reactions_fire', arrayContains: myUid)
              .orderBy('createdAt', descending: true).limit(50).get();
          final seen = <String>{};
          final result = <Map<String, dynamic>>[];
          for (final d in hearts.docs) {
            if (seen.add(d.id)) result.add({...d.data(), '_postId': d.id, '_myReaction': 'heart'});
          }
          for (final d in fires.docs) {
            if (seen.add(d.id)) result.add({...d.data(), '_postId': d.id, '_myReaction': 'fire'});
          }
          result.sort((a, b) {
            final ta = (a['createdAt'] as dynamic)?.seconds ?? 0;
            final tb = (b['createdAt'] as dynamic)?.seconds ?? 0;
            return (tb as int).compareTo(ta as int);
          });
          return result;
        }(),
        builder: (_, snap) {
          if (!snap.hasData) return const Center(child: ZyloLoader());
          final posts = snap.data ?? [];
          if (posts.isEmpty) return _EmptyGrid(icon: meta[0] as IconData, color: meta[1] as Color, title: meta[2] as String, sub: meta[3] as String);
          return GridView.builder(
            padding: const EdgeInsets.all(2),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3, crossAxisSpacing: 2, mainAxisSpacing: 2),
            itemCount: posts.length,
            itemBuilder: (_, i) {
              final p = posts[i];
              final reaction = p['_myReaction'] as String? ?? 'heart';
              return _PostGridItem(
                post: p, postId: p['_postId'] as String, myUid: myUid,
                isSaved: false, reactionEmoji: reaction == 'heart' ? '❤️' : '🔥');
            });
        });
    }

    // Commented: posts where user has a comment
    if (type == 'commented') {
      return FutureBuilder<List<String>>(
        future: _fetchCommentedPostIds(),
        builder: (_, snap) {
          if (!snap.hasData) return const Center(child: ZyloLoader());
          final ids = snap.data ?? [];
          if (ids.isEmpty) return _EmptyGrid(icon: meta[0] as IconData, color: meta[1] as Color, title: meta[2] as String, sub: meta[3] as String);
          return _buildGrid(ids, context);
        });
    }

    // Viewed: posts where myUid has a view entry
    if (type == 'viewed') {
      return StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('users').doc(myUid)
            .collection('viewedPosts').orderBy('viewedAt', descending: true).limit(50).snapshots(),
        builder: (_, snap) {
          if (snap.connectionState == ConnectionState.waiting) return const Center(child: ZyloLoader());
          final ids = snap.data?.docs.map((d) => d.id).toList() ?? [];
          if (ids.isEmpty) return _EmptyGrid(icon: meta[0] as IconData, color: meta[1] as Color, title: meta[2] as String, sub: meta[3] as String);
          return _buildGrid(ids, context);
        });
    }

    return const SizedBox.shrink();
  }

  Future<List<String>> _fetchCommentedPostIds() async {
    // collectionGroup query for comments by this user
    final snap = await FirebaseFirestore.instance
        .collectionGroup('comments')
        .where('authorId', isEqualTo: myUid)
        .orderBy('createdAt', descending: true)
        .limit(50)
        .get();
    final seen = <String>{};
    return snap.docs
        .map((d) => d.reference.parent.parent?.id ?? '')
        .where((id) => id.isNotEmpty && seen.add(id))
        .toList();
  }

  Widget _buildGrid(List<String> ids, BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(2),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3, crossAxisSpacing: 2, mainAxisSpacing: 2),
      itemCount: ids.length,
      itemBuilder: (_, i) => FutureBuilder<DocumentSnapshot>(
        future: FirebaseFirestore.instance.collection('posts').doc(ids[i]).get(),
        builder: (_, pSnap) {
          if (!pSnap.hasData) return Container(color: Colors.grey[100]);
          final post = pSnap.data?.data() as Map<String, dynamic>? ?? {};
          return _PostGridItem(post: post, postId: ids[i], myUid: myUid, isSaved: type == 'saved');
        }));
  }

  Widget _buildGridFromDocs(List<QueryDocumentSnapshot> docs, BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(2),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3, crossAxisSpacing: 2, mainAxisSpacing: 2),
      itemCount: docs.length,
      itemBuilder: (_, i) {
        final post = docs[i].data() as Map<String, dynamic>? ?? {};
        return _PostGridItem(post: post, postId: docs[i].id, myUid: myUid, isSaved: false);
      });
  }
}

// Saved posts grid (kept for backward compatibility) ──────────────────────────
class _SavedPosts extends StatelessWidget {
  final String myUid;
  const _SavedPosts({required this.myUid});
  @override
  Widget build(BuildContext context) {
    if (myUid.isEmpty) return const Center(child: ZyloLoader());
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('users').doc(myUid)
          .collection('savedPosts').orderBy('savedAt', descending: true).snapshots(),
      builder: (_, snap) {
        if (snap.connectionState == ConnectionState.waiting)
          return const Center(child: ZyloLoader());
        final savedIds = snap.data?.docs.map((d) => d.id).toList() ?? [];
        if (savedIds.isEmpty) return _EmptyGrid(
          icon: Icons.bookmark_outline_rounded, color: Colors.amber,
          title: 'No saved posts', sub: 'Tap 🔖 on any post to save it');
        return GridView.builder(
          padding: const EdgeInsets.all(2),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3, crossAxisSpacing: 2, mainAxisSpacing: 2),
          itemCount: savedIds.length,
          itemBuilder: (_, i) => FutureBuilder<DocumentSnapshot>(
            future: FirebaseFirestore.instance.collection('posts').doc(savedIds[i]).get(),
            builder: (_, pSnap) {
              if (!pSnap.hasData) return Container(color: Colors.grey[100]);
              final post = pSnap.data?.data() as Map<String, dynamic>? ?? {};
              return _PostGridItem(post: post, postId: savedIds[i], myUid: myUid, isSaved: true);
            }));
      });
  }
}

// ── Settings Tab (inline in profile) ─────────────────────────────────────────
class _SettingsTab extends StatelessWidget {
  final VoidCallback onNavigate;
  const _SettingsTab({required this.onNavigate});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.symmetric(vertical: 12),
    children: [
      _SettingsTile(
        icon: Icons.settings_rounded, color: Colors.grey[700]!,
        title: 'All Settings', subtitle: 'Privacy, security, account',
        onTap: onNavigate),
      _SettingsTile(
        icon: Icons.lock_outline_rounded, color: Colors.indigo,
        title: 'Privacy', subtitle: 'Who can see your profile',
        onTap: onNavigate),
      _SettingsTile(
        icon: Icons.notifications_outlined, color: Colors.orange,
        title: 'Notifications', subtitle: 'Manage alerts',
        onTap: onNavigate),
      _SettingsTile(
        icon: Icons.block_rounded, color: Colors.red,
        title: 'Blocked Users', subtitle: 'Manage blocked accounts',
        onTap: onNavigate),
      _SettingsTile(
        icon: Icons.help_outline_rounded, color: Colors.teal,
        title: 'Help & Support', subtitle: 'FAQ, contact us',
        onTap: onNavigate),
    ]);
}

class _SettingsTile extends StatelessWidget {
  final IconData icon; final Color color;
  final String title, subtitle; final VoidCallback onTap;
  const _SettingsTile({required this.icon, required this.color, required this.title, required this.subtitle, required this.onTap});
  @override
  Widget build(BuildContext context) => ListTile(
    leading: Container(width: 40, height: 40,
      decoration: BoxDecoration(color: color.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(12)),
      child: Icon(icon, color: color, size: 20)),
    title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
    subtitle: Text(subtitle, style: TextStyle(fontSize: 12, color: Colors.grey[800])),
    trailing: const Icon(Icons.chevron_right_rounded, color: Colors.grey),
    onTap: onTap);
}

class _EmptyGrid extends StatelessWidget {
  final IconData icon; final Color color; final String title, sub;
  final String? imagePath;
  const _EmptyGrid({required this.icon, required this.color, required this.title, required this.sub, this.imagePath});
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        if (imagePath != null)
          Image.asset(imagePath!, width: 200, height: 200, fit: BoxFit.contain)
        else
          Container(padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(color: color.withValues(alpha: 0.07), shape: BoxShape.circle),
            child: Icon(icon, size: 44, color: color.withValues(alpha: 0.45))),
        const SizedBox(height: 14),
        Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: const Color(0xFF0D1B2A)),
          textAlign: TextAlign.center),
        const SizedBox(height: 6),
        Text(sub, style: TextStyle(color: Colors.grey[800], fontSize: 13), textAlign: TextAlign.center),
      ]),
    ),
  );
}

// Post grid item ───────────────────────────────────────────────────────────────
class _PostGridItem extends StatelessWidget {
  final Map<String, dynamic> post;
  final String postId, myUid;
  final bool isSaved;
  final String? reactionEmoji;
  const _PostGridItem({required this.post, required this.postId, required this.myUid, required this.isSaved, this.reactionEmoji});

  @override
  Widget build(BuildContext context) {
    final images   = (post['images'] as List?)?.cast<String>() ?? [];
    final files    = (post['files']  as List?)?.cast<Map>().map((f) => Map<String, dynamic>.from(f)).toList() ?? [];
    final text     = post['text'] as String? ?? '';
    final likes    = (post['likes'] as List?)?.length ?? 0;
    final isMyPost = (post['authorId'] as String? ?? '') == myUid;

    // First file for grid display (if no image)
    final firstFile = files.isNotEmpty ? files.first : null;
    final fileType  = firstFile?['type'] as String? ?? 'file';

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onLongPress: () => _showOptions(context, isMyPost),
      child: Stack(fit: StackFit.expand, children: [
        images.isNotEmpty
          ? ZyloCachedImage(url: images[0], fit: BoxFit.cover,
              errorWidget: Container(color: Colors.grey.shade100,
                child: const Icon(Icons.broken_image, color: Colors.grey)))
          : firstFile != null
            // File post (audio, doc, apk)
            ? Container(
                color: _fileGridColor(fileType).withValues(alpha: 0.1),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(_fileGridIcon(fileType), color: _fileGridColor(fileType), size: 28),
                  const SizedBox(height: 4),
                  Padding(padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: Text(firstFile['name'] as String? ?? fileType,
                      style: TextStyle(fontSize: 7, color: _fileGridColor(fileType), fontWeight: FontWeight.w700),
                      textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis)),
                ]))
            : Container(color: const Color(0xFFEFF6FF), padding: const EdgeInsets.all(6),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Icon(Icons.article_outlined, color: _kBlue, size: 20),
                  const SizedBox(height: 3),
                  Text(text.length > 35 ? '${text.substring(0, 35)}...' : text,
                    style: const TextStyle(fontSize: 8, color: Colors.black54),
                    textAlign: TextAlign.center, maxLines: 4, overflow: TextOverflow.ellipsis),
                ])),

        // Gradient overlay
        Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [Colors.transparent, Colors.black.withValues(alpha: 0.42)])))),

        // Like count
        Positioned(bottom: 5, left: 5, child: Row(children: [
          const Icon(Icons.favorite, size: 11, color: Colors.white),
          const SizedBox(width: 2),
          Text('$likes', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700)),
        ])),

        // Reaction emoji badge (shown in Liked history)
        if (reactionEmoji != null)
          Positioned(bottom: 4, right: 4,
            child: Container(
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.45),
                borderRadius: BorderRadius.circular(8)),
              child: Text(reactionEmoji!, style: const TextStyle(fontSize: 12)))),

        // Saved badge
        if (isSaved)
          Positioned(top: 4, right: 4,
            child: Container(padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(color: Colors.amber.withValues(alpha: 0.9), shape: BoxShape.circle),
              child: const Icon(Icons.bookmark_rounded, size: 10, color: Colors.white))),

        if (images.length > 1 || files.length > 1)
          Positioned(top: 4, left: 4,
            child: Icon(Icons.collections_rounded, size: 14, color: Colors.white.withValues(alpha: 0.9))),
      ]),
    );
  }

  void _showOptions(BuildContext ctx, bool isMyPost) {
    HapticFeedback.mediumImpact();
    showModalBottomSheet(
      context: ctx, backgroundColor: Colors.transparent,
      builder: (_) => Container(
        decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4,
            decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
          const SizedBox(height: 16),
          if (isMyPost) ...[
            // Edit Post
            ListTile(
              leading: Container(padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: const Color(0xFF0284C7).withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.edit_rounded, color: Color(0xFF0284C7), size: 20)),
              title: const Text('Edit Post', style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text('Edit text of your post', style: TextStyle(fontSize: 12)),
              onTap: () { Navigator.pop(ctx); _showEditPostSheet(ctx); },
            ),
            // Analytics
            ListTile(
              leading: Container(padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: Colors.purple.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.bar_chart_rounded, color: Colors.purple, size: 20)),
              title: const Text('Analytics', style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text('Views, likes, shares & more', style: TextStyle(fontSize: 12)),
              onTap: () { Navigator.pop(ctx); _showAnalyticsDialog(ctx); },
            ),
            const Divider(),
            // Delete
            ListTile(
              leading: Container(padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: Colors.red.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.delete_outline, color: Colors.red, size: 20)),
              title: const Text('Delete Post', style: TextStyle(fontWeight: FontWeight.w700, color: Colors.red)),
              subtitle: const Text('Permanently remove this post', style: TextStyle(fontSize: 12, color: Colors.red)),
              onTap: () {
                Navigator.pop(ctx);
                showDialog(context: ctx, builder: (_) => AlertDialog(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  title: const Text('Delete Post?', style: TextStyle(fontWeight: FontWeight.w900)),
                  content: const Text('This will permanently delete your post.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                      onPressed: () { Navigator.pop(ctx); FirebaseFirestore.instance.collection('posts').doc(postId).delete(); },
                      child: const Text('Delete')),
                  ]));
              }),
          ] else ...[
            if (isSaved)
              ListTile(
                leading: const Icon(Icons.bookmark_remove_rounded, color: Colors.orange),
                title: const Text('Remove from Saved', style: TextStyle(fontWeight: FontWeight.w700)),
                onTap: () {
                  Navigator.pop(ctx);
                  FirebaseFirestore.instance.collection('users').doc(myUid)
                      .collection('savedPosts').doc(postId).delete();
                }),
          ],
        ])));
  }

  void _showEditPostSheet(BuildContext ctx) {
    final images = (post['images'] as List?)?.cast<String>() ?? [];
    final textCtrl = TextEditingController(text: post['text'] as String? ?? '');
    showModalBottomSheet(
      context: ctx, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (bCtx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(bCtx).viewInsets.bottom),
        child: Container(
          decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(width: 40, height: 4,
              decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10)))),
            const SizedBox(height: 16),
            const Row(children: [
              Icon(Icons.edit_rounded, color: Color(0xFF0284C7), size: 22),
              SizedBox(width: 8),
              Text('Edit Post', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
            ]),
            const SizedBox(height: 16),
            // Show images (read-only preview)
            if (images.isNotEmpty) ...[
              Container(
                height: 90,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: images.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (_, i) => Stack(children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: ColorFiltered(
                        colorFilter: ColorFilter.mode(Colors.black.withValues(alpha: 0.18), BlendMode.darken),
                        child: ZyloCachedImage(url: images[i], width: 90, height: 90, fit: BoxFit.cover))),
                    Positioned.fill(child: Center(child:
                      Icon(Icons.lock_outline_rounded, color: Colors.white.withValues(alpha: 0.85), size: 22))),
                  ])),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF8E1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFFFFCC02).withValues(alpha: 0.5))),
                child: const Row(children: [
                  Icon(Icons.image_not_supported_outlined, size: 14, color: Color(0xFF92661A)),
                  SizedBox(width: 6),
                  Expanded(child: Text(
                    'Images cannot be changed after posting. Only the caption is editable.',
                    style: TextStyle(fontSize: 11, color: Color(0xFF92661A), height: 1.4))),
                ])),
              const SizedBox(height: 12),
            ],
            // Editable text
            Container(
              decoration: BoxDecoration(color: const Color(0xFFF8FAFD), borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.grey[200]!)),
              child: TextField(
                controller: textCtrl, maxLines: 5, minLines: 3,
                decoration: const InputDecoration(
                  hintText: 'What\'s on your mind?',
                  border: InputBorder.none, contentPadding: EdgeInsets.all(14)),
              )),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(child: GestureDetector(
                onTap: () => Navigator.pop(bCtx),
                child: Container(height: 48,
                  decoration: BoxDecoration(color: Colors.grey[100], borderRadius: BorderRadius.circular(14)),
                  child: const Center(child: Text('Cancel', style: TextStyle(fontWeight: FontWeight.w700, color: Colors.grey)))))),
              const SizedBox(width: 12),
              Expanded(child: GestureDetector(
                onTap: () async {
                  final newText = textCtrl.text.trim();
                  if (newText.isNotEmpty) {
                    await FirebaseFirestore.instance.collection('posts').doc(postId).update(
                      {'text': newText, 'editedAt': FieldValue.serverTimestamp()});
                  }
                  Navigator.pop(bCtx);
                },
                child: Container(height: 48,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFF0284C7), Color(0xFF6366F1)]),
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [BoxShadow(color: const Color(0xFF0284C7).withValues(alpha: 0.3), blurRadius: 8, offset: const Offset(0, 3))]),
                  child: const Center(child: Text('Save Changes', style: TextStyle(fontWeight: FontWeight.w800, color: Colors.white, fontSize: 15)))))),
            ]),
            const SizedBox(height: 8),
          ]),
        ),
      ));
  }

  void _showAnalyticsDialog(BuildContext ctx) {
    showDialog(
      context: ctx,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        backgroundColor: Colors.white,
        child: StreamBuilder<DocumentSnapshot>(
          stream: FirebaseFirestore.instance.collection('posts').doc(postId).snapshots(),
          builder: (_, snap) {
            final data     = snap.data?.data() as Map<String, dynamic>? ?? post;
            final likes    = (data['likes']   as List?)?.length ?? 0;
            final views    = data['views']    ?? 0;
            final shares   = data['shares']   ?? 0;
            final comments = data['comments'] ?? 0;
            final reposts  = data['reposts']  ?? 0;
            final reach    = views > 0 ? '${((likes / views) * 100).toStringAsFixed(1)}%' : '0%';
            return Padding(
              padding: const EdgeInsets.all(24),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                // Header
                Row(children: [
                  Container(padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [Color(0xFF7C3AED), Color(0xFF9333EA)]),
                      borderRadius: BorderRadius.circular(14)),
                    child: const Icon(Icons.bar_chart_rounded, color: Colors.white, size: 22)),
                  const SizedBox(width: 12),
                  const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Post Analytics', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                    Text('Real-time insights', style: TextStyle(fontSize: 12, color: Colors.grey)),
                  ])),
                  IconButton(
                    onPressed: () => Navigator.pop(ctx),
                    icon: Container(padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(color: Colors.grey[100], shape: BoxShape.circle),
                      child: const Icon(Icons.close_rounded, size: 18, color: Colors.black54))),
                ]),
                const SizedBox(height: 20),
                // Stats grid
                GridView.count(
                  crossAxisCount: 3, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.1,
                  children: [
                    _ProfileAnalyticTile(icon: Icons.visibility_rounded,   label: 'Views',    value: '$views',   color: Colors.blue),
                    _ProfileAnalyticTile(icon: Icons.favorite_rounded,      label: 'Likes',    value: '$likes',   color: Colors.red),
                    _ProfileAnalyticTile(icon: Icons.chat_bubble_rounded,   label: 'Comments', value: '$comments', color: Colors.green),
                    _ProfileAnalyticTile(icon: Icons.share_rounded,         label: 'Shares',   value: '$shares',  color: Colors.purple),
                    _ProfileAnalyticTile(icon: Icons.repeat_rounded,        label: 'Reposts',  value: '$reposts', color: Colors.orange),
                    _ProfileAnalyticTile(icon: Icons.trending_up_rounded,   label: 'Reach',    value: reach,      color: Colors.teal),
                  ]),
                const SizedBox(height: 16),
                // Insight tip
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.purple.withValues(alpha: 0.06),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.purple.withValues(alpha: 0.15))),
                  child: Row(children: [
                    const Icon(Icons.lightbulb_outline, color: Colors.purple, size: 16),
                    const SizedBox(width: 8),
                    Expanded(child: Text(
                      views > 50 ? '🚀 Great reach! Keep posting at this time.' : '📈 Post consistently to grow your reach.',
                      style: const TextStyle(fontSize: 12, color: Colors.purple, fontWeight: FontWeight.w600))),
                  ])),
                const SizedBox(height: 4),
              ]));
          })));
  }
}

// Lazy import to avoid circular reference
class _ViewProfile extends StatelessWidget {
  final String uid;
  const _ViewProfile({required this.uid});
  @override
  Widget build(BuildContext context) {
    return ViewProfileScreen(targetUid: uid);
  }
}

// ═══════════════════════════════════════════════════════════
//  Profile Viewers Sheet
// ═══════════════════════════════════════════════════════════
class _ProfileViewersSheet extends StatelessWidget {
  final String myUid;
  const _ProfileViewersSheet({required this.myUid});
  @override
  Widget build(BuildContext context) => Container(
    height: MediaQuery.of(context).size.height * 0.6,
    decoration: const BoxDecoration(color: Colors.white,
      borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    child: StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance.collection('users').doc(myUid).snapshots(),
      builder: (_, snap) {
        final data     = snap.data?.data() as Map<String, dynamic>? ?? {};
        final viewers  = (data['profileViewers'] as List? ?? []).cast<String>();
        final total    = data['profileViews'] ?? 0;
        return Column(children: [
          _SheetHandle(),
          _SheetTitle(Icons.visibility_rounded, '$total Profile Views', Colors.orange),
          const Divider(height: 1),
          if (viewers.isEmpty)
            const Expanded(child: Center(child: Text('No viewers yet',
              style: TextStyle(color: Colors.grey))))
          else Expanded(child: FutureBuilder<QuerySnapshot>(
            future: FirebaseFirestore.instance.collection('users')
                .where(FieldPath.documentId, whereIn: viewers.take(10).toList()).get(),
            builder: (_, uSnap) {
              if (!uSnap.hasData) return const Center(child: ZyloLoader());
              return ListView.builder(padding: const EdgeInsets.all(12),
                itemCount: uSnap.data!.docs.length,
                itemBuilder: (_, i) {
                  final u = uSnap.data!.docs[i].data() as Map<String, dynamic>;
                  return _UserTile(u);
                });
            })),
        ]);
      }));
}

// ── Shared small widgets ──────────────────────────────────────────────────────
class _SheetHandle extends StatelessWidget {
  @override Widget build(BuildContext context) => Container(
    width: 40, height: 4, margin: const EdgeInsets.symmetric(vertical: 10),
    decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10)));
}

class _SheetTitle extends StatelessWidget {
  final IconData icon; final String title; final Color color;
  const _SheetTitle(this.icon, this.title, this.color);
  @override Widget build(BuildContext context) =>
    Padding(padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
      child: Row(children: [
        Container(padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: color.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
          child: Icon(icon, color: color, size: 20)),
        const SizedBox(width: 10),
        Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
      ]));
}

class _UserTile extends StatelessWidget {
  final Map<String, dynamic> data;
  const _UserTile(this.data);
  @override Widget build(BuildContext context) {
    final photo    = data['photoURL'] as String? ?? '';
    final name     = data['username'] as String? ?? '?';
    final isOnline = data['isOnline'] == true;
    return ListTile(
      leading: Stack(children: [
        ZyloAvatar(
          photoUrl: photo.isNotEmpty ? photo : null,
          radius: 22,
        ),
        if (isOnline) Positioned(bottom: 0, right: 0,
          child: Container(width: 11, height: 11,
            decoration: BoxDecoration(color: _kGreen, shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 2)))),
      ]),
      title: Text('@$name', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
      subtitle: Text(isOnline ? 'Active now' : 'Offline',
        style: TextStyle(color: isOnline ? _kGreen : Colors.grey[600], fontSize: 12)));
  }
}

Widget _BigStat(String val, String label, Color color) =>
  Expanded(child: Column(children: [
    Text(val, style: TextStyle(color: color, fontSize: 22, fontWeight: FontWeight.w900)),
    const SizedBox(height: 3),
    Text(label, style: const TextStyle(color: Colors.grey, fontSize: 10)),
  ]));

Widget _Pill(String text, Color color) => Container(
  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
  decoration: BoxDecoration(color: color.withValues(alpha: 0.1),
    borderRadius: BorderRadius.circular(8),
    border: Border.all(color: color.withValues(alpha: 0.3))),
  child: Text(text, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w700)));

// ── Profile Analytics Tile ────────────────────────────────────────────────────
class _ProfileAnalyticTile extends StatelessWidget {
  final IconData icon;
  final String label, value;
  final Color color;
  const _ProfileAnalyticTile({required this.icon, required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(color: color.withValues(alpha: 0.07), borderRadius: BorderRadius.circular(14),
      border: Border.all(color: color.withValues(alpha: 0.15))),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Container(width: 34, height: 34,
        decoration: BoxDecoration(color: color.withValues(alpha: 0.13), shape: BoxShape.circle),
        child: Icon(icon, color: color, size: 17)),
      const SizedBox(height: 5),
      Text(value, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15, color: color)),
      Text(label, style: const TextStyle(fontSize: 9, color: Colors.grey, fontWeight: FontWeight.w600)),
    ]));
}

// ── Following Sheet ─────────────────────────────────────────────────────────
void _showFollowersSheet(BuildContext context, String myUid) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => _FollowersSheet(myUid: myUid),
  );
}

class _FollowersSheet extends StatelessWidget {
  final String myUid;
  const _FollowersSheet({required this.myUid});

  static const _purple = Color(0xFF7C3AED);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.80,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: Column(children: [
        Container(margin: const EdgeInsets.only(top: 10), width: 40, height: 4,
          decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),

        Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
          child: StreamBuilder<int>(
            stream: FirestoreService().followersCountStream(myUid),
            builder: (_, snap) {
              final count = snap.data ?? 0;
              return Row(children: [
                Container(width: 42, height: 42,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF7C3AED), Color(0xFFA855F7)],
                      begin: Alignment.topLeft, end: Alignment.bottomRight),
                    shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: _purple.withValues(alpha: 0.3),
                        blurRadius: 10, offset: const Offset(0, 4))]),
                  child: const Center(child: Icon(Icons.people_rounded, color: Colors.white, size: 22))),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Followers',
                    style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: _purple)),
                  Text('$count people follow you',
                    style: TextStyle(fontSize: 12, color: Colors.grey[800])),
                ])),
              ]);
            },
          ),
        ),

        const SizedBox(height: 12),

        Expanded(
          child: StreamBuilder<List<Map<String, dynamic>>>(
            stream: FirestoreService().myFollowersWithDataStream(),
            builder: (_, snap) {
              if (snap.connectionState == ConnectionState.waiting) {
                return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const CircularProgressIndicator(color: _purple, strokeWidth: 2),
                  const SizedBox(height: 12),
                  Text('Loading followers…',
                    style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                ]));
              }
              final members = snap.data ?? [];
              if (members.isEmpty) {
                return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Container(width: 72, height: 72,
                    decoration: BoxDecoration(
                      color: _purple.withValues(alpha: 0.07), shape: BoxShape.circle),
                    child: const Icon(Icons.people_outline_rounded, size: 32, color: _purple)),
                  const SizedBox(height: 14),
                  const Text('No followers yet',
                    style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                  const SizedBox(height: 6),
                  Text('Share your profile to get followers.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                ]));
              }
              return ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                itemCount: members.length,
                itemBuilder: (ctx, i) {
                  final m = members[i];
                  final name = m['username'] as String? ?? '';
                  final photo = m['photoURL'] as String? ?? '';
                  final uid = m['uid'] as String? ?? '';
                  return ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                    onTap: uid.isNotEmpty ? () => Navigator.push(ctx, MaterialPageRoute(
                        builder: (_) => ViewProfileScreen(targetUid: uid))) : null,
                    leading: GestureDetector(
                      onTap: uid.isNotEmpty ? () => Navigator.push(ctx, MaterialPageRoute(
                          builder: (_) => ViewProfileScreen(targetUid: uid))) : null,
                      child: ZyloAvatar(
                        photoUrl: photo.isNotEmpty ? photo : null,
                        radius: 22,
                      ),
                    ),
                    title: Text('@$name',
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                  );
                },
              );
            },
          ),
        ),
      ]),
    );
  }
}

void _showFollowingSheet(BuildContext context, String myUid) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => _FollowingSheet(myUid: myUid),
  );
}

class _FollowingSheet extends StatelessWidget {
  final String myUid;
  const _FollowingSheet({required this.myUid});

  static const _purple = Color(0xFF0284C7);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.80,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: Column(children: [
        // ── Handle ────────────────────────────────────────────────────────
        Container(margin: const EdgeInsets.only(top: 10), width: 40, height: 4,
          decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),

        // ── Header ────────────────────────────────────────────────────────
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
          child: StreamBuilder<int>(
            stream: FirestoreService().followingCountStream(),
            builder: (_, snap) {
              final count = snap.data ?? 0;
              const double pct = 0; // unused
              const bool isFull = false;
              return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Container(width: 42, height: 42,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF0284C7), Color(0xFF0EA5E9)],
                        begin: Alignment.topLeft, end: Alignment.bottomRight),
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: _purple.withValues(alpha: 0.3),
                          blurRadius: 10, offset: const Offset(0, 4))]),
                    child: const Center(child: Icon(Icons.people_alt_rounded, color: Colors.white, size: 22))),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Following',
                      style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: _purple)),
                    Text(
                      '$count people you follow',
                      style: TextStyle(fontSize: 12, color: Colors.grey[800])),
                  ])),
                ]),

              ]);
            },
          ),
        ),

        // ── Explainer card ─────────────────────────────────────────────────
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _purple.withValues(alpha: 0.05),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _purple.withValues(alpha: 0.15)),
            ),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.info_outline_rounded, size: 16, color: _purple.withValues(alpha: 0.7)),
              const SizedBox(width: 10),
              Expanded(child: Text(
                "People you follow will appear here. Follow someone from their profile.",
                style: TextStyle(fontSize: 12, color: Colors.grey[600], height: 1.5),
              )),
            ]),
          ),
        ),

        const SizedBox(height: 12),

        // ── Member list (rich — uses bulk fetch stream) ─────────────────────
        Expanded(
          child: StreamBuilder<List<Map<String, dynamic>>>(
            stream: FirestoreService().myFollowingWithDataStream(),
            builder: (_, snap) {
              if (snap.connectionState == ConnectionState.waiting) {
                return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const CircularProgressIndicator(color: _purple, strokeWidth: 2),
                  const SizedBox(height: 12),
                  Text('Loading members…',
                    style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                ]));
              }
              final members = snap.data ?? [];
              if (members.isEmpty) {
                return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Container(width: 72, height: 72,
                    decoration: BoxDecoration(
                      color: _purple.withValues(alpha: 0.07), shape: BoxShape.circle),
                    child: const Icon(Icons.person_add_alt_1_rounded, size: 32, color: _purple)),
                  const SizedBox(height: 14),
                  const Text('Not following anyone yet',
                    style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: const Color(0xFF0D1B2A))),
                  const SizedBox(height: 6),
                  Text("Go to someone's profile and tap Follow.",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12, color: Colors.grey[800], height: 1.5)),
                ]));
              }
              return ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                itemCount: members.length,
                itemBuilder: (ctx, i) => _FollowingMemberTile(
                  member: members[i], myUid: myUid),
              );
            },
          ),
        ),
      ]),
    );
  }
}

// ── Member Tile (uses pre-fetched data — no extra Firestore reads) ─────────────
class _FollowingMemberTile extends StatefulWidget {
  final Map<String, dynamic> member;
  final String myUid;
  const _FollowingMemberTile({required this.member, required this.myUid});
  @override State<_FollowingMemberTile> createState() => _FollowingMemberTileState();
}

class _FollowingMemberTileState extends State<_FollowingMemberTile> {
  static const _purple = Color(0xFF0284C7);
  bool _removing = false;

  String _formatFollowedAt(dynamic ts) {
    if (ts == null) return 'Recently added';
    try {
      final dt = (ts as dynamic).toDate() as DateTime;
      final diff = DateTime.now().difference(dt);
      if (diff.inDays == 0) return 'Followed today';
      if (diff.inDays == 1) return 'Followed yesterday';
      if (diff.inDays < 7)  return 'Followed ${diff.inDays}d ago';
      if (diff.inDays < 30) return 'Followed ${(diff.inDays / 7).floor()}w ago';
      return 'Followed ${(diff.inDays / 30).floor()}mo ago';
    } catch (_) { return 'Recently followed'; }
  }

  @override
  Widget build(BuildContext context) {
    final name     = widget.member['username'] as String? ?? '…';
    final photo    = widget.member['photoURL']  as String? ?? '';
    final addedAt  = widget.member['followedAt'];

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF0284C7).withValues(alpha: 0.08)),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: Row(children: [
        // Avatar with purple ring — tappable to open profile
        GestureDetector(
          onTap: () {
            final uid = widget.member['uid'] as String? ?? '';
            if (uid.isNotEmpty) Navigator.push(context, MaterialPageRoute(
              builder: (_) => ViewProfileScreen(targetUid: uid)));
          },
          child: Container(
            padding: const EdgeInsets.all(2),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [Color(0xFF7C3AED), Color(0xFF9333EA)],
                begin: Alignment.topLeft, end: Alignment.bottomRight),
            ),
            child: ZyloAvatar(
              photoUrl: photo.isNotEmpty ? photo : null,
              radius: 21,
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('@$name',
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14, color: const Color(0xFF0D1B2A))),
          const SizedBox(height: 2),
          Row(children: [
            Icon(Icons.access_time_rounded, size: 10, color: Colors.grey[600]),
            const SizedBox(width: 3),
            Text(_formatFollowedAt(addedAt),
              style: TextStyle(fontSize: 10, color: Colors.grey[600])),
          ]),
        ])),
        // Remove button with loading state
        _removing
          ? const SizedBox(
              width: 24, height: 24,
              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.red))
          : GestureDetector(
              onTap: () => _remove(context, name),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(
                  color: Colors.red.withValues(alpha: 0.06),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.red.withValues(alpha: 0.25)),
                ),
                child: const Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.person_remove_outlined, size: 13, color: Colors.red),
                  SizedBox(width: 4),
                  Text('Unfollow',
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.red)),
                ]),
              ),
            ),
      ]),
    );
  }

  Future<void> _remove(BuildContext ctx, String name) async {
    final confirm = await showDialog<bool>(
      context: ctx,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(children: [
          Container(width: 36, height: 36,
            decoration: BoxDecoration(color: Colors.red.withValues(alpha: 0.1), shape: BoxShape.circle),
            child: const Icon(Icons.remove_circle_outline_rounded, color: Colors.red, size: 20)),
          const SizedBox(width: 10),
          const Expanded(child: Text('Remove from Circle?',
            style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
        ]),
        content: RichText(text: TextSpan(
          style: const TextStyle(fontSize: 13, color: const Color(0xFF0D1B2A), height: 1.5),
          children: [
            TextSpan(text: '@$name', style: const TextStyle(fontWeight: FontWeight.w800)),
            const TextSpan(text: ' will be removed from your following list.'),
          ],
        )),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text('Cancel', style: TextStyle(color: Colors.grey[600]))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
              elevation: 0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Unfollow', style: TextStyle(fontWeight: FontWeight.w700))),
        ],
      ),
    );
    if (confirm == true && mounted) {
      setState(() => _removing = true);
      try {
        await FirestoreService().unfollowUser(widget.member['uid'] as String);
      } catch (_) {}
      if (ctx.mounted) {
        ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
          content: Row(children: [
            const Text('⚫', style: TextStyle(fontSize: 16)),
            const SizedBox(width: 8),
            Text('Unfollowed @$name',
              style: const TextStyle(fontWeight: FontWeight.w600)),
          ]),
          backgroundColor: Colors.grey[800],
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.all(16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))));
      }
    }
  }
}
