import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/auth_service.dart';
import '../theme.dart';
import '../services/cache_service.dart';
import 'auth/login_screen.dart';
import 'profile/view_profile_screen.dart';

import 'admin/admin_panel_screen.dart';
import 'storage/file_manager_screen.dart';
import 'privacy_policy_screen.dart';
import '../widgets/zylo_avatar.dart';
import 'chat/saved_messages_screen.dart';
import 'zylo_guide_screen.dart';
import 'problem_report_screen.dart';
import '../services/accent_theme_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  static const _blue  = Color(0xFF0284C7);
  static const _kBg   = Color(0xFFF2F2F7);

  bool _notifMessages   = true;
  bool _notifLikes      = true;
  bool _notifFollows    = true;
  bool _notifStories    = true;
  bool _notifCalls      = true;
  bool _readReceipts    = true;
  bool _typingIndicator = true;
  bool _isPublic   = true;
  bool _showOnline = true;
  bool _showLastSeen = true;
  bool _loadingPrefs = true;
  bool _isAdmin = false;

  final _searchCtrl = TextEditingController();
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _loadPrefs();
    _searchCtrl.addListener(() => setState(() => _searchQuery = _searchCtrl.text.toLowerCase()));
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadPrefs() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) { setState(() => _loadingPrefs = false); return; }
    final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
    final d = doc.data() ?? {};
    final notif = d['notifPrefs'] as Map<String, dynamic>? ?? {};
    final chat  = d['chatPrefs']  as Map<String, dynamic>? ?? {};
    setState(() {
      _notifMessages   = notif['messages']   != false;
      _notifLikes      = notif['likes']      != false;
      _notifFollows    = notif['follows']    != false;
      _notifStories    = notif['stories']    != false;
      _notifCalls      = notif['calls']      != false;
      _readReceipts    = chat['readReceipts']    != false;
      _typingIndicator = chat['typingIndicator'] != false;
      _isPublic        = d['isPublic']    != false;
      _showOnline      = d['showOnline']  != false;
      _showLastSeen    = d['showLastSeen'] != false;
      _isAdmin         = d['isAdmin'] == true || d['isAdmin'] == 'true';
      _loadingPrefs    = false;
    });
  }

  Future<void> _savePrefs() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    await FirebaseFirestore.instance.collection('users').doc(uid).update({
      'notifPrefs': {'messages': _notifMessages, 'likes': _notifLikes, 'follows': _notifFollows, 'stories': _notifStories, 'calls': _notifCalls},
      'chatPrefs': {'readReceipts': _readReceipts, 'typingIndicator': _typingIndicator},
      'isPublic': _isPublic,
      'showOnline': _showOnline,
      'showLastSeen': _showLastSeen,
    });
  }

  @override
  Widget build(BuildContext context) {
    final authService = Provider.of<AuthService>(context);
    final uid = authService.user?.uid ?? '';
    return Scaffold(
      backgroundColor: _kBg,
      appBar: AppBar(
        title: const Text('Settings', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black)),
        backgroundColor: Colors.white, elevation: 0, centerTitle: true,
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: Colors.black87), onPressed: () => Navigator.pop(context)),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(52),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: TextField(
              controller: _searchCtrl,
              decoration: InputDecoration(
                hintText: 'Search settings...',
                hintStyle: TextStyle(color: Colors.grey[400], fontSize: 14),
                prefixIcon: const Icon(Icons.search_rounded, color: Colors.grey, size: 20),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.close_rounded, size: 18, color: Colors.grey),
                        onPressed: () => _searchCtrl.clear(),
                      )
                    : null,
                filled: true,
                fillColor: const Color(0xFFF2F2F7),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 0),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: _blue.withValues(alpha: 0.4), width: 1.5)),
              ),
            ),
          ),
        ),
      ),
      body: _loadingPrefs
          ? const Center(child: ZyloLoader())
          : _searchQuery.isNotEmpty
              ? _buildSearchResults(authService, uid)
              : ListView(children: [
              const SizedBox(height: 20),
              _buildProfileTile(authService),

              if (_isAdmin) ...[
                const SizedBox(height: 20),
                _sectionLabel('Admin'),
                _buildSection([_Tile(icon: Icons.admin_panel_settings, color: const Color(0xFFFFBB35), title: 'Admin Panel', subtitle: 'Manage users, posts & app',
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminPanelScreen())))]),
              ],

              const SizedBox(height: 20),
              _sectionLabel('Account'),
              _buildSection([
                _Tile(icon: Icons.person_outline, color: _blue, title: 'My Profile', subtitle: 'View your public profile',
                    onTap: uid.isNotEmpty ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => ViewProfileScreen(targetUid: uid))) : null),
                _Tile(icon: Icons.bookmark_rounded, color: const Color(0xFF0284C7), title: 'Saved Messages', subtitle: 'Messages you bookmarked',
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SavedMessagesScreen()))),
                _Tile(icon: Icons.lock_outline, color: const Color(0xFF8B5CF6), title: 'Change Password', subtitle: 'Update your password',
                    onTap: () => _showChangePasswordSheet(context, authService)),
              ]),

              const SizedBox(height: 20),
              _sectionLabel('Appearance'),
              _buildSection([
                _AccentColorPicker(),
              ]),

              const SizedBox(height: 20),
              _sectionLabel('Notifications'),
              _buildSection([
                _sw(Icons.chat_bubble_outline, Colors.blue, 'Messages', 'New message alerts', _notifMessages, (v) { setState(() => _notifMessages = v); _savePrefs(); }),
                _sw(Icons.favorite_outline, Colors.red, 'Likes & Comments', 'Post interactions', _notifLikes, (v) { setState(() => _notifLikes = v); _savePrefs(); }),
                _sw(Icons.person_add_outlined, Colors.green, 'Inner Circle', 'When someone adds you to their circle', _notifFollows, (v) { setState(() => _notifFollows = v); _savePrefs(); }),
                _sw(Icons.auto_stories_outlined, Colors.orange, 'Stories', 'Coming soon', _notifStories, (v) { setState(() => _notifStories = v); _savePrefs(); }),
                _sw(Icons.call_outlined, Colors.teal, 'Calls', 'Coming soon', _notifCalls, (v) { setState(() => _notifCalls = v); _savePrefs(); }),
              ]),

              const SizedBox(height: 20),
              _sectionLabel('Privacy'),
              _buildSection([
                _sw(Icons.public, Colors.blue, 'Public Account', 'Anyone can see your profile', _isPublic, (v) { setState(() => _isPublic = v); _savePrefs(); }),
                _sw(Icons.circle, Colors.green, 'Show Online Status', "Friends can see when you're active", _showOnline, (v) { setState(() => _showOnline = v); _savePrefs(); }),
                _sw(Icons.access_time, Colors.grey, 'Last Seen', 'Show when you were last active', _showLastSeen, (v) { setState(() => _showLastSeen = v); _savePrefs(); }),
                _Tile(icon: Icons.block_rounded, color: Colors.red, title: 'Blocked Users', subtitle: 'Manage blocked accounts',
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BlockedUsersScreen(myUid: uid)))),
                _Tile(icon: Icons.timer_outlined, color: Colors.deepOrange, title: 'Disappearing Messages', subtitle: 'Auto-delete messages after a time',
                    onTap: () => _showDisappearingSheet(context, uid)),
              ]),

              const SizedBox(height: 20),
              _sectionLabel('Chats'),
              _buildSection([
                _sw(Icons.done_all, _blue, 'Read Receipts', 'Show blue ticks when message is read', _readReceipts, (v) { setState(() => _readReceipts = v); _savePrefs(); }),
                _sw(Icons.keyboard_outlined, Colors.indigo, 'Typing Indicator', 'Show "typing..." to others', _typingIndicator, (v) { setState(() => _typingIndicator = v); _savePrefs(); }),
              ]),




              const SizedBox(height: 20),
              _sectionLabel('Safety'),
              _buildSection([
                _Tile(icon: Icons.cloud_rounded, color: const Color(0xFF7C3AED), title: 'Zylo Storage', subtitle: 'Upload & download big files securely',
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FileManagerScreen()))),
              ]),

              _buildSection([
                _Tile(icon: Icons.flag_outlined, color: Colors.deepOrange, title: 'Report a Problem', subtitle: 'Send feedback or report an issue',
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProblemReportScreen()))),
                _Tile(icon: Icons.shield_outlined, color: Colors.blue, title: 'Privacy Policy',
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivacyPolicyScreen(fromSettings: true)))),
              ]),

              const SizedBox(height: 20),
              _sectionLabel('Support'),
              _buildSection([
                _Tile(icon: Icons.menu_book_rounded, color: const Color(0xFF0284C7), title: 'How Zylo Works', subtitle: 'App guide, Follow System & Storage explained',
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ZyloGuideScreen(isNewUser: false)))),
                _Tile(icon: Icons.help_outline, color: Colors.orange, title: 'Help Center', subtitle: 'Get help & FAQs', onTap: () => _showHelpCenter(context)),
                _Tile(icon: Icons.info_outline, color: Colors.grey, title: 'About zylo.pages', subtitle: 'Version 1.5.0', onTap: () => _showAbout(context)),
              ]),

              const SizedBox(height: 20),
              _sectionLabel('Developer'),
              _buildOwnerCard(),

              const SizedBox(height: 20),
              _sectionLabel('Contact Us'),
              _buildSection([
                _Tile(
                  icon: Icons.email_outlined,
                  color: const Color(0xFFEA4335),
                  title: 'Email Support',
                  subtitle: 'zylopages@gmail.com',
                  onTap: () async {
                    final uri = Uri(scheme: 'mailto', path: 'zylopages@gmail.com',
                      queryParameters: {'subject': 'zylo.pages Support'});
                    if (await canLaunchUrl(uri)) await launchUrl(uri);
                  },
                ),
                _Tile(
                  icon: Icons.chat_rounded,
                  color: const Color(0xFF25D366),
                  title: 'WhatsApp Support',
                  subtitle: '+91 95967 22619',
                  onTap: () async {
                    final uri = Uri.parse('https://wa.me/919596722619?text=Hi%20zylo.pages%20support!');
                    if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
                  },
                ),
              ]),

              const SizedBox(height: 20),
              _sectionLabel('Danger Zone'),
              _buildSection([
                _Tile(icon: Icons.delete_forever_outlined, color: Colors.red, title: 'Delete Account', subtitle: 'Permanently remove your account',
                    onTap: () => _confirmDeleteAccount(context, authService), textColor: Colors.red),
              ]),

              const SizedBox(height: 20),
              _buildClearCacheButton(context),
              const SizedBox(height: 8),
              _buildLogoutButton(context, authService),
              const SizedBox(height: 24),
              Column(children: [
                Text('zylo.pages v1.5.0', style: TextStyle(color: Colors.grey[400], fontSize: 12, fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Icon(Icons.code, size: 13, color: Colors.grey),
                  const SizedBox(width: 4),
                  Text('Made by Mehran Chandail', style: TextStyle(color: Colors.grey[400], fontSize: 12)),
                ]),
              ]),
              const SizedBox(height: 40),
            ]),
    );
  }

  Widget _sectionLabel(String label) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 0, 16, 6),
    child: Text(label.toUpperCase(), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: Colors.grey, letterSpacing: 0.8)));

  // ── Search results for settings ──────────────────────────────────────────
  Widget _buildSearchResults(AuthService authService, String uid) {
    // All searchable tiles defined as (title, subtitle, icon, color, onTap)
    final allTiles = <Map<String, dynamic>>[
      {'title': 'Accent Color', 'subtitle': 'Customize app color theme', 'icon': Icons.palette_rounded, 'color': const Color(0xFF0284C7), 'onTap': null},
      {'title': 'My Profile', 'subtitle': 'View your public profile', 'icon': Icons.person_outline, 'color': _blue,
        'onTap': uid.isNotEmpty ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => ViewProfileScreen(targetUid: uid))) : null},
      {'title': 'Change Password', 'subtitle': 'Update your password', 'icon': Icons.lock_outline, 'color': const Color(0xFF8B5CF6),
        'onTap': () => _showChangePasswordSheet(context, authService)},
      {'title': 'Messages', 'subtitle': 'New message alerts', 'icon': Icons.chat_bubble_outline, 'color': Colors.blue, 'isSwitch': true, 'value': _notifMessages},
      {'title': 'Likes & Comments', 'subtitle': 'Post interactions', 'icon': Icons.favorite_outline, 'color': Colors.red, 'isSwitch': true, 'value': _notifLikes},
      {'title': 'Inner Circle', 'subtitle': 'When someone adds you to their circle', 'icon': Icons.person_add_outlined, 'color': Colors.green, 'isSwitch': true, 'value': _notifFollows},
      {'title': 'Stories', 'subtitle': 'Coming soon', 'icon': Icons.auto_stories_outlined, 'color': Colors.orange, 'isSwitch': true, 'value': _notifStories},
      {'title': 'Call Notifications', 'subtitle': 'Coming soon', 'icon': Icons.call_outlined, 'color': Colors.teal, 'isSwitch': true, 'value': _notifCalls},
      {'title': 'Public Account', 'subtitle': 'Anyone can view your profile', 'icon': Icons.public_rounded, 'color': Colors.blue, 'isSwitch': true, 'value': _isPublic},
      {'title': 'Show Online Status', 'subtitle': 'Friends can see when you are active', 'icon': Icons.circle, 'color': Colors.green, 'isSwitch': true, 'value': _showOnline},
      {'title': 'Show Last Seen', 'subtitle': 'Friends can see your last active time', 'icon': Icons.access_time_rounded, 'color': Colors.blueGrey, 'isSwitch': true, 'value': _showLastSeen},
      {'title': 'Read Receipts', 'subtitle': 'Show when you read messages', 'icon': Icons.done_all_rounded, 'color': _blue, 'isSwitch': true, 'value': _readReceipts},
      {'title': 'Typing Indicator', 'subtitle': 'Show when you are typing', 'icon': Icons.keyboard_rounded, 'color': Colors.indigo, 'isSwitch': true, 'value': _typingIndicator},
      {'title': 'Blocked Users', 'subtitle': 'Manage blocked accounts', 'icon': Icons.block_rounded, 'color': Colors.red,
        'onTap': () => Navigator.push(context, MaterialPageRoute(builder: (_) => BlockedUsersScreen(myUid: uid)))},
      {'title': 'Zylo Storage', 'subtitle': 'Upload & manage your files', 'icon': Icons.cloud_rounded, 'color': const Color(0xFF7C3AED),
        'onTap': () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FileManagerScreen()))},
      {'title': 'How Zylo Works', 'subtitle': 'App guide, Follow System & Storage explained', 'icon': Icons.menu_book_rounded, 'color': _blue,
        'onTap': () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ZyloGuideScreen(isNewUser: false)))},
      {'title': 'Help Center', 'subtitle': 'FAQs and support', 'icon': Icons.help_outline_rounded, 'color': _blue},
      {'title': 'Report a Bug', 'subtitle': 'Let us know what went wrong', 'icon': Icons.bug_report_outlined, 'color': Colors.orange},
      {'title': 'Privacy Policy', 'subtitle': 'How we handle your data', 'icon': Icons.privacy_tip_outlined, 'color': Colors.blueGrey},
      {'title': 'Clear Cache', 'subtitle': 'Free up local storage', 'icon': Icons.cleaning_services_outlined, 'color': Colors.teal,
        'onTap': null},  // widget, not navigable via search
      {'title': 'Log Out', 'subtitle': 'Sign out of your account', 'icon': Icons.logout_rounded, 'color': Colors.red,
        'onTap': null},  // widget, not navigable via search
      {'title': 'Delete Account', 'subtitle': 'Permanently remove your account', 'icon': Icons.delete_forever_outlined, 'color': Colors.red,
        'onTap': () => _confirmDeleteAccount(context, authService)},
    ];

    final q = _searchQuery.toLowerCase();
    final filtered = allTiles.where((t) =>
      (t['title'] as String).toLowerCase().contains(q) ||
      (t['subtitle'] as String).toLowerCase().contains(q)
    ).toList();

    if (filtered.isEmpty) {
      return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.search_off_rounded, size: 56, color: Colors.grey[400]),
        const SizedBox(height: 12),
        Text('No settings found for "$_searchQuery"', style: TextStyle(color: Colors.grey[500], fontSize: 14)),
      ]));
    }

    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('${filtered.length} result${filtered.length == 1 ? '' : 's'}',
          style: const TextStyle(fontSize: 12, color: Colors.grey, fontWeight: FontWeight.w600)),
      const SizedBox(height: 10),
      _buildSection(filtered.map((t) => _Tile(
        icon: t['icon'] as IconData,
        color: t['color'] as Color,
        title: t['title'] as String,
        subtitle: t['subtitle'] as String,
        onTap: t['onTap'] as VoidCallback?,
      )).toList()),
    ]);
  }

  Widget _buildProfileTile(AuthService auth) {
    return Container(color: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(children: [
        CircleAvatar(radius: 32, backgroundColor: AppTheme.primaryColor,
          backgroundImage: auth.photoURL != null ? NetworkImage(auth.photoURL!) : null,
          child: auth.photoURL == null ? const Icon(Icons.person, color: Colors.white, size: 28) : null),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Text(auth.userName ?? 'User', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            StreamBuilder<DocumentSnapshot>(
              stream: FirebaseFirestore.instance.collection('users').doc(auth.user?.uid ?? '').snapshots(),
              builder: (_, snap) {
                final d = snap.data?.data() as Map<String, dynamic>? ?? {};
                return Row(children: [
                  if (d['isOfficialTick'] == true) const Padding(padding: EdgeInsets.only(left: 4), child: Icon(Icons.verified, color: Color(0xFF0284C7), size: 16)),
                  if (d['isDonater'] == true) const Padding(padding: EdgeInsets.only(left: 4), child: Icon(Icons.favorite, color: Color(0xFFFF6B9D), size: 16)),
                  if (d['isAdmin'] == true) Container(margin: const EdgeInsets.only(left: 6), padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(color: const Color(0xFFFFBB35).withValues(alpha: 0.15), borderRadius: BorderRadius.circular(6)),
                    child: const Text('ADMIN', style: TextStyle(color: Color(0xFFFFBB35), fontSize: 9, fontWeight: FontWeight.w900))),
                ]);
              }),
          ]),
          Text(auth.user?.email ?? '', style: const TextStyle(color: Colors.grey, fontSize: 13)),
        ])),
        const Icon(Icons.chevron_right, color: Colors.grey),
      ]));
  }

  Widget _buildSection(List<Widget> tiles) => Container(
    decoration: const BoxDecoration(color: Colors.white, border: Border(
      top: BorderSide(color: Color(0xFFE5E5EA)), bottom: BorderSide(color: Color(0xFFE5E5EA)))),
    child: Column(children: [
      for (int i = 0; i < tiles.length; i++) ...[
        tiles[i],
        if (i < tiles.length - 1) const Divider(height: 1, indent: 56, color: Color(0xFFE5E5EA)),
      ],
    ]));

  Widget _sw(IconData icon, Color color, String title, String sub, bool value, Function(bool) cb) {
    return SwitchListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
      secondary: Container(padding: const EdgeInsets.all(6), decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(8)),
        child: Icon(icon, color: Colors.white, size: 18)),
      title: Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500)),
      subtitle: Text(sub, style: TextStyle(fontSize: 11, color: Colors.grey[500])),
      value: value, activeColor: _blue, onChanged: cb);
  }

  Widget _buildClearCacheButton(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE5E5EA)),
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(8)),
          child: const Icon(Icons.cleaning_services_rounded, color: AppColors.primary, size: 20),
        ),
        title: const Text('Clear Local Cache', style: TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text('Free up space & reset offline data', style: TextStyle(fontSize: 11, color: Colors.grey[500])),
        trailing: const Icon(Icons.chevron_right, color: Colors.grey),
        onTap: () async {
          await CacheService.clearAll();
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Cache cleared successfully'),
                behavior: SnackBarBehavior.floating,
                backgroundColor: AppColors.primary,
              ),
            );
          }
        },
      ),
    );
  }

  Widget _buildLogoutButton(BuildContext context, AuthService authService) {
    return Container(margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE5E5EA))),
      child: ListTile(
        leading: Container(padding: const EdgeInsets.all(6), decoration: BoxDecoration(color: Colors.red[50], borderRadius: BorderRadius.circular(8)),
          child: const Icon(Icons.logout, color: Colors.red, size: 20)),
        title: const Text('Log Out', style: TextStyle(color: Colors.red, fontWeight: FontWeight.w700)),
        trailing: const Icon(Icons.chevron_right, color: Colors.grey),
        onTap: () async {
          await CacheService.clearAll();
          await authService.signOut();
          if (context.mounted) Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginScreen()), (r) => false);
        }));
  }

  // ── Sheets ────────────────────────────────────────────────────────────────
  void _showChangePasswordSheet(BuildContext ctx, AuthService auth) {
    final ctrl = TextEditingController();
    showModalBottomSheet(context: ctx, isScrollControlled: true, backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (bCtx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(bCtx).viewInsets.bottom + 24, top: 20, left: 20, right: 20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16), decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
          const Text('Change Password', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 16),
          TextField(controller: ctrl, obscureText: true, decoration: InputDecoration(
            hintText: 'New password (min 6 chars)', filled: true, fillColor: const Color(0xFFF1F5F9),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
            prefixIcon: const Icon(Icons.lock_outline))),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity, child: ElevatedButton(
            onPressed: () async {
              if (ctrl.text.length < 6) return;
              try { await auth.user?.updatePassword(ctrl.text);
                if (bCtx.mounted) { Navigator.pop(bCtx); ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(content: Text('Password updated!'), backgroundColor: Colors.green, behavior: SnackBarBehavior.floating)); }
              } catch (e) { ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red, behavior: SnackBarBehavior.floating)); }
            },
            style: ElevatedButton.styleFrom(backgroundColor: _blue, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)), padding: const EdgeInsets.symmetric(vertical: 14)),
            child: const Text('Update Password', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)))),
        ])));
  }

  void _showDisappearingSheet(BuildContext ctx, String uid) {
    final options = [0, 5, 10, 30, 60, 300];
    final labels  = ['Off', '5 sec', '10 sec', '30 sec', '1 min', '5 min'];
    int selected = 0;
    showModalBottomSheet(context: ctx, backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => StatefulBuilder(builder: (ctx2, set2) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 40),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16), decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
          const Text('Disappearing Messages', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 16),
          Wrap(spacing: 10, runSpacing: 10, children: List.generate(options.length, (i) {
            final active = selected == options[i];
            return GestureDetector(onTap: () => set2(() => selected = options[i]),
              child: Container(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                decoration: BoxDecoration(color: active ? _blue : Colors.grey[100], borderRadius: BorderRadius.circular(20), border: Border.all(color: active ? _blue : Colors.grey[300]!)),
                child: Text(labels[i], style: TextStyle(color: active ? Colors.white : Colors.black87, fontWeight: active ? FontWeight.w800 : FontWeight.w500))));
          })),
          const SizedBox(height: 16),
          SizedBox(width: double.infinity, child: ElevatedButton(
            onPressed: () async {
              await FirebaseFirestore.instance.collection('users').doc(uid).update({'disappearingMessages': selected});
              if (ctx2.mounted) Navigator.pop(ctx2);
            },
            style: ElevatedButton.styleFrom(backgroundColor: _blue, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)), padding: const EdgeInsets.symmetric(vertical: 14)),
            child: const Text('Save', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)))),
        ]))));
  }

  void _showLocationSheet(BuildContext ctx, AuthService auth) {
    final ctrl = TextEditingController();
    showModalBottomSheet(context: ctx, isScrollControlled: true, backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (bCtx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(bCtx).viewInsets.bottom + 24, top: 20, left: 20, right: 20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16), decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
          const Text('Update Location', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 14),
          TextField(controller: ctrl, decoration: InputDecoration(
            hintText: 'Enter your city (e.g. Lahore)', filled: true, fillColor: const Color(0xFFF1F5F9),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
            prefixIcon: const Icon(Icons.location_on_outlined))),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity, child: ElevatedButton(
            onPressed: () async {
              if (ctrl.text.trim().isEmpty) return;
              await FirebaseFirestore.instance.collection('users').doc(auth.user?.uid).update({'city': ctrl.text.trim(), 'location': ctrl.text.trim()});
              if (bCtx.mounted) { Navigator.pop(bCtx); ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(content: Text('Location updated!'), backgroundColor: Colors.green, behavior: SnackBarBehavior.floating)); }
            },
            style: ElevatedButton.styleFrom(backgroundColor: _blue, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)), padding: const EdgeInsets.symmetric(vertical: 14)),
            child: const Text('Save Location', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)))),
        ])));
  }

  void _showReportSheet(BuildContext ctx, String uid) {
    final ctrl = TextEditingController();
    showModalBottomSheet(context: ctx, isScrollControlled: true, backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (bCtx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(bCtx).viewInsets.bottom + 24, top: 20, left: 20, right: 20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16), decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
          const Text('Report a Problem', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 14),
          TextField(controller: ctrl, maxLines: 5, decoration: InputDecoration(hintText: 'Describe the issue...', filled: true, fillColor: const Color(0xFFF1F5F9), border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none))),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity, child: ElevatedButton(
            onPressed: () async {
              if (ctrl.text.trim().isEmpty) return;
              await FirebaseFirestore.instance.collection('problemReports').add({'uid': uid, 'description': ctrl.text.trim(), 'timestamp': FieldValue.serverTimestamp()});
              if (bCtx.mounted) { Navigator.pop(bCtx); ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(content: Text('Report submitted!'), backgroundColor: Colors.green, behavior: SnackBarBehavior.floating)); }
            },
            style: ElevatedButton.styleFrom(backgroundColor: _blue, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)), padding: const EdgeInsets.symmetric(vertical: 14)),
            child: const Text('Submit Report', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)))),
        ])));
  }

  void _showHelpCenter(BuildContext ctx) {
    final faqs = [
      ('How do I change my password?', 'Go to Settings → Account → Change Password and enter your new password.'),
      ('How do I make my account private?', 'Go to Settings → Privacy → turn off "Public Account".'),
      ('How do disappearing messages work?', 'Go to Settings → Privacy → Disappearing Messages. Choose a timer and messages will auto-delete after that duration.'),
      ('How do I hide my online status?', 'Go to Settings → Privacy → toggle off "Show Online Status".'),
      ('How do I hide Last Seen?', 'Go to Settings → Privacy → toggle off "Last Seen".'),
      ('How do I block someone?', 'Go to a user\'s profile and tap the three-dot menu, then select Block.'),
      ('How do I delete my account?', 'Go to Settings → Danger Zone → Delete Account. This action is permanent.'),
      ('How do I contact support?', 'Use "Report a Problem" in Settings or email support@zylopages.com'),
    ];
    showModalBottomSheet(
      context: ctx,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => DraggableScrollableSheet(
        expand: false, initialChildSize: 0.75, maxChildSize: 0.92, minChildSize: 0.4,
        builder: (_, sc) => Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10)))),
            const SizedBox(height: 16),
            Row(children: [
              Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: Colors.orange[50], borderRadius: BorderRadius.circular(12)),
                child: const Icon(Icons.help_outline, color: Colors.orange, size: 22)),
              const SizedBox(width: 12),
              const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Help Center', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                Text('Frequently Asked Questions', style: TextStyle(fontSize: 12, color: Colors.grey)),
              ]),
            ]),
            const SizedBox(height: 16),
            Expanded(child: ListView.separated(
              controller: sc,
              itemCount: faqs.length,
              separatorBuilder: (_, __) => const Divider(height: 1, color: Color(0xFFE5E5EA)),
              itemBuilder: (_, i) => ExpansionTile(
                tilePadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 4),
                childrenPadding: const EdgeInsets.only(bottom: 12),
                iconColor: _blue, collapsedIconColor: Colors.grey,
                title: Text(faqs[i].$1, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                children: [Text(faqs[i].$2, style: const TextStyle(fontSize: 13, color: Colors.black54, height: 1.5))],
              ),
            )),
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, child: OutlinedButton.icon(
              icon: const Icon(Icons.flag_outlined, size: 16),
              label: const Text('Still need help? Report a Problem'),
              style: OutlinedButton.styleFrom(foregroundColor: _blue, side: const BorderSide(color: _blue),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                padding: const EdgeInsets.symmetric(vertical: 12)),
              onPressed: () { Navigator.pop(ctx); _showReportSheet(ctx, FirebaseAuth.instance.currentUser?.uid ?? ''); })),
            const SizedBox(height: 24),
          ]),
        ),
      ),
    );
  }


  // ── Owner Card ─────────────────────────────────────────────────────────────
  Widget _buildOwnerCard() {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0A0A1A), Color(0xFF0C1A2E), Color(0xFF0A0A1A)],
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 20, offset: Offset(0, 8))],
      ),
      child: Stack(children: [
        Positioned(top: -20, left: -20,
          child: Container(width: 100, height: 100,
            decoration: BoxDecoration(shape: BoxShape.circle,
              color: Color(0xFF0284C7).withValues(alpha: 0.12)))),
        Positioned(bottom: -20, right: -20,
          child: Container(width: 100, height: 100,
            decoration: BoxDecoration(shape: BoxShape.circle,
              color: Color(0xFF7C3AED).withValues(alpha: 0.10)))),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 46),
          child: Row(children: [
            Container(
              width: 72, height: 72,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const SweepGradient(colors: [
                  Color(0xFF0284C7), Color(0xFF7C3AED), Color(0xFF38BDF8), Color(0xFF0284C7),
                ]),
                boxShadow: [BoxShadow(color: Color(0xFF0284C7).withValues(alpha: 0.35), blurRadius: 14, spreadRadius: 2)],
              ),
              padding: const EdgeInsets.all(2.5),
              child: Container(
                decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFF0A0A1A)),
                padding: const EdgeInsets.all(2),
                child: ClipOval(
                  child: Image.asset(
                    'assets/images/made_by_mehran.png',
                    width: 64, height: 64, fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      width: 64, height: 64,
                      decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFF1A1A2E)),
                      child: const Icon(Icons.person_rounded, color: Color(0xFF38BDF8), size: 32)),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Container(width: 6, height: 6, decoration: const BoxDecoration(
                  shape: BoxShape.circle, color: Color(0xFF34A853))),
                const SizedBox(width: 6),
                const Text('Made by', style: TextStyle(fontSize: 11, color: Colors.white54,
                  fontWeight: FontWeight.w500, letterSpacing: 0.3)),
              ]),
              const SizedBox(height: 5),
              ShaderMask(
                shaderCallback: (b) => const LinearGradient(
                  colors: [Color(0xFF38BDF8), Colors.white, Color(0xFF7C3AED)]).createShader(b),
                child: const Text('Mehran Chandail',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900,
                    color: Colors.white, letterSpacing: -0.3)),
              ),
              const SizedBox(height: 6),
              Wrap(spacing: 6, children: const [
                _OwnerBadge(icon: Icons.phone_android_rounded, label: 'Flutter Dev'),
                _OwnerBadge(icon: Icons.design_services_rounded, label: 'UI Design'),
              ]),
            ])),
          ]),
        ),
        Positioned(bottom: 0, left: 0, right: 0,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: const BoxDecoration(
              color: Color(0x22FFFFFF),
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(20))),
            child: Center(
              child: ShaderMask(
                shaderCallback: (b) => const LinearGradient(
                  colors: [Color(0xFF0284C7), Color(0xFF38BDF8)]).createShader(b),
                child: const Text('zylo.pages', style: TextStyle(
                  fontSize: 12, fontWeight: FontWeight.w800,
                  color: Colors.white, letterSpacing: 1.0)),
              ),
            ),
          ),
        ),
      ]),
    );
  }


  void _showAbout(BuildContext ctx) {
    showModalBottomSheet(context: ctx, backgroundColor: const Color(0xFF0A0A0A),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 20, 24, 44),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 20), decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(10))),
          Container(width: 72, height: 72, decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF0284C7), Color(0xFF38BDF8)]), borderRadius: BorderRadius.circular(20)),
            child: const Icon(Icons.chat_bubble_rounded, color: Colors.white, size: 36)),
          const SizedBox(height: 16),
          const Text('zylo.pages', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          const Text('Version 1.5.0', style: TextStyle(color: Colors.white38, fontSize: 13)),
          const SizedBox(height: 20),
          Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFF1A1A1A), borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white.withValues(alpha: 0.08))),
            child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.code, color: Color(0xFF0284C7), size: 16),
              SizedBox(width: 8),
              Text('Made with ❤️ by ', style: TextStyle(color: Colors.white60, fontSize: 13)),
              Text('Mehran Chandail', style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w800)),
            ])),
        ])));
  }

  void _confirmDeleteAccount(BuildContext ctx, AuthService auth) {
    final passCtrl = TextEditingController();
    showDialog(context: ctx, builder: (dialogCtx) => StatefulBuilder(
      builder: (dialogCtx, setS) {
        bool deleting = false;
        String? err;
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Row(children: [
            Icon(Icons.warning_rounded, color: Colors.red, size: 22),
            SizedBox(width: 8),
            Text('Delete Account?', style: TextStyle(fontWeight: FontWeight.w900, color: Colors.red, fontSize: 17)),
          ]),
          content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('This will permanently delete:\n• Your account & profile\n• All your posts\n• All your chats\n• All notifications\n\nThis cannot be undone.',
              style: TextStyle(fontSize: 13, height: 1.5)),
            const SizedBox(height: 16),
            TextField(
              controller: passCtrl,
              obscureText: true,
              decoration: InputDecoration(
                hintText: 'Enter your password to confirm',
                prefixIcon: const Icon(Icons.lock_outline, size: 18),
                filled: true, fillColor: const Color(0xFFF3F6FB),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              ),
            ),
            if (err != null) ...[
              const SizedBox(height: 8),
              Text(err!, style: const TextStyle(color: Colors.red, fontSize: 12)),
            ],
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogCtx), child: const Text('Cancel')),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
              onPressed: deleting ? null : () async {
                if (passCtrl.text.isEmpty) {
                  setS(() => err = 'Please enter your password');
                  return;
                }
                setS(() { deleting = true; err = null; });
                try {
                  final user = auth.user;
                  if (user == null) return;
                  final uid = user.uid;
                  final db = FirebaseFirestore.instance;
                  final cred = EmailAuthProvider.credential(email: user.email!, password: passCtrl.text);
                  await user.reauthenticateWithCredential(cred);
                  final posts = await db.collection('posts').where('authorId', isEqualTo: uid).get();
                  for (final doc in posts.docs) await doc.reference.delete();
                  final chats = await db.collection('chats').where('participants', arrayContains: uid).get();
                  for (final doc in chats.docs) await doc.reference.delete();
                  final notifs = await db.collection('users').doc(uid).collection('notifications').get();
                  for (final doc in notifs.docs) await doc.reference.delete();
                  final friends = await db.collection('users').doc(uid).collection('friends').get();
                  for (final doc in friends.docs) await doc.reference.delete();
                  await db.collection('users').doc(uid).delete();
                  await user.delete();
                  if (ctx.mounted) {
                    Navigator.of(ctx).pushAndRemoveUntil(
                      MaterialPageRoute(builder: (_) => const LoginScreen()), (r) => false);
                  }
                } on FirebaseAuthException catch (e) {
                  setS(() {
                    deleting = false;
                    err = e.code == 'wrong-password' ? 'Wrong password. Try again.' : e.message ?? 'Auth error';
                  });
                } catch (e) {
                  setS(() { deleting = false; err = 'Error: $e'; });
                }
              },
              child: deleting
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : const Text('Delete Account')),
          ]);
      }));
  }
}

// ── Tile widget ───────────────────────────────────────────────────────────────
class _Tile extends StatelessWidget {
  final IconData icon; final Color color; final String title; final String? subtitle; final VoidCallback? onTap; final Color? textColor;
  const _Tile({required this.icon, required this.color, required this.title, this.subtitle, this.onTap, this.textColor});
  @override
  Widget build(BuildContext context) => ListTile(
    leading: Container(padding: const EdgeInsets.all(6), decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(8)), child: Icon(icon, color: Colors.white, size: 18)),
    title: Text(title, style: TextStyle(color: textColor ?? Colors.black87, fontWeight: FontWeight.w500, fontSize: 15)),
    subtitle: subtitle != null ? Text(subtitle!, style: TextStyle(fontSize: 11, color: Colors.grey[500])) : null,
    trailing: const Icon(Icons.chevron_right, color: Colors.grey),
    onTap: onTap);
}

// ── Blocked Users Screen ──────────────────────────────────────────────────────
class BlockedUsersScreen extends StatelessWidget {
  final String myUid;
  const BlockedUsersScreen({super.key, required this.myUid});

  Future<void> _unblock(String uid) async {
    await FirebaseFirestore.instance.collection('users').doc(myUid).update({'blockedUsers': FieldValue.arrayRemove([uid])});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFF),
      appBar: AppBar(title: const Text('Blocked Users', style: TextStyle(fontWeight: FontWeight.w800, color: Colors.black87)),
        backgroundColor: Colors.white, elevation: 0, centerTitle: true,
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: Colors.black87), onPressed: () => Navigator.pop(context))),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance.collection('users').doc(myUid).snapshots(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: ZyloLoader());
          final data = snap.data?.data() as Map<String, dynamic>? ?? {};
          final blocked = (data['blockedUsers'] as List<dynamic>? ?? []).cast<String>();
          if (blocked.isEmpty) return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.block_rounded, size: 64, color: Colors.grey[300]),
            const SizedBox(height: 12),
            Text('No blocked users', style: TextStyle(color: Colors.grey[400], fontSize: 15)),
          ]));
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: blocked.length,
            itemBuilder: (_, i) => FutureBuilder<DocumentSnapshot>(
              future: FirebaseFirestore.instance.collection('users').doc(blocked[i]).get(),
              builder: (_, uSnap) {
                if (!uSnap.hasData) return const SizedBox.shrink();
                final u = uSnap.data!.data() as Map<String, dynamic>? ?? {};
                final name = u['username'] ?? 'Unknown';
                final photo = u['photoURL'] ?? '';
                return Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 8)]),
                  child: Row(children: [
                    CircleAvatar(radius: 24, backgroundColor: const Color(0xFF0284C7),
                      backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null,
                      child: photo.isEmpty ? Text(name[0].toUpperCase(), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)) : null),
                    const SizedBox(width: 12),
                    Expanded(child: Text(name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14))),
                    GestureDetector(onTap: () => _unblock(blocked[i]),
                      child: Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(border: Border.all(color: const Color(0xFF0284C7), width: 1.5), borderRadius: BorderRadius.circular(20)),
                        child: const Text('Unblock', style: TextStyle(color: Color(0xFF0284C7), fontWeight: FontWeight.w700, fontSize: 12)))),
                  ]));
              }));
        }));
  }
}

class _OwnerBadge extends StatelessWidget {
  final IconData icon;
  final String label;
  const _OwnerBadge({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 11, color: const Color(0xFF38BDF8)),
        const SizedBox(width: 4),
        Text(label, style: const TextStyle(
            fontSize: 10, color: Colors.white70, fontWeight: FontWeight.w600)),
      ]),
    );
  }
}

// ═══════════════════════════════════════════════════════════
//  Accent Color Picker tile
// ═══════════════════════════════════════════════════════════
class _AccentColorPicker extends StatelessWidget {
  const _AccentColorPicker();

  @override
  Widget build(BuildContext context) {
    final accentSvc = Provider.of<AccentThemeService>(context);
    final current = accentSvc.accent;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                color: current.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(Icons.palette_rounded, color: current, size: 20),
            ),
            const SizedBox(width: 12),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Accent Color',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
              Text('Buttons, tabs, icons',
                style: TextStyle(fontSize: 12, color: Colors.grey[500])),
            ]),
          ]),
          const SizedBox(height: 16),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: kZyloAccents.map((acc) {
              final isSelected = acc.color.value == current.value;
              return GestureDetector(
                onTap: () => accentSvc.setAccent(acc.color),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 44, height: 44,
                  decoration: BoxDecoration(
                    color: acc.color,
                    shape: BoxShape.circle,
                    border: isSelected
                        ? Border.all(color: Colors.white, width: 3)
                        : null,
                    boxShadow: isSelected
                        ? [BoxShadow(color: acc.color.withValues(alpha: 0.5), blurRadius: 8, spreadRadius: 1)]
                        : [BoxShadow(color: Colors.black.withValues(alpha: 0.1), blurRadius: 4)],
                  ),
                  child: isSelected
                      ? const Icon(Icons.check_rounded, color: Colors.white, size: 20)
                      : Icon(acc.icon, color: Colors.white.withValues(alpha: 0.7), size: 18),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 8),
          Text(
            kZyloAccents.firstWhere((a) => a.color.value == current.value,
                orElse: () => kZyloAccents.first).name,
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: current),
          ),
        ],
      ),
    );
  }
}
