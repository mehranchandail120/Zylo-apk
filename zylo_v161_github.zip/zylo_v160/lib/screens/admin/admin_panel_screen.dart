import 'dart:io';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../widgets/zylo_cached_image.dart';
import 'package:image_picker/image_picker.dart';
import '../../services/file_service.dart';

// ── Admin check helper (called from settings) ─────────────────────────────────
// Firestore: users/{uid}.isAdmin == true

class AdminPanelScreen extends StatefulWidget {
  const AdminPanelScreen({super.key});
  @override State<AdminPanelScreen> createState() => _AdminPanelScreenState();
}

class _AdminPanelScreenState extends State<AdminPanelScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;
  static const _bg    = Color(0xFF0A0A0A);
  static const _card  = Color(0xFF1A1A1A);
  static const _blue  = Color(0xFF0284C7);
  static const _red   = Color(0xFFEF4444);
  static const _green = Color(0xFF10B981);

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 11, vsync: this);
  }

  @override
  void dispose() { _tab.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _card,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Row(children: [
          Icon(Icons.admin_panel_settings, color: Color(0xFFFFBB35), size: 22),
          SizedBox(width: 10),
          Text('Admin Panel', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18)),
        ]),
        bottom: TabBar(
          controller: _tab,
          isScrollable: true,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white38,
          indicatorColor: _blue,
          indicatorSize: TabBarIndicatorSize.label,
          tabs: const [
            Tab(text: 'Stats'),
            Tab(text: 'Users'),
            Tab(text: 'Posts'),
            Tab(text: 'Reports'),
            Tab(text: 'App Control'),
            Tab(text: 'Banner'),
            Tab(text: 'Poster'),
            Tab(text: 'Feed Post'),
            Tab(text: 'Notifications'),
            Tab(text: 'Broadcast'),
            Tab(text: 'Announcements'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          _StatsTab(blue: _blue, card: _card, green: _green, red: _red),
          _UsersTab(blue: _blue, red: _red, green: _green, card: _card),
          _PostsTab(blue: _blue, red: _red, card: _card, green: _green),
          _ReportsTab(blue: _blue, red: _red, card: _card, green: _green),
          _AppControlTab(blue: _blue, card: _card, green: _green),
          _BannerTab(blue: _blue, card: _card),
          _StartupPosterTab(blue: _blue, card: _card, green: _green),
          _AdminFeedPostTab(blue: _blue, card: _card, green: _green),
          _NotificationsTab(blue: _blue, card: _card, green: _green, red: _red),
          _BroadcastTab(blue: _blue, card: _card, green: _green),
          _AnnouncementsTab(blue: _blue, card: _card, green: _green, red: _red),
        ],
      ),
    );
  }
}


// ── STATS TAB ─────────────────────────────────────────────────────────────────
class _StatsTab extends StatelessWidget {
  final Color blue, card, green, red;
  const _StatsTab({required this.blue, required this.card, required this.green, required this.red});

  @override
  Widget build(BuildContext context) {
    final todayStart = DateTime.now().copyWith(hour: 0, minute: 0, second: 0, millisecond: 0);
    final todayTs = Timestamp.fromDate(todayStart);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('App Statistics', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18)),
        const SizedBox(height: 4),
        const Text('Live real-time data', style: TextStyle(color: Colors.white38, fontSize: 12)),
        const SizedBox(height: 20),
        _StatCard(label: 'Total Users', icon: Icons.people_rounded, color: blue,
          stream: FirebaseFirestore.instance.collection('users').snapshots(),
          getValue: (snap) => '${snap.docs.length}'),
        const SizedBox(height: 12),
        _StatCard(label: 'New Users Today', icon: Icons.person_add_rounded, color: green,
          stream: FirebaseFirestore.instance.collection('users').where('createdAt', isGreaterThanOrEqualTo: todayTs).snapshots(),
          getValue: (snap) => '${snap.docs.length}'),
        const SizedBox(height: 12),
        _StatCard(label: 'Active Now', icon: Icons.circle, color: const Color(0xFF10B981),
          stream: FirebaseFirestore.instance.collection('users').where('isOnline', isEqualTo: true).snapshots(),
          getValue: (snap) => '${snap.docs.length}'),
        const SizedBox(height: 12),
        _StatCard(label: 'Total Posts', icon: Icons.article_rounded, color: const Color(0xFF8B5CF6),
          stream: FirebaseFirestore.instance.collection('posts').snapshots(),
          getValue: (snap) => '${snap.docs.length}'),
        const SizedBox(height: 12),
        _StatCard(label: 'Posts Today', icon: Icons.post_add_rounded, color: const Color(0xFFF59E0B),
          stream: FirebaseFirestore.instance.collection('posts').where('createdAt', isGreaterThanOrEqualTo: todayTs).snapshots(),
          getValue: (snap) => '${snap.docs.length}'),
        const SizedBox(height: 12),
        _StatCard(label: 'Banned Users', icon: Icons.block_rounded, color: red,
          stream: FirebaseFirestore.instance.collection('users').where('isBanned', isEqualTo: true).snapshots(),
          getValue: (snap) => '${snap.docs.length}'),
        const SizedBox(height: 12),
        _StatCard(label: 'Pending Reports', icon: Icons.flag_rounded, color: Colors.orange,
          stream: FirebaseFirestore.instance.collection('postReports').where('resolved', isEqualTo: false).snapshots(),
          getValue: (snap) => '${snap.docs.length}'),
      ]),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final Stream<QuerySnapshot> stream;
  final String Function(QuerySnapshot) getValue;
  const _StatCard({required this.label, required this.icon, required this.color, required this.stream, required this.getValue});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: stream,
      builder: (_, snap) {
        final value = snap.hasData ? getValue(snap.data!) : '...';
        return Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: const Color(0xFF1A1A1A), borderRadius: BorderRadius.circular(16),
            border: Border.all(color: color.withValues(alpha: 0.25))),
          child: Row(children: [
            Container(width: 48, height: 48,
              decoration: BoxDecoration(color: color.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(14)),
              child: Icon(icon, color: color, size: 24)),
            const SizedBox(width: 16),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(label, style: const TextStyle(color: Colors.white60, fontSize: 13, fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              Text(value, style: TextStyle(color: color, fontSize: 28, fontWeight: FontWeight.w900)),
            ])),
            if (snap.connectionState == ConnectionState.waiting)
              SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: color, strokeWidth: 2)),
          ]),
        );
      },
    );
  }
}
// ── USERS TAB ─────────────────────────────────────────────────────────────────
class _UsersTab extends StatefulWidget {
  final Color blue, red, green, card;
  const _UsersTab({required this.blue, required this.red, required this.green, required this.card});
  @override State<_UsersTab> createState() => _UsersTabState();
}

class _UsersTabState extends State<_UsersTab> {
  String _search = '';
  String _filter = 'all'; // all | banned | admin

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      // ── Search + Filter bar ─────────────────────────────────────────────
      Container(
        color: const Color(0xFF111111),
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 8),
        child: Column(children: [
          TextField(
            onChanged: (v) => setState(() => _search = v.toLowerCase().trim()),
            style: const TextStyle(color: Colors.white, fontSize: 14),
            decoration: InputDecoration(
              hintText: 'Search by username or email...',
              hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
              prefixIcon: const Icon(Icons.search, color: Colors.white38, size: 20),
              filled: true, fillColor: const Color(0xFF1E1E1E),
              contentPadding: const EdgeInsets.symmetric(vertical: 10),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 8),
          Row(children: [
            for (final f in [('all','All'), ('banned','Banned'), ('admin','Admins')])
              GestureDetector(
                onTap: () => setState(() => _filter = f.$1),
                child: Container(
                  margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  decoration: BoxDecoration(
                    color: _filter == f.$1 ? const Color(0xFF0284C7) : const Color(0xFF1E1E1E),
                    borderRadius: BorderRadius.circular(20)),
                  child: Text(f.$2, style: TextStyle(
                    color: _filter == f.$1 ? Colors.white : Colors.white54,
                    fontSize: 12, fontWeight: FontWeight.w700)),
                )),
          ]),
        ]),
      ),
      // ── User list ───────────────────────────────────────────────────────
      Expanded(child: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('users').orderBy('createdAt', descending: true).snapshots(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting)
            return const Center(child: CircularProgressIndicator(color: Color(0xFF0284C7)));
          var users = snap.data?.docs ?? [];
          // Apply filter
          users = users.where((doc) {
            final u = doc.data() as Map<String, dynamic>;
            if (_filter == 'banned' && u['isBanned'] != true) return false;
            if (_filter == 'admin' && u['isAdmin'] != true) return false;
            if (_search.isNotEmpty) {
              final name  = (u['username'] ?? '').toString().toLowerCase();
              final email = (u['email']    ?? '').toString().toLowerCase();
              if (!name.contains(_search) && !email.contains(_search)) return false;
            }
            return true;
          }).toList();

          if (users.isEmpty)
            return const Center(child: Text('No users found', style: TextStyle(color: Colors.white38)));

          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: users.length,
            itemBuilder: (_, i) {
              final u   = users[i].data() as Map<String, dynamic>;
              final uid = users[i].id;
              final name    = u['username'] ?? 'Unknown';
              final photo   = u['photoURL'] ?? '';
              final email   = u['email'] ?? '';
              final isBanned       = u['isBanned'] == true;
              final isAdmin        = u['isAdmin']  == true || u['isAdmin'] == 'true';
              final isOfficialTick = u['isOfficialTick'] == true;
              final isDonater      = u['isDonater'] == true;
              final banReason      = u['banReason'] as String? ?? '';
              final warnCount      = (u['warnCount'] as int?) ?? 0;
              final followersCount = (u['followersCount'] as int?) ?? 0;
              final postsCount     = (u['postsCount'] as int?) ?? 0;

              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  color: const Color(0xFF1A1A1A),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: isBanned
                      ? Colors.red.withValues(alpha: 0.5)
                      : isAdmin
                        ? const Color(0xFFFFBB35).withValues(alpha: 0.4)
                        : Colors.white.withValues(alpha: 0.06),
                    width: isBanned || isAdmin ? 1.5 : 1),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  // ── Header ─────────────────────────────────────────────────
                  Padding(
                    padding: const EdgeInsets.fromLTRB(14, 14, 14, 0),
                    child: Row(children: [
                      Stack(children: [
                        CircleAvatar(
                          radius: 26,
                          backgroundColor: const Color(0xFF0284C7),
                          backgroundImage: photo.isNotEmpty ? CachedNetworkImageProvider(photo) : null,
                          child: photo.isEmpty ? Text(name.isNotEmpty ? name[0].toUpperCase() : '?',
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18)) : null),
                        if (isBanned) Positioned.fill(child: ClipOval(child: Container(
                          color: Colors.red.withValues(alpha: 0.6),
                          child: const Icon(Icons.block, color: Colors.white, size: 18)))),
                      ]),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Flexible(child: Text('@$name',
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15),
                            overflow: TextOverflow.ellipsis)),
                          if (isOfficialTick) const Padding(padding: EdgeInsets.only(left: 4),
                            child: Icon(Icons.verified, color: Color(0xFF0284C7), size: 15)),
                          if (isDonater) const Padding(padding: EdgeInsets.only(left: 4),
                            child: Icon(Icons.favorite, color: Color(0xFFFF6B9D), size: 13)),
                          if (isAdmin) Container(margin: const EdgeInsets.only(left: 6),
                            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                            decoration: BoxDecoration(color: const Color(0xFFFFBB35).withValues(alpha: 0.18), borderRadius: BorderRadius.circular(6)),
                            child: const Text('ADMIN', style: TextStyle(color: Color(0xFFFFBB35), fontSize: 9, fontWeight: FontWeight.w900))),
                          if (isBanned) Container(margin: const EdgeInsets.only(left: 6),
                            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                            decoration: BoxDecoration(color: Colors.red.withValues(alpha: 0.18), borderRadius: BorderRadius.circular(6)),
                            child: const Text('BANNED', style: TextStyle(color: Colors.red, fontSize: 9, fontWeight: FontWeight.w900))),
                        ]),
                        const SizedBox(height: 2),
                        Text(email, style: const TextStyle(color: Colors.white38, fontSize: 11)),
                        const SizedBox(height: 4),
                        Row(children: [
                          _statChip(Icons.people, '$followersCount followers'),
                          const SizedBox(width: 8),
                          _statChip(Icons.grid_view_rounded, '$postsCount posts'),
                          if (warnCount > 0) ...[ const SizedBox(width: 8),
                            _statChip(Icons.warning_amber_rounded, '$warnCount warns', color: Colors.orange)],
                        ]),
                      ])),
                    ]),
                  ),
                  if (isBanned && banReason.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.fromLTRB(14, 8, 14, 0),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(color: Colors.red.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.red.withValues(alpha: 0.2))),
                        child: Row(children: [
                          const Icon(Icons.info_outline, color: Colors.red, size: 13),
                          const SizedBox(width: 6),
                          Flexible(child: Text('Ban reason: $banReason',
                            style: const TextStyle(color: Colors.red, fontSize: 11))),
                        ]))),
                  // ── Action buttons ─────────────────────────────────────────
                  Padding(
                    padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
                    child: Wrap(spacing: 8, runSpacing: 8, children: [
                      // Ban / Unban (with reason dialog)
                      _btn(isBanned ? 'Unban' : 'Ban', isBanned ? widget.green : widget.red,
                        isBanned ? Icons.lock_open_rounded : Icons.block_rounded, () {
                        if (isBanned) {
                          FirebaseFirestore.instance.collection('users').doc(uid)
                            .update({'isBanned': false, 'banReason': ''});
                          _snack(context, '@$name unbanned', widget.green);
                        } else {
                          _showBanDialog(context, uid, name);
                        }
                      }),
                      // Warn
                      _btn('Warn', Colors.orange, Icons.warning_amber_rounded, () async {
                        await FirebaseFirestore.instance.collection('users').doc(uid)
                          .update({'warnCount': FieldValue.increment(1)});
                        // Save warn record
                        await FirebaseFirestore.instance.collection('users').doc(uid)
                          .collection('notifications').add({
                            'type': 'admin_warn',
                            'text': '⚠️ You received a warning from admin',
                            'read': false,
                            'createdAt': FieldValue.serverTimestamp(),
                          });
                        _snack(context, '@$name warned (${warnCount + 1} total)', Colors.orange);
                      }),
                      // Suspend posts
                      _btn('Suspend Posts', Colors.deepOrange, Icons.post_add_rounded, () async {
                        final ps = await FirebaseFirestore.instance.collection('posts')
                          .where('authorId', isEqualTo: uid).get();
                        for (final d in ps.docs) d.reference.update({'suspended': true});
                        _snack(context, 'All posts suspended', Colors.deepOrange);
                      }),
                      // Official tick
                      _btn(isOfficialTick ? 'Remove ✓' : 'Give ✓', const Color(0xFF0284C7), Icons.verified_rounded, () async {
                        await FirebaseFirestore.instance.collection('users').doc(uid)
                          .update({'isOfficialTick': !isOfficialTick});
                        _snack(context, isOfficialTick ? 'Tick removed' : '✓ Tick granted', const Color(0xFF0284C7));
                      }),
                      // Donater badge
                      _btn(isDonater ? 'Remove ♥' : 'Give ♥', const Color(0xFFFF6B9D), Icons.favorite_rounded, () async {
                        await FirebaseFirestore.instance.collection('users').doc(uid)
                          .update({'isDonater': !isDonater});
                        _snack(context, isDonater ? 'Badge removed' : '♥ Donater badge granted', const Color(0xFFFF6B9D));
                      }),
                      // Make/Remove admin
                      _btn(isAdmin ? 'Remove Admin' : 'Make Admin', const Color(0xFFFFBB35), Icons.admin_panel_settings_rounded, () async {
                        await FirebaseFirestore.instance.collection('users').doc(uid)
                          .update({'isAdmin': !isAdmin});
                        _snack(context, isAdmin ? 'Admin removed' : '⭐ $name is now admin', const Color(0xFFFFBB35));
                      }),
                      // Delete account
                      _btn('Delete', widget.red, Icons.delete_forever_rounded, () => _showDeleteDialog(context, uid, name)),
                    ]),
                  ),
                ]),
              );
            },
          );
        },
      )),
    ]);
  }

  Widget _statChip(IconData icon, String label, {Color color = const Color(0xFF475569)}) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 10, color: color),
      const SizedBox(width: 3),
      Text(label, style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w500)),
    ]);
  }

  Widget _btn(String label, Color color, IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withValues(alpha: 0.35))),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: color, size: 14),
          const SizedBox(width: 5),
          Text(label, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700)),
        ]),
      ),
    );
  }

  void _showBanDialog(BuildContext ctx, String uid, String name) {
    final reasonCtrl = TextEditingController();
    showDialog(context: ctx, builder: (_) => AlertDialog(
      backgroundColor: const Color(0xFF1A1A1A),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Text('Ban @$name?', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('User ko app access nahi milega. Reason optional hai.', style: TextStyle(color: Colors.white60, fontSize: 13)),
        const SizedBox(height: 12),
        TextField(
          controller: reasonCtrl, maxLines: 2,
          style: const TextStyle(color: Colors.white, fontSize: 13),
          decoration: InputDecoration(
            hintText: 'Ban reason (optional)...',
            hintStyle: const TextStyle(color: Colors.white38, fontSize: 12),
            filled: true, fillColor: const Color(0xFF222222),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)),
        ),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx),
          child: const Text('Cancel', style: TextStyle(color: Colors.white38))),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
          onPressed: () async {
            Navigator.pop(ctx);
            await FirebaseFirestore.instance.collection('users').doc(uid).update({
              'isBanned': true, 'banReason': reasonCtrl.text.trim(),
              'bannedAt': FieldValue.serverTimestamp(),
            });
            // Notify user
            await FirebaseFirestore.instance.collection('users').doc(uid)
              .collection('notifications').add({
                'type': 'admin_ban',
                'text': '🚫 Your account has been banned',
                'preview': reasonCtrl.text.trim().isNotEmpty ? 'Reason: ${reasonCtrl.text.trim()}' : 'Contact support for more info',
                'read': false,
                'createdAt': FieldValue.serverTimestamp(),
              });
            _snack(ctx, '@$name has been banned', Colors.red);
          },
          child: const Text('Ban User'),
        ),
      ],
    ));
  }

  void _showDeleteDialog(BuildContext ctx, String uid, String name) {
    showDialog(context: ctx, builder: (_) => AlertDialog(
      backgroundColor: const Color(0xFF1A1A1A),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Text('Delete @$name?', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
      content: const Text('Yeh permanently delete ho jayega — posts, messages sab. Undo nahi hoga.', style: TextStyle(color: Colors.white60, fontSize: 13)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx),
          child: const Text('Cancel', style: TextStyle(color: Colors.white38))),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
          onPressed: () async {
            Navigator.pop(ctx);
            await FirebaseFirestore.instance.collection('users').doc(uid).delete();
            final posts = await FirebaseFirestore.instance.collection('posts')
              .where('authorId', isEqualTo: uid).get();
            for (final d in posts.docs) await d.reference.delete();
            _snack(ctx, '@$name deleted permanently', widget.red);
          },
          child: const Text('Delete Forever'),
        ),
      ],
    ));
  }

  void _snack(BuildContext ctx, String msg, Color color) {
    ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
      content: Text(msg), backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }
}

// ── POSTS TAB ─────────────────────────────────────────────────────────────────
class _PostsTab extends StatelessWidget {
  final Color blue, red, card, green;
  const _PostsTab({required this.blue, required this.red, required this.card, required this.green});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('posts').orderBy('createdAt', descending: true).limit(80).snapshots(),
      builder: (_, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(color: Color(0xFF0284C7)));
        }
        final posts = snap.data?.docs ?? [];
        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: posts.length,
          itemBuilder: (_, i) {
            final p   = posts[i].data() as Map<String, dynamic>;
            final pid = posts[i].id;
            final text = p['text'] as String? ?? '';
            final authorId = p['authorId'] as String? ?? '';
            final isSuspended = p['suspended'] == true;
            final deletedByAdmin = p['deletedByAdmin'] == true;
            final isPinned = p['isPinned'] == true;
            final images = (p['images'] as List?)?.cast<String>() ?? [];

            return GestureDetector(
              onLongPress: () => _showPinDialog(context, pid, isPinned),
              child: Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: card, borderRadius: BorderRadius.circular(14),
                border: isPinned
                    ? Border.all(color: const Color(0xFFFFBB35).withValues(alpha: 0.5), width: 1.5)
                    : isSuspended
                        ? Border.all(color: Colors.orange.withValues(alpha: 0.4))
                        : Border.all(color: Colors.white.withValues(alpha: 0.05)),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                FutureBuilder<DocumentSnapshot?>(
                  future: FirebaseFirestore.instance.collection('users').doc(authorId).get(),
                  builder: (_, us) {
                    final u = us.data?.data() as Map<String, dynamic>? ?? {};
                    final uname = u['username'] ?? 'unknown';
                    final photo = u['photoURL'] ?? '';
                    return Row(children: [
                      CircleAvatar(radius: 16, backgroundColor: blue,
                        backgroundImage: photo.isNotEmpty ? CachedNetworkImageProvider(photo) : null,
                        child: photo.isEmpty ? Text(uname[0].toUpperCase(), style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w900)) : null),
                      const SizedBox(width: 8),
                      Text('@$uname', style: const TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w700)),
                      const Spacer(),
                      if (isPinned) Container(margin: const EdgeInsets.only(right: 6), padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(color: const Color(0xFFFFBB35).withValues(alpha: 0.15), borderRadius: BorderRadius.circular(6)),
                        child: const Row(mainAxisSize: MainAxisSize.min, children: [
                          Icon(Icons.push_pin_rounded, color: Color(0xFFFFBB35), size: 10), SizedBox(width: 3),
                          Text('PINNED', style: TextStyle(color: Color(0xFFFFBB35), fontSize: 9, fontWeight: FontWeight.w900)),
                        ])),
                      if (isSuspended) Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(color: Colors.orange.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(6)),
                        child: const Text('SUSPENDED', style: TextStyle(color: Colors.orange, fontSize: 9, fontWeight: FontWeight.w900))),
                    ]);
                  },
                ),
                if (text.isNotEmpty) Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(text.length > 120 ? '${text.substring(0, 120)}...' : text,
                    style: const TextStyle(color: Colors.white60, fontSize: 12, height: 1.4)),
                ),
                // Show image thumbnail if exists
                if (images.isNotEmpty) Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: ZyloCachedImage(
                      url: images.first,
                      height: 80, width: null,
                      fit: BoxFit.cover,
                      placeholder: (_, __) => Container(height: 80, color: Colors.white10),
                      errorWidget: Container(height: 80, color: Colors.white10,
                        child: const Icon(Icons.broken_image, color: Colors.white30)),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Row(children: [
                  _postBtn(isSuspended ? 'Restore' : 'Suspend', isSuspended ? green : Colors.orange, () async {
                    await FirebaseFirestore.instance.collection('posts').doc(pid).update({'suspended': !isSuspended});
                  }),
                  const SizedBox(width: 8),
                  _postBtn('Delete by Admin', red, () async {
                    final confirmed = await showDialog<bool>(
                      context: context,
                      builder: (_) => AlertDialog(
                        backgroundColor: const Color(0xFF1A1A1A),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                        title: const Text('Delete Post?', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
                        content: const Text('This post will be marked as deleted by admin. The user will see this.', style: TextStyle(color: Colors.white60)),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel', style: TextStyle(color: Colors.white38))),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
                            onPressed: () => Navigator.pop(context, true),
                            child: const Text('Delete'),
                          ),
                        ],
                      ),
                    );
                    if (confirmed == true) {
                      await FirebaseFirestore.instance.collection('posts').doc(pid).update({
                        'deletedByAdmin': true,
                        'adminDeletedAt': FieldValue.serverTimestamp(),
                      });
                    }
                  }),
                ]),
              ]),
            ),);
          },
        );
      },
    );
  }

  void _showPinDialog(BuildContext context, String pid, bool isPinned) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Row(children: [
          const Icon(Icons.push_pin_rounded, color: Color(0xFFFFBB35), size: 20),
          const SizedBox(width: 8),
          Text(isPinned ? 'Unpin Post?' : 'Pin to Top?',
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
        ]),
        content: Text(isPinned ? 'Remove from top?' : 'Pin this post to the top of the feed for all users?',
          style: const TextStyle(color: Colors.white60)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.white38))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFFBB35), foregroundColor: Colors.black,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () async {
              Navigator.pop(context);
              if (!isPinned) {
                final pinned = await FirebaseFirestore.instance
                    .collection('posts').where('isPinned', isEqualTo: true).get();
                for (final doc in pinned.docs) await doc.reference.update({'isPinned': false});
              }
              await FirebaseFirestore.instance.collection('posts').doc(pid).update({
                'isPinned': !isPinned,
                'pinnedAt': isPinned ? null : FieldValue.serverTimestamp(),
              });
            },
            child: Text(isPinned ? 'Unpin' : 'Pin to Top'),
          ),
        ],
      ),
    );
  }

  Widget _postBtn(String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withValues(alpha: 0.3))),
        child: Text(label, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700)),
      ),
    );
  }
}

// ── REPORTS TAB ───────────────────────────────────────────────────────────────
class _ReportsTab extends StatefulWidget {
  final Color blue, red, card, green;
  const _ReportsTab({required this.blue, required this.red, required this.card, required this.green});
  @override State<_ReportsTab> createState() => _ReportsTabState();
}

class _ReportsTabState extends State<_ReportsTab> with SingleTickerProviderStateMixin {
  late TabController _inner;
  @override
  void initState() {
    super.initState();
    _inner = TabController(length: 4, vsync: this);
  }
  @override
  void dispose() { _inner.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Container(
        color: const Color(0xFF1A1A1A),
        child: TabBar(
          controller: _inner,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white38,
          indicatorColor: widget.blue,
          indicatorSize: TabBarIndicatorSize.label,
          tabs: const [Tab(text: 'Posts'), Tab(text: 'Profiles'), Tab(text: 'Feed'), Tab(text: 'Problems')],
        ),
      ),
      Expanded(child: TabBarView(
        controller: _inner,
        children: [
          _ReportList(collection: 'postReports', blue: widget.blue, red: widget.red, card: widget.card, green: widget.green),
          _ReportList(collection: 'profileReports', blue: widget.blue, red: widget.red, card: widget.card, green: widget.green),
          _ReportList(collection: 'feedReports', blue: widget.blue, red: widget.red, card: widget.card, green: widget.green),
          _ProblemReportList(blue: widget.blue, red: widget.red, card: widget.card, green: widget.green),
        ],
      )),
    ]);
  }
}

class _ReportList extends StatelessWidget {
  final String collection;
  final Color blue, red, card, green;
  const _ReportList({required this.collection, required this.blue, required this.red, required this.card, required this.green});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection(collection)
          .orderBy('timestamp', descending: true).limit(60).snapshots(),
      builder: (_, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator(color: Color(0xFF0284C7)));
        // If index not ready, try without orderBy
        if (snap.hasError) {
          return StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance.collection(collection).limit(60).snapshots(),
            builder: (_, snap2) {
              if (snap2.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator(color: Color(0xFF0284C7)));
              final docs2 = snap2.data?.docs ?? [];
              if (docs2.isEmpty) return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.flag_outlined, size: 48, color: Colors.white12),
                const SizedBox(height: 12),
                const Text('No reports yet', style: TextStyle(color: Colors.white38, fontSize: 15, fontWeight: FontWeight.w600)),
              ]));
              return ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: docs2.length,
                itemBuilder: (_, i) {
                  final r = docs2[i].data() as Map<String, dynamic>;
                  final rid = docs2[i].id;
                  final reason = r['reason'] as String? ?? 'Unknown';
                  final resolved = r['resolved'] == true;
                  final reportedBy = r['reportedBy'] as String? ?? '';
                  final ts = r['timestamp'] as Timestamp?;

                  return Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: card, borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: resolved ? Colors.white.withValues(alpha: 0.05) : red.withValues(alpha: 0.3)),
                    ),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: resolved ? Colors.white10 : red.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(8)),
                          child: Text(resolved ? 'RESOLVED' : 'PENDING',
                            style: TextStyle(color: resolved ? Colors.white38 : red, fontSize: 10, fontWeight: FontWeight.w900)),
                        ),
                        const SizedBox(width: 8),
                        Expanded(child: Text(reason, style: const TextStyle(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.w700))),
                        if (ts != null) Text(_timeAgo(ts.toDate()), style: const TextStyle(color: Colors.white38, fontSize: 11)),
                      ]),
                      const SizedBox(height: 8),
                      FutureBuilder<DocumentSnapshot?>(
                        future: reportedBy.isNotEmpty
                            ? FirebaseFirestore.instance.collection('users').doc(reportedBy).get()
                            : Future.value(null),
                        builder: (_, us) {
                          final u = us.data?.data() as Map<String, dynamic>? ?? {};
                          final name = u['username'] ?? 'Unknown';
                          return Text('Reported by: @$name', style: const TextStyle(color: Colors.white38, fontSize: 11));
                        },
                      ),
                      if (r['postId'] != null) Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text('Post: ${r['postId']}', style: const TextStyle(color: Colors.white24, fontSize: 10, fontFamily: 'monospace')),
                      ),
                      const SizedBox(height: 12),
                      Row(children: [
                        if (!resolved)
                          _rBtn('Mark Resolved', green, Icons.check_circle_outline, () async {
                            await FirebaseFirestore.instance.collection(collection).doc(rid)
                                .update({'resolved': true, 'resolvedAt': FieldValue.serverTimestamp()});
                          }),
                        const SizedBox(width: 8),
                        _rBtn('Delete Report', red, Icons.delete_outline, () async {
                          await FirebaseFirestore.instance.collection(collection).doc(rid).delete();
                        }),
                        if (r['postId'] != null) ...[
                          const SizedBox(width: 8),
                          _rBtn('Delete Post', Colors.deepOrange, Icons.remove_circle_outline, () async {
                            await FirebaseFirestore.instance.collection('posts').doc(r['postId']).update({
                              'deletedByAdmin': true, 'adminDeletedAt': FieldValue.serverTimestamp(),
                            });
                            await FirebaseFirestore.instance.collection(collection).doc(rid)
                                .update({'resolved': true, 'resolvedAt': FieldValue.serverTimestamp()});
                          }),
                        ],
                      ]),
                    ]),
                  );
                },
              );
            },
          );
        }
        final docs = snap.data?.docs ?? [];
        if (docs.isEmpty) return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(Icons.flag_outlined, size: 48, color: Colors.white12),
          const SizedBox(height: 12),
          const Text('No reports yet', style: TextStyle(color: Colors.white38, fontSize: 15, fontWeight: FontWeight.w600)),
        ]));
        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: docs.length,
          itemBuilder: (_, i) {
            final r = docs[i].data() as Map<String, dynamic>;
            final rid = docs[i].id;
            final reason = r['reason'] as String? ?? 'Unknown';
            final resolved = r['resolved'] == true;
            final reportedBy = r['reportedBy'] as String? ?? '';
            final ts = r['timestamp'] as Timestamp?;

            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: card, borderRadius: BorderRadius.circular(14),
                border: Border.all(color: resolved ? Colors.white.withValues(alpha: 0.05) : red.withValues(alpha: 0.3)),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: resolved ? Colors.white10 : red.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(8)),
                    child: Text(resolved ? 'RESOLVED' : 'PENDING',
                      style: TextStyle(color: resolved ? Colors.white38 : red, fontSize: 10, fontWeight: FontWeight.w900)),
                  ),
                  const SizedBox(width: 8),
                  Expanded(child: Text(reason, style: const TextStyle(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.w700))),
                  if (ts != null) Text(_timeAgo(ts.toDate()), style: const TextStyle(color: Colors.white38, fontSize: 11)),
                ]),
                const SizedBox(height: 8),
                FutureBuilder<DocumentSnapshot?>(
                  future: reportedBy.isNotEmpty
                      ? FirebaseFirestore.instance.collection('users').doc(reportedBy).get()
                      : Future.value(null),
                  builder: (_, us) {
                    final u = us.data?.data() as Map<String, dynamic>? ?? {};
                    final name = u['username'] ?? 'Unknown';
                    return Text('Reported by: @$name', style: const TextStyle(color: Colors.white38, fontSize: 11));
                  },
                ),
                // Show postId / authorId etc. if present
                if (r['postId'] != null) Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text('Post: ${r['postId']}', style: const TextStyle(color: Colors.white24, fontSize: 10, fontFamily: 'monospace')),
                ),
                const SizedBox(height: 12),
                Row(children: [
                  if (!resolved)
                    _rBtn('Mark Resolved', green, Icons.check_circle_outline, () async {
                      await FirebaseFirestore.instance.collection(collection).doc(rid)
                          .update({'resolved': true, 'resolvedAt': FieldValue.serverTimestamp()});
                    }),
                  const SizedBox(width: 8),
                  _rBtn('Delete Report', red, Icons.delete_outline, () async {
                    await FirebaseFirestore.instance.collection(collection).doc(rid).delete();
                  }),
                  if (r['postId'] != null) ...[
                    const SizedBox(width: 8),
                    _rBtn('Delete Post', Colors.deepOrange, Icons.remove_circle_outline, () async {
                      await FirebaseFirestore.instance.collection('posts').doc(r['postId']).update({
                        'deletedByAdmin': true, 'adminDeletedAt': FieldValue.serverTimestamp(),
                      });
                      await FirebaseFirestore.instance.collection(collection).doc(rid)
                          .update({'resolved': true, 'resolvedAt': FieldValue.serverTimestamp()});
                    }),
                  ],
                ]),
              ]),
            );
          },
        );
      },
    );
  }

  Widget _rBtn(String label, Color color, IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withValues(alpha: 0.3))),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: color, size: 13),
          const SizedBox(width: 5),
          Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w700)),
        ]),
      ),
    );
  }

  String _timeAgo(DateTime dt) {
    final d = DateTime.now().difference(dt);
    if (d.inMinutes < 1) return 'Just now';
    if (d.inHours < 1) return '${d.inMinutes}m ago';
    if (d.inDays < 1) return '${d.inHours}h ago';
    return '${d.inDays}d ago';
  }
}

// ── APP CONTROL TAB ───────────────────────────────────────────────────────────
class _AppControlTab extends StatefulWidget {
  final Color blue, card, green;
  const _AppControlTab({required this.blue, required this.card, required this.green});
  @override State<_AppControlTab> createState() => _AppControlTabState();
}

class _AppControlTabState extends State<_AppControlTab> {
  final _apkCtrl          = TextEditingController();
  final _versionCtrl      = TextEditingController();
  final _maintenanceCtrl  = TextEditingController();
  final _mainLinkCtrl     = TextEditingController();
  final _appLogoCtrl      = TextEditingController();
  final _splashLogoCtrl   = TextEditingController();
  final _donaterBadgeCtrl = TextEditingController();
  final _adminEmailCtrl   = TextEditingController();
  final _adminPassCtrl    = TextEditingController();
  bool _maintenanceMode = false;
  bool _loading = true;
  bool _obscureAdminPass = true;
  // Upload loading states
  bool _uploadingAppLogo     = false;
  bool _uploadingSplashLogo  = false;
  bool _uploadingDonaterBadge = false;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _pickAndUpload(TextEditingController ctrl, String label, Function(bool) setUploading) async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
    if (picked == null) return;
    setUploading(true);
    try {
      final url = await FileService.uploadFile(File(picked.path), 'admin');
      if (mounted) {
        ctrl.text = url;
        setState(() {});
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('$label uploaded!'),
          backgroundColor: widget.green,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Upload failed: $e'),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating));
    } finally {
      setUploading(false);
    }
  }

  Future<void> _load() async {
    try {
      final doc = await FirebaseFirestore.instance.collection('appConfig').doc('main').get();
      final data = doc.data() ?? {};
      _apkCtrl.text          = data['apkDownloadUrl']    ?? '';
      _versionCtrl.text      = data['latestVersion']     ?? '';
      _maintenanceCtrl.text  = data['maintenanceMessage'] ?? 'App is under maintenance. Please check back soon.';
      _mainLinkCtrl.text     = data['maintenanceLink']   ?? '';
      _appLogoCtrl.text      = data['appLogoUrl']        ?? '';
      _splashLogoCtrl.text   = data['splashLogoUrl']     ?? '';
      _donaterBadgeCtrl.text = data['donaterBadgeUrl']   ?? '';
      _maintenanceMode       = data['maintenanceMode']   == true;
    } catch (_) {}

    try {
      final adminDoc  = await FirebaseFirestore.instance.collection('appConfig').doc('adminAccess').get();
      final adminData = adminDoc.data() ?? {};
      _adminEmailCtrl.text = adminData['adminEmail']    ?? '';
      _adminPassCtrl.text  = adminData['adminPassword'] ?? '';
    } catch (_) {}

    if (mounted) setState(() => _loading = false);
  }

  Future<void> _save() async {
    await FirebaseFirestore.instance.collection('appConfig').doc('main').set({
      'apkDownloadUrl':     _apkCtrl.text.trim(),
      'latestVersion':      _versionCtrl.text.trim(),
      'maintenanceMode':    _maintenanceMode,
      'maintenanceMessage': _maintenanceCtrl.text.trim(),
      'maintenanceLink':    _mainLinkCtrl.text.trim(),
      'appLogoUrl':         _appLogoCtrl.text.trim(),
      'splashLogoUrl':      _splashLogoCtrl.text.trim(),
      'donaterBadgeUrl':    _donaterBadgeCtrl.text.trim(),
      'updatedAt':          FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Text('App config saved!'),
      backgroundColor: widget.green,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }

  Future<void> _saveAdminAccess() async {
    final email = _adminEmailCtrl.text.trim().toLowerCase();
    final pass  = _adminPassCtrl.text.trim();
    if (email.isEmpty || pass.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Email and password are both required'),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating));
      return;
    }
    await FirebaseFirestore.instance.collection('appConfig').doc('adminAccess').set({
      'adminEmail':    email,
      'adminPassword': pass,
      'updatedAt':     FieldValue.serverTimestamp(),
    });
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Text('Admin access saved! Next login se apply hoga.'),
      backgroundColor: widget.green,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }

  @override
  void dispose() {
    _apkCtrl.dispose(); _versionCtrl.dispose(); _maintenanceCtrl.dispose();
    _mainLinkCtrl.dispose(); _appLogoCtrl.dispose(); _splashLogoCtrl.dispose();
    _donaterBadgeCtrl.dispose(); _adminEmailCtrl.dispose(); _adminPassCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: Color(0xFF0284C7)));
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

        // App Logo
        _sectionTitle('App Logo'),
        _uploadField(
          ctrl: _appLogoCtrl,
          hint: 'App Logo URL',
          icon: Icons.image_outlined,
          uploading: _uploadingAppLogo,
          onUpload: () => _pickAndUpload(_appLogoCtrl, 'App Logo',
            (v) => setState(() => _uploadingAppLogo = v)),
        ),
        const SizedBox(height: 8),
        if (_appLogoCtrl.text.isNotEmpty)
          Center(child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.network(_appLogoCtrl.text, height: 60, width: 60, fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white30, size: 40)))),
        const SizedBox(height: 24),

        // Splash Logo
        _sectionTitle('Splash Screen Logo'),
        _uploadField(
          ctrl: _splashLogoCtrl,
          hint: 'Splash Logo URL',
          icon: Icons.phone_android_rounded,
          uploading: _uploadingSplashLogo,
          onUpload: () => _pickAndUpload(_splashLogoCtrl, 'Splash Logo',
            (v) => setState(() => _uploadingSplashLogo = v)),
        ),
        const SizedBox(height: 6),
        const Text('Shown on splash screen instead of default icon.', style: TextStyle(color: Colors.white38, fontSize: 11)),
        const SizedBox(height: 8),
        if (_splashLogoCtrl.text.isNotEmpty)
          Center(child: Container(width: 70, height: 70,
            decoration: BoxDecoration(color: const Color(0xFF0284C7), borderRadius: BorderRadius.circular(18),
              boxShadow: [BoxShadow(color: const Color(0xFF0284C7).withValues(alpha: 0.3), blurRadius: 16, offset: const Offset(0, 6))]),
            child: ClipRRect(borderRadius: BorderRadius.circular(18),
              child: Image.network(_splashLogoCtrl.text, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white30, size: 36))))),
        const SizedBox(height: 20),

        // Donater Badge PNG
        _sectionTitle('Donater Badge PNG'),
        _uploadField(
          ctrl: _donaterBadgeCtrl,
          hint: 'Donater Badge URL',
          icon: Icons.favorite_rounded,
          uploading: _uploadingDonaterBadge,
          onUpload: () => _pickAndUpload(_donaterBadgeCtrl, 'Donater Badge',
            (v) => setState(() => _uploadingDonaterBadge = v)),
        ),
        const SizedBox(height: 6),
        const Text('Shows next to donater names in app.', style: TextStyle(color: Colors.white38, fontSize: 11)),
        const SizedBox(height: 8),
        if (_donaterBadgeCtrl.text.isNotEmpty)
          Center(child: Container(padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: const Color(0xFFFF6B9D).withValues(alpha: 0.1), borderRadius: BorderRadius.circular(12)),
            child: Image.network(_donaterBadgeCtrl.text, width: 40, height: 40, fit: BoxFit.contain,
              errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white30, size: 40)))),
        const SizedBox(height: 20),

        // APK Download
        _sectionTitle('APK Download'),
        _darkField(_versionCtrl, 'Latest version (e.g. 1.7.0)', Icons.new_releases_outlined),
        const SizedBox(height: 10),
        _darkField(_apkCtrl, 'APK Download URL', Icons.link_rounded),
        const SizedBox(height: 4),
        const Text('Users will see an update prompt when a new version is set.', style: TextStyle(color: Colors.white38, fontSize: 11)),
        const SizedBox(height: 24),

        // Maintenance Mode
        _sectionTitle('Maintenance Mode'),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: widget.card, borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _maintenanceMode ? Colors.orange.withValues(alpha: 0.4) : Colors.white.withValues(alpha: 0.06)),
          ),
          child: Column(children: [
            Row(children: [
              const Icon(Icons.construction_rounded, color: Colors.orange, size: 20),
              const SizedBox(width: 10),
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Maintenance Mode', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14)),
                Text('Blocks all users from using the app', style: TextStyle(color: Colors.white38, fontSize: 11)),
              ])),
              Switch(value: _maintenanceMode, activeColor: Colors.orange, onChanged: (v) => setState(() => _maintenanceMode = v)),
            ]),
            if (_maintenanceMode) ...[
              const SizedBox(height: 12),
              _darkField(_maintenanceCtrl, 'Maintenance message', Icons.message_outlined, maxLines: 3),
              const SizedBox(height: 10),
              _darkField(_mainLinkCtrl, 'Link (shown on maintenance screen)', Icons.link_rounded),
            ],
          ]),
        ),

        const SizedBox(height: 24),
        SizedBox(
          width: double.infinity, height: 50,
          child: ElevatedButton(
            onPressed: _save,
            style: ElevatedButton.styleFrom(
              backgroundColor: widget.blue,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            child: const Text('Save App Config', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
          ),
        ),

        const SizedBox(height: 32),
        const Divider(color: Colors.white12),
        const SizedBox(height: 16),

        // ── Admin Access Section ────────────────────────────────────────────
        _sectionTitle('Admin Access (Email & Password)'),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: widget.card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFFFBB35).withValues(alpha: 0.35)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Icon(Icons.shield_rounded, color: Color(0xFFFFBB35), size: 18),
              const SizedBox(width: 8),
              const Expanded(child: Text(
                'Jo email+password yahan set hogi, woh account automatically admin ban jayega jab login karega.',
                style: TextStyle(color: Colors.white54, fontSize: 11, height: 1.4),
              )),
            ]),
            const SizedBox(height: 14),
            // Email field
            TextField(
              controller: _adminEmailCtrl,
              keyboardType: TextInputType.emailAddress,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              decoration: InputDecoration(
                hintText: 'Admin Email (e.g. admin@zylo.com)',
                hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
                prefixIcon: const Icon(Icons.email_outlined, color: Colors.white38, size: 18),
                filled: true, fillColor: const Color(0xFF222222),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              ),
            ),
            const SizedBox(height: 10),
            // Password field
            TextField(
              controller: _adminPassCtrl,
              obscureText: _obscureAdminPass,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              decoration: InputDecoration(
                hintText: 'Admin Password',
                hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
                prefixIcon: const Icon(Icons.lock_outline, color: Colors.white38, size: 18),
                suffixIcon: IconButton(
                  icon: Icon(_obscureAdminPass ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                    color: Colors.white38, size: 18),
                  onPressed: () => setState(() => _obscureAdminPass = !_obscureAdminPass),
                ),
                filled: true, fillColor: const Color(0xFF222222),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              ),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity, height: 44,
              child: ElevatedButton.icon(
                onPressed: _saveAdminAccess,
                icon: const Icon(Icons.save_rounded, size: 16, color: Colors.white),
                label: const Text('Save Admin Access', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFFBB35),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _sectionTitle(String t) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Text(t, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
  );

  Widget _darkField(TextEditingController ctrl, String hint, IconData icon, {int maxLines = 1}) {
    return TextField(
      controller: ctrl,
      maxLines: maxLines,
      style: const TextStyle(color: Colors.white, fontSize: 13),
      onChanged: (_) => setState(() {}),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
        prefixIcon: Icon(icon, color: Colors.white38, size: 18),
        filled: true, fillColor: const Color(0xFF222222),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      ),
    );
  }

  // Upload field: text field + gallery pick button
  Widget _uploadField({
    required TextEditingController ctrl,
    required String hint,
    required IconData icon,
    required bool uploading,
    required VoidCallback onUpload,
  }) {
    return Row(children: [
      Expanded(child: TextField(
        controller: ctrl,
        style: const TextStyle(color: Colors.white, fontSize: 13),
        onChanged: (_) => setState(() {}),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
          prefixIcon: Icon(icon, color: Colors.white38, size: 18),
          filled: true, fillColor: const Color(0xFF222222),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        ),
      )),
      const SizedBox(width: 8),
      GestureDetector(
        onTap: uploading ? null : onUpload,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: 48, height: 48,
          decoration: BoxDecoration(
            color: uploading ? Colors.white10 : widget.blue.withValues(alpha: 0.15),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: widget.blue.withValues(alpha: 0.4)),
          ),
          child: uploading
            ? const Center(child: SizedBox(width: 18, height: 18,
                child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF0284C7))))
            : const Icon(Icons.upload_rounded, color: Color(0xFF0284C7), size: 22),
        ),
      ),
    ]);
  }
}

// ── BANNER TAB ────────────────────────────────────────────────────────────────
class _BannerTab extends StatefulWidget {
  final Color blue, card;
  const _BannerTab({required this.blue, required this.card});
  @override State<_BannerTab> createState() => _BannerTabState();
}

class _BannerTabState extends State<_BannerTab> {
  final _imageCtrl = TextEditingController();
  final _linkCtrl  = TextEditingController();
  final _titleCtrl = TextEditingController();
  String _type = 'image';
  bool _active = true;
  bool _loading = true;
  bool _uploading = false;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _pickAndUploadBanner() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
    if (picked == null) return;
    setState(() => _uploading = true);
    try {
      final url = await FileService.uploadFile(File(picked.path), 'admin_banner');
      if (mounted) {
        _imageCtrl.text = url;
        setState(() {});
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Banner image uploaded!'),
          backgroundColor: Color(0xFF10B981),
          behavior: SnackBarBehavior.floating));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Upload failed: $e'), backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating));
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  Future<void> _load() async {
    try {
      final doc = await FirebaseFirestore.instance.collection('appConfig').doc('banner').get();
      final d = doc.data() ?? {};
      _imageCtrl.text = d['mediaUrl'] ?? '';
      _linkCtrl.text  = d['linkUrl']  ?? '';
      _titleCtrl.text = d['title']    ?? '';
      _type   = d['type']   ?? 'image';
      _active = d['active'] != false;
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _save() async {
    await FirebaseFirestore.instance.collection('appConfig').doc('banner').set({
      'mediaUrl': _imageCtrl.text.trim(),
      'linkUrl':  _linkCtrl.text.trim(),
      'title':    _titleCtrl.text.trim(),
      'type':     _type,
      'active':   _active,
      'updatedAt': FieldValue.serverTimestamp(),
    });
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Text('Banner saved!'),
      backgroundColor: const Color(0xFF10B981),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }

  @override
  void dispose() { _imageCtrl.dispose(); _linkCtrl.dispose(); _titleCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: Color(0xFF0284C7)));
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Chat List Top Banner', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
        const SizedBox(height: 4),
        const Text('Shown at the top of the chats screen for all users.', style: TextStyle(color: Colors.white38, fontSize: 12)),
        const SizedBox(height: 16),

        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: widget.card, borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.white.withValues(alpha: 0.06))),
          child: Row(children: [
            Icon(Icons.visibility_outlined, color: _active ? const Color(0xFF10B981) : Colors.white38, size: 20),
            const SizedBox(width: 10),
            const Expanded(child: Text('Show Banner', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700))),
            Switch(value: _active, activeColor: const Color(0xFF10B981), onChanged: (v) => setState(() => _active = v)),
          ]),
        ),
        const SizedBox(height: 12),

        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: widget.card, borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.white.withValues(alpha: 0.06))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Media Type', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w700, fontSize: 13)),
            const SizedBox(height: 10),
            Row(children: [
              _typeBtn('image', Icons.image_outlined, 'Image / Poster'),
              const SizedBox(width: 10),
              _typeBtn('video', Icons.videocam_outlined, 'Video'),
            ]),
          ]),
        ),
        const SizedBox(height: 12),

        _darkField(_titleCtrl, 'Banner Title (optional)', Icons.title),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: _darkField(_imageCtrl,
            _type == 'video' ? 'Video URL' : 'Image URL',
            _type == 'video' ? Icons.link : Icons.link_rounded)),
          if (_type == 'image') ...[
            const SizedBox(width: 8),
            GestureDetector(
              onTap: _uploading ? null : _pickAndUploadBanner,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: 48, height: 48,
                decoration: BoxDecoration(
                  color: _uploading ? Colors.white10 : widget.blue.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: widget.blue.withValues(alpha: 0.4))),
                child: _uploading
                  ? const Center(child: SizedBox(width: 18, height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF0284C7))))
                  : const Icon(Icons.upload_rounded, color: Color(0xFF0284C7), size: 22),
              ),
            ),
          ],
        ]),
        const SizedBox(height: 10),
        _darkField(_linkCtrl, 'Tap link URL (optional)', Icons.open_in_new),

        // Preview
        if (_imageCtrl.text.isNotEmpty && _type == 'image') ...[
          const SizedBox(height: 16),
          const Text('Preview', style: TextStyle(color: Colors.white38, fontSize: 12, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.network(_imageCtrl.text, height: 120, width: double.infinity, fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(height: 120, color: Colors.white10, child: const Icon(Icons.broken_image, color: Colors.white30))),
          ),
        ],

        const SizedBox(height: 24),
        SizedBox(
          width: double.infinity, height: 50,
          child: ElevatedButton(
            onPressed: _save,
            style: ElevatedButton.styleFrom(
              backgroundColor: widget.blue,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            child: const Text('Save Banner', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
          ),
        ),
      ]),
    );
  }

  Widget _typeBtn(String value, IconData icon, String label) {
    final selected = _type == value;
    return Expanded(child: GestureDetector(
      onTap: () => setState(() => _type = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: selected ? widget.blue.withValues(alpha: 0.15) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: selected ? widget.blue : Colors.white.withValues(alpha: 0.1)),
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: selected ? widget.blue : Colors.white38, size: 20),
          const SizedBox(height: 4),
          Text(label, style: TextStyle(color: selected ? widget.blue : Colors.white38, fontSize: 11, fontWeight: FontWeight.w600)),
        ]),
      ),
    ));
  }

  Widget _darkField(TextEditingController ctrl, String hint, IconData icon) {
    return TextField(
      controller: ctrl,
      style: const TextStyle(color: Colors.white, fontSize: 13),
      onChanged: (_) => setState(() {}),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
        prefixIcon: Icon(icon, color: Colors.white38, size: 18),
        filled: true, fillColor: const Color(0xFF222222),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      ),
    );
  }
}

// ── ADMIN FEED POST TAB ───────────────────────────────────────────────────────
// Admin can post directly to the feed with image/video/text
class _AdminFeedPostTab extends StatefulWidget {
  final Color blue, card, green;
  const _AdminFeedPostTab({required this.blue, required this.card, required this.green});
  @override State<_AdminFeedPostTab> createState() => _AdminFeedPostTabState();
}

class _AdminFeedPostTabState extends State<_AdminFeedPostTab> {
  final _textCtrl     = TextEditingController();
  final _imageUrlCtrl = TextEditingController();
  final _videoUrlCtrl = TextEditingController();
  bool _isPosting = false;
  String _mediaType = 'none'; // none, image, video

  @override
  void dispose() { _textCtrl.dispose(); _imageUrlCtrl.dispose(); _videoUrlCtrl.dispose(); super.dispose(); }

  Future<void> _post() async {
    final text  = _textCtrl.text.trim();
    final image = _imageUrlCtrl.text.trim();
    final video = _videoUrlCtrl.text.trim();
    if (text.isEmpty && image.isEmpty && video.isEmpty) return;
    setState(() => _isPosting = true);
    try {
      final Map<String, dynamic> data = {
        'text': text,
        'authorId': 'admin',
        'isAdminPost': true,
        'createdAt': FieldValue.serverTimestamp(),
        'likes': [],
        'commentCount': 0,
      };
      if (image.isNotEmpty) data['images'] = [image];
      if (video.isNotEmpty) data['files'] = [{'url': video, 'type': 'video', 'name': 'Admin Video'}];
      await FirebaseFirestore.instance.collection('posts').add(data);
      _textCtrl.clear();
      _imageUrlCtrl.clear();
      _videoUrlCtrl.clear();
      setState(() => _mediaType = 'none');
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Post published to feed!'),
        backgroundColor: widget.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ));
    } finally {
      if (mounted) setState(() => _isPosting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Post to Feed', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
        const SizedBox(height: 4),
        const Text('Published as an official admin post visible to all users.', style: TextStyle(color: Colors.white38, fontSize: 12)),
        const SizedBox(height: 16),

        // Admin badge preview
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: widget.card, borderRadius: BorderRadius.circular(14)),
          child: Row(children: [
            Container(width: 40, height: 40, decoration: BoxDecoration(
              gradient: LinearGradient(colors: [widget.blue, const Color(0xFF7C3AED)]),
              borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.admin_panel_settings, color: Colors.white, size: 22)),
            const SizedBox(width: 12),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Text('Zylo Admin', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14)),
                const SizedBox(width: 4),
                const Icon(Icons.verified, color: Color(0xFF0284C7), size: 14),
              ]),
              const Text('Official post', style: TextStyle(color: Colors.white38, fontSize: 11)),
            ]),
          ]),
        ),
        const SizedBox(height: 16),

        // Text
        TextField(
          controller: _textCtrl,
          maxLines: 5,
          style: const TextStyle(color: Colors.white, fontSize: 14),
          decoration: InputDecoration(
            hintText: 'Write your announcement or post...',
            hintStyle: const TextStyle(color: Colors.white38, fontSize: 14),
            filled: true, fillColor: const Color(0xFF222222),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
            contentPadding: const EdgeInsets.all(14),
          ),
        ),
        const SizedBox(height: 16),

        // Media type selector
        Row(children: [
          _mediaTypeBtn('none', Icons.text_fields, 'Text Only'),
          const SizedBox(width: 8),
          _mediaTypeBtn('image', Icons.image_outlined, 'Image'),
          const SizedBox(width: 8),
          _mediaTypeBtn('video', Icons.videocam_outlined, 'Video'),
        ]),
        const SizedBox(height: 14),

        if (_mediaType == 'image') ...[
          _darkField(_imageUrlCtrl, 'Image URL (direct link)', Icons.link_rounded),
          const SizedBox(height: 8),
          if (_imageUrlCtrl.text.isNotEmpty)
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.network(_imageUrlCtrl.text, height: 150, width: double.infinity, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(height: 150, color: Colors.white10,
                  child: const Icon(Icons.broken_image, color: Colors.white30, size: 40))),
            ),
        ],

        if (_mediaType == 'video') ...[
          _darkField(_videoUrlCtrl, 'Video URL (direct link)', Icons.link_rounded),
        ],

        const SizedBox(height: 24),
        SizedBox(
          width: double.infinity, height: 50,
          child: ElevatedButton(
            onPressed: _isPosting ? null : _post,
            style: ElevatedButton.styleFrom(
              backgroundColor: widget.blue,
              disabledBackgroundColor: const Color(0xFF1A1A1A),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            child: _isPosting
                ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : const Text('Publish Post', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
          ),
        ),

        const SizedBox(height: 32),
        const Divider(color: Colors.white12),
        const SizedBox(height: 12),
        const Text('Recent Admin Posts', style: TextStyle(color: Colors.white60, fontSize: 13, fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance.collection('posts')
              .where('isAdminPost', isEqualTo: true)
              .orderBy('createdAt', descending: true)
              .limit(10).snapshots(),
          builder: (_, snap) {
            final posts = snap.data?.docs ?? [];
            if (posts.isEmpty) return const Text('No admin posts yet.', style: TextStyle(color: Colors.white24, fontSize: 12));
            return Column(children: posts.map((doc) {
              final p = doc.data() as Map<String, dynamic>;
              final text = p['text'] as String? ?? '';
              final ts = p['createdAt'] as Timestamp?;
              return Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: widget.card, borderRadius: BorderRadius.circular(12)),
                child: Row(children: [
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    if (text.isNotEmpty) Text(text.length > 80 ? '${text.substring(0, 80)}...' : text,
                      style: const TextStyle(color: Colors.white70, fontSize: 12)),
                    if (ts != null) Text(_timeAgo(ts.toDate()), style: const TextStyle(color: Colors.white38, fontSize: 10)),
                  ])),
                  GestureDetector(
                    onTap: () async {
                      await FirebaseFirestore.instance.collection('posts').doc(doc.id).delete();
                    },
                    child: const Padding(padding: EdgeInsets.all(6),
                      child: Icon(Icons.delete_outline, color: Colors.red, size: 18)),
                  ),
                ]),
              );
            }).toList());
          },
        ),
      ]),
    );
  }

  Widget _mediaTypeBtn(String value, IconData icon, String label) {
    final selected = _mediaType == value;
    return Expanded(child: GestureDetector(
      onTap: () => setState(() => _mediaType = value),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 9),
        decoration: BoxDecoration(
          color: selected ? widget.blue.withValues(alpha: 0.15) : const Color(0xFF222222),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: selected ? widget.blue : Colors.white.withValues(alpha: 0.1)),
        ),
        child: Column(children: [
          Icon(icon, color: selected ? widget.blue : Colors.white38, size: 18),
          const SizedBox(height: 3),
          Text(label, style: TextStyle(color: selected ? widget.blue : Colors.white38, fontSize: 10, fontWeight: FontWeight.w600)),
        ]),
      ),
    ));
  }

  Widget _darkField(TextEditingController ctrl, String hint, IconData icon) {
    return TextField(
      controller: ctrl,
      style: const TextStyle(color: Colors.white, fontSize: 13),
      onChanged: (_) => setState(() {}),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
        prefixIcon: Icon(icon, color: Colors.white38, size: 18),
        filled: true, fillColor: const Color(0xFF222222),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      ),
    );
  }

  String _timeAgo(DateTime dt) {
    final d = DateTime.now().difference(dt);
    if (d.inMinutes < 1) return 'Just now';
    if (d.inHours < 1) return '${d.inMinutes}m ago';
    if (d.inDays < 1) return '${d.inHours}h ago';
    return '${d.inDays}d ago';
  }
}

String _timeAgo(DateTime dt) {
  final d = DateTime.now().difference(dt);
  if (d.inMinutes < 1) return 'Just now';
  if (d.inHours < 1) return '${d.inMinutes}m ago';
  if (d.inDays < 1) return '${d.inHours}h ago';
  return '${d.inDays}d ago';
}

// ── NOTIFICATIONS TAB ─────────────────────────────────────────────────────────
// View all notifications sent across the app (system-wide)
class _NotificationsTab extends StatelessWidget {
  final Color blue, card, green, red;
  const _NotificationsTab({required this.blue, required this.card, required this.green, required this.red});

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Container(
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: card, borderRadius: BorderRadius.circular(14),
          border: Border.all(color: blue.withValues(alpha: 0.25)),
        ),
        child: Row(children: [
          Container(width: 40, height: 40,
            decoration: BoxDecoration(color: blue.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(12)),
            child: Icon(Icons.notifications_rounded, color: blue, size: 20)),
          const SizedBox(width: 12),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('App Notifications', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14)),
            Text('All notifications delivered across the platform', style: TextStyle(color: Colors.white38, fontSize: 11)),
          ])),
        ]),
      ),
      Expanded(
        child: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance
              .collectionGroup('notifications')
              .orderBy('createdAt', descending: true)
              .limit(100)
              .snapshots(),
          builder: (_, snap) {
            if (snap.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator(color: Color(0xFF0284C7)));
            }
            if (snap.hasError) {
              // Fallback: show admin_notifications collection
              return StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('admin_notifications')
                    .orderBy('createdAt', descending: true)
                    .limit(60)
                    .snapshots(),
                builder: (_, s2) {
                  final docs = s2.data?.docs ?? [];
                  if (docs.isEmpty) {
                    return _emptyState('No notifications yet', Icons.notifications_none);
                  }
                  return _notifList(context, docs);
                },
              );
            }
            final docs = snap.data?.docs ?? [];
            if (docs.isEmpty) return _emptyState('No notifications yet', Icons.notifications_none);
            return _notifList(context, docs);
          },
        ),
      ),
    ]);
  }

  Widget _notifList(BuildContext ctx, List<QueryDocumentSnapshot> docs) {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 20),
      itemCount: docs.length,
      itemBuilder: (_, i) {
        final d = docs[i].data() as Map<String, dynamic>;
        final type = d['type'] as String? ?? 'system';
        final text = d['text'] as String? ?? d['message'] as String? ?? '';
        final read = d['read'] as bool? ?? false;
        final ts = d['createdAt'] as Timestamp?;
        final uid = d['userId'] as String? ?? '';

        Color typeColor;
        IconData typeIcon;
        switch (type) {
          case 'friend_request': typeColor = const Color(0xFF0284C7); typeIcon = Icons.person_add; break;
          case 'broadcast': typeColor = const Color(0xFFFFBB35); typeIcon = Icons.campaign_rounded; break;
          case 'announcement': typeColor = const Color(0xFF10B981); typeIcon = Icons.announcement_rounded; break;
          default: typeColor = Colors.grey; typeIcon = Icons.notifications;
        }

        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: card,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: read ? Colors.white.withValues(alpha: 0.05) : typeColor.withValues(alpha: 0.25)),
          ),
          child: Row(children: [
            Container(width: 36, height: 36,
              decoration: BoxDecoration(color: typeColor.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
              child: Icon(typeIcon, color: typeColor, size: 17)),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(text.isNotEmpty ? text : '(no content)',
                style: TextStyle(color: read ? Colors.white38 : Colors.white70, fontSize: 12,
                  fontWeight: read ? FontWeight.normal : FontWeight.w600)),
              const SizedBox(height: 3),
              Row(children: [
                Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(color: typeColor.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(6)),
                  child: Text(type, style: TextStyle(color: typeColor, fontSize: 9, fontWeight: FontWeight.w800))),
                if (uid.isNotEmpty) ...[ const SizedBox(width: 6),
                  Text('uid: ${uid.substring(0, 6)}...', style: const TextStyle(color: Colors.white24, fontSize: 9))],
                const Spacer(),
                if (ts != null) Text(_timeAgo(ts.toDate()), style: const TextStyle(color: Colors.white24, fontSize: 9)),
              ]),
            ])),
            if (!read) Container(width: 8, height: 8,
              margin: const EdgeInsets.only(left: 8),
              decoration: BoxDecoration(color: typeColor, shape: BoxShape.circle)),
          ]),
        );
      },
    );
  }

  Widget _emptyState(String msg, IconData icon) {
    return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(icon, size: 52, color: Colors.white12),
      const SizedBox(height: 12),
      Text(msg, style: const TextStyle(color: Colors.white38, fontSize: 15, fontWeight: FontWeight.w600)),
    ]));
  }

  String _timeAgo(DateTime dt) {
    final d = DateTime.now().difference(dt);
    if (d.inMinutes < 1) return 'Just now';
    if (d.inHours < 1) return '${d.inMinutes}m ago';
    if (d.inDays < 1) return '${d.inHours}h ago';
    return '${d.inDays}d ago';
  }
}

// ── BROADCAST TAB ─────────────────────────────────────────────────────────────
// Send a push notification / in-app message to ALL users at once
class _BroadcastTab extends StatefulWidget {
  final Color blue, card, green;
  const _BroadcastTab({required this.blue, required this.card, required this.green});
  @override State<_BroadcastTab> createState() => _BroadcastTabState();
}

class _BroadcastTabState extends State<_BroadcastTab> {
  final _titleCtrl   = TextEditingController();
  final _messageCtrl = TextEditingController();
  String _targetGroup = 'all'; // all | active | new
  bool _sending = false;

  @override
  void dispose() { _titleCtrl.dispose(); _messageCtrl.dispose(); super.dispose(); }

  Future<void> _sendBroadcast() async {
    final title   = _titleCtrl.text.trim();
    final message = _messageCtrl.text.trim();
    if (title.isEmpty || message.isEmpty) return;

    setState(() => _sending = true);
    try {
      // 1. Store broadcast record
      await FirebaseFirestore.instance.collection('broadcasts').add({
        'title': title,
        'message': message,
        'targetGroup': _targetGroup,
        'sentAt': FieldValue.serverTimestamp(),
        'sentBy': 'admin',
      });

      // 2. Add notification to each user's subcollection
      Query usersQuery = FirebaseFirestore.instance.collection('users');
      if (_targetGroup == 'active') {
        usersQuery = usersQuery.where('isOnline', isEqualTo: true);
      } else if (_targetGroup == 'new') {
        final cutoff = Timestamp.fromDate(DateTime.now().subtract(const Duration(days: 7)));
        usersQuery = usersQuery.where('createdAt', isGreaterThanOrEqualTo: cutoff);
      }

      final users = await usersQuery.get();
      final batch = FirebaseFirestore.instance.batch();
      for (final userDoc in users.docs) {
        final notifRef = FirebaseFirestore.instance
            .collection('users').doc(userDoc.id)
            .collection('notifications').doc();
        batch.set(notifRef, {
          'type': 'broadcast',
          'title': title,
          'text': message,
          'read': false,
          'createdAt': FieldValue.serverTimestamp(),
        });
      }
      await batch.commit();

      _titleCtrl.clear();
      _messageCtrl.clear();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('📢 Broadcast sent to ${users.docs.length} users!'),
          backgroundColor: widget.green,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Error: $e'), backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final canSend = _titleCtrl.text.trim().isNotEmpty && _messageCtrl.text.trim().isNotEmpty;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Broadcast Message', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18)),
        const SizedBox(height: 4),
        const Text('Send an in-app notification to users instantly.', style: TextStyle(color: Colors.white38, fontSize: 12)),
        const SizedBox(height: 20),

        // Target group
        _label('Target Group'),
        Row(children: [
          _groupBtn('all',    Icons.people_rounded,       'All Users'),
          const SizedBox(width: 8),
          _groupBtn('active', Icons.circle,               'Active Now'),
          const SizedBox(width: 8),
          _groupBtn('new',    Icons.person_add_rounded,   'New (7d)'),
        ]),
        const SizedBox(height: 16),

        // Title
        _label('Notification Title'),
        _field(_titleCtrl, 'e.g. 🎉 New Feature!', Icons.title_rounded),
        const SizedBox(height: 12),

        // Message
        _label('Message Body'),
        TextField(
          controller: _messageCtrl,
          maxLines: 4,
          style: const TextStyle(color: Colors.white, fontSize: 13),
          onChanged: (_) => setState(() {}),
          decoration: InputDecoration(
            hintText: 'Write your broadcast message here...',
            hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
            filled: true, fillColor: const Color(0xFF222222),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            contentPadding: const EdgeInsets.all(14),
          ),
        ),
        const SizedBox(height: 24),

        // Send button
        SizedBox(width: double.infinity, height: 50,
          child: ElevatedButton.icon(
            onPressed: (canSend && !_sending) ? _sendBroadcast : null,
            icon: _sending
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : const Icon(Icons.campaign_rounded, size: 20, color: Colors.white),
            label: Text(_sending ? 'Sending...' : 'Send Broadcast',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
            style: ElevatedButton.styleFrom(
              backgroundColor: canSend ? const Color(0xFFFFBB35) : Colors.grey[800],
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
        ),

        const SizedBox(height: 32),
        const Divider(color: Colors.white12),
        const SizedBox(height: 12),
        const Text('Broadcast History', style: TextStyle(color: Colors.white60, fontSize: 13, fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),

        StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance.collection('broadcasts')
              .orderBy('sentAt', descending: true).limit(15).snapshots(),
          builder: (_, snap) {
            final docs = snap.data?.docs ?? [];
            if (docs.isEmpty) return const Text('No broadcasts yet.', style: TextStyle(color: Colors.white24, fontSize: 12));
            return Column(children: docs.map((doc) {
              final d = doc.data() as Map<String, dynamic>;
              final ts = d['sentAt'] as Timestamp?;
              return Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: widget.card, borderRadius: BorderRadius.circular(12)),
                child: Row(children: [
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(d['title'] ?? '', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
                    const SizedBox(height: 2),
                    Text(d['message'] ?? '', style: const TextStyle(color: Colors.white38, fontSize: 11), maxLines: 2, overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 4),
                    Row(children: [
                      Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(color: const Color(0xFFFFBB35).withValues(alpha: 0.1), borderRadius: BorderRadius.circular(6)),
                        child: Text(d['targetGroup'] ?? 'all', style: const TextStyle(color: Color(0xFFFFBB35), fontSize: 9, fontWeight: FontWeight.w800))),
                      if (ts != null) ...[ const SizedBox(width: 8),
                        Text(_timeAgo2(ts.toDate()), style: const TextStyle(color: Colors.white24, fontSize: 10))],
                    ]),
                  ])),
                  GestureDetector(
                    onTap: () => doc.reference.delete(),
                    child: const Padding(padding: EdgeInsets.all(6),
                      child: Icon(Icons.delete_outline, color: Colors.red, size: 18))),
                ]),
              );
            }).toList());
          },
        ),
      ]),
    );
  }

  Widget _label(String t) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Text(t, style: const TextStyle(color: Colors.white60, fontSize: 12, fontWeight: FontWeight.w700)));

  Widget _field(TextEditingController ctrl, String hint, IconData icon) {
    return TextField(
      controller: ctrl,
      style: const TextStyle(color: Colors.white, fontSize: 13),
      onChanged: (_) => setState(() {}),
      decoration: InputDecoration(
        hintText: hint, hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
        prefixIcon: Icon(icon, color: Colors.white38, size: 18),
        filled: true, fillColor: const Color(0xFF222222),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      ),
    );
  }

  Widget _groupBtn(String value, IconData icon, String label) {
    final selected = _targetGroup == value;
    return Expanded(child: GestureDetector(
      onTap: () => setState(() => _targetGroup = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFFFBB35).withValues(alpha: 0.15) : const Color(0xFF222222),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: selected ? const Color(0xFFFFBB35) : Colors.white.withValues(alpha: 0.1)),
        ),
        child: Column(children: [
          Icon(icon, color: selected ? const Color(0xFFFFBB35) : Colors.white38, size: 18),
          const SizedBox(height: 3),
          Text(label, style: TextStyle(color: selected ? const Color(0xFFFFBB35) : Colors.white38, fontSize: 10, fontWeight: FontWeight.w600)),
        ]),
      ),
    ));
  }

  String _timeAgo2(DateTime dt) {
    final d = DateTime.now().difference(dt);
    if (d.inMinutes < 1) return 'Just now';
    if (d.inHours < 1) return '${d.inMinutes}m ago';
    if (d.inDays < 1) return '${d.inHours}h ago';
    return '${d.inDays}d ago';
  }
}

// ── ANNOUNCEMENTS TAB ─────────────────────────────────────────────────────────
// Pinned announcements shown to users inside app (like an info bar)
class _AnnouncementsTab extends StatefulWidget {
  final Color blue, card, green, red;
  const _AnnouncementsTab({required this.blue, required this.card, required this.green, required this.red});
  @override State<_AnnouncementsTab> createState() => _AnnouncementsTabState();
}

class _AnnouncementsTabState extends State<_AnnouncementsTab> {
  final _titleCtrl   = TextEditingController();
  final _bodyCtrl    = TextEditingController();
  final _linkCtrl    = TextEditingController();
  String _type = 'info'; // info | warning | success | update
  bool _pinned = false;
  bool _saving = false;

  @override
  void dispose() { _titleCtrl.dispose(); _bodyCtrl.dispose(); _linkCtrl.dispose(); super.dispose(); }

  Future<void> _publish() async {
    final title = _titleCtrl.text.trim();
    final body  = _bodyCtrl.text.trim();
    if (title.isEmpty || body.isEmpty) return;
    setState(() => _saving = true);
    try {
      await FirebaseFirestore.instance.collection('announcements').add({
        'title':     title,
        'body':      body,
        'link':      _linkCtrl.text.trim(),
        'type':      _type,
        'pinned':    _pinned,
        'active':    true,
        'createdAt': FieldValue.serverTimestamp(),
        'createdBy': 'admin',
      });
      _titleCtrl.clear(); _bodyCtrl.clear(); _linkCtrl.clear();
      setState(() { _type = 'info'; _pinned = false; });
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('📣 Announcement published!'),
        backgroundColor: widget.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Color _typeColor(String t) {
    switch (t) {
      case 'warning': return Colors.orange;
      case 'success': return const Color(0xFF10B981);
      case 'update':  return const Color(0xFF8B5CF6);
      default:        return const Color(0xFF0284C7);
    }
  }

  IconData _typeIcon(String t) {
    switch (t) {
      case 'warning': return Icons.warning_rounded;
      case 'success': return Icons.check_circle_rounded;
      case 'update':  return Icons.system_update_rounded;
      default:        return Icons.info_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Announcements', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18)),
        const SizedBox(height: 4),
        const Text('Publish pinned announcements visible inside the app.', style: TextStyle(color: Colors.white38, fontSize: 12)),
        const SizedBox(height: 20),

        // Type selector
        _label('Announcement Type'),
        Wrap(spacing: 8, runSpacing: 8, children: ['info','warning','success','update'].map((t) {
          final selected = _type == t;
          final color = _typeColor(t);
          return GestureDetector(
            onTap: () => setState(() => _type = t),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: selected ? color.withValues(alpha: 0.15) : const Color(0xFF222222),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: selected ? color : Colors.white.withValues(alpha: 0.1)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(_typeIcon(t), color: selected ? color : Colors.white38, size: 14),
                const SizedBox(width: 5),
                Text(t.toUpperCase(), style: TextStyle(color: selected ? color : Colors.white38,
                  fontSize: 11, fontWeight: FontWeight.w700)),
              ]),
            ),
          );
        }).toList()),
        const SizedBox(height: 16),

        // Title & body
        _label('Title'),
        _field(_titleCtrl, 'Announcement title', Icons.title_rounded),
        const SizedBox(height: 12),
        _label('Message'),
        TextField(
          controller: _bodyCtrl,
          maxLines: 4,
          style: const TextStyle(color: Colors.white, fontSize: 13),
          onChanged: (_) => setState(() {}),
          decoration: InputDecoration(
            hintText: 'Announcement details...',
            hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
            filled: true, fillColor: const Color(0xFF222222),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            contentPadding: const EdgeInsets.all(14),
          ),
        ),
        const SizedBox(height: 12),
        _label('Link (optional)'),
        _field(_linkCtrl, 'https://...', Icons.link_rounded),
        const SizedBox(height: 14),

        // Pinned toggle
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(color: widget.card, borderRadius: BorderRadius.circular(12)),
          child: Row(children: [
            Icon(Icons.push_pin_rounded, color: _pinned ? const Color(0xFFFFBB35) : Colors.white38, size: 18),
            const SizedBox(width: 10),
            const Expanded(child: Text('Pin to top', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13))),
            Switch(value: _pinned, activeColor: const Color(0xFFFFBB35), onChanged: (v) => setState(() => _pinned = v)),
          ]),
        ),
        const SizedBox(height: 24),

        SizedBox(width: double.infinity, height: 50,
          child: ElevatedButton.icon(
            onPressed: (!_saving && _titleCtrl.text.trim().isNotEmpty && _bodyCtrl.text.trim().isNotEmpty) ? _publish : null,
            icon: _saving
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : const Icon(Icons.announcement_rounded, size: 20, color: Colors.white),
            label: Text(_saving ? 'Publishing...' : 'Publish Announcement',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
            style: ElevatedButton.styleFrom(
              backgroundColor: widget.blue,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
        ),

        const SizedBox(height: 32),
        const Divider(color: Colors.white12),
        const SizedBox(height: 12),
        const Text('Active Announcements', style: TextStyle(color: Colors.white60, fontSize: 13, fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),

        StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance.collection('announcements')
              .orderBy('createdAt', descending: true).limit(20).snapshots(),
          builder: (_, snap) {
            final docs = snap.data?.docs ?? [];
            if (docs.isEmpty) return const Text('No announcements yet.', style: TextStyle(color: Colors.white24, fontSize: 12));
            return Column(children: docs.map((doc) {
              final d   = doc.data() as Map<String, dynamic>;
              final ts  = d['createdAt'] as Timestamp?;
              final t   = d['type'] as String? ?? 'info';
              final active = d['active'] as bool? ?? true;
              final color  = _typeColor(t);

              return Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: widget.card, borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: active ? color.withValues(alpha: 0.3) : Colors.white.withValues(alpha: 0.05)),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Icon(_typeIcon(t), color: color, size: 14),
                    const SizedBox(width: 6),
                    Expanded(child: Text(d['title'] ?? '', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13))),
                    if (d['pinned'] == true) const Icon(Icons.push_pin_rounded, color: Color(0xFFFFBB35), size: 13),
                    const SizedBox(width: 8),
                    // Toggle active
                    GestureDetector(
                      onTap: () => doc.reference.update({'active': !active}),
                      child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: active ? widget.green.withValues(alpha: 0.12) : Colors.white10,
                          borderRadius: BorderRadius.circular(8)),
                        child: Text(active ? 'LIVE' : 'OFF',
                          style: TextStyle(color: active ? widget.green : Colors.white38, fontSize: 9, fontWeight: FontWeight.w900))),
                    ),
                    const SizedBox(width: 6),
                    GestureDetector(
                      onTap: () => doc.reference.delete(),
                      child: const Icon(Icons.delete_outline, color: Colors.red, size: 16)),
                  ]),
                  const SizedBox(height: 4),
                  Text(d['body'] ?? '', style: const TextStyle(color: Colors.white38, fontSize: 11), maxLines: 2, overflow: TextOverflow.ellipsis),
                  if (ts != null) Padding(padding: const EdgeInsets.only(top: 4),
                    child: Text(_timeAgo3(ts.toDate()), style: const TextStyle(color: Colors.white24, fontSize: 9))),
                ]),
              );
            }).toList());
          },
        ),
      ]),
    );
  }

  Widget _label(String t) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Text(t, style: const TextStyle(color: Colors.white60, fontSize: 12, fontWeight: FontWeight.w700)));

  Widget _field(TextEditingController ctrl, String hint, IconData icon) {
    return TextField(
      controller: ctrl,
      style: const TextStyle(color: Colors.white, fontSize: 13),
      onChanged: (_) => setState(() {}),
      decoration: InputDecoration(
        hintText: hint, hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
        prefixIcon: Icon(icon, color: Colors.white38, size: 18),
        filled: true, fillColor: const Color(0xFF222222),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      ),
    );
  }

  String _timeAgo3(DateTime dt) {
    final d = DateTime.now().difference(dt);
    if (d.inMinutes < 1) return 'Just now';
    if (d.inHours < 1) return '${d.inMinutes}m ago';
    if (d.inDays < 1) return '${d.inHours}h ago';
    return '${d.inDays}d ago';
  }
}

// ── Problem Reports (from users via Settings → Report a Problem) ──────────────
class _ProblemReportList extends StatelessWidget {
  final Color blue, red, card, green;
  const _ProblemReportList({required this.blue, required this.red, required this.card, required this.green});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('problemReports')
          .orderBy('timestamp', descending: true)
          .limit(100)
          .snapshots(),
      builder: (_, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(color: Color(0xFF0284C7)));
        }
        // Fallback without orderBy
        if (snap.hasError) {
          return StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance.collection('problemReports').snapshots(),
            builder: (_, s2) {
              if (!s2.hasData) return const Center(child: CircularProgressIndicator(color: Color(0xFF0284C7)));
              return _buildList(context, s2.data!.docs);
            },
          );
        }
        return _buildList(context, snap.data?.docs ?? []);
      },
    );
  }

  Widget _buildList(BuildContext context, List<QueryDocumentSnapshot> docs) {
    if (docs.isEmpty) {
      return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(Icons.flag_outlined, size: 48, color: Colors.white12),
        const SizedBox(height: 12),
        const Text('No problem reports yet', style: TextStyle(color: Colors.white38, fontSize: 15, fontWeight: FontWeight.w600)),
      ]));
    }

    // Stats bar
    final total    = docs.length;
    final pending  = docs.where((d) => (d.data() as Map)['resolved'] != true && (d.data() as Map)['status'] != 'in_review').length;
    final inReview = docs.where((d) => (d.data() as Map)['status'] == 'in_review').length;
    final resolved = docs.where((d) => (d.data() as Map)['resolved'] == true).length;

    return Column(children: [
      // Stats header
      Container(
        color: const Color(0xFF111111),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(children: [
          _stat('Total', total.toString(), Colors.white54),
          _stat('Pending', pending.toString(), red),
          _stat('In Review', inReview.toString(), const Color(0xFFF59E0B)),
          _stat('Resolved', resolved.toString(), green),
        ]),
      ),
      // List
      Expanded(child: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: docs.length,
        itemBuilder: (_, i) {
          final doc = docs[i];
          final r          = doc.data() as Map<String, dynamic>;
          final docId      = doc.id;
          final category   = r['category']    as String? ?? 'Other';
          final desc       = r['description'] as String? ?? '';
          final uid        = r['uid']         as String? ?? '';
          final isResolved = r['resolved']    == true;
          final status     = r['status']      as String? ?? 'pending';
          final ts         = r['timestamp']   as Timestamp?;
          final adminNote  = r['adminNote']   as String? ?? '';

          final statusColor = isResolved ? green
              : status == 'in_review' ? const Color(0xFFF59E0B)
              : red;
          final statusLabel = isResolved ? 'Resolved'
              : status == 'in_review' ? 'In Review'
              : 'Pending';

          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: card, borderRadius: BorderRadius.circular(14),
              border: Border.all(color: isResolved
                  ? Colors.white.withValues(alpha: 0.05)
                  : statusColor.withValues(alpha: 0.3)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // Top row
              Row(children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: statusColor.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(8)),
                  child: Text(statusLabel,
                    style: TextStyle(color: statusColor, fontSize: 10, fontWeight: FontWeight.w900)),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.06),
                    borderRadius: BorderRadius.circular(8)),
                  child: Text(category,
                    style: const TextStyle(color: Colors.white70, fontSize: 10, fontWeight: FontWeight.w700)),
                ),
                const Spacer(),
                if (ts != null) Text(_fmt(ts.toDate()),
                    style: const TextStyle(color: Colors.white38, fontSize: 10)),
              ]),
              const SizedBox(height: 8),
              Text(desc,
                maxLines: 4, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white70, fontSize: 13, height: 1.4)),
              const SizedBox(height: 8),
              // Reported by
              FutureBuilder<DocumentSnapshot?>(
                future: uid.isNotEmpty
                    ? FirebaseFirestore.instance.collection('users').doc(uid).get()
                    : Future.value(null),
                builder: (_, us) {
                  final u    = us.data?.data() as Map<String, dynamic>? ?? {};
                  final name = u['username'] ?? 'Unknown';
                  return Text('By: @$name',
                      style: const TextStyle(color: Colors.white38, fontSize: 11));
                },
              ),
              if (adminNote.isNotEmpty) ...[
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: blue.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: blue.withValues(alpha: 0.2)),
                  ),
                  child: Text('Note: $adminNote',
                      style: TextStyle(color: blue, fontSize: 11, fontWeight: FontWeight.w500)),
                ),
              ],
              const SizedBox(height: 10),
              // Action buttons
              Wrap(spacing: 6, runSpacing: 6, children: [
                if (!isResolved && status != 'in_review')
                  _btn('Mark In Review', const Color(0xFFF59E0B), Icons.hourglass_top_rounded, () async {
                    await FirebaseFirestore.instance.collection('problemReports').doc(docId)
                        .update({'status': 'in_review'});
                  }),
                if (!isResolved)
                  _btn('Mark Resolved', green, Icons.check_circle_outline, () async {
                    await FirebaseFirestore.instance.collection('problemReports').doc(docId)
                        .update({'resolved': true, 'status': 'resolved', 'resolvedAt': FieldValue.serverTimestamp()});
                  }),
                _btn('Add Note', blue, Icons.edit_note_rounded, () => _addNoteDialog(context, docId, adminNote)),
                _btn('Delete', red, Icons.delete_outline, () async {
                  await FirebaseFirestore.instance.collection('problemReports').doc(docId).delete();
                }),
              ]),
            ]),
          );
        },
      )),
    ]);
  }

  void _addNoteDialog(BuildContext context, String docId, String current) {
    final ctrl = TextEditingController(text: current);
    showDialog(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: const Color(0xFF1A1A1A),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: const Text('Add Admin Note', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16)),
      content: TextField(
        controller: ctrl,
        maxLines: 3,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          hintText: 'Write a note for this report...',
          hintStyle: const TextStyle(color: Colors.white38),
          filled: true, fillColor: const Color(0xFF222222),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: Text('Cancel', style: TextStyle(color: Colors.white38))),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: blue, foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
          onPressed: () async {
            await FirebaseFirestore.instance.collection('problemReports').doc(docId)
                .update({'adminNote': ctrl.text.trim()});
            if (ctx.mounted) Navigator.pop(ctx);
          },
          child: const Text('Save'),
        ),
      ],
    ));
  }

  Widget _stat(String label, String value, Color color) {
    return Expanded(child: Column(children: [
      Text(value, style: TextStyle(color: color, fontSize: 16, fontWeight: FontWeight.w900)),
      Text(label, style: const TextStyle(color: Colors.white24, fontSize: 10)),
    ]));
  }

  Widget _btn(String label, Color color, IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.15),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withValues(alpha: 0.4)),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 13, color: color),
          const SizedBox(width: 4),
          Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w700)),
        ]),
      ),
    );
  }

  String _fmt(DateTime dt) {
    final d = DateTime.now().difference(dt);
    if (d.inMinutes < 1) return 'Just now';
    if (d.inHours < 1)   return '${d.inMinutes}m ago';
    if (d.inDays < 1)    return '${d.inHours}h ago';
    return '${d.inDays}d ago';
  }
}

// ── STARTUP POSTER TAB ────────────────────────────────────────────────────────
// Full-screen poster shown to all users when the app opens.
// Media is uploaded directly to Cloudinary.
class _StartupPosterTab extends StatefulWidget {
  final Color blue, card, green;
  const _StartupPosterTab({required this.blue, required this.card, required this.green});
  @override State<_StartupPosterTab> createState() => _StartupPosterTabState();
}

class _StartupPosterTabState extends State<_StartupPosterTab> {
  // Cloudinary config
  final _cloudNameCtrl    = TextEditingController();
  final _uploadPresetCtrl = TextEditingController();

  // Poster content
  final _mediaUrlCtrl  = TextEditingController();
  final _titleCtrl     = TextEditingController();
  final _subtitleCtrl  = TextEditingController();
  final _textBodyCtrl  = TextEditingController();
  final _buttonLabelCtrl = TextEditingController();
  final _buttonLinkCtrl  = TextEditingController();

  String _type    = 'image'; // image | video | text
  bool   _active  = false;
  bool   _loading = true;
  bool   _uploading = false;

  static const _kDoc = 'startupPoster';

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final doc = await FirebaseFirestore.instance
          .collection('appConfig').doc(_kDoc).get();
      final d = doc.data() ?? {};
      _cloudNameCtrl.text    = d['cloudinaryCloudName']    ?? '';
      _uploadPresetCtrl.text = d['cloudinaryUploadPreset'] ?? '';
      _mediaUrlCtrl.text     = d['mediaUrl']   ?? '';
      _titleCtrl.text        = d['title']      ?? '';
      _subtitleCtrl.text     = d['subtitle']   ?? '';
      _textBodyCtrl.text     = d['textBody']   ?? '';
      _buttonLabelCtrl.text  = d['buttonLabel'] ?? '';
      _buttonLinkCtrl.text   = d['buttonLink']  ?? '';
      _type   = d['type']   ?? 'image';
      _active = d['active'] == true;
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _save() async {
    await FirebaseFirestore.instance
        .collection('appConfig').doc(_kDoc).set({
      'cloudinaryCloudName':    _cloudNameCtrl.text.trim(),
      'cloudinaryUploadPreset': _uploadPresetCtrl.text.trim(),
      'mediaUrl':    _mediaUrlCtrl.text.trim(),
      'title':       _titleCtrl.text.trim(),
      'subtitle':    _subtitleCtrl.text.trim(),
      'textBody':    _textBodyCtrl.text.trim(),
      'buttonLabel': _buttonLabelCtrl.text.trim(),
      'buttonLink':  _buttonLinkCtrl.text.trim(),
      'type':        _type,
      'active':      _active,
      'updatedAt':   FieldValue.serverTimestamp(),
    });
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Text('Startup Poster saved!'),
      backgroundColor: widget.green,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }

  // ── Cloudinary direct upload ──────────────────────────────────────────────
  Future<void> _pickAndUpload() async {
    final cloudName = _cloudNameCtrl.text.trim();
    final preset    = _uploadPresetCtrl.text.trim();
    if (cloudName.isEmpty || preset.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Pehle Cloudinary Cloud Name aur Upload Preset enter karo'),
        backgroundColor: Colors.red, behavior: SnackBarBehavior.floating));
      return;
    }

    final picker = ImagePicker();
    XFile? picked;
    if (_type == 'video') {
      picked = await picker.pickVideo(source: ImageSource.gallery);
    } else {
      picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 92);
    }
    if (picked == null) return;

    setState(() => _uploading = true);
    try {
      final resourceType = _type == 'video' ? 'video' : 'image';
      final uri = Uri.parse(
          'https://api.cloudinary.com/v1_1/$cloudName/$resourceType/upload');
      final request = http.MultipartRequest('POST', uri)
        ..fields['upload_preset'] = preset
        ..files.add(await http.MultipartFile.fromPath('file', picked.path));

      final streamed  = await request.send()
          .timeout(const Duration(minutes: 10));
      final respBody  = await streamed.stream.bytesToString();
      final respJson  = jsonDecode(respBody) as Map<String, dynamic>;

      if (streamed.statusCode == 200) {
        final url = respJson['secure_url'] as String? ?? '';
        if (url.isNotEmpty && mounted) {
          setState(() => _mediaUrlCtrl.text = url);
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: const Text('✅ Cloudinary upload successful!'),
            backgroundColor: widget.green,
            behavior: SnackBarBehavior.floating));
        }
      } else {
        final err = respJson['error']?['message'] ?? 'Upload failed';
        throw Exception(err);
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Upload failed: $e'),
        backgroundColor: Colors.red, behavior: SnackBarBehavior.floating));
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  @override
  void dispose() {
    _cloudNameCtrl.dispose(); _uploadPresetCtrl.dispose();
    _mediaUrlCtrl.dispose();  _titleCtrl.dispose();
    _subtitleCtrl.dispose();  _textBodyCtrl.dispose();
    _buttonLabelCtrl.dispose(); _buttonLinkCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: Color(0xFF0284C7)));
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

        // ── Header ────────────────────────────────────────────────────────
        Row(children: [
          Container(padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: widget.blue.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(10)),
            child: Icon(Icons.web_stories_outlined, color: widget.blue, size: 20)),
          const SizedBox(width: 10),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Startup Poster', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
            Text('App open hone par sabko full-screen poster dikhega', style: TextStyle(color: Colors.white38, fontSize: 11)),
          ])),
        ]),
        const SizedBox(height: 20),

        // ── Active toggle ─────────────────────────────────────────────────
        _card(child: Row(children: [
          Icon(Icons.toggle_on_rounded, color: _active ? widget.green : Colors.white38, size: 22),
          const SizedBox(width: 10),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Poster Active', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
            Text('Off karo toh kisi ko nahi dikhega', style: TextStyle(color: Colors.white38, fontSize: 11)),
          ])),
          Switch(value: _active, activeColor: widget.green, onChanged: (v) => setState(() => _active = v)),
        ])),
        const SizedBox(height: 12),

        // ── Cloudinary config ─────────────────────────────────────────────
        _card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(Icons.cloud_upload_outlined, color: widget.blue, size: 18),
            const SizedBox(width: 8),
            const Text('Cloudinary Settings', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
          ]),
          const SizedBox(height: 4),
          const Text('cloudinary.com → Settings → Upload Presets (unsigned)', style: TextStyle(color: Colors.white38, fontSize: 10)),
          const SizedBox(height: 12),
          _field(_cloudNameCtrl,    'Cloud Name (e.g. myapp123)',  Icons.dns_outlined),
          const SizedBox(height: 8),
          _field(_uploadPresetCtrl, 'Upload Preset (unsigned)',    Icons.vpn_key_outlined),
        ])),
        const SizedBox(height: 12),

        // ── Media type ────────────────────────────────────────────────────
        _card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Poster Type', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w700, fontSize: 13)),
          const SizedBox(height: 10),
          Row(children: [
            _typeBtn('image', Icons.image_outlined,    'Image'),
            const SizedBox(width: 8),
            _typeBtn('video', Icons.videocam_outlined, 'Video'),
            const SizedBox(width: 8),
            _typeBtn('text',  Icons.text_fields,       'Text Only'),
          ]),
        ])),
        const SizedBox(height: 12),

        // ── Media upload (image / video) ──────────────────────────────────
        if (_type != 'text') ...[
          _card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(_type == 'video' ? 'Video Upload' : 'Image Upload',
              style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w700, fontSize: 13)),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: _field(_mediaUrlCtrl,
                _type == 'video' ? 'Video URL (Cloudinary)' : 'Image URL (Cloudinary)',
                Icons.link_rounded)),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: _uploading ? null : _pickAndUpload,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 52, height: 52,
                  decoration: BoxDecoration(
                    color: _uploading ? Colors.white10 : widget.blue.withValues(alpha: 0.18),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: widget.blue.withValues(alpha: 0.5))),
                  child: _uploading
                    ? const Center(child: SizedBox(width: 20, height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2.5, color: Color(0xFF0284C7))))
                    : Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(Icons.upload_rounded, color: widget.blue, size: 20),
                        Text('Upload', style: TextStyle(color: widget.blue, fontSize: 8, fontWeight: FontWeight.w700)),
                      ]),
                ),
              ),
            ]),

            // Image preview
            if (_mediaUrlCtrl.text.isNotEmpty && _type == 'image') ...[
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.network(_mediaUrlCtrl.text,
                  height: 160, width: double.infinity, fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(height: 160,
                    color: Colors.white10,
                    child: const Icon(Icons.broken_image, color: Colors.white30, size: 40))),
              ),
            ],
          ])),
          const SizedBox(height: 12),
        ],

        // ── Text content ──────────────────────────────────────────────────
        _card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Text Content', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w700, fontSize: 13)),
          const SizedBox(height: 10),
          _field(_titleCtrl,    'Title (bold heading)',      Icons.title),
          const SizedBox(height: 8),
          _field(_subtitleCtrl, 'Subtitle (smaller text)',   Icons.short_text),
          if (_type == 'text') ...[
            const SizedBox(height: 8),
            TextField(
              controller: _textBodyCtrl,
              maxLines: 4,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              decoration: InputDecoration(
                hintText: 'Main text body (sirf text type ke liye)',
                hintStyle: const TextStyle(color: Colors.white38, fontSize: 12),
                prefixIcon: const Icon(Icons.notes, color: Colors.white38, size: 18),
                filled: true, fillColor: const Color(0xFF222222),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12)),
            ),
          ],
        ])),
        const SizedBox(height: 12),

        // ── Button (optional) ─────────────────────────────────────────────
        _card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Action Button (optional)', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w700, fontSize: 13)),
          const SizedBox(height: 10),
          _field(_buttonLabelCtrl, 'Button label (e.g. Learn More)', Icons.touch_app_outlined),
          const SizedBox(height: 8),
          _field(_buttonLinkCtrl,  'Button URL (https://...)',       Icons.open_in_new),
        ])),
        const SizedBox(height: 24),

        // ── Save ──────────────────────────────────────────────────────────
        SizedBox(
          width: double.infinity, height: 52,
          child: ElevatedButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.save_rounded, color: Colors.white, size: 18),
            label: const Text('Save Poster', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
            style: ElevatedButton.styleFrom(
              backgroundColor: widget.blue,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          ),
        ),
        const SizedBox(height: 32),
      ]),
    );
  }

  Widget _card({required Widget child}) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: widget.card,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: Colors.white.withValues(alpha: 0.06))),
    child: child);

  Widget _field(TextEditingController ctrl, String hint, IconData icon) =>
    TextField(
      controller: ctrl,
      style: const TextStyle(color: Colors.white, fontSize: 13),
      onChanged: (_) => setState(() {}),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white38, fontSize: 12),
        prefixIcon: Icon(icon, color: Colors.white38, size: 18),
        filled: true, fillColor: const Color(0xFF222222),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12)));

  Widget _typeBtn(String value, IconData icon, String label) {
    final sel = _type == value;
    return Expanded(child: GestureDetector(
      onTap: () => setState(() => _type = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: sel ? widget.blue.withValues(alpha: 0.15) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: sel ? widget.blue : Colors.white.withValues(alpha: 0.1))),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: sel ? widget.blue : Colors.white38, size: 20),
          const SizedBox(height: 4),
          Text(label, style: TextStyle(
            color: sel ? widget.blue : Colors.white38,
            fontSize: 10, fontWeight: FontWeight.w600)),
        ]),
      ),
    ));
  }
}
