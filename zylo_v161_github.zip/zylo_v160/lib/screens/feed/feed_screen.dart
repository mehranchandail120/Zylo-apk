import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter_riverpod/flutter_riverpod.dart' hide Provider;
import 'package:shared_preferences/shared_preferences.dart';
import '../../services/cache_service.dart';
import '../../services/cloudflare_service.dart';
import '../../services/notification_service.dart';
import '../../utils/share_utils.dart';
import '../../providers/feed_providers.dart';
import '../../widgets/zylo_shimmer.dart';
import '../../widgets/zylo_cached_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:open_filex/open_filex.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';
import '../../services/file_service.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'post_analytics_screen.dart';
import 'post_comments_screen.dart';
import 'post_deep_link_screen.dart';
import '../profile/view_profile_screen.dart';
import '../chat/chat_room_screen.dart';
import '../../widgets/zylo_avatar.dart';
import '../../widgets/zylo_people_suggestion.dart';

const _kBlue = Color(0xFF0284C7);
const _kBg   = Colors.white;

// ── YouTube helpers ────────────────────────────────────────────────────────────
String? _extractYoutubeId(String url) {
  return YoutubePlayer.convertUrlToId(url);
}

bool _isYoutubeUrl(String url) {
  final lower = url.toLowerCase();
  return lower.contains('youtube.com/watch') ||
      lower.contains('youtu.be/') ||
      lower.contains('youtube.com/shorts/') ||
      lower.contains('youtube.com/embed/');
}

// ── File type helpers ──────────────────────────────────────────────────────────
String _fileTypeFromUrl(String url) {
  final lower = url.toLowerCase().split('?').first;
  if (lower.endsWith('.mp3') || lower.endsWith('.m4a') || lower.endsWith('.wav') || lower.endsWith('.aac') || lower.endsWith('.ogg')) return 'audio';
  if (lower.endsWith('.pdf')) return 'pdf';
  if (lower.endsWith('.apk')) return 'apk';
  if (lower.endsWith('.doc') || lower.endsWith('.docx') || lower.endsWith('.ppt') || lower.endsWith('.pptx') || lower.endsWith('.xls') || lower.endsWith('.xlsx') || lower.endsWith('.txt')) return 'document';
  if (lower.endsWith('.zip') || lower.endsWith('.rar') || lower.endsWith('.7z')) return 'archive';
  return 'file';
}

IconData _fileIcon(String type) {
  switch (type) {
    case 'audio': return Icons.audiotrack_rounded;
    case 'pdf':   return Icons.picture_as_pdf_rounded;
    case 'apk':   return Icons.android_rounded;
    case 'document': return Icons.description_rounded;
    case 'archive':  return Icons.folder_zip_rounded;
    default:         return Icons.insert_drive_file_rounded;
  }
}

Color _fileColor(String type) {
  switch (type) {
    case 'audio': return const Color(0xFF8B5CF6);
    case 'pdf':   return Colors.red;
    case 'apk':   return const Color(0xFF3DDC84);
    case 'document': return const Color(0xFF0284C7);
    case 'archive':  return Colors.orange;
    default:         return Colors.grey;
  }
}

String _fileLabel(String type) {
  switch (type) {
    case 'audio': return 'Audio File';
    case 'pdf':   return 'PDF Document';
    case 'apk':   return 'Android App (APK)';
    case 'document': return 'Document';
    case 'archive':  return 'Archive';
    default:         return 'File';
  }
}

class FeedScreen extends ConsumerStatefulWidget {
  const FeedScreen({super.key});
  @override ConsumerState<FeedScreen> createState() => _FeedScreenState();

  /// Call this to open a post in a bottom sheet from anywhere
  static void openPostSheet(BuildContext context, String postId) {
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => PostDeepLinkScreen(postId: postId),
    ));
  }
}

class _FeedScreenState extends ConsumerState<FeedScreen> with SingleTickerProviderStateMixin {
  // ── Tab controller ────────────────────────────────────────────────────────
  late final TabController _tabController;
  int _currentTab = 0;

  // ── Post-upload banner state ───────────────────────────────────────────────
  bool   _isUploadingPost = false;
  String _uploadLabel     = 'Uploading post...';
  double _uploadProgress  = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this)
      ..addListener(() {
        if (_tabController.indexIsChanging) {
          setState(() => _currentTab = _tabController.index);
        }
      });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _onPostUploadStart(Stream<_UploadEvent> events) {
    setState(() { _isUploadingPost = true; _uploadProgress = 0; _uploadLabel = 'Uploading...'; });
    events.listen(
      (e) { if (mounted) setState(() { _uploadLabel = e.label; _uploadProgress = e.progress; }); },
      onDone: () {
        if (mounted) setState(() => _isUploadingPost = false);
        // Refresh feed so new post appears at top immediately
        Future.delayed(const Duration(milliseconds: 500), () {
          final auth = context.read<AuthService>();
          final myUid = auth.user?.uid ?? '';
          if (myUid.isNotEmpty) {
            ref.read(globalFeedProvider(myUid).notifier).refresh();
          }
        });
      },
      onError: (_) { if (mounted) setState(() => _isUploadingPost = false); },
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth  = Provider.of<AuthService>(context);
    final myUid = auth.user?.uid ?? '';

    return Scaffold(
      backgroundColor: _kBg,
      body: Stack(children: [
        SafeArea(child: Column(children: [
        // ── Header ─────────────────────────────────────────────────────────
        AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          color: Colors.white,
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              // ── Main title = feed filter (Global / Following) ─────────────
              GestureDetector(
                onTap: () => _showFeedSwitcher(context),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Text(
                    _currentTab == 0 ? 'Global' : 'Following',
                    style: TextStyle(
                      fontSize: 26, fontWeight: FontWeight.w900,
                      color: _currentTab == 0 ? _kBlue : const Color(0xFF7C3AED),
                      letterSpacing: -0.5,
                      shadows: [Shadow(
                        color: Colors.black.withValues(alpha: 0.08),
                        offset: const Offset(0, 1), blurRadius: 2)]),
                  ),
                  const SizedBox(width: 5),
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                    decoration: BoxDecoration(
                      color: (_currentTab == 0 ? _kBlue : const Color(0xFF7C3AED)).withValues(alpha: 0.10),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: (_currentTab == 0 ? _kBlue : const Color(0xFF7C3AED)).withValues(alpha: 0.25))),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Text(_currentTab == 0 ? '🌍' : '👥', style: const TextStyle(fontSize: 11)),
                      const SizedBox(width: 2),
                      Icon(Icons.keyboard_arrow_down_rounded, size: 14,
                        color: _currentTab == 0 ? _kBlue : const Color(0xFF7C3AED)),
                    ]),
                  ),
                ]),
              ),
              const Spacer(),
              // ── Downloads button ───────────────────────────────────────────
              StreamBuilder<List<_DLItem>>(
                stream: _FeedDownloadsMgr.instance.stream,
                initialData: _FeedDownloadsMgr.instance.all,
                builder: (_, snap) {
                  final items      = snap.data ?? [];
                  final active     = items.where((i) => i.status == _DLStatus.downloading).length;
                  final hasDone    = items.any((i) => i.status == _DLStatus.done);
                  return GestureDetector(
                    onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const _DownloadsScreen())),
                    child: Container(
                      width: 40, height: 40, margin: const EdgeInsets.only(right: 6),
                      decoration: BoxDecoration(
                        color: (active > 0 || hasDone)
                            ? _kBlue.withValues(alpha: 0.1)
                            : Colors.grey[100],
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: active > 0 ? _kBlue.withValues(alpha: 0.5) : Colors.transparent,
                          width: 1.5)),
                      child: Stack(alignment: Alignment.center, children: [
                        Icon(
                          active > 0
                            ? Icons.downloading_rounded
                            : Icons.download_rounded,
                          color: (active > 0 || hasDone) ? _kBlue : Colors.grey[600],
                          size: 20),
                        if (active > 0)
                          Positioned(top: 4, right: 4,
                            child: Container(
                              width: 14, height: 14,
                              decoration: const BoxDecoration(color: _kBlue, shape: BoxShape.circle),
                              child: Center(child: Text('$active',
                                style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w900))))),
                      ])));
                }),
              _NotifBell(myUid: myUid),

            ]),

          ]),
        ),

        // ── Tab Content ────────────────────────────────────────────────────
        Expanded(child: Container(
          color: Colors.white,
          child: TabBarView(
            controller: _tabController,
            physics: const NeverScrollableScrollPhysics(),
            children: [
              _GlobalFeed(key: ValueKey(myUid), myUid: myUid, auth: auth),
              _FollowingFeed(myUid: myUid, auth: auth),
            ],
          ),
        )),
      ])),

        // ── Upload Progress Banner ──────────────────────────────────────────
        if (_isUploadingPost)
          Positioned(
            top: MediaQuery.of(context).padding.top + 8,
            left: 16, right: 16,
            child: _UploadBanner(label: _uploadLabel, progress: _uploadProgress),
          ),
      ]),
    );
  }

  void _showFeedSwitcher(BuildContext ctx) {
    showMenu<int>(
      context: ctx,
      position: const RelativeRect.fromLTRB(16, 100, 0, 0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      color: Colors.white,
      elevation: 8,
      items: [
        PopupMenuItem<int>(
          value: 1,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          child: Row(children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                color: const Color(0xFF7C3AED).withValues(alpha: 0.1), shape: BoxShape.circle),
              child: const Center(child: Icon(Icons.people_alt_rounded, size: 18, color: Color(0xFF7C3AED)))),
            const SizedBox(width: 14),
            const Text('Following', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            const SizedBox(width: 20),
            if (_currentTab == 1) const Icon(Icons.check_rounded, color: Color(0xFF7C3AED), size: 20),
          ]),
        ),
        PopupMenuItem<int>(
          value: 0,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          child: Row(children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                color: _kBlue.withValues(alpha: 0.1), shape: BoxShape.circle),
              child: const Center(child: Text('🌍', style: TextStyle(fontSize: 18)))),
            const SizedBox(width: 14),
            const Text('Global', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            const SizedBox(width: 20),
            if (_currentTab == 0) const Icon(Icons.check_rounded, color: _kBlue, size: 20),
          ]),
        ),
      ],
    ).then((val) {
      if (val == null) return;
      _tabController.animateTo(val);
      setState(() => _currentTab = val);
    });
  }

  void _showCreatePost(BuildContext ctx, String uid, AuthService auth) {
    showModalBottomSheet(
      context: ctx,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _CreatePostSheet(
        myUid: uid,
        auth: auth,
        onPostStart: (stream) {
          _onPostUploadStart(stream);
        },
      ),
    );
  }
}

// ── Upload event & banner ─────────────────────────────────────────────────────
class _UploadEvent {
  final String label;
  final double progress;
  const _UploadEvent(this.label, this.progress);
}

class _UploadBanner extends StatelessWidget {
  final String label;
  final double progress;
  const _UploadBanner({required this.label, required this.progress});

  @override
  Widget build(BuildContext context) => Material(
    elevation: 8,
    borderRadius: BorderRadius.circular(16),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _kBlue.withValues(alpha: 0.15)),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.10), blurRadius: 14, offset: const Offset(0, 4))],
      ),
      child: Row(children: [
        SizedBox(width: 22, height: 22,
          child: CircularProgressIndicator(strokeWidth: 2.5, color: _kBlue,
            value: progress > 0 && progress < 1 ? progress : null)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: const Color(0xFF0D1B2A))),
          if (progress > 0 && progress < 1) ...[ const SizedBox(height: 5),
            ClipRRect(borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(value: progress, backgroundColor: Colors.grey[200],
                color: _kBlue, minHeight: 4)),
          ],
        ])),
        if (progress >= 1)
          const Icon(Icons.check_circle_rounded, color: Colors.green, size: 20),
      ]),
    ),
  );
}

// ── Notification bell ─────────────────────────────────────────────────────────
class _NotifBell extends StatelessWidget {
  final String myUid;
  const _NotifBell({required this.myUid});
  @override
  Widget build(BuildContext context) {
    if (myUid.isEmpty) return const SizedBox(width: 40, height: 40);
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('users').doc(myUid)
          .collection('notifications').where('read', isEqualTo: false).snapshots(),
      builder: (_, snap) {
        final count = snap.data?.docs.length ?? 0;
        return GestureDetector(
          onTap: () => _showNotifSheet(context, myUid),
          child: Stack(children: [
            Container(width: 40, height: 40,
              decoration: BoxDecoration(
                color: count > 0 ? const Color(0xFFEFF6FF) : Colors.grey[100],
                shape: BoxShape.circle),
              child: Icon(count > 0 ? Icons.notifications_rounded : Icons.notifications_none,
                color: count > 0 ? _kBlue : Colors.black87, size: 22)),
            if (count > 0)
              Positioned(top: 4, right: 4,
                child: Container(
                  padding: const EdgeInsets.all(3),
                  decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                  child: Text(count > 99 ? '99+' : '$count',
                    style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w900)))),
          ]));
      });
  }

  void _showNotifSheet(BuildContext ctx, String uid) =>
    showModalBottomSheet(context: ctx, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (_) => _NotifSheet(myUid: uid));
}

// ── Global feed — LAZY LOADING + real-time per-post updates ──────────────────

// ══════════════════════════════════════════════════════════════
//  Following Feed — shows posts from people the current user follows
//  posts from people the current user follows
// ══════════════════════════════════════════════════════════════
class _FollowingFeed extends StatefulWidget {
  final String myUid;
  final AuthService auth;
  const _FollowingFeed({required this.myUid, required this.auth});
  @override
  State<_FollowingFeed> createState() => _FollowingFeedState();
}

class _FollowingFeedState extends State<_FollowingFeed>
    with AutomaticKeepAliveClientMixin {
  @override bool get wantKeepAlive => true;

  static const _purple = Color(0xFF7C3AED);

  @override
  Widget build(BuildContext context) {
    super.build(context);
    // Get list of people I follow first, then show their posts
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('users').doc(widget.myUid)
          .collection('following')
          .orderBy('followedAt', descending: false)
          .snapshots(),
      builder: (ctx, followSnap) {
        final followingUids = followSnap.data?.docs.map((d) => d.id).toList() ?? [];
        // Show empty state immediately if we know there are no follows (even mid-load)
        if (followingUids.isEmpty) {
          if (followSnap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: _purple, strokeWidth: 2));
          }
          return _FollowingEmptyState();
        }

        // Batch into chunks of 10 (Firestore whereIn limit)
        final chunk = followingUids.take(10).toList();

        return StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance
              .collection('posts')
              .where('authorId', whereIn: chunk)
              .limit(30)
              .snapshots(),
          builder: (ctx2, postSnap) {
            if (postSnap.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator(color: _purple, strokeWidth: 2));
            }
            final allDocs = List<QueryDocumentSnapshot>.of(postSnap.data?.docs ?? [])
              ..sort((a, b) {
                final aT = (a.data() as Map)['createdAt'];
                final bT = (b.data() as Map)['createdAt'];
                if (aT == null && bT == null) return 0;
                if (aT == null) return 1;
                if (bT == null) return -1;
                return (bT as dynamic).compareTo(aT as dynamic);
              });
            if (allDocs.isEmpty) {
              return _FollowingEmptyState();
            }
            return _FollowingFeedList(
              docs: allDocs,
              myUid: widget.myUid,
              auth: widget.auth,
            );
          },
        );
      },
    );
  }
}

class _FollowingFeedList extends StatefulWidget {
  final List<QueryDocumentSnapshot> docs;
  final String myUid;
  final AuthService auth;
  const _FollowingFeedList({required this.docs, required this.myUid, required this.auth});
  @override
  State<_FollowingFeedList> createState() => _FollowingFeedListState();
}

class _FollowingFeedListState extends State<_FollowingFeedList> {
  static const _purple = Color(0xFF7C3AED);
  List<Map<String, dynamic>>? _filtered;

  @override
  void initState() {
    super.initState();
    _filterPosts();
  }

  @override
  void didUpdateWidget(_FollowingFeedList old) {
    super.didUpdateWidget(old);
    if (old.docs != widget.docs) _filterPosts();
  }

  Future<void> _filterPosts() async {
    final fs = FirestoreService();
    final result = <Map<String, dynamic>>[];
    for (final doc in widget.docs) {
      final data = doc.data() as Map<String, dynamic>;
      final authorId = data['uid'] as String? ?? '';
      if (authorId == widget.myUid) {
        result.add({...data, 'postId': doc.id, 'authorId': authorId});
        continue;
      }
      final inCircle = await fs.amIInTheirInnerCircle(authorId);
      if (inCircle) result.add({...data, 'postId': doc.id, 'authorId': authorId});
    }
    if (mounted) setState(() => _filtered = result);
  }

  @override
  Widget build(BuildContext context) {
    if (_filtered == null) {
      return const Center(child: CircularProgressIndicator(color: _purple, strokeWidth: 2));
    }
    if (_filtered!.isEmpty) {
      return _FollowingEmptyState();
    }
    return ListView.builder(
      padding: const EdgeInsets.only(top: 0, bottom: 80),
      physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
      itemCount: _filtered!.length,
      itemBuilder: (ctx, i) {
        final item = _filtered![i];
        return _PostCard(
          post: item,
          postId: item['postId'] as String,
          myUid: widget.myUid,
          auth: widget.auth,
        );
      },
    );
  }
}

class _FollowingEmptyState extends StatelessWidget {
  static const _purple = Color(0xFF7C3AED);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 80, height: 80,
            decoration: BoxDecoration(
              color: _purple.withValues(alpha: 0.08),
              shape: BoxShape.circle,
            ),
            child: const Center(child: Text('🟣', style: TextStyle(fontSize: 34))),
          ),
          const SizedBox(height: 18),
          const Text('No posts from people you follow',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: const Color(0xFF0D1B2A)),
            textAlign: TextAlign.center),
          const SizedBox(height: 8),
          Text(
            'Posts from people you follow will appear here.',
            style: TextStyle(fontSize: 13, color: Colors.grey[700], height: 1.6),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: _purple.withValues(alpha: 0.07),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _purple.withValues(alpha: 0.2)),
            ),
            child: const Text('👥 Only your followers can see this post',
              style: TextStyle(fontSize: 12, color: _purple, fontWeight: FontWeight.w700)),
          ),
        ]),
      ),
    );
  }
}

class _GlobalFeed extends ConsumerStatefulWidget {
  final String myUid; final AuthService auth;
  const _GlobalFeed({super.key, required this.myUid, required this.auth});
  @override ConsumerState<_GlobalFeed> createState() => _GlobalFeedState();
}

class _GlobalFeedState extends ConsumerState<_GlobalFeed> with AutomaticKeepAliveClientMixin {
  @override bool get wantKeepAlive => true;
  final ScrollController _scrollCtrl = ScrollController();

  @override
  void initState() {
    super.initState();
    _scrollCtrl.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollCtrl.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollCtrl.position.pixels >= _scrollCtrl.position.maxScrollExtent - 400) {
      ref.read(globalFeedProvider(widget.myUid).notifier).loadMore();
    }
  }

  // Called by FeedScreen after post upload completes
  void _refresh() {
    ref.read(globalFeedProvider(widget.myUid).notifier).refresh();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context); // required for AutomaticKeepAliveClientMixin
    final feedState = ref.watch(globalFeedProvider(widget.myUid));
    final isAdminAsync = ref.watch(isAdminProvider(widget.myUid));
    final isAdmin = isAdminAsync.value ?? false;

    if (feedState.firstLoad) {
      final cached = CacheService.getStaleFeedPosts(widget.myUid);
      if (cached != null && cached.isNotEmpty)
        return _CachedFeedList(posts: cached, myUid: widget.myUid, auth: widget.auth);
      return const FeedShimmerList();
    }

    // Combine: pinned first (deduped), then regular feed
    final visiblePinned = feedState.pinnedIds.where((id) => feedState.postData[id] != null).toList();
    final regularIds = feedState.postIds.where((id) => !feedState.pinnedIds.contains(id)).toList();
    final combinedIds = [...visiblePinned, ...regularIds];
    if (combinedIds.isEmpty && !feedState.hasMore) return _EmptyFeed();

    return RefreshIndicator(
      color: _kBlue, onRefresh: () => ref.read(globalFeedProvider(widget.myUid).notifier).refresh(),
      child: ListView.builder(
        controller: _scrollCtrl,
        physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
        padding: const EdgeInsets.only(bottom: 100),
        cacheExtent: 1200,
        itemCount: combinedIds.length + (feedState.hasMore ? 1 : 0),
        itemBuilder: (_, i) {
          if (i == combinedIds.length) {
            return feedState.loading
              ? const Padding(padding: EdgeInsets.all(20),
                  child: Center(child: CircularProgressIndicator(color: _kBlue, strokeWidth: 2)))
              : const SizedBox.shrink();
          }

          // ── Inject People Suggestion after every 5th post ───────────────
          if (i > 0 && i % 5 == 0) {
            final postId = combinedIds[i];
            final data = feedState.postData[postId];
            if (data == null) return const SizedBox.shrink();
            final isPinnedPost = feedState.pinnedIds.contains(postId);
            final authorId = data['authorId'] as String? ?? '';
            return Column(children: [
              ZyloPeopleSuggestion(
                key: const ValueKey('feed_suggestion'), // stable key — no rebuild
                myUid: widget.myUid, compact: true),
              if (data['isAdminPost'] == true)
                _AdminPostCard(post: data, postId: postId, isPinned: isPinnedPost)
              else
                _PrivacyAwarePostCard(
                  post: data, postId: postId,
                  myUid: widget.myUid, auth: widget.auth, authorId: authorId,
                  isAdmin: isAdmin, isPinned: isPinnedPost),
            ]);
          }

          final postId = combinedIds[i];
          final data = feedState.postData[postId];
          if (data == null) return const SizedBox.shrink();
          final isPinnedPost = feedState.pinnedIds.contains(postId);
          final authorId = data['authorId'] as String? ?? '';
          if (data['isAdminPost'] == true)
            return _AdminPostCard(post: data, postId: postId, isPinned: isPinnedPost);
          return _PrivacyAwarePostCard(
            post: data, postId: postId,
            myUid: widget.myUid, auth: widget.auth, authorId: authorId,
            isAdmin: isAdmin, isPinned: isPinnedPost);
        }),
    );
  }
}

// ── Feed Shimmer — shown while first page loads ────────────────────────────────
// Delegated to FeedShimmerList from zylo_shimmer.dart
// (kept as alias for backward compat with any remaining references)
class _FeedShimmer extends StatelessWidget {
  const _FeedShimmer();
  @override
  Widget build(BuildContext context) => const FeedShimmerList();
}

// ── Friends feed ──────────────────────────────────────────────────────────────
class _FriendsFeed extends StatelessWidget {
  final String myUid; final AuthService auth;
  const _FriendsFeed({required this.myUid, required this.auth});
  @override
  Widget build(BuildContext context) {
    if (myUid.isEmpty) return const Center(child: ZyloLoader());
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('users').doc(myUid)
          .collection('friends').where('status', isEqualTo: 'friends').snapshots(),
      builder: (_, fSnap) {
        final friendIds = fSnap.data?.docs.map((d) => d.id).toList() ?? [];
        final ids = [...friendIds, myUid];
        if (ids.length == 1) return _EmptyFeed(friends: true);
        return StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance.collection('posts')
              .where('authorId', whereIn: ids.take(10).toList())
              .limit(60).snapshots(),
          builder: (_, snap) {
            if (snap.connectionState == ConnectionState.waiting)
              return const Center(child: ZyloLoader());
            final posts = List.of(snap.data?.docs ?? [])
              ..sort((a, b) {
                final aT = (a.data() as Map)['createdAt'];
                final bT = (b.data() as Map)['createdAt'];
                if (aT == null && bT == null) return 0;
                if (aT == null) return 1;
                if (bT == null) return -1;
                return (bT as dynamic).compareTo(aT as dynamic);
              });
            if (posts.isEmpty) return _EmptyFeed(friends: true);
            return RefreshIndicator(
              color: _kBlue,
              onRefresh: () async {},
              child: ListView.builder(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.only(bottom: 100),
                itemCount: posts.length,
                itemBuilder: (_, i) {
                  final data = posts[i].data() as Map<String, dynamic>;
                  return _PostCard(post: data, postId: posts[i].id, myUid: myUid, auth: auth);
                }));
          });
      });
  }
}

// ── Admin official post card ───────────────────────────────────────────────────
class _AdminPostCard extends StatelessWidget {
  final Map<String, dynamic> post;
  final String postId;
  final bool isPinned;
  const _AdminPostCard({required this.post, required this.postId, this.isPinned = false});

  @override
  Widget build(BuildContext context) {
    final text   = post['text']   as String? ?? '';
    final images = (post['images'] as List?)?.cast<String>() ?? [];
    final files  = (post['files']  as List?)?.cast<Map>().map((f) => Map<String, dynamic>.from(f)).toList() ?? [];

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: isPinned ? const Color(0xFFFFBB35).withValues(alpha: 0.6) : _kBlue.withValues(alpha: 0.25), width: isPinned ? 2 : 1.5),
        boxShadow: [BoxShadow(color: isPinned ? const Color(0xFFFFBB35).withValues(alpha: 0.12) : _kBlue.withValues(alpha: 0.08), blurRadius: 12, offset: const Offset(0, 3))]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Pinned banner
        if (isPinned)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFFFFBB35), Color(0xFFFF8C00)]),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20))),
            child: const Row(children: [
              Icon(Icons.push_pin_rounded, color: Colors.white, size: 13),
              SizedBox(width: 5),
              Text('📌 Pinned Post', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 0.3)),
            ])),
        // Admin header
        Padding(padding: const EdgeInsets.fromLTRB(14, 14, 14, 0),
          child: Row(children: [
            Container(width: 40, height: 40,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF0284C7), Color(0xFF7C3AED)]),
                borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.admin_panel_settings, color: Colors.white, size: 20)),
            const SizedBox(width: 10),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Text('Zylo Admin', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14, color: Color(0xFF0D1B2A))),
                const SizedBox(width: 4),
                const Icon(Icons.verified, color: Color(0xFF0284C7), size: 14),
              ]),
              Text('Official Announcement', style: TextStyle(fontSize: 11, color: Colors.grey[700])),
            ]),
            const Spacer(),
            Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: _kBlue.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(8)),
              child: const Text('OFFICIAL', style: TextStyle(color: _kBlue, fontSize: 10, fontWeight: FontWeight.w900))),
          ])),
        if (text.isNotEmpty)
          Padding(padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
            child: Text(text, style: const TextStyle(fontSize: 14, color: Color(0xFF0D1B2A), height: 1.45))),
        if (images.isNotEmpty)
          Padding(padding: const EdgeInsets.only(top: 10),
            child: _PostImages(images: images)),
        const SizedBox(height: 14),
      ]),
    );
  }
}

// ══════════════════════════════════════════════════════════════
//  Empty Feed — Welcome Discovery Screen
// ══════════════════════════════════════════════════════════════
class _EmptyFeed extends StatefulWidget {
  final bool friends;
  const _EmptyFeed({this.friends = false});
  @override
  State<_EmptyFeed> createState() => _EmptyFeedState();
}

class _EmptyFeedState extends State<_EmptyFeed> {
  static const _tips = [
    _TipCard(icon: Icons.add_circle_outline_rounded, color: Color(0xFF0284C7),
      title: 'Write Your First Post!',
      body: 'Tap the + button above to create your first post and share it with the world.'),
    _TipCard(icon: Icons.people_outline_rounded, color: Color(0xFF7C3AED),
      title: 'Make Friends',
      body: 'Find your friends in Search and send them a request — their posts will appear here.'),
    _TipCard(icon: Icons.image_outlined, color: Color(0xFF059669),
      title: 'Share Photos',
      body: 'Attach images and files to your posts completely for free.'),
    _TipCard(icon: Icons.lock_outline_rounded, color: Color(0xFFD97706),
      title: 'Privacy Control',
      body: 'Keep posts private or public — only you decide who can see them.'),
    _TipCard(icon: Icons.notifications_none_rounded, color: Color(0xFFEF4444),
      title: 'Stay Notified',
      body: 'Get instant notifications whenever someone likes or comments on your post.'),
  ];

  @override
  Widget build(BuildContext context) {
    if (widget.friends) return _buildFriendsEmpty();
    return RefreshIndicator(
      color: _kBlue,
      onRefresh: () async {},
      child: ListView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.only(bottom: 100),
        children: [
          // ── Welcome Banner ───────────────────────────────────────────────
          _WelcomeBanner(),
          const SizedBox(height: 20),

          // ── Tips Section ─────────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(children: [
              Container(width: 4, height: 20,
                decoration: BoxDecoration(
                  color: _kBlue, borderRadius: BorderRadius.circular(2))),
              const SizedBox(width: 8),
              const Text('App Tips', style: TextStyle(
                fontSize: 16, fontWeight: FontWeight.w800, color: const Color(0xFF0D1B2A))),
            ]),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 140,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemCount: _tips.length,
              itemBuilder: (_, i) => _tips[i],
            ),
          ),
          const SizedBox(height: 24),

          const SizedBox(height: 16),

          // ── CTA to post ─────────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF0284C7), Color(0xFF7C3AED)],
                  begin: Alignment.topLeft, end: Alignment.bottomRight),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(children: [
                const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Make Your First Post! 🚀',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800,
                        color: Colors.white)),
                    SizedBox(height: 4),
                    Text('The feed comes alive when you start sharing',
                      style: TextStyle(fontSize: 12, color: Colors.white70)),
                  ])),
                const SizedBox(width: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14)),
                  child: const Text('Post Now',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800,
                      color: Color(0xFF0284C7)))),
              ]),
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildFriendsEmpty() => Center(
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(
          width: 90, height: 90,
          decoration: BoxDecoration(
            color: _kBlue.withValues(alpha: 0.08),
            shape: BoxShape.circle),
          child: const Icon(Icons.people_outline_rounded,
            size: 44, color: _kBlue)),
        const SizedBox(height: 20),
        const Text('No Posts from Friends',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900,
            color: const Color(0xFF0D1B2A)), textAlign: TextAlign.center),
        const SizedBox(height: 8),
        Text('Add friends to see their posts here',
          style: TextStyle(fontSize: 14, color: Colors.grey[700], height: 1.4),
          textAlign: TextAlign.center),
        const SizedBox(height: 24),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF0284C7), Color(0xFF7C3AED)]),
            borderRadius: BorderRadius.circular(30)),
          child: const Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.search_rounded, color: Colors.white, size: 18),
            SizedBox(width: 8),
            Text('Find Friends',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
          ])),
      ]),
    ),
  );
}

// ── Welcome Banner ────────────────────────────────────────────────────────────
class _WelcomeBanner extends StatelessWidget {
  const _WelcomeBanner();
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _kBlue.withValues(alpha: 0.12)),
        boxShadow: [BoxShadow(
          color: _kBlue.withValues(alpha: 0.08),
          blurRadius: 20, offset: const Offset(0, 4))],
      ),
      child: Row(children: [
        Container(
          width: 54, height: 54,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF0284C7), Color(0xFF7C3AED)],
              begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: BorderRadius.circular(16)),
          child: const Icon(Icons.waving_hand_rounded,
            color: Colors.white, size: 28)),
        const SizedBox(width: 14),
        const Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Welcome to Zylo! 🎉',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800,
                color: const Color(0xFF0D1B2A))),
            SizedBox(height: 4),
            Text('Post, make friends, and connect with the world',
              style: TextStyle(fontSize: 12, color: Colors.grey, height: 1.4)),
          ])),
      ]),
    );
  }
}

// ── Tip Card ──────────────────────────────────────────────────────────────────
class _TipCard extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title, body;
  const _TipCard({
    required this.icon, required this.color,
    required this.title, required this.body});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 200,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withValues(alpha: 0.15)),
        boxShadow: [BoxShadow(
          color: color.withValues(alpha: 0.08),
          blurRadius: 12, offset: const Offset(0, 3))],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          width: 38, height: 38,
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(10)),
          child: Icon(icon, color: color, size: 20)),
        const SizedBox(height: 10),
        Text(title,
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800,
            color: const Color(0xFF0D1B2A))),
        const SizedBox(height: 4),
        Text(body,
          style: TextStyle(fontSize: 11, color: Colors.grey[600], height: 1.4),
          maxLines: 3, overflow: TextOverflow.ellipsis),
      ]),
    );
  }
}

// ══════════════════════════════════════════════════════════════
//  Privacy-Aware Post Card (wrapper — filters by visibility)
// ══════════════════════════════════════════════════════════════
class _PrivacyAwarePostCard extends StatefulWidget {
  final Map<String, dynamic> post;
  final String postId, myUid, authorId;
  final AuthService auth;
  final bool isAdmin;
  final bool isPinned;
  const _PrivacyAwarePostCard({
    required this.post,
    required this.postId,
    required this.myUid,
    required this.auth,
    required this.authorId,
    this.isAdmin = false,
    this.isPinned = false,
  });
  @override
  State<_PrivacyAwarePostCard> createState() => _PrivacyAwarePostCardState();
}

class _PrivacyAwarePostCardState extends State<_PrivacyAwarePostCard> {
  bool? _inCircle; // null = loading

  @override
  void initState() {
    super.initState();
    final visibility = widget.post['visibility'] as String? ?? 'public';
    // Only need to check if it's an inner-circle post and not my own
    if (visibility == 'inner' && widget.authorId != widget.myUid) {
      FirestoreService().amIInTheirInnerCircle(widget.authorId).then((v) {
        if (mounted) setState(() => _inCircle = v);
      });
    } else {
      _inCircle = true; // public or own post — show
    }
  }

  @override
  Widget build(BuildContext context) {
    // Always show own posts
    if (widget.authorId == widget.myUid) {
      return _PostCard(post: widget.post, postId: widget.postId,
          myUid: widget.myUid, auth: widget.auth, isAdmin: widget.isAdmin, isPinned: widget.isPinned);
    }

    final visibility = widget.post['visibility'] as String? ?? 'public';

    // Legacy 'private' posts — hide from feed
    if (visibility == 'private') return const SizedBox.shrink();

    // Followers-only post — check if I follow this person
    if (visibility == 'inner') {
      if (_inCircle == null) return _FollowingShimmer(); // loading shimmer
      if (!_inCircle!) return const SizedBox.shrink();       // not in circle
    }

    return _PostCard(post: widget.post, postId: widget.postId,
        myUid: widget.myUid, auth: widget.auth, isAdmin: widget.isAdmin, isPinned: widget.isPinned);
  }
}

// ══════════════════════════════════════════════════════════════

// ══════════════════════════════════════════════════════════════
//  Inner Circle Shimmer — shown while amIInTheirInnerCircle loads
// ══════════════════════════════════════════════════════════════
class _FollowingShimmer extends StatefulWidget {
  @override
  State<_FollowingShimmer> createState() => _FollowingShimmerState();
}

class _FollowingShimmerState extends State<_FollowingShimmer>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000))
      ..repeat(reverse: true);
    _anim = Tween(begin: 0.3, end: 0.7).animate(
        CurveTween(curve: Curves.easeInOut).animate(_ctrl));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, __) => Container(
        height: 80,
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        decoration: BoxDecoration(
          color: const Color(0xFF7C3AED).withValues(alpha: _anim.value * 0.08),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
              color: const Color(0xFF7C3AED).withValues(alpha: _anim.value * 0.25)),
        ),
        child: Row(children: [
          const SizedBox(width: 16),
          Container(
            width: 40, height: 40,
            decoration: BoxDecoration(
              color: const Color(0xFF7C3AED).withValues(alpha: _anim.value * 0.15),
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(height: 10, width: 120,
                  decoration: BoxDecoration(
                      color: Colors.grey.withValues(alpha: _anim.value * 0.4),
                      borderRadius: BorderRadius.circular(6))),
              const SizedBox(height: 8),
              Container(height: 8, width: 200,
                  decoration: BoxDecoration(
                      color: Colors.grey.withValues(alpha: _anim.value * 0.3),
                      borderRadius: BorderRadius.circular(6))),
            ],
          )),
        ]),
      ),
    );
  }
}

//  Post Card
// ══════════════════════════════════════════════════════════════
// ══════════════════════════════════════════════════════════════
//  Post Card — Optimized (no N+1 admin fetch, no nested streams)
// ══════════════════════════════════════════════════════════════
class _PostCard extends StatefulWidget {
  final Map<String, dynamic> post;
  final String postId, myUid;
  final AuthService auth;
  // isAdmin passed from parent so each card doesn't do its own Firestore fetch
  final bool isAdmin;
  final bool isPinned;
  const _PostCard({
    required this.post,
    required this.postId,
    required this.myUid,
    required this.auth,
    this.isAdmin = false,
    this.isPinned = false,
  });
  @override
  State<_PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<_PostCard> {
  Map<String, dynamic> get post    => widget.post;
  String get postId  => widget.postId;
  String get myUid   => widget.myUid;
  AuthService get auth => widget.auth;

  // ── Author data (live stream) ─────────────────────────────────────────────
  Map<String, dynamic> _authorData = {};
  StreamSubscription<DocumentSnapshot>? _authorSub;
  bool _isSaved = false;
  bool _isFollowing = false;   // I follow them
  bool _theyAddedMe     = false;   // They added me — show "Add Back"
  bool _togglingCircle  = false;

  // ── 5-second view timer ───────────────────────────────────────────────────
  Timer? _viewTimer;
  bool   _viewTracked = false;

  @override
  void initState() {
    super.initState();
    final authorId = post['authorId'] as String? ?? '';
    // Only use cache if it's for the correct author
    final cached = CacheService.getStaleProfile(authorId);
    if (cached != null && authorId.isNotEmpty) _authorData = cached;
    _subscribeAuthor(authorId);
    _loadSaveAndCircleState(authorId);
    // Start 5s view timer (only for other users' posts to avoid self-inflation)
    if (myUid.isNotEmpty && authorId != myUid) {
      _viewTimer = Timer(const Duration(seconds: 5), _trackView);
    }
  }

  @override
  void dispose() {
    _viewTimer?.cancel();
    _authorSub?.cancel();
    super.dispose();
  }

  Future<void> _trackView() async {
    if (_viewTracked || myUid.isEmpty) return;
    _viewTracked = true;
    final authorId = post['authorId'] as String? ?? '';
    if (authorId == myUid) return; // don't count own views
    try {
      final postRef = FirebaseFirestore.instance.collection('posts').doc(postId);
      final viewerRef = postRef.collection('viewers').doc(myUid);
      // Only increment views if this user hasn't viewed before (true dedup)
      final existing = await viewerRef.get();
      if (existing.exists) return; // already counted — skip increment
      final batch = FirebaseFirestore.instance.batch();
      batch.update(postRef, {'views': FieldValue.increment(1)});
      batch.set(viewerRef, {
        'uid': myUid,
        'viewedAt': FieldValue.serverTimestamp(),
      });
      await batch.commit();
    } catch (_) {}
  }

  Future<void> _trackClick() async {
    if (myUid.isEmpty) return;
    final authorId = post['authorId'] as String? ?? '';
    if (authorId == myUid) return;
    try {
      await FirebaseFirestore.instance.collection('posts').doc(postId)
          .update({'clicks': FieldValue.increment(1)});
    } catch (_) {}
  }

  Future<void> _trackHtmlOpen() async {
    if (myUid.isEmpty) return;
    final authorId = post['authorId'] as String? ?? '';
    if (authorId == myUid) return;
    try {
      final batch = FirebaseFirestore.instance.batch();
      final postRef = FirebaseFirestore.instance.collection('posts').doc(postId);
      batch.update(postRef, {'htmlOpens': FieldValue.increment(1)});
      final openerRef = postRef.collection('htmlOpeners').doc(myUid);
      batch.set(openerRef, {
        'uid': myUid,
        'openedAt': FieldValue.serverTimestamp(),
        'openCount': FieldValue.increment(1),
      }, SetOptions(merge: true));
      await batch.commit();
    } catch (_) {}
  }

  /// Live-stream the author's profile so username/photo changes reflect immediately.
  void _subscribeAuthor(String authorId) {
    if (authorId.isEmpty) return;
    _authorSub?.cancel();
    _authorSub = FirebaseFirestore.instance
        .collection('users').doc(authorId)
        .snapshots()
        .listen((snap) {
      final d = snap.data();
      if (d != null && mounted) {
        setState(() => _authorData = d);
        CacheService.cacheProfile(authorId, d);
      }
    });
  }

  Future<void> _loadSaveAndCircleState(String authorId) async {
    // Load save state once
    if (myUid.isNotEmpty) {
      try {
        final snap = await FirebaseFirestore.instance
            .collection('users').doc(myUid)
            .collection('savedPosts').doc(postId).get();
        if (mounted) setState(() => _isSaved = snap.exists);
      } catch (_) {}
    }
    // Load inner circle state for non-own posts
    if (myUid.isNotEmpty && authorId.isNotEmpty && authorId != myUid) {
      try {
        final theySnap = await FirebaseFirestore.instance
            .collection('users').doc(authorId).collection('followers').doc(myUid).get();
        final myCircleSnap = await FirebaseFirestore.instance
            .collection('users').doc(myUid).collection('following').doc(authorId).get();
        if (mounted) setState(() {
          _theyAddedMe  = theySnap.exists;
          _isFollowing  = myCircleSnap.exists;
        });
      } catch (_) {}
    }
  }

  // ── Double-tap heart animation ─────────────────────────────────────────────
  bool _showHeart = false;

  void _onDoubleTap(bool isLiked) {
    if (!isLiked) _toggleLike(false);
    _trackClick(); // count as a click/engagement
    setState(() => _showHeart = true);
    HapticFeedback.mediumImpact();
    Future.delayed(const Duration(milliseconds: 900), () {
      if (mounted) setState(() => _showHeart = false);
    });
  }

  // ── Reactions ─────────────────────────────────────────────────────────────
  static const _reactions    = ['❤️','🔥'];
  static const _reactionKeys = ['heart','fire'];

  String? _myReaction(Map<String, dynamic> p) {
    for (final k in _reactionKeys) {
      final list = (p['reactions_$k'] as List?)?.cast<String>() ?? [];
      if (list.contains(myUid)) return k;
    }
    return null;
  }

  String _reactionEmoji(String? key) {
    if (key == null) return '';
    final i = _reactionKeys.indexOf(key);
    return i >= 0 ? _reactions[i] : '';
  }

  int _totalReactions(Map<String, dynamic> p) {
    int total = 0;
    for (final k in _reactionKeys) {
      total += ((p['reactions_$k'] as List?)?.length ?? 0);
    }
    return total;
  }

  Future<void> _setReaction(String? newKey) async {
    final ref   = FirebaseFirestore.instance.collection('posts').doc(postId);
    final batch = FirebaseFirestore.instance.batch();
    for (final k in _reactionKeys) {
      batch.update(ref, {'reactions_$k': FieldValue.arrayRemove([myUid])});
    }
    await batch.commit();
    if (newKey != null) {
      await ref.update({'reactions_$newKey': FieldValue.arrayUnion([myUid])});
      final authorId = post['authorId'] as String? ?? '';
      if (authorId.isNotEmpty && authorId != myUid) {
        final myName = auth.userName ?? 'Someone';
        final emoji  = _reactionEmoji(newKey);
        FirebaseFirestore.instance.collection('users').doc(authorId)
            .collection('notifications').add({
          'type': 'post_like',
          'text': '@$myName reacted $emoji to your post',
          'fromUid': myUid, 'fromName': myName,
          'fromPhoto': auth.photoURL ?? '',
          'postId': postId, 'read': false,
          'createdAt': FieldValue.serverTimestamp(),
        });
        // Push notification
        NotificationService().sendLikeNotification(
          toUid: authorId,
          fromName: myName,
          fromPhotoUrl: auth.photoURL,
          postId: postId,
          emoji: emoji,
        ).catchError((_) {});
      }
    }
    HapticFeedback.lightImpact();
  }

  void _showReactionPicker(BuildContext ctx, Map<String, dynamic> p) {
    final myReact = _myReaction(p);
    showModalBottomSheet(
      context: ctx,
      backgroundColor: Colors.transparent,
      builder: (_) => Padding(
        padding: const EdgeInsets.only(bottom: 48),
        child: Center(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(50),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.18), blurRadius: 24, offset: const Offset(0, 8))]),
            child: Row(mainAxisSize: MainAxisSize.min, children: List.generate(_reactions.length, (i) {
              final key = _reactionKeys[i];
              final isSelected = myReact == key;
              return GestureDetector(
                onTap: () { Navigator.pop(ctx); _setReaction(isSelected ? null : key); },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  margin: const EdgeInsets.symmetric(horizontal: 5),
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: isSelected ? _kBlue.withValues(alpha: 0.12) : Colors.transparent,
                    shape: BoxShape.circle,
                    border: isSelected ? Border.all(color: _kBlue, width: 2) : null),
                  child: Text(_reactions[i], style: TextStyle(fontSize: isSelected ? 38 : 34))),
              );
            })),
          ),
        ),
      ));
  }

  String _fmtTs(Timestamp ts) {
    final dt = ts.toDate();
    final months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    final h = dt.hour % 12 == 0 ? 12 : dt.hour % 12;
    final m = dt.minute.toString().padLeft(2, '0');
    final ampm = dt.hour < 12 ? 'AM' : 'PM';
    return '${months[dt.month-1]} ${dt.day}, $h:$m $ampm';
  }

  @override
  Widget build(BuildContext context) {
    final authorId       = post['authorId']       as String? ?? '';
    final text           = post['text']           as String? ?? '';
    final images         = (post['images']  as List?)?.cast<String>() ?? [];
    final files          = (post['files']   as List?)?.cast<Map>().map((f) => Map<String, dynamic>.from(f)).toList() ?? [];
    final likes          = (post['likes']   as List?)?.cast<String>() ?? [];
    final commentCnt     = post['commentCount']   as int? ?? 0;
    final createdAt      = post['createdAt']      as Timestamp?;
    final isLiked        = likes.contains(myUid);
    final isMyPost       = authorId == myUid;
    final deletedByAdmin = post['deletedByAdmin'] == true;
    final myReact        = _myReaction(post);
    final totalReacts    = _totalReactions(post);
    final isAdmin        = widget.isAdmin;
    final isPinned       = widget.isPinned;
    final linkUrl        = post['linkUrl'] as String? ?? '';
    final hasLink        = linkUrl.isNotEmpty;
    final hasImage       = images.isNotEmpty;
    final hasText        = text.isNotEmpty;
    final viewCount      = post['views'] as int? ?? 0;

    if (deletedByAdmin && !isMyPost) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        child: Row(children: [
          const Icon(Icons.gavel_rounded, color: Colors.red, size: 14),
          const SizedBox(width: 8),
          const Expanded(child: Text('This post was removed by admin.',
            style: TextStyle(color: Colors.red, fontSize: 12, fontWeight: FontWeight.w500))),
          const Divider(),
        ]),
      );
    }

    final u     = _authorData;
    final name  = u['username']  as String? ?? 'user';
    final photo = u['photoURL']  as String? ?? '';
    final isSaved = _isSaved;

    void openFullPost() {
      _trackClick();
      Navigator.push(context, MaterialPageRoute(
        builder: (_) => _PostDetailScreen(
          postId: postId, myUid: myUid, auth: auth,
          initialPost: post, authorData: _authorData,
        )));
    }

    final otherFiles = files.toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // ── PINNED LABEL ──────────────────────────────────────────────────────
        if (isPinned)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 6, 16, 0),
            child: Row(children: [
              Icon(Icons.push_pin_rounded, size: 11, color: Colors.amber[700]),
              const SizedBox(width: 4),
              Text('Pinned', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: Colors.amber[700])),
            ]),
          ),

        // ── HEADER ────────────────────────────────────────────────────────────
        GestureDetector(
          onTap: openFullPost,
          onLongPress: () {
            HapticFeedback.mediumImpact();
            if (isAdmin && !isMyPost) {
              _showAdminLongPressMenu(context, authorId);
            } else if (isMyPost) {
              _showLongPressMenu(context);
            }
          },
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
            child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
              // Avatar
              GestureDetector(
                onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => ViewProfileScreen(targetUid: authorId))),
                child: ZyloAvatar(photoUrl: photo, radius: 17)),
              const SizedBox(width: 9),
              // Name + meta
              Expanded(child: GestureDetector(
                onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => ViewProfileScreen(targetUid: authorId))),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Flexible(child: Text(name,
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: Color(0xFF0D1B2A)),
                      overflow: TextOverflow.ellipsis)),
                    if (u['isOfficialTick'] == true)
                      const Padding(padding: EdgeInsets.only(left: 3),
                        child: Icon(Icons.verified, color: Color(0xFF0284C7), size: 12)),
                    if ((post['visibility'] as String? ?? 'public') == 'inner')
                      Container(
                        margin: const EdgeInsets.only(left: 5),
                        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                        decoration: BoxDecoration(
                          color: const Color(0xFF7C3AED).withValues(alpha: 0.10),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: const Color(0xFF7C3AED).withValues(alpha: 0.3))),
                        child: const Text('🟣 Inner',
                          style: TextStyle(fontSize: 8, fontWeight: FontWeight.w700, color: Color(0xFF7C3AED))),
                      ),
                  ]),
                  Row(children: [
                    Text('${_timeAgo(createdAt?.toDate())}', style: TextStyle(fontSize: 10, color: Colors.grey[500])),
                    if (viewCount > 0) ...[ 
                      Text(' · ', style: TextStyle(fontSize: 10, color: Colors.grey[400])),
                      Icon(Icons.visibility_outlined, size: 10, color: Colors.grey[400]),
                      const SizedBox(width: 2),
                      Text('$viewCount', style: TextStyle(fontSize: 10, color: Colors.grey[400])),
                    ],
                  ]),
                ]),
              )),
              // Follow button or My Post menu
              if (!isMyPost && !_isFollowing)
                GestureDetector(
                  onTap: _togglingCircle ? null : () => _toggleInnerCircleFromPost(context, authorId),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      border: Border.all(color: _kBlue.withValues(alpha: 0.7), width: 1.2),
                      borderRadius: BorderRadius.circular(20)),
                    child: Text(_togglingCircle ? '...' : '+ Follow',
                      style: const TextStyle(color: _kBlue, fontSize: 11, fontWeight: FontWeight.w700)))),
              const SizedBox(width: 4),
              if (isMyPost)
                Row(mainAxisSize: MainAxisSize.min, children: [
                  GestureDetector(
                    onTap: () => _showSearchKeywordsSheet(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                      margin: const EdgeInsets.only(right: 2),
                      decoration: BoxDecoration(
                        color: const Color(0xFF059669).withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(8)),
                      child: const Text('\\',
                        style: TextStyle(fontSize: 13, fontWeight: FontWeight.w900, color: Color(0xFF059669))))),
                  PopupMenuButton<String>(
                    icon: Icon(Icons.more_horiz, color: Colors.grey[500], size: 18),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    onSelected: (v) {
                      if (v == 'delete') _showLongPressMenu(context);
                      if (v == 'analytics') Navigator.push(context, MaterialPageRoute(builder: (_) => PostAnalyticsScreen(postId: postId, post: widget.post)));
                    },
                    itemBuilder: (_) => [
                      const PopupMenuItem(value: 'analytics', child: Row(children: [
                        Icon(Icons.bar_chart_rounded, size: 16, color: Color(0xFF0284C7)),
                        SizedBox(width: 8), Text('Analytics'),
                      ])),
                      const PopupMenuItem(value: 'delete', child: Row(children: [
                        Icon(Icons.delete_outline, size: 16, color: Colors.red),
                        SizedBox(width: 8), Text('Delete', style: TextStyle(color: Colors.red)),
                      ])),
                    ]),
                ])
              else
                PopupMenuButton<String>(
                  icon: Icon(Icons.more_horiz, color: Colors.grey[500], size: 18),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  onSelected: (v) {
                    if (v == 'report') _showReportSheet(context, postId, authorId);
                  },
                  itemBuilder: (_) => [
                    const PopupMenuItem(value: 'report', child: Row(children: [
                      Icon(Icons.flag_outlined, size: 16, color: Colors.orange),
                      SizedBox(width: 8), Text('Report', style: TextStyle(color: Colors.orange)),
                    ])),
                  ]),
            ]),
          ),
        ),

        // ── TEXT ──────────────────────────────────────────────────────────────
        if (hasText)
          GestureDetector(
            onTap: openFullPost,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(14, 8, 14, 0),
              child: _ExpandableText(text: text, maxLines: 4, onExpand: openFullPost))),

        // ── LINK pill ─────────────────────────────────────────────────────────
        if (hasLink && !_isYoutubeUrl(linkUrl))
          Padding(padding: const EdgeInsets.fromLTRB(14, 6, 14, 0),
            child: GestureDetector(
              onTap: () async {
                final uri = Uri.tryParse(linkUrl.startsWith('http') ? linkUrl : 'https://$linkUrl');
                if (uri != null) await launchUrl(uri, mode: LaunchMode.externalApplication);
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0xFFEFF6FF),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFF0284C7).withValues(alpha: 0.2))),
                child: Row(children: [
                  const Icon(Icons.link_rounded, color: Color(0xFF0284C7), size: 13),
                  const SizedBox(width: 6),
                  Expanded(child: Text(linkUrl,
                    style: const TextStyle(color: Color(0xFF0284C7), fontSize: 11,
                      decoration: TextDecoration.underline, fontWeight: FontWeight.w600),
                    maxLines: 1, overflow: TextOverflow.ellipsis)),
                  const Icon(Icons.open_in_new_rounded, color: Color(0xFF0284C7), size: 11),
                ]),
              ))),

        // ── IMAGE — full width 16:9 ───────────────────────────────────────────
        if (hasImage)
          GestureDetector(
            onDoubleTap: () => _onDoubleTap(isLiked),
            onTap: openFullPost,
            child: Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Stack(alignment: Alignment.center, children: [
                AspectRatio(
                  aspectRatio: images.length == 1 ? 16 / 9 : 1.0,
                  child: ZyloCachedImage(
                    url: images[0],
                    width: null,
                    height: null,
                    fit: BoxFit.cover,
                    errorWidget: Container(
                      color: Colors.grey[100],
                      child: const Icon(Icons.broken_image, color: Colors.grey)))),
                if (images.length > 1)
                  Positioned(top: 10, right: 10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(12)),
                      child: Text('+${images.length - 1}',
                        style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)))),
                if (_showHeart)
                  TweenAnimationBuilder<double>(
                    tween: Tween(begin: 0.4, end: 1.0),
                    duration: const Duration(milliseconds: 400),
                    curve: Curves.elasticOut,
                    builder: (_, v, __) => Transform.scale(scale: v,
                      child: Opacity(opacity: v.clamp(0.0, 1.0),
                        child: const Icon(Icons.favorite_rounded,
                          color: Colors.white, size: 80,
                          shadows: [Shadow(color: Colors.black38, blurRadius: 20)])))),
              ])),
          ),

        // ── YOUTUBE embed ─────────────────────────────────────────────────────
        if (hasLink && _isYoutubeUrl(linkUrl))
          Padding(padding: const EdgeInsets.only(top: 8),
            child: _LazyYoutubeEmbed(url: linkUrl)),


        // ── OTHER FILES ───────────────────────────────────────────────────────
        if (otherFiles.isNotEmpty)
          Padding(padding: const EdgeInsets.fromLTRB(14, 8, 14, 0),
            child: Column(children: otherFiles.map((f) => _FileAttachment(fileData: f)).toList())),

        // ── ACTION BAR ────────────────────────────────────────────────────────
        Padding(
          padding: const EdgeInsets.fromLTRB(10, 6, 10, 8),
          child: Row(children: [
            // ── ❤️ Heart reaction ─────────────────────────────────────────
            GestureDetector(
              onTap: () {
                final cur = _myReaction(post);
                _setReaction(cur == 'heart' ? null : 'heart');
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Text(
                    _myReaction(post) == 'heart' ? '❤️' : '🤍',
                    style: const TextStyle(fontSize: 18),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '${((post['reactions_heart'] as List?)?.length ?? 0)}',
                    style: TextStyle(
                      fontSize: 12,
                      color: _myReaction(post) == 'heart' ? Colors.red : Colors.grey[600],
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ]),
              ),
            ),
            // ── 🔥 Fire reaction ──────────────────────────────────────────
            GestureDetector(
              onTap: () {
                final cur = _myReaction(post);
                _setReaction(cur == 'fire' ? null : 'fire');
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Text(
                    _myReaction(post) == 'fire' ? '🔥' : '🩶',
                    style: const TextStyle(fontSize: 18),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '${((post['reactions_fire'] as List?)?.length ?? 0)}',
                    style: TextStyle(
                      fontSize: 12,
                      color: _myReaction(post) == 'fire' ? Colors.orange : Colors.grey[600],
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ]),
              ),
            ),
            // Comments
            GestureDetector(
              onTap: openFullPost,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.chat_bubble_outline_rounded, size: 17, color: Colors.grey[500]),
                  const SizedBox(width: 4),
                  Text('$commentCnt', style: TextStyle(fontSize: 12, color: Colors.grey[600], fontWeight: FontWeight.w600)),
                ]))),
            // Share
            GestureDetector(
              onTap: () => _showShareSheet(context),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                child: Icon(Icons.share_outlined, size: 17, color: Colors.grey[500]))),
            const Spacer(),
            // Save
            GestureDetector(
              onTap: () {
                HapticFeedback.lightImpact();
                final wasS = _isSaved;
                setState(() => _isSaved = !wasS);
                final ref = FirebaseFirestore.instance
                    .collection('users').doc(myUid)
                    .collection('savedPosts').doc(postId);
                if (wasS) {
                  ref.delete().catchError((_) { if (mounted) setState(() => _isSaved = wasS); });
                } else {
                  ref.set({'savedAt': FieldValue.serverTimestamp(), 'postId': postId})
                      .catchError((_) { if (mounted) setState(() => _isSaved = wasS); });
                  // Notify post author that someone saved their post
                  final authorId = post['authorId'] as String? ?? '';
                  if (authorId.isNotEmpty && authorId != myUid) {
                    final myName = auth.userName ?? 'Someone';
                    NotificationService().sendPostSavedNotification(
                      toUid: authorId,
                      postId: postId,
                      fromName: myName,
                      fromPhotoUrl: auth.photoURL,
                    ).catchError((_) {});
                  }
                }
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 200),
                  child: Icon(
                    isSaved ? Icons.bookmark_rounded : Icons.bookmark_border_rounded,
                    key: ValueKey(isSaved),
                    color: isSaved ? Colors.amber[700] : Colors.grey[400], size: 20)))),
          ])),

        // ── DIVIDER ───────────────────────────────────────────────────────────
        Divider(height: 1, thickness: 1, color: Colors.grey[100]),
      ],
    );
  }

  void _showAdminLongPressMenu
(BuildContext ctx, String authorId) {
    final currentlyPinned = post['isPinned'] == true;
    showModalBottomSheet(
      context: ctx, backgroundColor: Colors.transparent,
      builder: (_) => Container(
        decoration: const BoxDecoration(color: Color(0xFF1A1A1A), borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4,
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(10))),
          const SizedBox(height: 16),
          const Row(children: [
            Icon(Icons.admin_panel_settings, color: Color(0xFFFFBB35), size: 18),
            SizedBox(width: 8),
            Text('Admin Actions', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16)),
          ]),
          const SizedBox(height: 12),
          // ── Pin / Unpin ───────────────────────────────────────────────────
          ListTile(
            leading: Container(padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: const Color(0xFFFFBB35).withValues(alpha: 0.15), borderRadius: BorderRadius.circular(10)),
              child: Icon(currentlyPinned ? Icons.push_pin_outlined : Icons.push_pin_rounded,
                color: const Color(0xFFFFBB35), size: 20)),
            title: Text(currentlyPinned ? 'Unpin Post' : '📌 Pin to Top',
              style: const TextStyle(color: Color(0xFFFFBB35), fontWeight: FontWeight.w700)),
            subtitle: Text(currentlyPinned ? 'Remove from featured' : 'Show at top of feed for everyone',
              style: const TextStyle(color: Colors.grey, fontSize: 12)),
            onTap: () async {
              Navigator.pop(ctx);
              final updateData = <String, dynamic>{'isPinned': !currentlyPinned};
              if (currentlyPinned) {
                updateData['pinnedAt'] = FieldValue.delete();
              } else {
                updateData['pinnedAt'] = FieldValue.serverTimestamp();
              }
              await FirebaseFirestore.instance.collection('posts').doc(postId).update(updateData);
              if (ctx.mounted) ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
                content: Text(currentlyPinned ? 'Post unpinned' : '📌 Post pinned to top!'),
                backgroundColor: const Color(0xFFFFBB35),
                behavior: SnackBarBehavior.floating));
            },
          ),
          ListTile(
            leading: Container(padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: Colors.red.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.gavel_rounded, color: Colors.red, size: 20)),
            title: const Text('Delete Post (Admin)', style: TextStyle(color: Colors.red, fontWeight: FontWeight.w700)),
            subtitle: const Text('User will see "Deleted by Admin"', style: TextStyle(color: Colors.grey, fontSize: 12)),
            onTap: () async {
              Navigator.pop(ctx);
              await FirebaseFirestore.instance.collection('posts').doc(postId).update({
                'deletedByAdmin': true,
                'adminDeletedAt': FieldValue.serverTimestamp(),
              });
              if (ctx.mounted) ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(
                content: Text('Post removed by admin'),
                backgroundColor: Colors.red,
                behavior: SnackBarBehavior.floating));
            },
          ),
          ListTile(
            leading: Container(padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: Colors.orange.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.block, color: Colors.orange, size: 20)),
            title: const Text('Ban User', style: TextStyle(color: Colors.orange, fontWeight: FontWeight.w700)),
            subtitle: const Text('Ban this user from the app', style: TextStyle(color: Colors.grey, fontSize: 12)),
            onTap: () async {
              Navigator.pop(ctx);
              await FirebaseFirestore.instance.collection('users').doc(authorId).update({'isBanned': true});
              if (ctx.mounted) ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(
                content: Text('User banned'),
                backgroundColor: Colors.orange,
                behavior: SnackBarBehavior.floating));
            },
          ),
        ])));
  }

  void _showLongPressMenu(BuildContext ctx) {
    showModalBottomSheet(
      context: ctx, backgroundColor: Colors.transparent,
      builder: (_) => Container(
        decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4,
            decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
          const SizedBox(height: 16),
          ListTile(
            leading: Container(padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: const Color(0xFF0284C7).withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.edit_rounded, color: Color(0xFF0284C7), size: 20)),
            title: const Text('Edit Post', style: TextStyle(fontWeight: FontWeight.w700)),
            subtitle: const Text('Change your post text', style: TextStyle(fontSize: 12)),
            onTap: () { Navigator.pop(ctx); if (context.mounted) _showEditPostSheet(context); },
          ),
          ListTile(
            leading: Container(padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: const Color(0xFF059669).withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.tag_rounded, color: Color(0xFF059669), size: 20)),
            title: const Text('Search Keywords', style: TextStyle(fontWeight: FontWeight.w700)),
            subtitle: const Text('Add keywords to help people find your post', style: TextStyle(fontSize: 12)),
            onTap: () { Navigator.pop(ctx); if (context.mounted) _showSearchKeywordsSheet(context); },
          ),
          ListTile(
            leading: Container(padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: Colors.purple.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.bar_chart_rounded, color: Colors.purple, size: 20)),
            title: const Text('Analytics', style: TextStyle(fontWeight: FontWeight.w700)),
            subtitle: const Text('Views, likes, shares & more', style: TextStyle(fontSize: 12)),
            onTap: () { Navigator.pop(ctx); if (context.mounted) _showAnalyticsSheet(context); },
          ),
          const Divider(),
          ListTile(
            leading: Container(padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: Colors.red.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.delete_outline, color: Colors.red, size: 20)),
            title: const Text('Delete Post', style: TextStyle(fontWeight: FontWeight.w700, color: Colors.red)),
            subtitle: const Text('Permanently remove this post', style: TextStyle(fontSize: 12, color: Colors.red)),
            onTap: () { Navigator.pop(ctx); if (context.mounted) _handleMenu(context, 'delete'); },
          ),
        ])));
  }

  void _showSearchKeywordsSheet(BuildContext ctx) {
    final existing = (post['searchKeywords'] as List?)?.cast<String>().join('  ') ?? '';
    final ctrl = TextEditingController(text: existing);
    showModalBottomSheet(
      context: ctx, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (bCtx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(bCtx).viewInsets.bottom),
        child: Container(
          decoration: const BoxDecoration(
            color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(width: 40, height: 4,
              decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10)))),
            const SizedBox(height: 16),
            const Row(children: [
              Icon(Icons.tag_rounded, color: Color(0xFF059669), size: 20),
              SizedBox(width: 8),
              Text('Search Keywords', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
            ]),
            const SizedBox(height: 6),
            Text('Add words so people can find your post in search. Words are hidden from others.',
              style: TextStyle(fontSize: 12, color: Colors.grey[600])),
            const SizedBox(height: 14),
            TextField(
              controller: ctrl,
              maxLines: 3,
              maxLength: 200,
              style: const TextStyle(fontSize: 14),
              decoration: InputDecoration(
                hintText: 'e.g. food recipe cooking tutorial...',
                hintStyle: TextStyle(color: Colors.grey[400]),
                filled: true, fillColor: const Color(0xFFF8FAFF),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: Colors.grey.withValues(alpha: 0.2))),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: Colors.grey.withValues(alpha: 0.2))),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(color: Color(0xFF059669), width: 1.5)),
                prefixIcon: const Icon(Icons.search_rounded, color: Color(0xFF059669)),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              ),
            ),
            const SizedBox(height: 14),
            SizedBox(width: double.infinity,
              child: ElevatedButton(
                onPressed: () async {
                  Navigator.pop(bCtx);
                  final keywords = ctrl.text.trim().toLowerCase().split(RegExp(r'\s+'))
                    .where((w) => w.isNotEmpty).toList();
                  await FirebaseFirestore.instance.collection('posts').doc(postId)
                      .update({'searchKeywords': keywords});
                  if (ctx.mounted) ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(
                    content: Text('✅ Keywords saved!'),
                    backgroundColor: Color(0xFF059669),
                    behavior: SnackBarBehavior.floating));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF059669),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  padding: const EdgeInsets.symmetric(vertical: 14)),
                child: const Text('Save Keywords', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
              )),
          ]),
        ),
      ),
    );
  }

  void _toggleLike(bool isLiked) {
    final ref = FirebaseFirestore.instance.collection('posts').doc(postId);
    if (isLiked) {
      ref.update({'likes': FieldValue.arrayRemove([myUid])});
    } else {
      HapticFeedback.lightImpact();
      ref.update({'likes': FieldValue.arrayUnion([myUid])});
      final authorId = post['authorId'] as String? ?? '';
      if (authorId.isNotEmpty && authorId != myUid) {
        final myName = auth.userName ?? 'Someone';
        FirebaseFirestore.instance.collection('users').doc(authorId)
            .collection('notifications').add({
          'type': 'post_like',
          'text': '@$myName liked your post',
          'fromUid': myUid, 'fromName': myName,
          'fromPhoto': auth.photoURL ?? '',
          'postId': postId, 'read': false,
          'createdAt': FieldValue.serverTimestamp(),
        });
        // Push notification
        NotificationService().sendLikeNotification(
          toUid: authorId,
          fromName: myName,
          fromPhotoUrl: auth.photoURL,
          postId: postId,
          emoji: '❤️',
        ).catchError((_) {});
      }
    }
  }

  void _showReportSheet(BuildContext ctx, String postId, String authorId) {
    final reasons = ['Spam', 'Hate Speech', 'Nudity or Sexual Content', 'Violence', 'Harassment', 'Misinformation', 'Other'];
    String? selected;
    showModalBottomSheet(
      context: ctx, isScrollControlled: true, backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (bCtx) => StatefulBuilder(builder: (c2, set2) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(bCtx).viewInsets.bottom + 24, top: 20, left: 20, right: 20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16),
            decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10)))),
          const Row(children: [
            Icon(Icons.flag_rounded, color: Colors.red, size: 20),
            SizedBox(width: 8),
            Text('Report Post', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          ]),
          const SizedBox(height: 4),
          const Text('Why are you reporting this post?', style: TextStyle(color: Colors.grey, fontSize: 13)),
          const SizedBox(height: 16),
          Wrap(spacing: 8, runSpacing: 8, children: reasons.map((r) {
            final active = selected == r;
            return GestureDetector(
              onTap: () => set2(() => selected = r),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: active ? Colors.red : Colors.grey[100],
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: active ? Colors.red : Colors.grey[300]!)),
                child: Text(r, style: TextStyle(
                  color: active ? Colors.white : Colors.black87,
                  fontWeight: active ? FontWeight.w700 : FontWeight.w500,
                  fontSize: 13))));
          }).toList()),
          const SizedBox(height: 20),
          SizedBox(width: double.infinity, child: ElevatedButton(
            onPressed: selected == null ? null : () async {
              await FirebaseFirestore.instance.collection('postReports').add({
                'postId': postId, 'authorId': authorId,
                'reportedBy': widget.myUid, 'reason': selected,
                'timestamp': FieldValue.serverTimestamp(),
              });
              if (bCtx.mounted) {
                Navigator.pop(bCtx);
                ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(
                  content: Text('Report submitted. Thank you!'),
                  backgroundColor: Colors.green,
                  behavior: SnackBarBehavior.floating));
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              disabledBackgroundColor: Colors.grey[200],
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              padding: const EdgeInsets.symmetric(vertical: 14)),
            child: Text('Submit Report', style: TextStyle(
              color: selected == null ? Colors.grey : Colors.white,
              fontWeight: FontWeight.w800)))),
        ]))));
  }

  Future<void> _toggleInnerCircleFromPost(BuildContext ctx, String authorId) async {
    if (_togglingCircle || authorId.isEmpty) return;
    setState(() => _togglingCircle = true);
    final fs = FirestoreService();
    final authorName = _authorData['username'] as String? ?? 'user';
    try {
      if (_isFollowing) {
        await fs.removeFromInnerCircle(authorId);
        if (mounted) {
          setState(() => _isFollowing = false);
          ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
            content: Row(children: [
              const Text('⚫', style: TextStyle(fontSize: 16)),
              const SizedBox(width: 8),
              Text('Unfollowed @$authorName',
                style: const TextStyle(fontWeight: FontWeight.w600)),
            ]),
            backgroundColor: Colors.grey[800],
            behavior: SnackBarBehavior.floating,
            margin: const EdgeInsets.all(16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))));
        }
      } else {
        final err = await fs.addToInnerCircle(authorId);
        if (mounted) {
          if (err != null) {
            ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
              content: Text(err, style: const TextStyle(fontWeight: FontWeight.w600)),
              backgroundColor: Colors.red[600],
              behavior: SnackBarBehavior.floating,
              margin: const EdgeInsets.all(16),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))));
          } else {
            setState(() => _isFollowing = true);
            ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
              content: Row(children: [
                const Text('🟣', style: TextStyle(fontSize: 16)),
                const SizedBox(width: 8),
                Text('Now following @$authorName!',
                  style: const TextStyle(fontWeight: FontWeight.w600)),
              ]),
              backgroundColor: const Color(0xFF7C3AED),
              behavior: SnackBarBehavior.floating,
              margin: const EdgeInsets.all(16),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))));
            // Send follow notification
            Future.microtask(() async {
              try {
                final me = FirebaseAuth.instance.currentUser;
                if (me == null) return;
                final doc = await FirebaseFirestore.instance
                    .collection('users').doc(me.uid).get();
                final meName = doc.data()?['username'] as String?
                    ?? me.displayName ?? me.email?.split('@').first ?? 'Someone';
                NotificationService().sendFollowNotification(
                    toUid: authorId, fromName: meName);
              } catch (_) {}
            });
          }
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
          content: Text('Could not follow @$authorName. Try again.',
            style: const TextStyle(fontWeight: FontWeight.w600)),
          backgroundColor: Colors.red[600],
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.all(16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))));
      }
    } finally {
      if (mounted) setState(() => _togglingCircle = false);
    }
  }

  void _handleMenu(BuildContext ctx, String action) {
    if (action == 'delete') {
      // Instant delete — no confirm dialog
      FirebaseFirestore.instance.collection('posts').doc(postId).delete();
      if (ctx.mounted) {
        ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(
          content: Text('Post deleted'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 2),
          behavior: SnackBarBehavior.floating,
        ));
      }
    } else if (action == 'edit') {
      _showEditPostSheet(ctx);
    } else if (action == 'analytics') {
      _showAnalyticsSheet(ctx);
    }
  }

  void _showEditPostSheet(BuildContext ctx) {
    final textCtrl = TextEditingController(text: post['text'] as String? ?? '');
    final images = (post['images'] as List?)?.cast<String>() ?? [];
    showModalBottomSheet(
      context: ctx, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (bCtx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(bCtx).viewInsets.bottom),
        child: Container(
          decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(width: 40, height: 4,
              decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10)))),
            const SizedBox(height: 16),
            const Row(children: [
              Icon(Icons.edit_rounded, color: Color(0xFF0284C7), size: 20),
              SizedBox(width: 8),
              Text('Edit Post', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
            ]),
            const SizedBox(height: 16),
            // Image preview (read-only) with clear explanation
            if (images.isNotEmpty) ...[
              SizedBox(
                height: 90,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: images.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (_, i) => Stack(children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: ColorFiltered(
                        colorFilter: ColorFilter.mode(Colors.black.withValues(alpha: 0.18), BlendMode.darken),
                        child: ZyloCachedImage(url: images[i], width: 90, height: 90, fit: BoxFit.cover))),
                    Positioned.fill(child: Center(child:
                      Icon(Icons.lock_outline_rounded, color: Colors.white.withValues(alpha: 0.85), size: 22))),
                  ]),
                ),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF8E1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFFFFCC02).withValues(alpha: 0.5))),
                child: const Row(children: [
                  Icon(Icons.image_not_supported_outlined, size: 14, color: Color(0xFF92661A)),
                  SizedBox(width: 6),
                  Expanded(child: Text(
                    'Images cannot be changed after posting. Only the caption is editable.',
                    style: TextStyle(fontSize: 11, color: Color(0xFF92661A), height: 1.4))),
                ])),
              const SizedBox(height: 12),
            ],
            Container(
              decoration: BoxDecoration(color: const Color(0xFFF8FAFD), borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.grey[200]!)),
              child: TextField(
                controller: textCtrl, maxLines: 5, minLines: 3,
                decoration: const InputDecoration(
                  hintText: 'What\'s on your mind?',
                  border: InputBorder.none, contentPadding: EdgeInsets.all(14)),
              )),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(child: GestureDetector(
                onTap: () => Navigator.pop(bCtx),
                child: Container(height: 48,
                  decoration: BoxDecoration(color: Colors.grey[100], borderRadius: BorderRadius.circular(14)),
                  child: const Center(child: Text('Cancel', style: TextStyle(fontWeight: FontWeight.w700, color: Colors.grey)))))),
              const SizedBox(width: 12),
              Expanded(child: GestureDetector(
                onTap: () async {
                  final newText = textCtrl.text.trim();
                  if (newText.isNotEmpty) {
                    await FirebaseFirestore.instance.collection('posts').doc(postId).update({
                      'text': newText, 'editedAt': FieldValue.serverTimestamp()});
                  }
                  if (bCtx.mounted) Navigator.pop(bCtx);
                },
                child: Container(height: 48,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFF0284C7), Color(0xFF6366F1)]),
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [BoxShadow(color: const Color(0xFF0284C7).withValues(alpha: 0.3), blurRadius: 8, offset: const Offset(0, 3))]),
                  child: const Center(child: Text('Save', style: TextStyle(fontWeight: FontWeight.w800, color: Colors.white, fontSize: 15)))))),
            ]),
            const SizedBox(height: 8),
          ]),
        ),
      ));
  }

  void _showAnalyticsSheet(BuildContext ctx) {
    final isHtml = (post['htmlSnippet'] as String? ?? '').isNotEmpty;
    Navigator.push(ctx, MaterialPageRoute(
      builder: (_) => PostAnalyticsScreen(
        postId: postId,
        post: post,
        isHtmlPost: isHtml)));
  }

  void _showShareSheet(BuildContext ctx) =>
    showModalBottomSheet(context: ctx, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (_) => _InAppShareSheet(postId: postId, post: post, myUid: myUid));

  String _timeAgo(DateTime? dt) {
    if (dt == null) return '';
    final d = DateTime.now().difference(dt);
    if (d.inMinutes < 1) return 'now';
    if (d.inMinutes < 60) return '${d.inMinutes}m';
    if (d.inHours   < 24) return '${d.inHours}h';
    if (d.inDays    <  7) return '${d.inDays}d';
    return '${dt.day}/${dt.month}';
  }
}


// ── HTML Snippet Card — shown in feed post card ────────────────────────────────
class _HtmlSnippetCard extends StatefulWidget {
  final String html;
  final String authorName;
  final String htmlAppName;   // custom app name (optional)
  final String htmlAppLogo;   // custom logo URL (optional)
  final VoidCallback? onOpen; // called when user opens the runner

  const _HtmlSnippetCard({
    required this.html,
    required this.authorName,
    this.htmlAppName = '',
    this.htmlAppLogo = '',
    this.onOpen,
  });
  @override
  State<_HtmlSnippetCard> createState() => _HtmlSnippetCardState();
}

class _HtmlSnippetCardState extends State<_HtmlSnippetCard> {
  static const _kOrange = Color(0xFFE8542A);

  int get _sizeKb => (widget.html.length / 1024).ceil();

  String get _displayName =>
      widget.htmlAppName.isNotEmpty ? widget.htmlAppName : 'HTML App';

  void _openRunner(BuildContext context) {
    widget.onOpen?.call();
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => _HtmlRunnerScreen(
        html: widget.html,
        title: widget.htmlAppName.isNotEmpty
            ? widget.htmlAppName
            : '@${widget.authorName} — HTML App',
        logoUrl: widget.htmlAppLogo)));
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
      child: GestureDetector(
        onTap: () => _openRunner(context),
        child: Container(
          decoration: BoxDecoration(
            color: const Color(0xFFFFF8F5),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _kOrange.withValues(alpha: 0.25))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // ── Header ─────────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 10, 8),
              child: Row(children: [
                // Logo or default code icon
                widget.htmlAppLogo.isNotEmpty
                  ? ZyloCachedImage(
                      url: widget.htmlAppLogo,
                      width: 28, height: 28, fit: BoxFit.cover,
                      radius: 8,
                      errorWidget: Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: _kOrange.withValues(alpha: 0.1), shape: BoxShape.circle),
                          child: const Icon(Icons.code_rounded, color: _kOrange, size: 16)))
                  : Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: _kOrange.withValues(alpha: 0.1), shape: BoxShape.circle),
                      child: const Icon(Icons.code_rounded, color: _kOrange, size: 16)),
                const SizedBox(width: 8),
                Text(_displayName, style: const TextStyle(
                  fontWeight: FontWeight.w900, fontSize: 13, color: _kOrange)),
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.grey[100], borderRadius: BorderRadius.circular(8)),
                  child: Text('${_sizeKb}KB', style: TextStyle(
                    fontSize: 10, fontWeight: FontWeight.w700, color: Colors.grey[600]))),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: _kOrange,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [BoxShadow(
                      color: _kOrange.withValues(alpha: 0.35),
                      blurRadius: 8, offset: const Offset(0, 3))]),
                  child: const Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.play_arrow_rounded, color: Colors.white, size: 16),
                    SizedBox(width: 4),
                    Text('Run', style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12)),
                  ])),
              ])),

            // ── Inline mini preview with centered play overlay ──────────────
            ClipRRect(
              borderRadius: const BorderRadius.vertical(bottom: Radius.circular(15)),
              child: SizedBox(
                height: 160,
                child: Stack(children: [
                  IgnorePointer(
                    child: _HtmlPreviewWidget(html: widget.html)),
                  Container(color: Colors.black.withValues(alpha: 0.18)),
                  Positioned(bottom: 0, left: 0, right: 0,
                    child: Container(
                      height: 60,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter, end: Alignment.bottomCenter,
                          colors: [Colors.transparent, Colors.black.withValues(alpha: 0.55)])))),
                  Center(
                    child: Container(
                      width: 56, height: 56,
                      decoration: BoxDecoration(
                        color: _kOrange,
                        shape: BoxShape.circle,
                        boxShadow: [BoxShadow(
                          color: _kOrange.withValues(alpha: 0.5),
                          blurRadius: 20, spreadRadius: 2)]),
                      child: const Icon(Icons.play_arrow_rounded,
                        color: Colors.white, size: 30))),
                  Positioned(bottom: 8, left: 0, right: 0,
                    child: Center(child: Text('Tap anywhere to run',
                      style: TextStyle(
                        fontSize: 11, color: Colors.white.withValues(alpha: 0.9),
                        fontWeight: FontWeight.w600,
                        shadows: const [Shadow(color: Colors.black54, blurRadius: 4)])))),
                ]))),
          ]))));
  }
}

// ── Analytic Tile ─────────────────────────────────────────────────────────────
class _AnalyticTile extends StatelessWidget {
  final IconData icon;
  final String label, value;
  final Color color;
  const _AnalyticTile({required this.icon, required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(color: color.withValues(alpha: 0.07), borderRadius: BorderRadius.circular(14),
      border: Border.all(color: color.withValues(alpha: 0.15))),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Container(width: 36, height: 36,
        decoration: BoxDecoration(color: color.withValues(alpha: 0.13), shape: BoxShape.circle),
        child: Icon(icon, color: color, size: 18)),
      const SizedBox(height: 6),
      Text(value, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: color)),
      Text(label, style: const TextStyle(fontSize: 10, color: Colors.grey, fontWeight: FontWeight.w600)),
    ]));
}

// ── File attachment widget ────────────────────────────────────────────────────
class _FileAttachment extends StatefulWidget {
  final Map<String, dynamic> fileData;
  const _FileAttachment({required this.fileData});
  @override
  State<_FileAttachment> createState() => _FileAttachmentState();
}

class _FileAttachmentState extends State<_FileAttachment> {
  bool _resolving = false;

  Future<void> _launch() async {
    final url  = widget.fileData['url'] as String? ?? '';
    final name = widget.fileData['name'] as String? ?? 'file';
    final type = widget.fileData['type'] as String? ?? _fileTypeFromUrl(url);
    if (url.isEmpty) return;

    final mgr = _FeedDownloadsMgr.instance;

    // If already done, open directly
    if (mgr.isDownloaded(url)) {
      final item = mgr.getItem(url);
      if (item?.localPath != null) {
        await OpenFilex.open(item!.localPath!);
        return;
      }
    }

    // tg: prefix — resolve first, then download
    if (url.startsWith('tg:')) {
      if (!mounted) return;
      setState(() => _resolving = true);
      try {
        final fileId  = url.substring(3);
        final token   = CloudflareService.tgToken;
        final metaUri = Uri.parse('https://api.telegram.org/bot$token/getFile?file_id=$fileId');
        final res     = await http.get(metaUri).timeout(const Duration(seconds: 15));
        final json    = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['ok'] == true) {
          final filePath  = (json['result'] as Map)['file_path'] as String;
          final directUrl = 'https://api.telegram.org/file/bot$token/$filePath';
          mgr.start(url: directUrl, name: name, type: type);
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Row(children: [
                const Icon(Icons.download_rounded, color: Colors.white, size: 16),
                const SizedBox(width: 8),
                Text('Downloading $name...', style: const TextStyle(fontWeight: FontWeight.w600)),
              ]),
              backgroundColor: _kBlue,
              behavior: SnackBarBehavior.floating,
              margin: const EdgeInsets.all(16),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
          }
        } else {
          if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Could not resolve download link'), behavior: SnackBarBehavior.floating));
        }
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Download failed: $e'), behavior: SnackBarBehavior.floating));
      } finally {
        if (mounted) setState(() => _resolving = false);
      }
      return;
    }

    // Regular HTTP URL — in-app download
    mgr.start(url: url, name: name, type: type);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Row(children: [
          const Icon(Icons.download_rounded, color: Colors.white, size: 16),
          const SizedBox(width: 8),
          Text('Downloading $name...', style: const TextStyle(fontWeight: FontWeight.w600)),
        ]),
        backgroundColor: _kBlue,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
    }
  }

  @override
  Widget build(BuildContext context) {
    final url     = widget.fileData['url'] as String? ?? '';
    final name    = widget.fileData['name'] as String? ?? 'File';
    final size    = widget.fileData['size'] as int? ?? 0;
    final type    = widget.fileData['type'] as String? ?? _fileTypeFromUrl(url);
    final color   = _fileColor(type);
    final icon    = _fileIcon(type);
    final label   = _fileLabel(type);
    final sizeStr = size > 0 ? _formatSize(size) : '';

    return StreamBuilder<List<_DLItem>>(
      stream: _FeedDownloadsMgr.instance.stream,
      initialData: _FeedDownloadsMgr.instance.all,
      builder: (_, __) {
        final mgr      = _FeedDownloadsMgr.instance;
        final dlItem   = mgr.getItem(url);
        final isDone   = dlItem?.status == _DLStatus.done;
        final isActive = dlItem?.status == _DLStatus.downloading;
        final hasError = dlItem?.status == _DLStatus.error;

        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.07),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withValues(alpha: 0.25))),
          child: Column(children: [
            Row(children: [
              Container(width: 44, height: 44,
                decoration: BoxDecoration(color: color.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(10)),
                child: Icon(icon, color: color, size: 24)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(name,
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: const Color(0xFF0D1B2A)),
                  maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 2),
                if (isDone)
                  Row(children: [
                    Icon(Icons.check_circle_rounded, color: Colors.green[600], size: 12),
                    const SizedBox(width: 4),
                    Text('Downloaded', style: TextStyle(fontSize: 11, color: Colors.green[600], fontWeight: FontWeight.w600)),
                  ])
                else if (isActive)
                  Text('${(dlItem!.progress * 100).toStringAsFixed(0)}% downloading...',
                    style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.w600))
                else if (hasError)
                  const Text('Failed — tap Retry', style: TextStyle(fontSize: 11, color: Colors.red))
                else
                  Text('$label${sizeStr.isNotEmpty ? ' · $sizeStr' : ''}',
                    style: TextStyle(fontSize: 11, color: Colors.grey[700])),
              ])),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: _resolving ? null : _launch,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                  decoration: BoxDecoration(
                    gradient: isDone
                      ? LinearGradient(colors: [Colors.green[600]!, Colors.green[500]!])
                      : LinearGradient(colors: [color, color.withValues(alpha: 0.8)]),
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [BoxShadow(
                      color: (isDone ? Colors.green : color).withValues(alpha: 0.3),
                      blurRadius: 6, offset: const Offset(0, 2))]),
                  child: (_resolving || isActive)
                    ? SizedBox(
                        width: 40, height: 14,
                        child: LinearProgressIndicator(
                          value: isActive ? dlItem!.progress : null,
                          backgroundColor: Colors.white30,
                          valueColor: const AlwaysStoppedAnimation(Colors.white),
                          minHeight: 3))
                    : Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(
                          isDone ? Icons.open_in_new_rounded
                            : hasError ? Icons.refresh_rounded
                            : Icons.download_rounded,
                          color: Colors.white, size: 16),
                        const SizedBox(width: 4),
                        Text(
                          isDone ? 'Open' : hasError ? 'Retry' : 'Download',
                          style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
                      ]))),
            ]),
            if (isActive) ...[
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: dlItem!.progress,
                  minHeight: 3,
                  backgroundColor: color.withValues(alpha: 0.15),
                  valueColor: AlwaysStoppedAnimation<Color>(color))),
            ],
          ]),
        );
      });
  }
  String _formatSize(int bytes) {
    if (bytes < 1024) return '${bytes}B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)}KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)}MB';
  }
}

// ── Post images — horizontal scroll ──────────────────────────────────────────
// ── Expandable text (3 lines + more...) ─────────────────────────────────────
class _ExpandableText extends StatefulWidget {
  final String text;
  final int maxLines;
  final VoidCallback? onExpand;
  const _ExpandableText({required this.text, this.maxLines = 3, this.onExpand});
  @override State<_ExpandableText> createState() => _ExpandableTextState();
}

class _ExpandableTextState extends State<_ExpandableText> {
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (ctx, constraints) {
      final plainStyle = const TextStyle(fontSize: 14, color: Color(0xFF0D1B2A), height: 1.45);
      final tp = TextPainter(
        text: TextSpan(text: widget.text, style: plainStyle),
        maxLines: widget.maxLines,
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: constraints.maxWidth);

      final overflow = tp.didExceedMaxLines;
      final displayText = overflow
          ? widget.text.substring(0, _charLimit(widget.text, widget.maxLines, constraints.maxWidth, plainStyle))
          : widget.text;

      return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _FeedMentionText(
          text: overflow ? displayText : widget.text,
          style: plainStyle,
          maxLines: overflow ? widget.maxLines : null,
        ),
        if (overflow)
          GestureDetector(
            onTap: widget.onExpand,
            child: const Padding(
              padding: EdgeInsets.only(top: 2),
              child: Text('more...', style: TextStyle(
                fontSize: 13, color: Color(0xFF0284C7), fontWeight: FontWeight.w700)))),
      ]);
    });
  }

  int _charLimit(String text, int maxLines, double maxWidth, TextStyle style) {
    // Binary-search approximate character count that fits within maxLines
    int lo = 0, hi = text.length;
    while (lo < hi - 1) {
      final mid = (lo + hi) ~/ 2;
      final tp2 = TextPainter(
        text: TextSpan(text: text.substring(0, mid), style: style),
        maxLines: maxLines,
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: maxWidth);
      if (tp2.didExceedMaxLines) hi = mid; else lo = mid;
    }
    return (lo - 3).clamp(0, text.length);
  }
}

/// Renders post caption text with tappable @mention links
class _FeedMentionText extends StatelessWidget {
  final String text;
  final TextStyle style;
  final int? maxLines;
  const _FeedMentionText({required this.text, required this.style, this.maxLines});

  @override
  Widget build(BuildContext context) {
    final mentionStyle = style.copyWith(
      color: const Color(0xFF0284C7),
      fontWeight: FontWeight.w700,
    );
    final regex = RegExp(r'@(\w+)');
    final spans = <InlineSpan>[];
    int last = 0;
    for (final m in regex.allMatches(text)) {
      if (m.start > last) {
        spans.add(TextSpan(text: text.substring(last, m.start), style: style));
      }
      final username = m.group(1)!;
      spans.add(WidgetSpan(
        alignment: PlaceholderAlignment.baseline,
        baseline: TextBaseline.alphabetic,
        child: GestureDetector(
          onTap: () async {
            // Lookup uid by username then open profile
            try {
              final snap = await FirebaseFirestore.instance
                  .collection('users')
                  .where('username', isEqualTo: username)
                  .limit(1)
                  .get();
              if (snap.docs.isNotEmpty && context.mounted) {
                Navigator.push(context, MaterialPageRoute(
                  builder: (_) => ViewProfileScreen(targetUid: snap.docs.first.id),
                ));
              }
            } catch (_) {}
          },
          child: Text('@$username', style: mentionStyle),
        ),
      ));
      last = m.end;
    }
    if (last < text.length) {
      spans.add(TextSpan(text: text.substring(last), style: style));
    }
    return RichText(
      text: TextSpan(children: spans),
      maxLines: maxLines,
      overflow: maxLines != null ? TextOverflow.ellipsis : TextOverflow.clip,
    );
  }
}

// ── Full Post Detail Screen ───────────────────────────────────────────────────
class _PostDetailScreen extends StatefulWidget {
  final String postId, myUid;
  final AuthService auth;
  final Map<String, dynamic> initialPost;
  final Map<String, dynamic> authorData;
  const _PostDetailScreen({
    required this.postId, required this.myUid, required this.auth,
    required this.initialPost, required this.authorData});
  @override State<_PostDetailScreen> createState() => _PostDetailScreenState();
}

class _PostDetailScreenState extends State<_PostDetailScreen> {
  static const _blue = Color(0xFF0284C7);
  late Map<String, dynamic> _post;
  late Map<String, dynamic> _author;

  @override
  void initState() {
    super.initState();
    _post   = widget.initialPost;
    _author = widget.authorData;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF0D1B2A),
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        title: GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(
            builder: (_) => ViewProfileScreen(targetUid: widget.initialPost['authorId'] ?? ''))),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            ZyloAvatar(photoUrl: _author['photoURL'] as String? ?? '', radius: 16),
            const SizedBox(width: 8),
            Text(_author['username'] as String? ?? 'Post',
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
          ])),
        actions: [
        ]),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance.collection('posts').doc(widget.postId).snapshots(),
        builder: (ctx, snap) {
          final post = (snap.hasData && snap.data!.exists)
            ? (snap.data!.data() as Map<String, dynamic>? ?? _post) : _post;
          final text   = post['text']   as String? ?? '';
          final images = (post['images'] as List?)?.cast<String>() ?? [];
          final files  = (post['files']  as List?)?.cast<Map>().map((f) => Map<String, dynamic>.from(f)).toList() ?? [];
          final likes  = (post['likes']  as List?)?.cast<String>() ?? [];
          final linkUrl = post['linkUrl'] as String? ?? '';
          final isLiked = likes.contains(widget.myUid);
          final commentCnt = post['commentCount'] as int? ?? 0;

          return Column(children: [
            Expanded(child: SingleChildScrollView(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                // Full text
                if (text.isNotEmpty)
                  Padding(padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                    child: Text(text,
                      style: const TextStyle(fontSize: 15, color: Color(0xFF0D1B2A), height: 1.5))),

                // Full images
                if (images.isNotEmpty)
                  Padding(padding: const EdgeInsets.only(top: 12),
                    child: _PostImages(images: images)),

                // Link
                if (linkUrl.isNotEmpty && !_isYoutubeUrl(linkUrl))
                  Padding(padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                    child: GestureDetector(
                      onTap: () async {
                        final uri = Uri.tryParse(linkUrl.startsWith('http') ? linkUrl : 'https://$linkUrl');
                        if (uri != null) await launchUrl(uri, mode: LaunchMode.externalApplication);
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        decoration: BoxDecoration(
                          color: const Color(0xFFEFF6FF),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: _blue.withValues(alpha: 0.25))),
                        child: Row(children: [
                          const Icon(Icons.link_rounded, color: _blue, size: 16),
                          const SizedBox(width: 8),
                          Expanded(child: Text(linkUrl,
                            style: const TextStyle(color: _blue, fontSize: 13,
                              decoration: TextDecoration.underline, fontWeight: FontWeight.w600),
                            maxLines: 2, overflow: TextOverflow.ellipsis)),
                          const Icon(Icons.open_in_new_rounded, color: _blue, size: 14),
                        ])))),

                // YouTube
                if (linkUrl.isNotEmpty && _isYoutubeUrl(linkUrl))
                  Padding(padding: const EdgeInsets.only(top: 10),
                    child: _LazyYoutubeEmbed(url: linkUrl)),

                // Files
                if (files.isNotEmpty)
                  Padding(padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                    child: Column(children: files.map((f) {
                      final url  = f['url']  as String? ?? '';
                      final type = f['type'] as String? ?? _fileTypeFromUrl(url);

                      return _FileAttachment(fileData: f);
                    }).toList())),

                // HTML snippet
                if ((post['htmlSnippet'] as String? ?? '').isNotEmpty)
                  _HtmlSnippetCard(
                    html: post['htmlSnippet'] as String,
                    authorName: post['authorName'] as String? ?? '',
                    htmlAppName: post['htmlAppName'] as String? ?? '',
                    htmlAppLogo: post['htmlAppLogo'] as String? ?? '',
                    onOpen: () {}),

                // Poll
                if ((post['poll'] as Map?) != null)
                  Padding(padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                    child: _PollWidget(
                      poll: post['poll'] as Map<String, dynamic>,
                      postId: widget.postId, myUid: widget.myUid)),

                // Like count
                if (likes.isNotEmpty)
                  Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                    child: Text('${likes.length} likes',
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: Color(0xFF0D1B2A)))),

                const SizedBox(height: 8),
                const Divider(height: 1),

                // Comments header
                Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                  child: Row(children: [
                    const Text('Comments', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(color: _blue.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
                      child: Text('$commentCnt',
                        style: const TextStyle(color: _blue, fontWeight: FontWeight.w700, fontSize: 12))),
                  ])),

                // Comments list (embedded)
                _InlineComments(postId: widget.postId, myUid: widget.myUid, auth: widget.auth),
                const SizedBox(height: 80),
              ])),
            ),

            // ── Bottom action bar ──────────────────────────────────────────
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(top: BorderSide(color: Colors.grey.withValues(alpha: 0.15)))),
              padding: EdgeInsets.only(
                left: 8, right: 8, top: 8,
                bottom: MediaQuery.of(context).padding.bottom + 8),
              child: Row(children: [
                // Like
                GestureDetector(
                  onTap: () async {
                    HapticFeedback.lightImpact();
                    final ref = FirebaseFirestore.instance.collection('posts').doc(widget.postId);
                    if (isLiked) {
                      ref.update({'likes': FieldValue.arrayRemove([widget.myUid])});
                    } else {
                      ref.update({'likes': FieldValue.arrayUnion([widget.myUid])});
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(isLiked ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                        color: isLiked ? Colors.red : Colors.grey[600], size: 22),
                      const SizedBox(width: 5),
                      Text('${likes.length}',
                        style: TextStyle(fontSize: 13,
                          color: isLiked ? Colors.red : Colors.grey[600],
                          fontWeight: FontWeight.w600)),
                    ]))),
                // Comment
                Expanded(child: GestureDetector(
                  onTap: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => PostCommentsScreen(postId: widget.postId, myUid: widget.myUid, auth: widget.auth))),
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 6),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: Colors.grey[100],
                      borderRadius: BorderRadius.circular(24)),
                    child: Text('Write a comment...',
                      style: TextStyle(color: Colors.grey[500], fontSize: 13))))),
                // Share
                GestureDetector(
                  onTap: () {
                    Share.share('Check this post on Zylo!');
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    child: Icon(Icons.share_outlined, color: Colors.grey[600], size: 22))),
              ])),
          ]);
        }),
    );
  }
}

// ── Inline comments (first 3 shown, tap to see all) ──────────────────────────
class _InlineComments extends StatelessWidget {
  final String postId, myUid;
  final AuthService auth;
  const _InlineComments({required this.postId, required this.myUid, required this.auth});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('posts').doc(postId).collection('comments')
          .orderBy('createdAt', descending: false)
          .limit(3)
          .snapshots(),
      builder: (ctx, snap) {
        if (!snap.hasData || snap.data!.docs.isEmpty) {
          return Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: Text('No comments yet. Be the first!',
              style: TextStyle(color: Colors.grey[400], fontSize: 13)));
        }
        final docs = snap.data!.docs;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ...docs.map((d) {
              final c = d.data() as Map<String, dynamic>;
              final cname  = c['authorName'] as String? ?? 'user';
              final ctext  = c['text'] as String? ?? '';
              final cphoto = c['authorPhoto'] as String? ?? '';
              return Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  ZyloAvatar(photoUrl: cphoto, radius: 14),
                  const SizedBox(width: 8),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('@$cname',
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12, color: Color(0xFF0D1B2A))),
                    Text(ctext, style: const TextStyle(fontSize: 13, color: Color(0xFF374151))),
                  ])),
                ]));
            }),
            if (docs.length == 3)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                child: GestureDetector(
                  onTap: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => PostCommentsScreen(postId: postId, myUid: myUid, auth: auth))),
                  child: const Text('View all comments →',
                    style: TextStyle(color: Color(0xFF0284C7), fontWeight: FontWeight.w700, fontSize: 13)))),
          ]);
      });
  }
}

class _PostImages extends StatefulWidget {
  final List<String> images;
  const _PostImages({required this.images});
  @override State<_PostImages> createState() => _PostImagesState();
}

class _PostImagesState extends State<_PostImages> {
  int _current = 0;

  @override
  Widget build(BuildContext context) {
    final count = widget.images.length;
    if (count == 1) {
      return GestureDetector(
        onTap: () => _view(context, 0),
        child: ZyloCachedImage(
          url: widget.images[0],
          width: null,
          height: 280,
          fit: BoxFit.cover,
        ));
    }

    // Multiple images — horizontal PageView
    return Column(children: [
      SizedBox(height: 280,
        child: PageView.builder(
          itemCount: count,
          onPageChanged: (i) => setState(() => _current = i),
          itemBuilder: (_, i) => GestureDetector(
            onTap: () => _view(context, i),
            child: ZyloCachedImage(
              url: widget.images[i],
              width: null,
              height: 280,
              fit: BoxFit.cover,
            )))),
      // Dots indicator
      if (count > 1)
        Padding(padding: const EdgeInsets.only(top: 8),
          child: Row(mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(count, (i) => AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: _current == i ? 18 : 6,
              height: 6,
              decoration: BoxDecoration(
                color: _current == i ? _kBlue : Colors.grey[300],
                borderRadius: BorderRadius.circular(3)))))),
    ]);
  }

  void _view(BuildContext ctx, int idx) => Navigator.push(ctx,
    PageRouteBuilder(opaque: false,
      pageBuilder: (_, __, ___) => _ImgViewer(images: widget.images, initial: idx)));
}

class _ImgViewer extends StatelessWidget {
  final List<String> images; final int initial;
  const _ImgViewer({required this.images, required this.initial});
  @override Widget build(BuildContext context) => Scaffold(
    backgroundColor: Colors.black,
    appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white,
      title: Text('${initial+1}/${images.length}')),
    body: PageView.builder(
      controller: PageController(initialPage: initial),
      itemCount: images.length,
      itemBuilder: (_, i) => InteractiveViewer(
        child: ZyloCachedImage(url: images[i], fit: BoxFit.contain,
          errorWidget: const Icon(Icons.broken_image, color: Colors.white54, size: 64)))));
}

// ── Action button ─────────────────────────────────────────────────────────────
class _ActionBtn extends StatelessWidget {
  final IconData icon; final String label; final Color color; final VoidCallback onTap;
  const _ActionBtn({required this.icon, required this.label, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(12),
    child: Padding(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 20, color: color),
        const SizedBox(width: 5),
        Text(label, style: TextStyle(fontSize: 13, color: color, fontWeight: FontWeight.w600)),
      ])));
}

// ── Mention text ──────────────────────────────────────────────────────────────
class _MentionText extends StatelessWidget {
  final String text; final TextStyle style;
  const _MentionText({required this.text, required this.style});
  @override
  Widget build(BuildContext context) {
    final spans = <TextSpan>[];
    final regex = RegExp(r'@(\w+)');
    int last = 0;
    for (final m in regex.allMatches(text)) {
      if (m.start > last) spans.add(TextSpan(text: text.substring(last, m.start), style: style));
      spans.add(TextSpan(text: m.group(0), style: style.copyWith(color: _kBlue, fontWeight: FontWeight.w700)));
      last = m.end;
    }
    if (last < text.length) spans.add(TextSpan(text: text.substring(last), style: style));
    return RichText(text: TextSpan(children: spans));
  }
}

// ══════════════════════════════════════════════════════════════
//  Poll Widget — live voting with option images, voter avatars & results
// ══════════════════════════════════════════════════════════════
class _PollWidget extends StatefulWidget {
  final Map<String, dynamic> poll;
  final String postId, myUid;
  const _PollWidget({required this.poll, required this.postId, required this.myUid});
  @override State<_PollWidget> createState() => _PollWidgetState();
}

class _PollWidgetState extends State<_PollWidget> {
  bool _voting = false;
  // cache: uid -> {name, photo}
  final Map<String, Map<String, dynamic>> _voterCache = {};

  String? _myVote() {
    final votes = widget.poll['votes'] as Map<String, dynamic>? ?? {};
    for (final entry in votes.entries) {
      final voters = (entry.value as List?)?.cast<String>() ?? [];
      if (voters.contains(widget.myUid)) return entry.key as String;
    }
    return null;
  }

  int _totalVotes() {
    final votes = widget.poll['votes'] as Map<String, dynamic>? ?? {};
    int total = 0;
    for (final v in votes.values) total += ((v as List?)?.length ?? 0);
    return total;
  }

  Future<void> _vote(String option) async {
    if (_voting) return;
    final myVote = _myVote();
    if (myVote == option) return;
    setState(() => _voting = true);
    HapticFeedback.lightImpact();
    try {
      final ref = FirebaseFirestore.instance.collection('posts').doc(widget.postId);
      // Store voter info alongside uid for results display
      final myDoc = await FirebaseFirestore.instance.collection('users').doc(widget.myUid).get();
      final myName  = myDoc.data()?['username'] as String? ?? 'user';
      final myPhoto = myDoc.data()?['photoURL']  as String? ?? '';
      if (myVote != null) {
        await ref.update({
          'poll.votes.$myVote': FieldValue.arrayRemove([widget.myUid]),
          'poll.voterDetails.${widget.myUid}': FieldValue.delete(),
        });
      }
      await ref.update({
        'poll.votes.$option': FieldValue.arrayUnion([widget.myUid]),
        'poll.voterDetails.${widget.myUid}': {'name': myName, 'photo': myPhoto, 'option': option},
      });
    } finally {
      if (mounted) setState(() => _voting = false);
    }
  }

  void _showResults(BuildContext ctx, Map<String, dynamic> poll) {
    final options = (poll['options'] as List?)?.cast<String>() ?? [];
    final votes   = poll['votes'] as Map<String, dynamic>? ?? {};
    final details = poll['voterDetails'] as Map<String, dynamic>? ?? {};
    int total = 0;
    for (final v in votes.values) total += ((v as List?)?.length ?? 0);

    showModalBottomSheet(
      context: ctx,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        maxChildSize: 0.92,
        minChildSize: 0.35,
        builder: (_, sc) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
          child: Column(children: [
            const SizedBox(height: 8),
            Container(width: 36, height: 4,
              decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
            const SizedBox(height: 14),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Row(children: [
                const Icon(Icons.bar_chart_rounded, color: Colors.green, size: 20),
                const SizedBox(width: 8),
                Expanded(child: Text(poll['question'] as String? ?? '',
                  style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15))),
                Text('$total vote${total == 1 ? '' : 's'}',
                  style: TextStyle(fontSize: 12, color: Colors.grey[600])),
              ])),
            const SizedBox(height: 12),
            Expanded(child: ListView(controller: sc, padding: const EdgeInsets.symmetric(horizontal: 16), children: [
              ...options.map((opt) {
                final optVoters = (votes[opt] as List?)?.cast<String>() ?? [];
                final count = optVoters.length;
                final pct = total > 0 ? count / total : 0.0;
                // get voters for this option from voterDetails
                final optDetails = details.entries
                    .where((e) => (e.value as Map?)? ['option'] == opt)
                    .toList();
                return Container(
                  margin: const EdgeInsets.only(bottom: 14),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF0FDF4),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.green.withValues(alpha: 0.2))),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Expanded(child: Text(opt,
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13))),
                      Text('${(pct * 100).round()}% · $count vote${count == 1 ? '' : 's'}',
                        style: TextStyle(fontSize: 11, color: Colors.grey[700], fontWeight: FontWeight.w700)),
                    ]),
                    const SizedBox(height: 6),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: LinearProgressIndicator(
                        value: pct, minHeight: 6,
                        backgroundColor: Colors.green.withValues(alpha: 0.12),
                        valueColor: const AlwaysStoppedAnimation(Colors.green))),
                    if (optDetails.isNotEmpty) ...[ 
                      const SizedBox(height: 10),
                      ...optDetails.map((e) {
                        final d = e.value as Map;
                        final name  = d['name']  as String? ?? 'user';
                        final photo = d['photo'] as String? ?? '';
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: Row(children: [
                            CircleAvatar(
                              radius: 14,
                              backgroundImage: photo.isNotEmpty ? CachedNetworkImageProvider(photo) : null,
                              backgroundColor: Colors.green.withValues(alpha: 0.2),
                              child: photo.isEmpty ? Text(name.isNotEmpty ? name[0].toUpperCase() : '?',
                                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Colors.green)) : null),
                            const SizedBox(width: 8),
                            Text('@$name',
                              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                          ]));
                      }),
                    ],
                  ]));
              }),
            ])),
          ]))));
  }

  @override
  Widget build(BuildContext context) {
    final poll     = widget.poll;
    final question = poll['question'] as String? ?? '';
    final options  = (poll['options'] as List?)?.cast<String>() ?? [];
    final votes    = poll['votes'] as Map<String, dynamic>? ?? {};
    // optionImages: map of option -> imageUrl
    final optImages = poll['optionImages'] as Map<String, dynamic>? ?? {};
    final myVote   = _myVote();
    final total    = _totalVotes();
    final hasVoted = myVote != null;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFF0FDF4),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.green.withValues(alpha: 0.25))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.poll_rounded, color: Colors.green, size: 16),
          const SizedBox(width: 6),
          Expanded(child: Text(question,
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14, color: Color(0xFF0D1B2A)))),
        ]),
        const SizedBox(height: 12),
        ...options.map((opt) {
          final optVoters = (votes[opt] as List?)?.cast<String>() ?? [];
          final count     = optVoters.length;
          final pct       = total > 0 ? count / total : 0.0;
          final isMyChoice = myVote == opt;
          final imgUrl    = optImages[opt] as String? ?? '';
          // show up to 3 voter avatars from voterDetails
          final details   = poll['voterDetails'] as Map<String, dynamic>? ?? {};
          final optVoterDetails = details.entries
              .where((e) => (e.value as Map?)? ['option'] == opt)
              .take(3)
              .toList();

          return GestureDetector(
            onTap: () => _vote(opt),
            child: Container(
              margin: const EdgeInsets.only(bottom: 8),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isMyChoice ? Colors.green : Colors.green.withValues(alpha: 0.2),
                  width: isMyChoice ? 2 : 1)),
              child: Stack(children: [
                // Progress fill bar (behind everything)
                if (hasVoted)
                  Positioned.fill(
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 600),
                      curve: Curves.easeOut,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10)),
                      child: FractionallySizedBox(
                        alignment: Alignment.centerLeft,
                        widthFactor: pct,
                        child: Container(
                          decoration: BoxDecoration(
                            color: isMyChoice
                              ? Colors.green.withValues(alpha: 0.18)
                              : Colors.green.withValues(alpha: 0.07),
                            borderRadius: BorderRadius.circular(10)))))),
                // Content row: image left + text right
                SizedBox(
                  height: 64,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
                    // Thumbnail image on left
                    if (imgUrl.isNotEmpty)
                      ClipRRect(
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(10),
                          bottomLeft: Radius.circular(10)),
                        child: ZyloCachedImage(
                          url: imgUrl,
                          width: 64, height: 64, fit: BoxFit.cover,
                          errorWidget: const SizedBox())),
                    // Text + info
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: Row(children: [
                          if (isMyChoice)
                            const Padding(padding: EdgeInsets.only(right: 6),
                              child: Icon(Icons.check_circle, color: Colors.green, size: 16)),
                          Expanded(child: Text(opt,
                            style: TextStyle(
                              fontWeight: isMyChoice ? FontWeight.w800 : FontWeight.w600,
                              fontSize: 13,
                              color: const Color(0xFF0D1B2A)))),
                          // Voter avatars (stacked)
                          if (hasVoted && optVoterDetails.isNotEmpty)
                            SizedBox(
                              width: (optVoterDetails.length * 16.0) + 8,
                              height: 24,
                              child: Stack(children: [
                                for (int i = 0; i < optVoterDetails.length; i++)
                                  Positioned(
                                    left: i * 16.0,
                                    child: Builder(builder: (_) {
                                      final d = optVoterDetails[i].value as Map;
                                      final photo = d['photo'] as String? ?? '';
                                      final name  = d['name']  as String? ?? '?';
                                      return CircleAvatar(
                                        radius: 10,
                                        backgroundImage: photo.isNotEmpty ? CachedNetworkImageProvider(photo) : null,
                                        backgroundColor: Colors.green.withValues(alpha: 0.25),
                                        child: photo.isEmpty ? Text(name.isNotEmpty ? name[0].toUpperCase() : '?',
                                          style: const TextStyle(fontSize: 7, fontWeight: FontWeight.w900, color: Colors.green)) : null);
                                    })),
                              ])),
                          if (hasVoted) ...[ 
                            const SizedBox(width: 6),
                            Text('${(pct * 100).round()}%',
                              style: TextStyle(
                                fontSize: 12, fontWeight: FontWeight.w700,
                                color: isMyChoice ? Colors.green[700] : Colors.grey[700])),
                          ],
                        ]))),
                  ])),
              ])));
        }).toList(),
        const SizedBox(height: 6),
        Row(children: [
          Text('$total vote${total == 1 ? '' : 's'}',
            style: TextStyle(fontSize: 11, color: Colors.grey[700])),
          const Spacer(),
          if (hasVoted)
            GestureDetector(
              onTap: () => _showResults(context, poll),
              child: Row(children: [
                Icon(Icons.people_alt_rounded, size: 13, color: Colors.green[700]),
                const SizedBox(width: 4),
                Text('View Results',
                  style: TextStyle(fontSize: 11, color: Colors.green[700], fontWeight: FontWeight.w800)),
              ])),
        ]),
      ]));
  }
}

// ══════════════════════════════════════════════════════════════
//  Create Post Sheet
// ══════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════
//  _CreatePostSheet  — redesigned with swipe-up toolbar + HTML viewer tool
// ═══════════════════════════════════════════════════════════════════════════

/// Public alias so home_screen can open the create-post sheet directly.
class FeedCreatePostSheet extends StatelessWidget {
  final String myUid;
  final AuthService auth;
  const FeedCreatePostSheet({super.key, required this.myUid, required this.auth});

  @override
  Widget build(BuildContext context) =>
      _CreatePostSheet(myUid: myUid, auth: auth);
}

class _CreatePostSheet extends StatefulWidget {
  final String myUid;
  final AuthService auth;
  final void Function(Stream<_UploadEvent> events)? onPostStart;
  const _CreatePostSheet({required this.myUid, required this.auth, this.onPostStart});
  @override State<_CreatePostSheet> createState() => _CreatePostSheetState();
}

class _CreatePostSheetState extends State<_CreatePostSheet>
    with SingleTickerProviderStateMixin {
  // ── controllers ────────────────────────────────────────────────────────
  final _ctrl     = TextEditingController();
  final _linkCtrl = TextEditingController();
  final _focusNode = FocusNode();
  final _ytCtrl   = TextEditingController();
  final List<File> _images = [];
  final List<Map<String, dynamic>> _attachedFiles = [];

  // ── tool states ────────────────────────────────────────────────────────
  bool _showLinkField    = false;
  bool _showYoutubeField = false;
  bool _showPollField    = false;
  bool _showHtmlTool     = false;   // NEW: HTML viewer tool
  bool _isPosting        = false;
  String _audience       = 'public';
  DateTime? _scheduledAt;
  List<String> _keywords = [];      // auto-generated + manually edited keywords

  // ── HTML tool state ─────────────────────────────────────────────────────
  final _htmlCtrl       = TextEditingController();
  final _htmlAppNameCtrl = TextEditingController();  // custom app name
  final _htmlAppLogoCtrl = TextEditingController();  // logo URL
  bool  _htmlPreview  = false;   // false = editor, true = preview

  // ── poll ────────────────────────────────────────────────────────────────
  final _pollQuestionCtrl = TextEditingController();
  final List<TextEditingController> _pollOptions = [
    TextEditingController(), TextEditingController()];
  // optional image file per poll option (index-aligned with _pollOptions)
  final List<File?> _pollOptionImages = [null, null];

  // ── mention ─────────────────────────────────────────────────────────────
  List<String> _suggestions = [];
  bool _showSugg = false;
  int  _mentionStart = -1;

  // ── toolbar animation ────────────────────────────────────────────────────
  late final AnimationController _tbAnim;
  late final Animation<double>   _tbSlide;
  bool _toolbarExpanded = false;

  @override
  void initState() {
    super.initState();
    _tbAnim = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 280));
    _tbSlide = CurvedAnimation(parent: _tbAnim, curve: Curves.easeOutCubic);
    // Auto-open keyboard when sheet opens
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) FocusScope.of(context).requestFocus(_focusNode);
    });
  }

  @override
  void dispose() {
    _ctrl.dispose(); _linkCtrl.dispose(); _ytCtrl.dispose();
    _htmlCtrl.dispose(); _htmlAppNameCtrl.dispose(); _htmlAppLogoCtrl.dispose();
    _pollQuestionCtrl.dispose();
    for (final c in _pollOptions) c.dispose();
    _tbAnim.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _toggleToolbar() {
    setState(() => _toolbarExpanded = !_toolbarExpanded);
    _toolbarExpanded ? _tbAnim.forward() : _tbAnim.reverse();
  }

  // ── mention logic ────────────────────────────────────────────────────────
  /// Generate keywords from post text — words 3+ chars, deduplicated, max 20
  List<String> _generateKeywords(String text) {
    final stopWords = {'the','and','for','are','but','not','you','all','can','her',
      'was','one','our','out','day','get','has','him','his','how','its','let',
      'man','new','now','old','see','two','way','who','boy','did','its','let',
      'put','say','she','too','use','hai','kya','yeh','woh','aur','nahi','mera',
      'tera','hum','tum','koi','bhi','kuch','iska','uska','apna','apni','mere'};
    final words = text.toLowerCase()
        .replaceAll(RegExp(r'[^\w\s]'), ' ')
        .split(RegExp(r'\s+'))
        .where((w) => w.length >= 3 && !stopWords.contains(w))
        .toSet()
        .take(20)
        .toList();
    return words;
  }

  void _onTextChanged(String val) {
    // Auto-generate keywords from text
    final autoKw = _generateKeywords(val);
    // Merge: keep any manually added ones not in auto list, add new auto ones
    final merged = {...autoKw, ..._keywords}.take(25).toList();
    setState(() { _keywords = merged; });
    final cursor = _ctrl.selection.baseOffset;
    if (cursor < 0) return;
    final before = val.substring(0, cursor);
    final match = RegExp(r'@(\w*)$').firstMatch(before);
    if (match != null) {
      _mentionStart = match.start;
      _fetchSugg(match.group(1) ?? '');
    } else {
      setState(() { _showSugg = false; _suggestions = []; });
    }
  }

  void _fetchSugg(String q) async {
    if (q.isEmpty) { setState(() => _showSugg = false); return; }
    final snap = await FirebaseFirestore.instance.collection('users')
        .where('username', isGreaterThanOrEqualTo: q)
        .where('username', isLessThanOrEqualTo: '$q\uf8ff')
        .limit(5).get();
    if (mounted) setState(() {
      _suggestions = snap.docs.map((d) => d['username'] as String).toList();
      _showSugg = _suggestions.isNotEmpty;
    });
  }

  void _applyMention(String u) {
    final text = _ctrl.text;
    final cursor = _ctrl.selection.baseOffset;
    final newText = text.substring(0, _mentionStart) + '@$u ' + text.substring(cursor);
    _ctrl.text = newText;
    _ctrl.selection = TextSelection.fromPosition(
        TextPosition(offset: _mentionStart + u.length + 2));
    setState(() { _showSugg = false; });
  }

  // ── image / file pickers ────────────────────────────────────────────────
  Future<void> _pickImages() async {
    if (_images.length >= 10) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Max 10 images allowed'),
        backgroundColor: Colors.orange,
        behavior: SnackBarBehavior.floating));
      return;
    }
    // Show in-app media sheet
    _showMediaPickerSheet();
  }

  // ── In-App Media Picker Sheet ────────────────────────────────────────
  void _showMediaPickerSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _PostMediaPickerSheet(
        remainingImages: 10 - _images.length,
        onImagesSelected: (files) {
          setState(() => _images.addAll(files));
        },

      ),
    );
  }

  // ── Replace selected image by picking a new one ───────────────────────
  Future<void> _openImageEditor(int index) async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
    if (picked != null && mounted) {
      setState(() => _images[index] = File(picked.path));
    }
  }

  Future<void> _pickFile() async {
    if (_attachedFiles.length >= 3) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Max 3 files allowed'), backgroundColor: Colors.orange,
        behavior: SnackBarBehavior.floating));
      return;
    }
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['mp3','wav','aac','m4a','ogg','pdf','doc','docx',
        'xls','xlsx','ppt','pptx','txt','apk','zip','rar','html'],
    );
    if (result != null && result.files.isNotEmpty) {
      final pFile = result.files.first;
      if (pFile.path != null) {
        final file = File(pFile.path!);
        final ext  = pFile.extension?.toLowerCase() ?? '';
        // If user picks HTML file — load it into the HTML tool
        if (ext == 'html') {
          final content = await file.readAsString();
          if (content.length > 40 * 1024) {
            if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text('HTML file is too large (max 40 KB)'),
              backgroundColor: Colors.red, behavior: SnackBarBehavior.floating));
            return;
          }
          setState(() {
            _htmlCtrl.text = content;
            _showHtmlTool  = true;
            _htmlPreview   = false;
          });
          return;
        }
        String type = 'file';
        if (['mp3','wav','aac','m4a','ogg'].contains(ext)) type = 'audio';
        else if (ext == 'pdf') type = 'pdf';
        else if (ext == 'apk') type = 'apk';
        else if (['doc','docx','xls','xlsx','ppt','pptx','txt'].contains(ext)) type = 'document';
        else if (['zip','rar'].contains(ext)) type = 'archive';
        setState(() => _attachedFiles.add({
          'file': file, 'name': pFile.name, 'type': type, 'size': pFile.size,
        }));
      }
    }
  }

  // ── schedule helpers ─────────────────────────────────────────────────────
  static String _fmtScheduleStatic(DateTime dt) {
    final months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    final h = dt.hour % 12 == 0 ? 12 : dt.hour % 12;
    final m = dt.minute.toString().padLeft(2, '0');
    final ampm = dt.hour < 12 ? 'AM' : 'PM';
    return '${months[dt.month-1]} ${dt.day}, $h:$m $ampm';
  }

  String _fmtSchedule(DateTime dt) => _fmtScheduleStatic(dt);

  // ── HTML tool: open picker (paste or pick file) ─────────────────────────
  void _openHtmlTool() {
    setState(() {
      _showHtmlTool = true;
      _htmlPreview  = false;
    });
  }

  // ── canPost guard ────────────────────────────────────────────────────────
  bool get _canPost =>
    _ctrl.text.trim().isNotEmpty || _images.isNotEmpty ||
    _attachedFiles.isNotEmpty   || _linkCtrl.text.trim().isNotEmpty ||
    _ytCtrl.text.trim().isNotEmpty ||
    (_showPollField && _pollQuestionCtrl.text.trim().isNotEmpty) ||
    (_showHtmlTool  && _htmlCtrl.text.trim().isNotEmpty);

  // ── post settings sheet ──────────────────────────────────────────────────
  void _showPostSettingsSheet() {
    String sheetAudience = _audience;
    DateTime? sheetSchedule = _scheduledAt;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) {
          Future<void> pickSchedule() async {
            final now = DateTime.now();
            final date = await showDatePicker(
              context: ctx,
              initialDate: sheetSchedule ?? now.add(const Duration(hours: 1)),
              firstDate: now,
              lastDate: now.add(const Duration(days: 365)),
              builder: (c, child) => Theme(
                data: Theme.of(c).copyWith(colorScheme: const ColorScheme.light(primary: _kBlue)),
                child: child!));
            if (date == null) return;
            if (!mounted) return;
            final time = await showTimePicker(
              context: ctx,
              initialTime: TimeOfDay.fromDateTime(
                  sheetSchedule ?? now.add(const Duration(hours: 1))),
              builder: (c, child) => Theme(
                data: Theme.of(c).copyWith(colorScheme: const ColorScheme.light(primary: _kBlue)),
                child: child!));
            if (time == null) return;
            final scheduled = DateTime(date.year, date.month, date.day, time.hour, time.minute);
            if (scheduled.isBefore(now.add(const Duration(minutes: 5)))) {
              if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                content: Text('Schedule at least 5 minutes in the future'),
                backgroundColor: Colors.orange, behavior: SnackBarBehavior.floating));
              return;
            }
            setS(() => sheetSchedule = scheduled);
          }

          final isScheduled = sheetSchedule != null;
          String fmtS(DateTime dt) {
            final months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            final h = dt.hour % 12 == 0 ? 12 : dt.hour % 12;
            final m = dt.minute.toString().padLeft(2, '0');
            final ampm = dt.hour < 12 ? 'AM' : 'PM';
            return '${months[dt.month-1]} ${dt.day}, $h:$m $ampm';
          }

          return DraggableScrollableSheet(
            initialChildSize: 0.75,
            minChildSize: 0.5,
            maxChildSize: 0.95,
            expand: false,
            builder: (_, scrollCtrl) => Container(
            padding: EdgeInsets.only(
              left: 20, right: 20, top: 12,
              bottom: MediaQuery.of(ctx).viewInsets.bottom + 32),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
            child: SingleChildScrollView(controller: scrollCtrl, child: Column(mainAxisSize: MainAxisSize.min, children: [
              Center(child: Container(width: 36, height: 4,
                decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10)))),
              const SizedBox(height: 20),
              const Align(alignment: Alignment.centerLeft,
                child: Text('Post Settings', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Color(0xFF0D1B2A)))),
              const SizedBox(height: 4),
              Align(alignment: Alignment.centerLeft,
                child: Text('Who sees this & when to publish', style: TextStyle(fontSize: 12, color: Colors.grey[700]))),
              const SizedBox(height: 20),
              const Align(alignment: Alignment.centerLeft,
                child: Text('AUDIENCE', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: Colors.grey, letterSpacing: 1.2))),
              const SizedBox(height: 10),
              // Public
              _SettingsOption(
                emoji: '🌐', label: 'Public', sub: 'Everyone on Zylo can see this',
                color: _kBlue, selected: sheetAudience == 'public',
                onTap: () => setS(() => sheetAudience = 'public')),
              const SizedBox(height: 10),
              // Followers
              _SettingsOption(
                emoji: '🫂', label: 'Followers Only', sub: 'Only your followers can see this',
                color: const Color(0xFF7C3AED), selected: sheetAudience == 'inner',
                onTap: () => setS(() => sheetAudience = 'inner')),
              const SizedBox(height: 20),
              // ── KEYWORDS SECTION ──────────────────────────────────────────
              const Align(alignment: Alignment.centerLeft,
                child: Text('SEARCH KEYWORDS', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: Colors.grey, letterSpacing: 1.2))),
              const SizedBox(height: 6),
              Align(alignment: Alignment.centerLeft,
                child: Text('Auto-generated from your text. Edit or add more:', style: TextStyle(fontSize: 11, color: Colors.grey[600]))),
              const SizedBox(height: 10),
              _KeywordsEditor(
                keywords: _keywords,
                onChanged: (kw) {
                  setState(() => _keywords = kw);
                  setS(() {});
                },
              ),
              const SizedBox(height: 20),
              const Align(alignment: Alignment.centerLeft,
                child: Text('PUBLISH TIME', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: Colors.grey, letterSpacing: 1.2))),
              const SizedBox(height: 10),
              _SettingsOption(
                emoji: '⚡', label: 'Post Now', sub: 'Publish immediately',
                color: _kBlue, selected: !isScheduled,
                onTap: () => setS(() => sheetSchedule = null)),
              const SizedBox(height: 10),
              _SettingsOption(
                emoji: '🗓️', label: 'Schedule',
                sub: isScheduled ? fmtS(sheetSchedule!) : 'Pick a date & time',
                color: Colors.deepPurple, selected: isScheduled,
                onTap: () async => await pickSchedule(),
                trailing: isScheduled ? GestureDetector(
                  onTap: () => setS(() => sheetSchedule = null),
                  child: Icon(Icons.close_rounded, size: 16, color: Colors.grey[600])) : null),
              const SizedBox(height: 24),
              SizedBox(width: double.infinity,
                child: GestureDetector(
                  onTap: () {
                    setState(() { _audience = sheetAudience; _scheduledAt = sheetSchedule; });
                    Navigator.pop(ctx);
                    _post();
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: isScheduled
                        ? [Colors.deepPurple, const Color(0xFF7C3AED)]
                        : sheetAudience == 'inner'
                          ? [const Color(0xFF7C3AED), _kBlue]
                          : [_kBlue, const Color(0xFF7C3AED)]),
                      borderRadius: BorderRadius.circular(18),
                      boxShadow: [BoxShadow(
                        color: (isScheduled ? Colors.deepPurple : _kBlue).withValues(alpha: 0.3),
                        blurRadius: 12, offset: const Offset(0, 4))]),
                    child: Center(child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(isScheduled ? Icons.schedule_rounded : Icons.send_rounded,
                        color: Colors.white, size: 18),
                      const SizedBox(width: 8),
                      Text(isScheduled ? 'Schedule Post' : sheetAudience == 'inner' ? 'Post to Followers' : 'Post Now',
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16)),
                    ]))))),
            ])))); // Column > SingleChildScrollView > Container > DraggableScrollableSheet
        }));
  }

  // ── post logic ───────────────────────────────────────────────────────────
  Future<void> _post() async {
    final text    = _ctrl.text.trim();
    final link    = _linkCtrl.text.trim();
    final ytLink  = _ytCtrl.text.trim();
    final htmlSrc = _showHtmlTool ? _htmlCtrl.text.trim() : '';
    final pollQ   = _pollQuestionCtrl.text.trim();
    final pollOpts = _showPollField
        ? _pollOptions.map((c) => c.text.trim()).where((s) => s.isNotEmpty).toList()
        : <String>[];
    // capture poll option image files (index-aligned with pollOpts, only for non-empty options)
    final pollOptImgFiles = _showPollField
        ? List.generate(_pollOptions.length, (i) {
            final opt = _pollOptions[i].text.trim();
            return opt.isNotEmpty ? (i < _pollOptionImages.length ? _pollOptionImages[i] : null) : null;
          }).where((f) => f != null).toList()
        : <File?>[];
    if (text.isEmpty && _images.isEmpty && _attachedFiles.isEmpty &&
        link.isEmpty && ytLink.isEmpty && pollQ.isEmpty && htmlSrc.isEmpty) return;

    final images     = List<File>.from(_images);
    final files      = List<Map<String, dynamic>>.from(_attachedFiles);
    final postText   = text;
    final postLink   = link;
    final postYtLink = ytLink;
    final scheduledAt = _scheduledAt;
    final audience   = _audience;
    final keywords   = List<String>.from(_keywords);
    final myUid      = widget.myUid;
    final authorName = widget.auth.userName ?? 'user';
    final authorPhoto= widget.auth.photoURL  ?? '';

    final controller = StreamController<_UploadEvent>();
    widget.onPostStart?.call(controller.stream);
    if (mounted) Navigator.pop(context);

    try {
      final totalItems = images.length + files.length;
      final imageUrls  = <String>[];

      for (int i = 0; i < images.length; i++) {
        controller.add(_UploadEvent('Uploading image ${i+1}/${images.length}...', (i / (totalItems + 1))));
        final url = await FileService.uploadFile(images[i], myUid,
          onProgress: (p) => controller.add(
            _UploadEvent('Image ${i+1} — ${(p * 100).round()}%', ((i + p) / (totalItems + 1)))));
        if (url.isNotEmpty) imageUrls.add(url);
      }

      final filesMeta = <Map<String, dynamic>>[];
      for (int i = 0; i < files.length; i++) {
        final f = files[i];
        controller.add(_UploadEvent('Uploading ${f['name']}...', ((images.length + i) / (totalItems + 1))));
        final url = await FileService.uploadFile(f['file'] as File, myUid,
          onProgress: (p) => controller.add(
            _UploadEvent('${f['name']} — ${(p * 100).round()}%', ((images.length + i + p) / (totalItems + 1)))));
        if (url.isNotEmpty) {
          filesMeta.add({'url': url, 'name': f['name'], 'type': f['type'], 'size': f['size']});
        }
      }

      controller.add(const _UploadEvent('Posting...', 0.95));
      final postData = <String, dynamic>{
        'authorId':    myUid,
        'authorName':  authorName,
        'authorPhoto': authorPhoto,
        'text':        postText,
        'images':      imageUrls,
        'files':       filesMeta,
        'likes':       [],
        'commentCount': 0,
        'visibility':  audience,
        'createdAt':   FieldValue.serverTimestamp(),
        if (keywords.isNotEmpty) 'searchKeywords': keywords,
      };
      if (scheduledAt != null) {
        postData['scheduledAt'] = Timestamp.fromDate(scheduledAt);
        postData['isScheduled'] = true;
      }
      if (postYtLink.isNotEmpty) {
        postData['linkUrl'] = postYtLink;
      } else if (postLink.isNotEmpty) {
        postData['linkUrl'] = postLink;
      }
      if (pollQ.isNotEmpty && pollOpts.length >= 2) {
        // Upload poll option images
        final optImageUrls = <String, String>{};
        for (int i = 0; i < pollOpts.length; i++) {
          final imgFile = i < pollOptImgFiles.length ? pollOptImgFiles[i] : null;
          if (imgFile != null) {
            controller.add(_UploadEvent('Uploading poll image ${i+1}...', 0.92));
            final url = await FileService.uploadFile(imgFile, myUid);
            if (url.isNotEmpty) optImageUrls[pollOpts[i]] = url;
          }
        }
        postData['poll'] = {
          'question': pollQ,
          'options': pollOpts,
          'votes': {for (final o in pollOpts) o: <String>[]},
          'voterDetails': <String, dynamic>{},
          if (optImageUrls.isNotEmpty) 'optionImages': optImageUrls,
        };
      }
      // HTML snippet embedded in post
      if (htmlSrc.isNotEmpty) {
        postData['htmlSnippet'] = htmlSrc;
        final appName = _htmlAppNameCtrl.text.trim();
        final appLogo = _htmlAppLogoCtrl.text.trim();
        if (appName.isNotEmpty) postData['htmlAppName'] = appName;
        if (appLogo.isNotEmpty) postData['htmlAppLogo'] = appLogo;
      }

      final docRef = await FirebaseFirestore.instance.collection('posts').add(postData);
      if (scheduledAt == null) {
        NotificationService().sendFeedNotification(
          authorName: authorName,
          authorPhotoUrl: authorPhoto.isNotEmpty ? authorPhoto : null,
          postText: postText,
          postId: docRef.id,
          visibility: audience,
        ).catchError((_) {});

        // ── @mention notifications in post text ──────────────────────────────
        final mentionRegex = RegExp(r'@(\w+)');
        final mentions = mentionRegex.allMatches(postText).map((m) => m.group(1)!).toSet();
        for (final username in mentions) {
          try {
            final mentionSnap = await FirebaseFirestore.instance
                .collection('users').where('username', isEqualTo: username).limit(1).get();
            if (mentionSnap.docs.isNotEmpty) {
              final mentionedUid = mentionSnap.docs.first.id;
              if (mentionedUid != myUid) {
                NotificationService().sendPostMentionNotification(
                  toUid: mentionedUid,
                  postId: docRef.id,
                  fromName: authorName,
                  fromPhotoUrl: authorPhoto.isNotEmpty ? authorPhoto : null,
                ).catchError((_) {});
              }
            }
          } catch (_) {}
        }
      }
      controller.add(_UploadEvent(
        scheduledAt != null ? 'Scheduled ✓ ${_fmtScheduleStatic(scheduledAt)}' : 'Posted! ✓', 1.0));
      await Future.delayed(const Duration(seconds: 2));
      controller.close();
    } catch (e) {
      controller.addError(e);
      controller.close();
    }
  }

  // ── TOOLBAR ITEMS config ─────────────────────────────────────────────────
  List<_ToolItem> get _toolItems => [
    _ToolItem(
      icon: Icons.image_outlined, label: 'Photo\n${_images.length}/10',
      color: _kBlue, active: _images.isNotEmpty,
      onTap: _pickImages),
    _ToolItem(
      icon: Icons.attach_file_rounded, label: 'File',
      color: Colors.purple, active: _attachedFiles.isNotEmpty,
      onTap: _pickFile),
    _ToolItem(
      icon: Icons.alternate_email, label: 'Mention',
      color: Colors.orange, active: false,
      onTap: () {
        _ctrl.text += '@';
        _ctrl.selection = TextSelection.fromPosition(
            TextPosition(offset: _ctrl.text.length));
        setState(() {});
      }),
    _ToolItem(
      icon: Icons.link_rounded, label: 'Link',
      color: Colors.teal, active: _showLinkField,
      onTap: () => setState(() {
        _showLinkField = !_showLinkField;
        if (_showLinkField) _showYoutubeField = false;
      })),
    _ToolItem(
      icon: Icons.play_circle_fill_rounded, label: 'YouTube',
      color: Colors.red, active: _showYoutubeField,
      onTap: () => setState(() {
        _showYoutubeField = !_showYoutubeField;
        if (_showYoutubeField) _showLinkField = false;
      })),
    _ToolItem(
      icon: Icons.poll_rounded, label: 'Poll',
      color: Colors.green, active: _showPollField,
      onTap: () => setState(() => _showPollField = !_showPollField)),
    _ToolItem(
      icon: Icons.code_rounded, label: 'HTML',
      color: const Color(0xFFE8542A), active: _showHtmlTool,
      onTap: () => setState(() {
        _showHtmlTool = !_showHtmlTool;
        _htmlPreview  = false;
      })),
  ];

  @override
  Widget build(BuildContext context) {
    final photo   = widget.auth.photoURL ?? '';
    final name    = widget.auth.userName ?? 'user';

    return Stack(children: [
      Container(
        height: MediaQuery.of(context).size.height * 0.92,
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
        child: Column(children: [
          // ── drag handle ─────────────────────────────────────────────────
          Container(margin: const EdgeInsets.only(top: 10), width: 40, height: 4,
            decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),

          // ── header ──────────────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: Row(children: [
              ZyloAvatar(photoUrl: photo, radius: 18),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('@$name', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                Text(
                  _audience == 'inner' ? '🫂 Followers only' : '🌐 Public',
                  style: TextStyle(fontSize: 11, color: Colors.grey[600])),
              ])),
              // Next button
              GestureDetector(
                onTap: (_canPost && !_isPosting) ? _showPostSettingsSheet : null,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                  decoration: BoxDecoration(
                    gradient: _canPost && !_isPosting
                      ? const LinearGradient(colors: [_kBlue, Color(0xFF7C3AED)])
                      : null,
                    color: (!_canPost || _isPosting) ? Colors.grey[200] : null,
                    borderRadius: BorderRadius.circular(20)),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Text('Next', style: TextStyle(
                      fontWeight: FontWeight.w800, fontSize: 14,
                      color: _canPost && !_isPosting ? Colors.white : Colors.grey[600])),
                    if (_canPost && !_isPosting) ...[
                      const SizedBox(width: 4),
                      const Icon(Icons.arrow_forward_rounded, size: 14, color: Colors.white),
                    ],
                  ]))),
            ])),

          // ── scrollable body ──────────────────────────────────────────────
          Expanded(child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

              // main text field
              TextField(
                controller: _ctrl, onChanged: _onTextChanged,
                focusNode: _focusNode,
                autofocus: true,
                maxLines: null, maxLength: 500,
                style: const TextStyle(fontSize: 16, color: Color(0xFF0D1B2A), height: 1.5),
                decoration: InputDecoration(
                  hintText: "What's on your mind? Use @username to mention",
                  hintStyle: TextStyle(color: Colors.grey[500], fontSize: 15),
                  border: InputBorder.none,
                  counterStyle: TextStyle(color: Colors.grey[500], fontSize: 11))),

              // mention suggestions
              if (_showSugg && _suggestions.isNotEmpty)
                Container(
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12),
                    boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.1), blurRadius: 10)]),
                  child: Column(children: _suggestions.map((u) => ListTile(
                    dense: true,
                    leading: const Icon(Icons.alternate_email, color: _kBlue, size: 18),
                    title: Text('@$u', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: _kBlue)),
                    onTap: () => _applyMention(u))).toList())),

              // image previews
              if (_images.isNotEmpty) ...[
                const SizedBox(height: 12),
                SizedBox(height: 104, child: ListView.separated(
                  scrollDirection: Axis.horizontal, itemCount: _images.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (_, i) => GestureDetector(
                    onTap: () => _openImageEditor(i),
                    child: Stack(children: [
                      ClipRRect(borderRadius: BorderRadius.circular(12),
                        child: Image.file(_images[i], width: 100, height: 100, fit: BoxFit.cover)),
                      // Edit badge bottom-left
                      Positioned(bottom: 5, left: 5,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.65),
                            borderRadius: BorderRadius.circular(8)),
                          child: const Row(mainAxisSize: MainAxisSize.min, children: [
                            Icon(Icons.edit_rounded, color: Colors.white, size: 10),
                            SizedBox(width: 3),
                            Text('Edit', style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w700)),
                          ]))),
                      // Remove button top-right
                      Positioned(top: 4, right: 4,
                        child: GestureDetector(
                          onTap: () => setState(() => _images.removeAt(i)),
                          child: Container(width: 22, height: 22,
                            decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                            child: const Icon(Icons.close, size: 14, color: Colors.white)))),
                    ])))),
              ],

              // file previews
              if (_attachedFiles.isNotEmpty) ...[
                const SizedBox(height: 12),
                ..._attachedFiles.asMap().entries.map((e) {
                  final i = e.key; final f = e.value;
                  final type = f['type'] as String;
                  final color = _fileColor(type);
                  return Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: color.withValues(alpha: 0.07),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: color.withValues(alpha: 0.25))),
                    child: Row(children: [
                      Icon(_fileIcon(type), color: color, size: 24),
                      const SizedBox(width: 10),
                      Expanded(child: Text(f['name'] as String,
                        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                        maxLines: 1, overflow: TextOverflow.ellipsis)),
                      GestureDetector(
                        onTap: () => setState(() => _attachedFiles.removeAt(i)),
                        child: const Icon(Icons.close, size: 18, color: Colors.red)),
                    ]));
                }),
              ],

              // link field
              if (_showLinkField) ...[
                const SizedBox(height: 12),
                _InputRow(
                  ctrl: _linkCtrl, icon: Icons.link_rounded,
                  color: _kBlue, hint: 'https://example.com',
                  onChanged: (_) => setState(() {}),
                  onClear: () => setState(() => _linkCtrl.clear())),
              ],

              // youtube field
              if (_showYoutubeField) ...[
                const SizedBox(height: 12),
                _InputRow(
                  ctrl: _ytCtrl, icon: Icons.play_circle_fill_rounded,
                  color: Colors.red, hint: 'Paste YouTube link (youtu.be/...)',
                  onChanged: (_) => setState(() {}),
                  onClear: () => setState(() => _ytCtrl.clear())),
                if (_ytCtrl.text.trim().isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 6, left: 4),
                    child: Builder(builder: (_) {
                      final id = _extractYoutubeId(_ytCtrl.text.trim());
                      if (id == null) return const Text('⚠ Invalid YouTube URL',
                        style: TextStyle(fontSize: 11, color: Colors.orange));
                      return Row(children: [
                        const Icon(Icons.check_circle, color: Colors.green, size: 14),
                        const SizedBox(width: 4),
                        Text('Video ID: $id', style: const TextStyle(
                          fontSize: 11, color: Colors.green, fontWeight: FontWeight.w600)),
                      ]);
                    })),
              ],

              // ── HTML TOOL ─────────────────────────────────────────────────
              if (_showHtmlTool) ...[
                const SizedBox(height: 14),
                _HtmlToolWidget(
                  ctrl: _htmlCtrl,
                  appNameCtrl: _htmlAppNameCtrl,
                  appLogoCtrl: _htmlAppLogoCtrl,
                  preview: _htmlPreview,
                  onTogglePreview: () => setState(() => _htmlPreview = !_htmlPreview),
                  onClose: () => setState(() {
                    _showHtmlTool = false;
                    _htmlCtrl.clear();
                    _htmlAppNameCtrl.clear();
                    _htmlAppLogoCtrl.clear();
                    _htmlPreview = false;
                  }),
                  onChanged: () => setState(() {})),
              ],

              // poll builder
              if (_showPollField) ...[
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF0FDF4),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.green.withValues(alpha: 0.3))),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      const Icon(Icons.poll_rounded, color: Colors.green, size: 18),
                      const SizedBox(width: 6),
                      const Text('Poll', style: TextStyle(fontWeight: FontWeight.w900, color: Colors.green, fontSize: 14)),
                      const Spacer(),
                      GestureDetector(
                        onTap: () => setState(() {
                          _showPollField = false;
                          _pollQuestionCtrl.clear();
                          for(final c in _pollOptions) c.clear();
                          _pollOptionImages.clear();
                        }),
                        child: const Icon(Icons.close, size: 16, color: Colors.grey)),
                    ]),
                    const SizedBox(height: 10),
                    TextField(controller: _pollQuestionCtrl, onChanged: (_) => setState(() {}),
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
                      decoration: InputDecoration(
                        hintText: 'Ask a question...',
                        hintStyle: TextStyle(color: Colors.grey[600], fontWeight: FontWeight.w400),
                        filled: true, fillColor: Colors.white,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
                        isDense: true, contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10))),
                    const SizedBox(height: 10),
                    ...List.generate(_pollOptions.length, (i) {
                      while (_pollOptionImages.length <= i) _pollOptionImages.add(null);
                      final hasImg = _pollOptionImages[i] != null;
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
                          // Optional image box
                          GestureDetector(
                            onTap: () async {
                              final picker = ImagePicker();
                              final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
                              if (picked != null) setState(() {
                                while (_pollOptionImages.length <= i) _pollOptionImages.add(null);
                                _pollOptionImages[i] = File(picked.path);
                              });
                            },
                            child: Stack(children: [
                              Container(
                                width: 50, height: 50,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(color: hasImg ? Colors.green : Colors.green.withValues(alpha: 0.35))),
                                child: hasImg
                                  ? ClipRRect(
                                      borderRadius: BorderRadius.circular(9),
                                      child: Image.file(_pollOptionImages[i]!, fit: BoxFit.cover, width: 50, height: 50))
                                  : Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                                      Icon(Icons.add_photo_alternate_outlined, size: 18, color: Colors.green.withValues(alpha: 0.6)),
                                      Text('img', style: TextStyle(fontSize: 8, color: Colors.green.withValues(alpha: 0.6))),
                                    ])),
                              if (hasImg)
                                Positioned(top: 2, right: 2,
                                  child: GestureDetector(
                                    onTap: () => setState(() => _pollOptionImages[i] = null),
                                    child: Container(
                                      width: 16, height: 16,
                                      decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                                      child: const Icon(Icons.close, size: 10, color: Colors.white)))),
                            ])),
                          const SizedBox(width: 8),
                          Expanded(child: TextField(
                            controller: _pollOptions[i], onChanged: (_) => setState(() {}),
                            style: const TextStyle(fontSize: 13),
                            decoration: InputDecoration(
                              hintText: 'Option ${i + 1}',
                              hintStyle: TextStyle(color: Colors.grey[600]),
                              filled: true, fillColor: Colors.white,
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
                              isDense: true, contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10)))),
                          if (i >= 2) const SizedBox(width: 6),
                          if (i >= 2) GestureDetector(
                            onTap: () => setState(() {
                              _pollOptions.removeAt(i);
                              if (_pollOptionImages.length > i) _pollOptionImages.removeAt(i);
                            }),
                            child: const Icon(Icons.remove_circle_outline, color: Colors.red, size: 20)),
                        ]));
                    }),
                    if (_pollOptions.length < 4)
                      GestureDetector(
                        onTap: () => setState(() {
                          _pollOptions.add(TextEditingController());
                          _pollOptionImages.add(null);
                        }),
                        child: Container(padding: const EdgeInsets.symmetric(vertical: 8),
                          child: Row(children: [
                            const Icon(Icons.add_circle_outline, color: Colors.green, size: 16),
                            const SizedBox(width: 6),
                            Text('Add option', style: TextStyle(color: Colors.green[700], fontSize: 13, fontWeight: FontWeight.w700)),
                          ]))),
                  ])),
              ],
            ]))),

          // ═══════════════════════════════════════════════════════════════
          //  BOTTOM TOOLBAR — collapsed one-line + swipe-up expands all
          // ═══════════════════════════════════════════════════════════════
          _BuildToolbar(
            items: _toolItems,
            expanded: _toolbarExpanded,
            slideAnim: _tbSlide,
            onToggle: _toggleToolbar,
            charCount: _ctrl.text.length,
          ),
        ])),
    ]);
  }
}

// ── Toolbar data model ────────────────────────────────────────────────────────
class _ToolItem {
  final IconData icon;
  final String label;
  final Color color;
  final bool active;
  final VoidCallback onTap;
  const _ToolItem({required this.icon, required this.label, required this.color,
    required this.active, required this.onTap});
}

// ── Animated swipe-up toolbar ─────────────────────────────────────────────────
class _BuildToolbar extends StatelessWidget {
  final List<_ToolItem> items;
  final bool expanded;
  final Animation<double> slideAnim;
  final VoidCallback onToggle;
  final int charCount;

  const _BuildToolbar({
    required this.items, required this.expanded,
    required this.slideAnim, required this.onToggle, required this.charCount});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Colors.grey.withValues(alpha: 0.12))),
        boxShadow: [BoxShadow(
          color: Colors.black.withValues(alpha: 0.04), blurRadius: 8, offset: const Offset(0, -3))]),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        // ── swipe handle + toggle ──────────────────────────────────────────
        GestureDetector(
          onTap: onToggle,
          onVerticalDragEnd: (d) {
            // swipe up → expand, swipe down → collapse
            if (d.primaryVelocity != null) {
              if (d.primaryVelocity! < -100 && !expanded) onToggle();
              if (d.primaryVelocity! > 100 && expanded) onToggle();
            }
          },
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 6),
            color: Colors.transparent,
            child: Center(child: AnimatedRotation(
              turns: expanded ? 0.5 : 0.0,
              duration: const Duration(milliseconds: 280),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(20)),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.keyboard_arrow_up_rounded,
                    size: 18, color: Colors.grey[600]),
                  const SizedBox(width: 4),
                  Text(expanded ? 'Less' : 'More tools',
                    style: TextStyle(fontSize: 11, color: Colors.grey[600], fontWeight: FontWeight.w600)),
                ])))))),

        // ── EXPANDED grid — all tools visible ─────────────────────────────
        SizeTransition(
          sizeFactor: slideAnim,
          axisAlignment: -1,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: GridView.count(
              crossAxisCount: 4,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 1.1,
              children: items.map((t) => _ToolCell(item: t)).toList()))),

        // ── COLLAPSED quick-row — first 4 tools ───────────────────────────
        if (!expanded)
          Padding(
            padding: EdgeInsets.only(
              left: 16, right: 16, bottom: MediaQuery.of(context).viewInsets.bottom + 10),
            child: Row(children: [
              ...items.take(4).map((t) => Padding(
                padding: const EdgeInsets.only(right: 8),
                child: _ToolChip(item: t))),
              const Spacer(),
              Text('${charCount}/500',
                style: TextStyle(
                  fontSize: 11,
                  color: charCount > 450 ? Colors.orange : Colors.grey[500])),
            ])),

        if (expanded)
          Padding(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom + 6,
              left: 16, right: 16),
            child: Row(children: [
              const Spacer(),
              Text('${charCount}/500',
                style: TextStyle(
                  fontSize: 11,
                  color: charCount > 450 ? Colors.orange : Colors.grey[500])),
            ])),
      ]));
  }
}

// ── Tool grid cell (expanded view) ────────────────────────────────────────────
class _ToolCell extends StatelessWidget {
  final _ToolItem item;
  const _ToolCell({required this.item});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: item.onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        decoration: BoxDecoration(
          color: item.active
            ? item.color.withValues(alpha: 0.13)
            : Colors.grey[50],
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: item.active ? item.color.withValues(alpha: 0.45) : Colors.grey[200]!,
            width: item.active ? 1.5 : 1)),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(item.icon, color: item.active ? item.color : Colors.grey[600], size: 24),
          const SizedBox(height: 5),
          Text(item.label,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 10, fontWeight: FontWeight.w700,
              color: item.active ? item.color : Colors.grey[600])),
        ])));
  }
}

// ── Tool chip (collapsed quick row) ──────────────────────────────────────────
class _ToolChip extends StatelessWidget {
  final _ToolItem item;
  const _ToolChip({required this.item});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: item.onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: item.active ? item.color.withValues(alpha: 0.12) : item.color.withValues(alpha: 0.07),
          borderRadius: BorderRadius.circular(10),
          border: item.active ? Border.all(color: item.color.withValues(alpha: 0.4)) : null),
        child: Icon(item.icon, color: item.active ? item.color : item.color.withValues(alpha: 0.7), size: 20)));
  }
}

// ── Post Settings Option row ──────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════
//  Keywords Editor — chips + inline add field
// ══════════════════════════════════════════════════════════════
class _KeywordsEditor extends StatefulWidget {
  final List<String> keywords;
  final void Function(List<String>) onChanged;
  const _KeywordsEditor({required this.keywords, required this.onChanged});
  @override
  State<_KeywordsEditor> createState() => _KeywordsEditorState();
}

class _KeywordsEditorState extends State<_KeywordsEditor> {
  final _addCtrl = TextEditingController();
  static const _green = Color(0xFF059669);

  @override
  void dispose() { _addCtrl.dispose(); super.dispose(); }

  void _remove(String kw) {
    final updated = List<String>.from(widget.keywords)..remove(kw);
    widget.onChanged(updated);
  }

  void _add() {
    final val = _addCtrl.text.trim().toLowerCase()
        .replaceAll(RegExp(r'[^\w]'), '');
    if (val.isEmpty || val.length < 2) return;
    if (widget.keywords.contains(val)) { _addCtrl.clear(); return; }
    if (widget.keywords.length >= 25) return;
    final updated = [...widget.keywords, val];
    widget.onChanged(updated);
    _addCtrl.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFF),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.withValues(alpha: 0.2))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // chips
        if (widget.keywords.isNotEmpty)
          Wrap(spacing: 6, runSpacing: 6,
            children: widget.keywords.map((kw) => GestureDetector(
              onTap: () => _remove(kw),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: _green.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _green.withValues(alpha: 0.3))),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Text('#$kw', style: const TextStyle(
                    fontSize: 12, fontWeight: FontWeight.w700, color: _green)),
                  const SizedBox(width: 4),
                  Icon(Icons.close_rounded, size: 12, color: _green.withValues(alpha: 0.7)),
                ])))).toList()),
        if (widget.keywords.isNotEmpty) const SizedBox(height: 10),
        // add field
        Row(children: [
          Expanded(child: TextField(
            controller: _addCtrl,
            style: const TextStyle(fontSize: 13),
            textInputAction: TextInputAction.done,
            onSubmitted: (_) => _add(),
            decoration: InputDecoration(
              hintText: widget.keywords.length >= 25
                  ? 'Max 25 keywords'
                  : 'Add keyword...',
              hintStyle: TextStyle(color: Colors.grey[400], fontSize: 12),
              isDense: true, contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(color: Colors.grey.withValues(alpha: 0.3))),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(color: Colors.grey.withValues(alpha: 0.3))),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(color: _green, width: 1.5)),
              filled: true, fillColor: Colors.white))),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: _add,
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: _green, borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.add_rounded, color: Colors.white, size: 18))),
        ]),
        if (widget.keywords.isNotEmpty) ...[
          const SizedBox(height: 6),
          Text('Tap a keyword to remove it • ${widget.keywords.length}/25',
            style: TextStyle(fontSize: 10, color: Colors.grey[500])),
        ],
      ]),
    );
  }
}

class _SettingsOption extends StatelessWidget {
  final String emoji, label, sub;
  final Color color;
  final bool selected;
  final VoidCallback onTap;
  final Widget? trailing;
  const _SettingsOption({required this.emoji, required this.label, required this.sub,
    required this.color, required this.selected, required this.onTap, this.trailing});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: selected ? color.withValues(alpha: 0.07) : Colors.grey[50],
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? color.withValues(alpha: 0.5) : Colors.grey[200]!,
            width: selected ? 1.5 : 1)),
        child: Row(children: [
          Container(width: 42, height: 42,
            decoration: BoxDecoration(color: color.withValues(alpha: 0.1), shape: BoxShape.circle),
            child: Center(child: Text(emoji, style: const TextStyle(fontSize: 20)))),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: selected ? color : const Color(0xFF0D1B2A))),
            Text(sub, style: TextStyle(fontSize: 12, color: Colors.grey[700])),
          ])),
          if (trailing != null) trailing!,
          const SizedBox(width: 4),
          AnimatedSwitcher(duration: const Duration(milliseconds: 180),
            child: selected
              ? Icon(Icons.check_circle_rounded, color: color, size: 22, key: ValueKey('sel_$label'))
              : Icon(Icons.circle_outlined, color: Colors.grey[300], size: 22, key: ValueKey('unsel_$label'))),
        ])));
  }
}

// ── Reusable input row (link / youtube) ───────────────────────────────────────
class _InputRow extends StatelessWidget {
  final TextEditingController ctrl;
  final IconData icon;
  final Color color;
  final String hint;
  final ValueChanged<String> onChanged;
  final VoidCallback onClear;
  const _InputRow({required this.ctrl, required this.icon, required this.color,
    required this.hint, required this.onChanged, required this.onClear});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.2))),
      child: Row(children: [
        Icon(icon, color: color, size: 18),
        const SizedBox(width: 8),
        Expanded(child: TextField(
          controller: ctrl, onChanged: onChanged,
          keyboardType: TextInputType.url,
          style: const TextStyle(fontSize: 13, color: Color(0xFF0D1B2A)),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(color: Colors.grey[500], fontSize: 13),
            border: InputBorder.none, isDense: true,
            contentPadding: const EdgeInsets.symmetric(vertical: 10)))),
        if (ctrl.text.isNotEmpty)
          GestureDetector(onTap: onClear,
            child: const Icon(Icons.close, size: 16, color: Colors.grey)),
      ]));
  }
}

// ════════════════════════════════════════════════════════════════════════════
//  HTML TOOL WIDGET — editor + live preview, max 40 KB, run/back button
// ════════════════════════════════════════════════════════════════════════════
class _HtmlToolWidget extends StatefulWidget {
  final TextEditingController ctrl;
  final TextEditingController appNameCtrl;
  final TextEditingController appLogoCtrl;
  final bool preview;
  final VoidCallback onTogglePreview;
  final VoidCallback onClose;
  final VoidCallback onChanged;
  const _HtmlToolWidget({
    required this.ctrl,
    required this.appNameCtrl,
    required this.appLogoCtrl,
    required this.preview,
    required this.onTogglePreview,
    required this.onClose,
    required this.onChanged,
  });
  @override
  State<_HtmlToolWidget> createState() => _HtmlToolWidgetState();
}

class _HtmlToolWidgetState extends State<_HtmlToolWidget> {
  final _scrollCtrl = ScrollController();
  int _sizeBytes = 0;

  @override
  void initState() {
    super.initState();
    _sizeBytes = widget.ctrl.text.length;
    widget.ctrl.addListener(_onCtrl);
  }

  void _onCtrl() {
    final len = widget.ctrl.text.length;
    if (len != _sizeBytes) {
      setState(() => _sizeBytes = len);
      widget.onChanged();
    }
  }

  @override
  void dispose() {
    widget.ctrl.removeListener(_onCtrl);
    _scrollCtrl.dispose();
    super.dispose();
  }

  bool get _overLimit => _sizeBytes > 40 * 1024;
  String get _sizeLabel {
    if (_sizeBytes < 1024) return '${_sizeBytes}B';
    return '${(_sizeBytes / 1024).toStringAsFixed(1)}KB';
  }

  // Insert common HTML snippets
  void _insert(String snippet) {
    final ctrl = widget.ctrl;
    final sel  = ctrl.selection;
    final text = ctrl.text;
    final start = sel.baseOffset < 0 ? text.length : sel.baseOffset;
    final end   = sel.extentOffset < 0 ? text.length : sel.extentOffset;
    final newText = text.replaceRange(start, end, snippet);
    ctrl.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: start + snippet.length));
    widget.onChanged();
  }

  // Load a full template into editor
  void _loadTemplate(String html) {
    widget.ctrl.value = TextEditingValue(
      text: html,
      selection: TextSelection.collapsed(offset: html.length));
    widget.onChanged();
    Navigator.pop(context); // close template sheet
  }

  // Quick snippet bar items
  static const _snippets = [
    ('<b>text</b>',        'Bold'),
    ('<i>text</i>',        'Italic'),
    ('<h1>Heading</h1>',   'H1'),
    ('<p>Para</p>',        'Para'),
    ('<ul><li>Item</li></ul>', 'List'),
    ('<a href="#">Link</a>', 'Link'),
    ('<hr>',               'HR'),
    ('<br>',               'BR'),
  ];

  // ── Template definitions ────────────────────────────────────────────────
  static const _templates = [
    (
      name: '🧮 Calculator',
      desc: 'Fully working calculator',
      html: '''<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  body{margin:0;background:#1a1a2e;display:flex;justify-content:center;align-items:center;min-height:100vh;font-family:-apple-system,sans-serif}
  .calc{background:#16213e;border-radius:24px;padding:20px;width:300px;box-shadow:0 20px 60px rgba(0,0,0,0.5)}
  .display{background:#0f3460;border-radius:16px;padding:16px 20px;margin-bottom:16px;text-align:right}
  .expr{color:#888;font-size:14px;min-height:20px}
  .num{color:#fff;font-size:32px;font-weight:700;word-break:break-all}
  .grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}
  button{border:none;border-radius:14px;padding:18px 0;font-size:18px;font-weight:700;cursor:pointer;transition:transform 0.1s,opacity 0.1s}
  button:active{transform:scale(0.93)}
  .op{background:#e94560;color:#fff}
  .eq{background:#0f3460;color:#e94560;grid-column:span 2}
  .num-btn{background:#1a1a3e;color:#fff}
  .clear{background:#533483;color:#fff}
</style>
</head>
<body>
<div class="calc">
  <div class="display">
    <div class="expr" id="expr"></div>
    <div class="num" id="num">0</div>
  </div>
  <div class="grid">
    <button class="clear" onclick="clearAll()">AC</button>
    <button class="clear" onclick="toggleSign()">+/-</button>
    <button class="clear" onclick="percent()">%</button>
    <button class="op" onclick="op('/')">÷</button>
    <button class="num-btn" onclick="press(7)">7</button>
    <button class="num-btn" onclick="press(8)">8</button>
    <button class="num-btn" onclick="press(9)">9</button>
    <button class="op" onclick="op('*')">×</button>
    <button class="num-btn" onclick="press(4)">4</button>
    <button class="num-btn" onclick="press(5)">5</button>
    <button class="num-btn" onclick="press(6)">6</button>
    <button class="op" onclick="op('-')">−</button>
    <button class="num-btn" onclick="press(1)">1</button>
    <button class="num-btn" onclick="press(2)">2</button>
    <button class="num-btn" onclick="press(3)">3</button>
    <button class="op" onclick="op('+')">+</button>
    <button class="num-btn" onclick="press(0)" style="grid-column:span 2">0</button>
    <button class="num-btn" onclick="dot()">.</button>
    <button class="eq" onclick="calc()">=</button>
  </div>
</div>
<script>
let cur='0',prev='',operator='',newNum=true;
function show(){document.getElementById('num').textContent=cur;document.getElementById('expr').textContent=prev+(operator||'')}
function press(n){if(newNum){cur=String(n);newNum=false}else{cur=cur==='0'?String(n):cur+n}show()}
function dot(){if(newNum){cur='0.';newNum=false}else if(!cur.includes('.'))cur+='.';show()}
function op(o){if(operator&&!newNum){calc();}prev=cur;operator=o;newNum=true;show()}
function calc(){if(!operator)return;const r=eval(prev+operator+cur);cur=String(parseFloat(r.toFixed(10)));prev='';operator='';newNum=true;show()}
function clearAll(){cur='0';prev='';operator='';newNum=true;show()}
function toggleSign(){cur=String(-parseFloat(cur));show()}
function percent(){cur=String(parseFloat(cur)/100);show()}
</script>
</body>
</html>''',
    ),
    (
      name: '⏱️ Stopwatch',
      desc: 'Start/Stop/Reset timer',
      html: '''<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:linear-gradient(135deg,#667eea,#764ba2);min-height:100vh;display:flex;justify-content:center;align-items:center;font-family:-apple-system,sans-serif}
  .card{background:rgba(255,255,255,0.15);backdrop-filter:blur(20px);border-radius:32px;padding:48px 40px;text-align:center;width:320px;border:1px solid rgba(255,255,255,0.3)}
  .time{font-size:56px;font-weight:800;color:#fff;letter-spacing:2px;margin-bottom:40px;text-shadow:0 4px 20px rgba(0,0,0,0.2)}
  .ms{font-size:28px;opacity:0.7}
  .btns{display:flex;gap:16px;justify-content:center}
  button{border:none;border-radius:50px;padding:14px 28px;font-size:16px;font-weight:700;cursor:pointer;transition:all 0.2s}
  button:active{transform:scale(0.95)}
  #startBtn{background:#fff;color:#764ba2;flex:1}
  #resetBtn{background:rgba(255,255,255,0.2);color:#fff;border:2px solid rgba(255,255,255,0.4)}
  .laps{margin-top:24px;max-height:160px;overflow-y:auto}
  .lap{color:rgba(255,255,255,0.8);font-size:13px;padding:6px 0;border-bottom:1px solid rgba(255,255,255,0.1)}
</style>
</head>
<body>
<div class="card">
  <div class="time"><span id="mm">00</span>:<span id="ss">00</span>.<span id="cs" class="ms">00</span></div>
  <div class="btns">
    <button id="startBtn" onclick="toggle()">Start</button>
    <button id="resetBtn" onclick="reset()">Lap</button>
  </div>
  <div class="laps" id="laps"></div>
</div>
<script>
let t=0,iv=null,running=false,lapCount=0;
function fmt(n){return String(Math.floor(n)).padStart(2,'0')}
function tick(){t+=10;document.getElementById('mm').textContent=fmt(t/60000%60);document.getElementById('ss').textContent=fmt(t/1000%60);document.getElementById('cs').textContent=fmt(t/10%100)}
function toggle(){if(running){clearInterval(iv);document.getElementById('startBtn').textContent='Start';document.getElementById('resetBtn').textContent='Reset';}else{iv=setInterval(tick,10);document.getElementById('startBtn').textContent='Stop';document.getElementById('resetBtn').textContent='Lap';}running=!running}
function reset(){if(running){lapCount++;const mm=document.getElementById('mm').textContent,ss=document.getElementById('ss').textContent,cs=document.getElementById('cs').textContent;document.getElementById('laps').innerHTML='<div class="lap">Lap '+lapCount+': '+mm+':'+ss+'.'+cs+'</div>'+document.getElementById('laps').innerHTML;}else{clearInterval(iv);t=0;lapCount=0;document.getElementById('mm').textContent='00';document.getElementById('ss').textContent='00';document.getElementById('cs').textContent='00';document.getElementById('laps').innerHTML='';document.getElementById('startBtn').textContent='Start';document.getElementById('resetBtn').textContent='Lap';}}
</script>
</body>
</html>''',
    ),
    (
      name: '🎨 Color Mixer',
      desc: 'Mix RGB colors interactively',
      html: '''<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:-apple-system,sans-serif;background:#f8f9fa;padding:20px}
  .preview{height:180px;border-radius:20px;margin-bottom:24px;transition:background 0.1s;box-shadow:0 8px 32px rgba(0,0,0,0.15)}
  .hex{text-align:center;font-size:24px;font-weight:800;margin-bottom:20px;color:#333;letter-spacing:2px}
  .row{margin-bottom:16px}
  label{display:flex;justify-content:space-between;font-weight:700;font-size:14px;margin-bottom:6px}
  .val{font-size:14px;font-weight:700;min-width:32px;text-align:right}
  input[type=range]{width:100%;height:8px;border-radius:4px;outline:none;-webkit-appearance:none;cursor:pointer}
  .r input{accent-color:#e74c3c} .g input{accent-color:#27ae60} .b input{accent-color:#3498db}
  .copy{display:block;width:100%;padding:14px;background:#333;color:#fff;border:none;border-radius:14px;font-size:16px;font-weight:700;cursor:pointer;margin-top:8px}
  .copy:active{background:#555}
</style>
</head>
<body>
<div class="preview" id="preview"></div>
<div class="hex" id="hex">#FF0000</div>
<div class="row r"><label>Red <span class="val" id="rv">255</span></label><input type="range" min="0" max="255" value="255" id="r" oninput="update()"></div>
<div class="row g"><label>Green <span class="val" id="gv">0</span></label><input type="range" min="0" max="255" value="0" id="g" oninput="update()"></div>
<div class="row b"><label>Blue <span class="val" id="bv">0</span></label><input type="range" min="0" max="255" value="0" id="b" oninput="update()"></div>
<button class="copy" onclick="copy()">Copy HEX</button>
<script>
function h(n){return n.toString(16).padStart(2,'0').toUpperCase()}
function update(){const r=+document.getElementById('r').value,g=+document.getElementById('g').value,b=+document.getElementById('b').value;const hex='#'+h(r)+h(g)+h(b);document.getElementById('preview').style.background=hex;document.getElementById('hex').textContent=hex;document.getElementById('rv').textContent=r;document.getElementById('gv').textContent=g;document.getElementById('bv').textContent=b}
function copy(){const hex=document.getElementById('hex').textContent;if(navigator.clipboard)navigator.clipboard.writeText(hex).then(()=>ZyloBridge.postMessage('Copied: '+hex)).catch(()=>ZyloBridge.postMessage(hex));else ZyloBridge.postMessage(hex)}
update();
</script>
</body>
</html>''',
    ),
    (
      name: '📊 Bar Chart',
      desc: 'Animated chart with Chart.js',
      html: '''<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
  body{margin:0;background:#fff;font-family:-apple-system,sans-serif;padding:16px}
  h3{color:#333;margin-bottom:16px;font-size:16px}
</style>
</head>
<body>
<h3>📊 Monthly Sales</h3>
<canvas id="chart"></canvas>
<script>
new Chart(document.getElementById('chart'),{
  type:'bar',
  data:{
    labels:['Jan','Feb','Mar','Apr','May','Jun'],
    datasets:[{
      label:'Sales (₹ Lac)',
      data:[12,19,8,25,22,30],
      backgroundColor:['#E8542A','#0284C7','#7C3AED','#059669','#DC2626','#D97706'],
      borderRadius:8,borderSkipped:false
    }]
  },
  options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,grid:{color:'#f0f0f0'}}},animation:{duration:1200,easing:'easeOutBounce'}}
});
</script>
</body>
</html>''',
    ),
    (
      name: '✅ Todo List',
      desc: 'Add and check off tasks',
      html: '''<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:-apple-system,sans-serif;background:#f0f4ff;padding:20px;min-height:100vh}
  h2{color:#1a1a2e;margin-bottom:20px;font-size:20px}
  .add{display:flex;gap:10px;margin-bottom:20px}
  .add input{flex:1;padding:12px 16px;border:2px solid #e2e8f0;border-radius:12px;font-size:14px;outline:none}
  .add input:focus{border-color:#667eea}
  .add button{background:#667eea;color:#fff;border:none;border-radius:12px;padding:12px 18px;font-size:18px;cursor:pointer}
  .item{display:flex;align-items:center;background:#fff;border-radius:14px;padding:14px 16px;margin-bottom:10px;box-shadow:0 2px 8px rgba(0,0,0,0.06);gap:12px;transition:all 0.2s}
  .item.done span{text-decoration:line-through;color:#aaa}
  .item input[type=checkbox]{width:20px;height:20px;accent-color:#667eea;cursor:pointer}
  .item span{flex:1;font-size:14px;font-weight:500;color:#333}
  .del{background:none;border:none;color:#e74c3c;font-size:18px;cursor:pointer}
  .empty{text-align:center;color:#aaa;margin-top:40px;font-size:14px}
</style>
</head>
<body>
<h2>✅ My Todo List</h2>
<div class="add"><input id="inp" placeholder="Add a task..." onkeydown="if(event.key==='Enter')add()"><button onclick="add()">+</button></div>
<div id="list"></div>
<script>
let todos=[];
function add(){const v=document.getElementById('inp').value.trim();if(!v)return;todos.unshift({text:v,done:false});document.getElementById('inp').value='';render()}
function toggle(i){todos[i].done=!todos[i].done;render()}
function del(i){todos.splice(i,1);render()}
function render(){const el=document.getElementById('list');if(!todos.length){el.innerHTML='<div class="empty">No tasks yet! Add one above 👆</div>';return}el.innerHTML=todos.map((t,i)=>'<div class="item'+(t.done?' done':'')+'"><input type="checkbox"'+(t.done?' checked':'')+' onchange="toggle('+i+')"><span>'+t.text+'</span><button class="del" onclick="del('+i+')">🗑</button></div>').join('')}
render();
</script>
</body>
</html>''',
    ),
    (
      name: '🎲 Dice Roller',
      desc: 'Roll dice with animation',
      html: '''<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  body{margin:0;background:linear-gradient(135deg,#1a1a2e,#16213e);min-height:100vh;display:flex;flex-direction:column;justify-content:center;align-items:center;font-family:-apple-system,sans-serif;gap:32px}
  .dice{font-size:120px;transition:transform 0.1s;user-select:none;filter:drop-shadow(0 8px 24px rgba(0,0,0,0.4))}
  .dice.rolling{animation:roll 0.5s ease}
  @keyframes roll{0%{transform:rotate(0) scale(1)}25%{transform:rotate(90deg) scale(0.7)}50%{transform:rotate(180deg) scale(1.2)}75%{transform:rotate(270deg) scale(0.8)}100%{transform:rotate(360deg) scale(1)}}
  .result{color:#fff;font-size:24px;font-weight:700;min-height:32px}
  button{background:#e94560;color:#fff;border:none;border-radius:50px;padding:18px 48px;font-size:18px;font-weight:800;cursor:pointer;box-shadow:0 8px 24px rgba(233,69,96,0.4);transition:transform 0.2s}
  button:active{transform:scale(0.94)}
</style>
</head>
<body>
<div class="dice" id="dice">🎲</div>
<div class="result" id="result">Tap to roll!</div>
<button onclick="roll()">Roll Dice</button>
<script>
const faces=['⚀','⚁','⚂','⚃','⚄','⚅'];
function roll(){const d=document.getElementById('dice');d.classList.remove('rolling');void d.offsetWidth;d.classList.add('rolling');setTimeout(()=>{const n=Math.floor(Math.random()*6);d.textContent=faces[n];document.getElementById('result').textContent='You rolled a '+(n+1)+'!';},300)}
</script>
</body>
</html>''',
    ),
    (
      name: '🌐 3D Cube',
      desc: 'Spinning 3D cube (CSS)',
      html: '''<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  body{margin:0;background:#0d0d1a;display:flex;flex-direction:column;justify-content:center;align-items:center;min-height:100vh;font-family:-apple-system,sans-serif;gap:32px}
  .scene{width:160px;height:160px;perspective:500px}
  .cube{width:160px;height:160px;position:relative;transform-style:preserve-3d;animation:spin 4s infinite linear}
  @keyframes spin{from{transform:rotateX(15deg) rotateY(0)}to{transform:rotateX(15deg) rotateY(360deg)}}
  .face{position:absolute;width:160px;height:160px;border:2px solid rgba(255,255,255,0.3);display:flex;align-items:center;justify-content:center;font-size:48px;border-radius:8px}
  .front {background:rgba(232,84,42,0.7);transform:translateZ(80px)}
  .back  {background:rgba(2,132,199,0.7);transform:rotateY(180deg) translateZ(80px)}
  .right {background:rgba(124,58,237,0.7);transform:rotateY(90deg) translateZ(80px)}
  .left  {background:rgba(5,150,105,0.7);transform:rotateY(-90deg) translateZ(80px)}
  .top   {background:rgba(220,38,38,0.7);transform:rotateX(90deg) translateZ(80px)}
  .bottom{background:rgba(217,119,6,0.7);transform:rotateX(-90deg) translateZ(80px)}
  p{color:rgba(255,255,255,0.6);font-size:13px}
</style>
</head>
<body>
<div class="scene"><div class="cube">
  <div class="face front">⚡</div>
  <div class="face back">🚀</div>
  <div class="face right">🎯</div>
  <div class="face left">🌟</div>
  <div class="face top">🔥</div>
  <div class="face bottom">💎</div>
</div></div>
<p>CSS 3D — No libraries needed</p>
</body>
</html>''',
    ),
    (
      name: '💬 Quiz Game',
      desc: 'Multiple choice quiz',
      html: '''<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:-apple-system,sans-serif;background:linear-gradient(135deg,#667eea,#764ba2);min-height:100vh;padding:20px;display:flex;align-items:center;justify-content:center}
  .card{background:#fff;border-radius:24px;padding:28px;width:100%;max-width:360px}
  .progress{height:6px;background:#e2e8f0;border-radius:3px;margin-bottom:24px}
  .bar{height:6px;background:linear-gradient(90deg,#667eea,#764ba2);border-radius:3px;transition:width 0.4s}
  .qnum{color:#667eea;font-size:12px;font-weight:700;margin-bottom:8px}
  h3{color:#1a1a2e;font-size:17px;line-height:1.5;margin-bottom:20px}
  .opt{display:block;width:100%;padding:14px 16px;border:2px solid #e2e8f0;border-radius:14px;background:#fff;text-align:left;font-size:14px;font-weight:600;color:#333;cursor:pointer;margin-bottom:10px;transition:all 0.2s}
  .opt:hover{border-color:#667eea;background:#f0f4ff}
  .opt.correct{border-color:#059669;background:#ecfdf5;color:#059669}
  .opt.wrong{border-color:#dc2626;background:#fef2f2;color:#dc2626}
  .score{text-align:center;padding:20px 0}
  .score .big{font-size:56px;font-weight:900;color:#667eea}
  .score p{color:#666;margin:8px 0 20px}
  .restart{background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;border:none;border-radius:14px;padding:14px 28px;font-size:15px;font-weight:700;cursor:pointer}
</style>
</head>
<body>
<div class="card" id="app"></div>
<script>
const qs=[{q:"What does HTML stand for?",a:"HyperText Markup Language",o:["HyperText Markup Language","HighText Machine Language","Hyper Transfer Markup Language","HyperTool Multi Language"]},{q:"Which tag is used for the largest heading?",a:"<h1>",o:["<h6>","<heading>","<h1>","<big>"]},{q:"What does CSS stand for?",a:"Cascading Style Sheets",o:["Computer Style Sheets","Cascading Style Sheets","Creative Style Sheets","Colorful Style Sheets"]},{q:"Which language runs in a web browser?",a:"JavaScript",o:["Java","C++","Python","JavaScript"]},{q:"What does 'DOM' stand for?",a:"Document Object Model",o:["Document Object Model","Data Object Mode","Digital Ordinance Model","Document Output Mode"]}];
let cur=0,score=0,answered=false;
function render(){const app=document.getElementById('app');if(cur>=qs.length){app.innerHTML='<div class="score"><div class="big">'+score+'/'+qs.length+'</div><p>'+(score===qs.length?'Perfect! 🎉':score>qs.length/2?'Good job! 👍':'Keep practicing! 💪')+'</p><button class="restart" onclick="restart()">Play Again</button></div>';ZyloBridge.postMessage('Quiz done! Score: '+score+'/'+qs.length);return}const q=qs[cur];app.innerHTML='<div class="progress"><div class="bar" style="width:'+((cur/qs.length)*100)+'%"></div></div><div class="qnum">Question '+(cur+1)+' of '+qs.length+'</div><h3>'+q.q+'</h3>'+q.o.map(o=>'<button class="opt" onclick="answer(this,\''+o+'\')" data-val="'+o+'">'+o+'</button>').join('')}
function answer(btn,val){if(answered)return;answered=true;const correct=qs[cur].a;document.querySelectorAll('.opt').forEach(b=>{b.disabled=true;if(b.dataset.val===correct)b.classList.add('correct');else if(b.dataset.val===val&&val!==correct)b.classList.add('wrong')});if(val===correct)score++;setTimeout(()=>{cur++;answered=false;render()},1200)}
function restart(){cur=0;score=0;answered=false;render()}
render();
</script>
</body>
</html>''',
    ),
  ];

  // ── Show templates bottom sheet ─────────────────────────────────────────
  void _showTemplates() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        height: MediaQuery.of(context).size.height * 0.75,
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
        child: Column(children: [
          // Handle
          Container(margin: const EdgeInsets.only(top: 12), width: 40, height: 4,
            decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
          const Padding(
            padding: EdgeInsets.fromLTRB(20, 16, 20, 12),
            child: Row(children: [
              Icon(Icons.auto_awesome_rounded, color: Color(0xFFE8542A), size: 20),
              SizedBox(width: 8),
              Text('HTML Templates', style: TextStyle(
                fontSize: 17, fontWeight: FontWeight.w900, color: Color(0xFF0D1B2A))),
            ])),
          const Divider(height: 1),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              itemCount: _templates.length,
              itemBuilder: (_, i) {
                final t = _templates[i];
                return GestureDetector(
                  onTap: () => _loadTemplate(t.html),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF8F5),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: const Color(0xFFE8542A).withValues(alpha: 0.2))),
                    child: Row(children: [
                      Container(
                        width: 48, height: 48,
                        decoration: BoxDecoration(
                          color: const Color(0xFFE8542A).withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(12)),
                        child: Center(child: Text(t.name.substring(0, 2),
                          style: const TextStyle(fontSize: 22)))),
                      const SizedBox(width: 14),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(t.name.substring(3), style: const TextStyle(
                          fontWeight: FontWeight.w800, fontSize: 14, color: Color(0xFF0D1B2A))),
                        const SizedBox(height: 2),
                        Text(t.desc, style: TextStyle(
                          fontSize: 12, color: Colors.grey[600])),
                      ])),
                      const Icon(Icons.arrow_forward_ios_rounded,
                        size: 14, color: Color(0xFFE8542A)),
                    ])));
              }),
          ),
        ])));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFFFF8F5),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _overLimit
            ? Colors.red.withValues(alpha: 0.5)
            : const Color(0xFFE8542A).withValues(alpha: 0.3))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // ── Header bar ────────────────────────────────────────────────────
        Container(
          padding: const EdgeInsets.fromLTRB(12, 10, 10, 10),
          decoration: BoxDecoration(
            color: const Color(0xFFE8542A).withValues(alpha: 0.08),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(15))),
          child: Row(children: [
            const Icon(Icons.code_rounded, color: Color(0xFFE8542A), size: 18),
            const SizedBox(width: 6),
            const Text('HTML Viewer', style: TextStyle(
              fontWeight: FontWeight.w900, fontSize: 13, color: Color(0xFFE8542A))),
            const SizedBox(width: 8),
            // Size badge
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
              decoration: BoxDecoration(
                color: _overLimit ? Colors.red.withValues(alpha: 0.12) : Colors.grey[200],
                borderRadius: BorderRadius.circular(10)),
              child: Text(_sizeLabel,
                style: TextStyle(
                  fontSize: 10, fontWeight: FontWeight.w700,
                  color: _overLimit ? Colors.red : Colors.grey[700]))),
            if (_overLimit) ...[
              const SizedBox(width: 4),
              const Text('max 40KB', style: TextStyle(fontSize: 10, color: Colors.red)),
            ],
            const Spacer(),
            // ── Templates button ─────────────────────────────────────────
            GestureDetector(
              onTap: _showTemplates,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: const Color(0xFFE8542A).withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFFE8542A).withValues(alpha: 0.3))),
                child: const Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.auto_awesome_rounded, size: 13, color: Color(0xFFE8542A)),
                  SizedBox(width: 4),
                  Text('Templates', style: TextStyle(
                    fontSize: 11, fontWeight: FontWeight.w800, color: Color(0xFFE8542A))),
                ]))),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: widget.onTogglePreview,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: widget.preview
                    ? const Color(0xFFE8542A).withValues(alpha: 0.12)
                    : Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFFE8542A).withValues(alpha: 0.3))),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(widget.preview ? Icons.arrow_back_rounded : Icons.play_arrow_rounded,
                    size: 14, color: const Color(0xFFE8542A)),
                  const SizedBox(width: 4),
                  Text(widget.preview ? 'Back' : 'Run',
                    style: const TextStyle(
                      fontSize: 11, fontWeight: FontWeight.w800, color: Color(0xFFE8542A))),
                ]))),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: widget.onClose,
              child: Container(
                padding: const EdgeInsets.all(4),
                child: Icon(Icons.close_rounded, size: 16, color: Colors.grey[600]))),
          ])),

        // ── App Name + Logo URL ───────────────────────────────────────────
        if (!widget.preview)
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 0),
            child: Row(children: [
              Expanded(
                flex: 3,
                child: TextField(
                  controller: widget.appNameCtrl,
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                  decoration: InputDecoration(
                    hintText: 'App name (optional)',
                    hintStyle: TextStyle(fontSize: 12, color: Colors.grey[500]),
                    prefixIcon: const Icon(Icons.apps_rounded,
                      size: 14, color: Color(0xFFE8542A)),
                    prefixIconConstraints: const BoxConstraints(minWidth: 32),
                    filled: true, fillColor: Colors.white,
                    isDense: true,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: Colors.grey[200]!)),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: Colors.grey[200]!)),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: Color(0xFFE8542A)))),
                )),
              const SizedBox(width: 8),
              Expanded(
                flex: 4,
                child: TextField(
                  controller: widget.appLogoCtrl,
                  style: const TextStyle(fontSize: 12),
                  decoration: InputDecoration(
                    hintText: 'Logo URL (optional)',
                    hintStyle: TextStyle(fontSize: 12, color: Colors.grey[500]),
                    prefixIcon: const Icon(Icons.image_outlined,
                      size: 14, color: Color(0xFFE8542A)),
                    prefixIconConstraints: const BoxConstraints(minWidth: 32),
                    filled: true, fillColor: Colors.white,
                    isDense: true,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: Colors.grey[200]!)),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: Colors.grey[200]!)),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: Color(0xFFE8542A)))),
                )),
            ])),

        // ── Quick snippet chips ───────────────────────────────────────────
        if (!widget.preview)
          SizedBox(height: 36,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              children: _snippets.map((s) => GestureDetector(
                onTap: () => _insert(s.$1),
                child: Container(
                  margin: const EdgeInsets.only(right: 6),
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.grey[300]!)),
                  child: Text(s.$2, style: TextStyle(
                    fontSize: 11, fontWeight: FontWeight.w700, color: Colors.grey[700]))))).toList())),

        // ── Editor / Preview area ─────────────────────────────────────────
        AnimatedCrossFade(
          duration: const Duration(milliseconds: 220),
          crossFadeState: widget.preview
            ? CrossFadeState.showSecond
            : CrossFadeState.showFirst,
          firstChild: Container(
            constraints: const BoxConstraints(minHeight: 160, maxHeight: 280),
            padding: const EdgeInsets.all(10),
            child: TextField(
              controller: widget.ctrl,
              maxLines: null,
              expands: true,
              style: const TextStyle(
                fontSize: 12, fontFamily: 'monospace', color: Color(0xFF0D1B2A), height: 1.5),
              decoration: InputDecoration(
                hintText: '<!-- Paste or type HTML here (max 40 KB) -->\n<h1>Hello World</h1>\n<p>Your HTML here...</p>',
                hintStyle: TextStyle(color: Colors.grey[400], fontSize: 12, fontFamily: 'monospace'),
                border: InputBorder.none, isDense: true),
              keyboardType: TextInputType.multiline,
            )),
          secondChild: SizedBox(
            height: 320,
            child: _HtmlPreviewWidget(html: widget.ctrl.text))),

        const SizedBox(height: 8),
      ]));
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  _HtmlPreviewWidget — full WebView, runs HTML + CSS + JS animations + CDN
// ══════════════════════════════════════════════════════════════════════════════
class _HtmlPreviewWidget extends StatefulWidget {
  final String html;
  final bool fullScreen; // used by post card full-screen launcher
  const _HtmlPreviewWidget({required this.html, this.fullScreen = false});
  @override
  State<_HtmlPreviewWidget> createState() => _HtmlPreviewWidgetState();
}

class _HtmlPreviewWidgetState extends State<_HtmlPreviewWidget> {
  late final WebViewController _wvc;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _wvc = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (_) {
          if (mounted) setState(() => _loaded = true);
        },
        onNavigationRequest: (req) {
          // Allow CDN script loads (jsdelivr, cdnjs, unpkg, googleapis etc.)
          final url = req.url;
          if (url == 'about:blank') return NavigationDecision.navigate;
          if (url.contains('cdn.jsdelivr.net') ||
              url.contains('cdnjs.cloudflare.com') ||
              url.contains('unpkg.com') ||
              url.contains('googleapis.com') ||
              url.contains('gstatic.com') ||
              url.contains('ajax.googleapis.com')) {
            return NavigationDecision.navigate;
          }
          // Block external page navigation — keep user inside app
          return NavigationDecision.prevent;
        },
      ))
      ..loadHtmlString(_wrapHtml(widget.html), baseUrl: 'https://zylo.app');
  }

  // Wraps bare HTML snippets so they always render correctly
  String _wrapHtml(String src) {
    final lower = src.trimLeft().toLowerCase();
    if (lower.startsWith('<!doctype') || lower.startsWith('<html')) return src;
    return '''<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, sans-serif; font-size: 14px;
         background: #fff; color: #0D1B2A; padding: 12px; }
</style>
</head>
<body>$src</body>
</html>''';
  }

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      WebViewWidget(controller: _wvc),
      if (!_loaded)
        const Center(child: CircularProgressIndicator(
          color: Color(0xFFE8542A), strokeWidth: 2.5)),
    ]);
  }
}

// ── Full-screen HTML runner screen (launched from post card) ──────────────────
class _HtmlRunnerScreen extends StatefulWidget {
  final String html;
  final String title;
  final String logoUrl;
  const _HtmlRunnerScreen({required this.html, required this.title, this.logoUrl = ''});
  @override
  State<_HtmlRunnerScreen> createState() => _HtmlRunnerScreenState();
}

class _HtmlRunnerScreenState extends State<_HtmlRunnerScreen> {
  late final WebViewController _wvc;
  bool _loaded     = false;
  bool _canGoBack  = false;
  bool _fullscreen = false;   // true = hide appbar (immersive mode)

  static const _kOrange = Color(0xFFE8542A);

  @override
  void initState() {
    super.initState();
    // Allow landscape when entering runner
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);

    _wvc = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      // ── JS Bridge: HTML can call ZyloBridge.postMessage("...") ──────────
      ..addJavaScriptChannel(
        'ZyloBridge',
        onMessageReceived: (JavaScriptMessage msg) {
          if (!mounted) return;
          // Try parse as JSON action, else show as snackbar
          try {
            final data = msg.message;
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text(data, style: const TextStyle(fontSize: 13)),
              backgroundColor: _kOrange,
              behavior: SnackBarBehavior.floating,
              duration: const Duration(seconds: 3),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
          } catch (_) {}
        },
      )
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (_) async {
          if (mounted) {
            final canBack = await _wvc.canGoBack();
            setState(() { _loaded = true; _canGoBack = canBack; });
          }
        },
        onUrlChange: (_) async {
          final canBack = await _wvc.canGoBack();
          if (mounted) setState(() => _canGoBack = canBack);
        },
        onNavigationRequest: (req) {
          final url = req.url;
          if (url == 'about:blank') return NavigationDecision.navigate;
          // Allow CDN libraries (Chart.js, Three.js, etc.)
          if (url.contains('cdn.jsdelivr.net') ||
              url.contains('cdnjs.cloudflare.com') ||
              url.contains('unpkg.com') ||
              url.contains('googleapis.com') ||
              url.contains('gstatic.com') ||
              url.contains('ajax.googleapis.com')) {
            return NavigationDecision.navigate;
          }
          // Allow internal anchors & data URIs
          if (url.startsWith('data:') || url.startsWith('#') || url.startsWith('javascript:')) {
            return NavigationDecision.navigate;
          }
          // Block external page navigation
          return NavigationDecision.prevent;
        },
      ))
      ..loadHtmlString(_wrapHtml(widget.html), baseUrl: 'https://zylo.app');
  }

  @override
  void dispose() {
    // Restore portrait-only when leaving
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    super.dispose();
  }

  String _wrapHtml(String src) {
    final lower = src.trimLeft().toLowerCase();
    if (lower.startsWith('<!doctype') || lower.startsWith('<html')) return src;
    return '''<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<style>
  * { box-sizing: border-box; }
  body { font-family: -apple-system, sans-serif; font-size: 15px;
         background: #fff; color: #0D1B2A; padding: 16px; }
</style>
</head>
<body>$src</body>
</html>''';
  }

  Future<void> _handleBack() async {
    if (await _wvc.canGoBack()) {
      await _wvc.goBack();
    } else {
      if (mounted) Navigator.pop(context);
    }
  }

  Widget _iconBtn({
    required IconData icon,
    required VoidCallback onTap,
    Color? color,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.grey[100], shape: BoxShape.circle),
        child: Icon(icon, color: color ?? _kOrange, size: 20)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      // ── AppBar hidden in fullscreen mode ──────────────────────────────
      appBar: _fullscreen ? null : AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: GestureDetector(
          onTap: _handleBack,
          child: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.grey[100], shape: BoxShape.circle),
            child: Icon(
              _canGoBack ? Icons.arrow_back_rounded : Icons.close_rounded,
              color: const Color(0xFF0D1B2A), size: 20))),
        title: Row(children: [
          if (widget.logoUrl.isNotEmpty) ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: ZyloCachedImage(
                url: widget.logoUrl,
                width: 24, height: 24, fit: BoxFit.cover,
                errorWidget: const SizedBox.shrink())),
            const SizedBox(width: 8),
          ],
          Expanded(child: Text(widget.title.isNotEmpty ? widget.title : 'HTML Viewer',
            style: const TextStyle(
              fontSize: 15, fontWeight: FontWeight.w800, color: Color(0xFF0D1B2A)),
            maxLines: 1, overflow: TextOverflow.ellipsis)),
        ]),
        actions: [
          // Reload
          _iconBtn(icon: Icons.refresh_rounded, onTap: () async {
            setState(() => _loaded = false);
            await _wvc.reload();
          }),
          // Fullscreen toggle
          _iconBtn(
            icon: Icons.fullscreen_rounded,
            color: const Color(0xFF0D1B2A),
            onTap: () => setState(() => _fullscreen = true)),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: Colors.grey.withValues(alpha: 0.1))),
      ),
      body: Stack(children: [
        // ── WebView ──────────────────────────────────────────────────────
        WebViewWidget(controller: _wvc),

        // ── Loading overlay ───────────────────────────────────────────────
        if (!_loaded)
          Container(
            color: Colors.white,
            child: const Center(child: Column(
              mainAxisSize: MainAxisSize.min, children: [
                CircularProgressIndicator(color: _kOrange, strokeWidth: 2.5),
                SizedBox(height: 12),
                Text('Loading...', style: TextStyle(
                  fontSize: 13, color: Colors.grey, fontWeight: FontWeight.w500)),
              ]))),

        // ── Fullscreen exit button (floating, shown only in fullscreen) ───
        if (_fullscreen)
          SafeArea(
            child: Align(
              alignment: Alignment.topRight,
              child: GestureDetector(
                onTap: () => setState(() => _fullscreen = false),
                child: Container(
                  margin: const EdgeInsets.all(12),
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.55),
                    shape: BoxShape.circle),
                  child: const Icon(Icons.fullscreen_exit_rounded,
                    color: Colors.white, size: 22))))),
      ]));
  }
}

// ── In-App Share Sheet ────────────────────────────────────────────────────────
class _InAppShareSheet extends StatelessWidget {
  final String postId, myUid; final Map<String, dynamic> post;
  const _InAppShareSheet({required this.postId, required this.myUid, required this.post});

  String get _shareText {
    final authorName = post['authorName'] as String? ?? '';
    final postText   = post['text']       as String? ?? '';
    final link       = ZyloShareUtils.postLink(postId);
    final preview    = postText.length > 120 ? '${postText.substring(0, 120)}...' : postText;
    return preview.isNotEmpty
        ? '📋 Post by @$authorName on Zylo:\n"$preview"\n\n$link'
        : '📋 Post by @$authorName on Zylo\n$link';
  }

  Future<void> _launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _shareToWhatsApp()   => _launchUrl('whatsapp://send?text=${Uri.encodeComponent(_shareText)}');
  Future<void> _shareToTelegram()   => _launchUrl('tg://msg?text=${Uri.encodeComponent(_shareText)}');
  Future<void> _shareToInstagram(BuildContext ctx) async {
    await Clipboard.setData(ClipboardData(text: _shareText));
    ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(
      content: Text('Text copied! Paste in Instagram'), backgroundColor: Colors.purple,
      behavior: SnackBarBehavior.floating));
    await _launchUrl('instagram://app');
  }
  Future<void> _shareToFacebook()   => _launchUrl('fb://facewebmodal/f?href=${Uri.encodeComponent(_shareText)}');
  Future<void> _shareToSnapchat()   => _launchUrl('snapchat://');
  Future<void> _shareOthers()       => Share.share(_shareText);

  @override
  Widget build(BuildContext context) => Container(
    height: MediaQuery.of(context).size.height * 0.75,
    decoration: const BoxDecoration(color: Colors.white,
      borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    child: Column(children: [
      Container(margin: const EdgeInsets.only(top: 10, bottom: 8), width: 40, height: 4,
        decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
      const Padding(padding: EdgeInsets.fromLTRB(16, 4, 16, 8),
        child: Row(children: [
          Icon(Icons.share_rounded, color: _kBlue, size: 20),
          SizedBox(width: 8),
          Text('Share', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
        ])),

      Container(
        color: const Color(0xFFF8FAFD),
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          _SocialBtn(icon: 'W', color: const Color(0xFF25D366), label: 'WhatsApp',
            onTap: _shareToWhatsApp),
          _SocialBtn(icon: '✈', color: const Color(0xFF0088CC), label: 'Telegram',
            onTap: _shareToTelegram),
          _SocialBtn(icon: '📸', color: const Color(0xFFE1306C), label: 'Instagram',
            onTap: () => _shareToInstagram(context)),
          _SocialBtn(icon: 'f', color: const Color(0xFF1877F2), label: 'Facebook',
            onTap: _shareToFacebook),
          _SocialBtn(icon: '👻', color: const Color(0xFFFFFC00), label: 'Snapchat',
            textColor: Colors.black, onTap: _shareToSnapchat),
          _SocialBtn(icon: '···', color: Colors.grey[700]!, label: 'Others',
            onTap: _shareOthers),
        ]),
      ),

      const Divider(height: 1),
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
        child: Row(children: [
          const Icon(Icons.chat_bubble_outline, color: _kBlue, size: 16),
          const SizedBox(width: 6),
          Text('Share to Chat', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: Colors.grey[700])),
        ]),
      ),

      Expanded(child: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('chats')
            .where('participants', arrayContains: myUid)
            .orderBy('lastMsgTime', descending: true).snapshots(),
        builder: (_, snap) {
          final chats = snap.data?.docs ?? [];
          if (chats.isEmpty) return Center(child: Text('No chats yet', style: TextStyle(color: Colors.grey[600])));
          return ListView.builder(itemCount: chats.length, itemBuilder: (_, i) {
            final chat = chats[i].data() as Map<String, dynamic>;
            final otherUid = (chat['participants'] as List).firstWhere((p) => p != myUid, orElse: () => '');
            return StreamBuilder<DocumentSnapshot>(
              stream: FirebaseFirestore.instance.collection('users').doc(otherUid).snapshots(),
              builder: (_, uSnap) {
                final u     = uSnap.data?.data() as Map<String, dynamic>? ?? {};
                final name  = u['username']  as String? ?? 'User';
                final photo = u['photoURL']  as String? ?? '';
                return ListTile(
                  leading: ZyloAvatar(photoUrl: photo, radius: 22),
                  title: Text('@$name', style: const TextStyle(fontWeight: FontWeight.w700)),
                  trailing: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [_kBlue, Color(0xFF7C3AED)]),
                      borderRadius: BorderRadius.circular(12)),
                    child: const Text('Send', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12))),
                  onTap: () async {
                    Navigator.pop(context);
                    final authorName  = post['authorName'] as String? ?? post['authorUsername'] as String? ?? 'Someone';
                    final authorPhoto = post['authorPhoto'] as String? ?? post['userPhoto'] as String? ?? '';
                    final postText   = post['text']       as String? ?? '';
                    final postImages = (post['images']    as List?)?.cast<String>() ?? [];
                    final imageUrl   = postImages.isNotEmpty ? postImages[0] : '';
                    final postType   = post['mediaType']  as String? ?? 'text'; // text/image/video/poll/html
                    final chatId     = ([myUid, otherUid]..sort()).join('_');
                    final chatRef = FirebaseFirestore.instance.collection('chats').doc(chatId);
                    // Ensure chat document exists (upsert) before writing message
                    await chatRef.set({
                      'participants': [myUid, otherUid],
                      'lastMsgTime': FieldValue.serverTimestamp(),
                      'lastMsg': '📎 Shared a post',
                    }, SetOptions(merge: true));
                    await chatRef.collection('messages').add({
                      'senderId': myUid,
                      'text': postText.isNotEmpty ? postText : '📎 Shared a post',
                      'mediaType': 'post_share',
                      'isRead': false,
                      'timestamp': FieldValue.serverTimestamp(),
                      'sharedPostId': postId,
                      'sharedPost': {
                        'postId': postId,
                        'authorName': authorName,
                        'authorPhoto': authorPhoto,
                        'text': postText,
                        'imageUrl': imageUrl,
                        'images': postImages, // all images
                        'postType': postType, // original post type
                        'likes': (post['likes'] as List?)?.length ?? 0,
                        // pass tool/html data if present
                        if (post['htmlContent'] != null) 'htmlContent': post['htmlContent'],
                        if (post['pollQuestion'] != null) 'pollQuestion': post['pollQuestion'],
                        if (post['pollOptions'] != null) 'pollOptions': post['pollOptions'],
                      },
                    });
                    FirebaseFirestore.instance.collection('posts').doc(postId).update({'shares': FieldValue.increment(1)}).catchError((_) {});
                    HapticFeedback.lightImpact();
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text('Shared to @$name!'), backgroundColor: _kBlue,
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
                  });
              });
          });
        })),
    ]));
}

class _SocialBtn extends StatelessWidget {
  final String icon, label; final Color color; final Color textColor; final VoidCallback onTap;
  const _SocialBtn({required this.icon, required this.color, required this.label,
    required this.onTap, this.textColor = Colors.white});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Container(width: 50, height: 50,
        decoration: BoxDecoration(color: color, shape: BoxShape.circle,
          boxShadow: [BoxShadow(color: color.withValues(alpha: 0.35), blurRadius: 8, offset: const Offset(0, 3))]),
        child: Center(child: Text(icon,
          style: TextStyle(color: textColor, fontSize: icon.length > 1 ? 13 : 20, fontWeight: FontWeight.w900)))),
      const SizedBox(height: 5),
      Text(label, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: const Color(0xFF0D1B2A))),
    ]),
  );
}

// ── Notifications sheet ───────────────────────────────────────────────────────
class _NotifSheet extends StatefulWidget {
  final String myUid;
  const _NotifSheet({required this.myUid});
  @override State<_NotifSheet> createState() => _NotifSheetState();
}
class _NotifSheetState extends State<_NotifSheet> {
  @override
  void initState() {
    super.initState();
    FirebaseFirestore.instance.collection('users').doc(widget.myUid)
        .collection('notifications')
        .where('read', isEqualTo: false).get().then((snap) {
      final batch = FirebaseFirestore.instance.batch();
      for (final doc in snap.docs) batch.update(doc.reference, {'read': true});
      batch.commit();
    });
  }

  IconData _iconFor(String type) {
    switch (type) {
      case 'post_like':         return Icons.favorite_rounded;
      case 'post_comment':      return Icons.comment_rounded;
      case 'comment_reply':     return Icons.reply_rounded;
      case 'mention':           return Icons.alternate_email_rounded;
      case 'post_mention':      return Icons.alternate_email_rounded;
      case 'post_saved':        return Icons.bookmark_rounded;
      case 'profile_view':      return Icons.visibility_rounded;
      case 'profile_milestone': return Icons.emoji_events_rounded;
      case 'friend_request':    return Icons.person_add_rounded;
      case 'follow':            return Icons.person_add_alt_1_rounded;
      case 'message':           return Icons.chat_bubble_rounded;
      case 'feed_post':         return Icons.post_add_rounded;
      default:                  return Icons.notifications_rounded;
    }
  }

  Color _colorFor(String type) {
    switch (type) {
      case 'post_like':         return Colors.red;
      case 'post_comment':      return _kBlue;
      case 'comment_reply':     return Colors.orange;
      case 'mention':           return const Color(0xFF7C3AED);
      case 'post_mention':      return const Color(0xFF7C3AED);
      case 'post_saved':        return Colors.amber[700]!;
      case 'profile_view':      return Colors.teal;
      case 'profile_milestone': return const Color(0xFFFFBB35);
      case 'friend_request':    return Colors.green;
      case 'follow':            return Colors.green;
      case 'message':           return _kBlue;
      case 'feed_post':         return Colors.deepOrange;
      default:                  return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) => Container(
    height: MediaQuery.of(context).size.height * 0.75,
    decoration: const BoxDecoration(color: Colors.white,
      borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    child: Column(children: [
      Container(margin: const EdgeInsets.only(top: 10, bottom: 8), width: 40, height: 4,
        decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
      const Padding(padding: EdgeInsets.fromLTRB(16, 4, 16, 12),
        child: Row(children: [
          Icon(Icons.notifications_rounded, color: _kBlue, size: 22),
          SizedBox(width: 8),
          Text('Notifications', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
        ])),
      const Divider(height: 1),
      Expanded(child: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('users').doc(widget.myUid)
            .collection('notifications').orderBy('createdAt', descending: true).limit(50).snapshots(),
        builder: (_, snap) {
          final docs = snap.data?.docs ?? [];
          if (snap.connectionState == ConnectionState.waiting)
            return const Center(child: ZyloLoader());
          if (docs.isEmpty) return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.notifications_none, size: 56, color: Colors.grey[300]),
            const SizedBox(height: 10),
            Text('No notifications yet', style: TextStyle(color: Colors.grey[600], fontSize: 15)),
          ]));
          return ListView.separated(
            padding: const EdgeInsets.symmetric(vertical: 4),
            itemCount: docs.length,
            separatorBuilder: (_, __) => const Divider(height: 1, indent: 72),
            itemBuilder: (_, i) {
              final d    = docs[i].data() as Map<String, dynamic>;
              final type = d['type'] as String? ?? '';
              final text = d['text'] as String? ?? '';
              final read = d['read'] as bool? ?? false;
              final fromPhoto = d['fromPhoto'] as String? ?? '';
              final ts   = d['createdAt'] as Timestamp?;
              final timeStr = ts != null ? _timeAgo(ts.toDate()) : '';
              return ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                leading: Stack(children: [
                  CircleAvatar(radius: 24,
                    backgroundColor: _colorFor(type).withValues(alpha: 0.12),
                    backgroundImage: fromPhoto.isNotEmpty ? NetworkImage(fromPhoto) : null,
                    child: fromPhoto.isEmpty
                      ? Icon(_iconFor(type), color: _colorFor(type), size: 22)
                      : null),
                  if (fromPhoto.isNotEmpty)
                    Positioned(bottom: 0, right: 0,
                      child: Container(width: 18, height: 18,
                        decoration: BoxDecoration(color: _colorFor(type), shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 1.5)),
                        child: Icon(_iconFor(type), color: Colors.white, size: 10))),
                ]),
                title: Text(text, style: TextStyle(fontSize: 13,
                  fontWeight: read ? FontWeight.w500 : FontWeight.w800)),
                subtitle: timeStr.isNotEmpty
                  ? Text(timeStr, style: TextStyle(fontSize: 11, color: Colors.grey[600]))
                  : null,
                tileColor: read ? null : _kBlue.withValues(alpha: 0.04),
                trailing: (type == 'post_comment' || type == 'comment_reply' || type == 'post_like' || type == 'mention' || type == 'post_mention' || type == 'post_saved' || type == 'feed_post')
                  ? Icon(Icons.chevron_right_rounded, color: Colors.grey[400])
                  : (type == 'message' || type == 'follow' || type == 'friend_request' || type == 'profile_view' || type == 'profile_milestone')
                  ? Icon(Icons.chevron_right_rounded, color: Colors.grey[400])
                  : null,
                onTap: () {
                  docs[i].reference.update({'read': true});
                  final fromUid  = d['fromUid']  as String? ?? '';
                  final fromName = d['fromName'] as String? ?? '';
                  final postId   = d['postId']   as String? ?? '';
                  final chatId   = d['chatId']   as String? ?? '';
                  final auth = Provider.of<AuthService>(context, listen: false);
                  Navigator.pop(context); // close sheet first
                  if ((type == 'post_like' || type == 'post_comment' ||
                       type == 'comment_reply' || type == 'mention' ||
                       type == 'post_mention' || type == 'post_saved' ||
                       type == 'feed_post') && postId.isNotEmpty) {
                    Navigator.push(context, MaterialPageRoute(
                      builder: (_) => PostCommentsScreen(
                        postId: postId, myUid: widget.myUid, auth: auth)));
                  } else if (type == 'message' && (chatId.isNotEmpty || fromUid.isNotEmpty)) {
                    Navigator.push(context, MaterialPageRoute(
                      builder: (_) => ChatRoomScreen(
                        targetId: fromUid, targetName: fromName)));
                  } else if ((type == 'follow' || type == 'friend_request' || type == 'profile_view') && fromUid.isNotEmpty) {
                    Navigator.push(context, MaterialPageRoute(
                      builder: (_) => ViewProfileScreen(targetUid: fromUid)));
                  }
                });
            });
        })),
    ]));

  String _timeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 1)  return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24)   return '${diff.inHours}h ago';
    if (diff.inDays < 7)     return '${diff.inDays}d ago';
    return '${dt.day}/${dt.month}';
  }
}

// ── Cached feed list shown while Firebase is loading / offline ────────────────
class _CachedFeedList extends StatelessWidget {
  final List<Map<String, dynamic>> posts;
  final String myUid;
  final AuthService auth;
  const _CachedFeedList({required this.posts, required this.myUid, required this.auth});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.only(bottom: 100),
      cacheExtent: 1200,
      itemCount: posts.length,
      itemBuilder: (_, i) {
        final data = posts[i];
        final postId = data['_docId'] as String? ?? '';
        final authorId = data['authorId'] as String? ?? '';
        if (data['isAdminPost'] == true) {
          return _AdminPostCard(post: data, postId: postId);
        }
        return _PrivacyAwarePostCard(
          post: data, postId: postId, myUid: myUid, auth: auth, authorId: authorId);
      },
    );
  }
}

// ── Lazy YouTube Embed — thumbnail first, player only loads on tap ────────────
class _LazyYoutubeEmbed extends StatefulWidget {
  final String url;
  const _LazyYoutubeEmbed({required this.url});
  @override
  State<_LazyYoutubeEmbed> createState() => _LazyYoutubeEmbedState();
}

class _LazyYoutubeEmbedState extends State<_LazyYoutubeEmbed> {
  bool _playerLoaded = false;
  YoutubePlayerController? _controller;
  String? _videoId;

  @override
  void initState() {
    super.initState();
    _videoId = YoutubePlayer.convertUrlToId(widget.url);
  }

  void _loadPlayer() {
    if (_videoId == null) return;
    _controller = YoutubePlayerController(
      initialVideoId: _videoId!,
      flags: const YoutubePlayerFlags(
        autoPlay: true,
        mute: false,
        enableCaption: false,
        forceHD: false,
        loop: false,
      ),
    );
    setState(() => _playerLoaded = true);
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_videoId == null) return _buildFallback();

    if (!_playerLoaded) {
      // Show thumbnail with play overlay — zero network cost, zero player weight
      final thumbUrl = 'https://img.youtube.com/vi/$_videoId/hqdefault.jpg';
      return GestureDetector(
        onTap: _loadPlayer,
        child: Stack(alignment: Alignment.center, children: [
          ZyloCachedImage(
            url: thumbUrl,
            width: null,
            height: 210,
            fit: BoxFit.cover,
            errorWidget: Container(
              height: 210, color: Colors.grey[200],
              child: const Icon(Icons.videocam_off, color: Colors.grey, size: 40)),
          ),
          Container(
            width: 60, height: 60,
            decoration: BoxDecoration(
              color: Colors.red,
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.4), blurRadius: 12, offset: const Offset(0, 4))]),
            child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 36)),
          Positioned(
            bottom: 10, right: 12,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(6)),
              child: const Text('YouTube', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w900)))),
        ]),
      );
    }

    // Player loaded — show real interactive player
    return YoutubePlayerBuilder(
      player: YoutubePlayer(
        controller: _controller!,
        showVideoProgressIndicator: true,
        progressIndicatorColor: Colors.red,
        progressColors: const ProgressBarColors(
          playedColor: Colors.red,
          handleColor: Colors.redAccent,
        ),
        bottomActions: [
          IconButton(
            icon: const Icon(Icons.replay_10_rounded, color: Colors.white, size: 22),
            onPressed: () {
              final pos = _controller!.value.position;
              final back = pos - const Duration(seconds: 10);
              _controller!.seekTo(back < Duration.zero ? Duration.zero : back);
            },
          ),
          CurrentPosition(),
          const SizedBox(width: 8),
          ProgressBar(isExpanded: true),
          const SizedBox(width: 8),
          RemainingDuration(),
          IconButton(
            icon: const Icon(Icons.forward_10_rounded, color: Colors.white, size: 22),
            onPressed: () {
              final pos      = _controller!.value.position;
              final duration = _controller!.value.metaData.duration;
              final forward  = pos + const Duration(seconds: 10);
              _controller!.seekTo(forward > duration ? duration : forward);
            },
          ),
          FullScreenButton(),
        ],
      ),
      builder: (ctx, player) => player,
    );
  }

  Widget _buildFallback() {
    return GestureDetector(
      onTap: () async {
        final uri = Uri.tryParse(widget.url);
        if (uri != null) await launchUrl(uri, mode: LaunchMode.externalApplication);
      },
      child: Container(
        margin: const EdgeInsets.fromLTRB(14, 8, 14, 0),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.red.withValues(alpha: 0.07),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.red.withValues(alpha: 0.25))),
        child: Row(children: [
          Container(width: 40, height: 40,
            decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(8)),
            child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 24)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('YouTube Video', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
            Text(widget.url,
              style: const TextStyle(color: Colors.red, fontSize: 11, decoration: TextDecoration.underline),
              maxLines: 1, overflow: TextOverflow.ellipsis),
          ])),
          const Icon(Icons.open_in_new_rounded, color: Colors.red, size: 16),
        ]),
      ),
    );
  }
}

// ── Downloads Manager ─────────────────────────────────────────────────────────
// Lightweight in-app download tracker (Telegram-style)

enum _DLStatus { downloading, done, error }

class _DLItem {
  final String id, name, url, type;
  final DateTime startedAt;
  String? localPath;
  _DLStatus status;
  double progress;
  String? errorMsg;
  CancelToken? _cancelToken;

  _DLItem({required this.id, required this.name, required this.url,
    required this.type, required this.startedAt,
    this.localPath, this.status = _DLStatus.downloading,
    this.progress = 0, this.errorMsg});
}

class _FeedDownloadsMgr {
  _FeedDownloadsMgr._();
  static final instance = _FeedDownloadsMgr._();

  final _items = <String, _DLItem>{};
  final _ctrl  = StreamController<List<_DLItem>>.broadcast();

  List<_DLItem> get all => List.of(_items.values.toList().reversed);
  Stream<List<_DLItem>> get stream => _ctrl.stream;
  void _notify() => _ctrl.add(all);

  String _id(String url) => url.hashCode.abs().toRadixString(16);

  bool isDownloaded(String url) => _items[_id(url)]?.status == _DLStatus.done;
  bool isDownloading(String url) => _items[_id(url)]?.status == _DLStatus.downloading;
  _DLItem? getItem(String url) => _items[_id(url)];

  Future<void> start({required String url, required String name, required String type}) async {
    final id = _id(url);
    final ex = _items[id];
    if (ex != null) {
      if (ex.status == _DLStatus.done && ex.localPath != null) {
        await OpenFilex.open(ex.localPath!);
        return;
      }
      if (ex.status == _DLStatus.downloading) return;
    }

    final item = _DLItem(id: id, name: name, url: url, type: type, startedAt: DateTime.now());
    _items[id] = item;
    _notify();

    try {
      Directory dir;
      if (Platform.isAndroid) {
        // Use app's external files dir (no permission needed on Android 10+)
        try {
          final extDirs = await getExternalStorageDirectories(type: StorageDirectory.downloads);
          if (extDirs != null && extDirs.isNotEmpty) {
            dir = Directory('${extDirs.first.path}/Zylo');
          } else {
            final docs = await getApplicationDocumentsDirectory();
            dir = Directory('${docs.path}/Downloads/Zylo');
          }
        } catch (_) {
          final docs = await getApplicationDocumentsDirectory();
          dir = Directory('${docs.path}/Downloads/Zylo');
        }
      } else {
        final docs = await getApplicationDocumentsDirectory();
        dir = Directory('${docs.path}/Downloads/Zylo');
      }
      if (!await dir.exists()) await dir.create(recursive: true);

      final safeName = name.replaceAll(RegExp(r'[<>:"/\\|?*\s]+'), '_');
      final savePath = '${dir.path}/$safeName';
      final ct = CancelToken();
      item._cancelToken = ct;

      await Dio().download(
        url, savePath,
        cancelToken: ct,
        onReceiveProgress: (recv, total) {
          if (total > 0 && !ct.isCancelled) {
            item.progress = recv / total;
            _notify();
          }
        },
        options: Options(receiveTimeout: const Duration(minutes: 15)),
      );

      item.localPath = savePath;
      item.status   = _DLStatus.done;
      item.progress = 1.0;
      _notify();
    } on DioException catch (e) {
      if (CancelToken.isCancel(e)) {
        _items.remove(id);
      } else {
        item.status   = _DLStatus.error;
        item.errorMsg = e.message ?? 'Download failed';
      }
      _notify();
    } catch (e) {
      item.status   = _DLStatus.error;
      item.errorMsg = e.toString();
      _notify();
    }
  }

  void cancel(String url) {
    final item = _items[_id(url)];
    item?._cancelToken?.cancel('User cancelled');
  }

  void remove(String url) {
    _items.remove(_id(url));
    _notify();
  }

  void clearAll() {
    _items.clear();
    _notify();
  }
}

// ── Downloads Screen (Telegram-style) ────────────────────────────────────────
class _DownloadsScreen extends StatelessWidget {
  const _DownloadsScreen();

  static const _blue   = Color(0xFF0284C7);
  static const _purple = Color(0xFF7C3AED);

  @override
  Widget build(BuildContext context) {
    final mgr = _FeedDownloadsMgr.instance;
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFD),
      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: _blue,
        elevation: 0,
        title: const Text('Downloads',
          style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20, color: _blue)),
        actions: [
          StreamBuilder<List<_DLItem>>(
            stream: mgr.stream,
            initialData: mgr.all,
            builder: (_, snap) {
              final items = snap.data ?? [];
              if (items.isEmpty) return const SizedBox.shrink();
              return TextButton.icon(
                onPressed: () => _confirmClear(context),
                icon: const Icon(Icons.delete_sweep_rounded, size: 18),
                label: const Text('Clear all',
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
              );
            }),
        ],
      ),
      body: StreamBuilder<List<_DLItem>>(
        stream: mgr.stream,
        initialData: mgr.all,
        builder: (_, snap) {
          final items = snap.data ?? [];
          if (items.isEmpty) {
            return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Container(
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_blue.withValues(alpha: 0.08), _purple.withValues(alpha: 0.08)],
                    begin: Alignment.topLeft, end: Alignment.bottomRight),
                  shape: BoxShape.circle),
                child: const Icon(Icons.download_rounded, size: 56, color: _blue)),
              const SizedBox(height: 20),
              const Text('No downloads yet',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: const Color(0xFF0D1B2A))),
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 48),
                child: Text(
                  'Files you download from posts will appear here — like Telegram',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: Colors.grey[700], height: 1.5))),
            ]));
          }

          return ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, i) => _DownloadTile(item: items[i]),
          );
        }),
    );
  }

  void _confirmClear(BuildContext context) {
    showDialog(context: context, builder: (_) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: const Text('Clear Downloads?', style: TextStyle(fontWeight: FontWeight.w900)),
      content: const Text('This removes all items from this list. Downloaded files remain on your device.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.red, foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
          onPressed: () {
            Navigator.pop(context);
            _FeedDownloadsMgr.instance.clearAll();
          },
          child: const Text('Clear', style: TextStyle(fontWeight: FontWeight.w700))),
      ]));
  }
}

class _DownloadTile extends StatelessWidget {
  final _DLItem item;
  const _DownloadTile({required this.item});

  Color get _typeColor {
    switch (item.type) {
      case 'audio':    return const Color(0xFF8B5CF6);
      case 'pdf':      return Colors.red;
      case 'apk':      return const Color(0xFF3DDC84);
      case 'document': return const Color(0xFF0284C7);
      case 'archive':  return Colors.orange;
        case 'image':    return Colors.teal;
      default:         return Colors.grey;
    }
  }

  IconData get _typeIcon {
    switch (item.type) {
      case 'audio':    return Icons.audiotrack_rounded;
      case 'pdf':      return Icons.picture_as_pdf_rounded;
      case 'apk':      return Icons.android_rounded;
      case 'document': return Icons.description_rounded;
      case 'archive':  return Icons.folder_zip_rounded;
        case 'image':    return Icons.image_rounded;
      default:         return Icons.insert_drive_file_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = _typeColor;
    final icon  = _typeIcon;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 8, offset: const Offset(0, 2))]),
      child: Row(children: [
        // File icon
        Container(
          width: 48, height: 48,
          decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, color: color, size: 24)),
        const SizedBox(width: 12),
        // Name + progress
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(item.name,
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: const Color(0xFF0D1B2A)),
            maxLines: 1, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 4),
          if (item.status == _DLStatus.downloading) ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: item.progress,
                minHeight: 4,
                backgroundColor: Colors.grey[200],
                valueColor: AlwaysStoppedAnimation<Color>(color))),
            const SizedBox(height: 3),
            Text('${(item.progress * 100).toStringAsFixed(0)}%',
              style: TextStyle(fontSize: 10, color: Colors.grey[700], fontWeight: FontWeight.w600)),
          ] else if (item.status == _DLStatus.done) ...[
            Row(children: [
              Icon(Icons.check_circle_rounded, color: Colors.green[600], size: 12),
              const SizedBox(width: 4),
              Text('Saved to Zylo folder',
                style: TextStyle(fontSize: 11, color: Colors.green[600], fontWeight: FontWeight.w600)),
            ]),
          ] else ...[
            Row(children: [
              const Icon(Icons.error_outline_rounded, color: Colors.red, size: 12),
              const SizedBox(width: 4),
              Expanded(child: Text(item.errorMsg ?? 'Download failed',
                style: const TextStyle(fontSize: 10, color: Colors.red),
                maxLines: 1, overflow: TextOverflow.ellipsis)),
            ]),
          ],
        ])),
        const SizedBox(width: 8),
        // Action button
        if (item.status == _DLStatus.done)
          GestureDetector(
            onTap: () => OpenFilex.open(item.localPath!),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: color.withValues(alpha: 0.3))),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.open_in_new_rounded, color: color, size: 14),
                const SizedBox(width: 4),
                Text('Open', style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700)),
              ])))
        else if (item.status == _DLStatus.downloading)
          GestureDetector(
            onTap: () => _FeedDownloadsMgr.instance.cancel(item.url),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                shape: BoxShape.circle),
              child: const Icon(Icons.close_rounded, color: Colors.grey, size: 18)))
        else
          GestureDetector(
            onTap: () => _FeedDownloadsMgr.instance.start(
              url: item.url, name: item.name, type: item.type),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(
                color: Colors.orange.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.orange.withValues(alpha: 0.3))),
              child: const Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.refresh_rounded, color: Colors.orange, size: 14),
                SizedBox(width: 4),
                Text('Retry', style: TextStyle(color: Colors.orange, fontSize: 12, fontWeight: FontWeight.w700)),
              ]))),
        // Long-press to delete
        const SizedBox(width: 4),
        GestureDetector(
          onLongPress: () => _FeedDownloadsMgr.instance.remove(item.url),
          child: const Icon(Icons.more_vert_rounded, color: Colors.grey, size: 18)),
      ]),
    );
  }
}

// ══════════════════════════════════════════════════════════════
//  Post Media Picker Sheet — in-app photo/video picker for posts
// ══════════════════════════════════════════════════════════════
class _PostMediaPickerSheet extends StatefulWidget {
  final int remainingImages;
  final void Function(List<File>) onImagesSelected;
  const _PostMediaPickerSheet({
    required this.remainingImages,
    required this.onImagesSelected,
  });
  @override
  State<_PostMediaPickerSheet> createState() => _PostMediaPickerSheetState();
}

class _PostMediaPickerSheetState extends State<_PostMediaPickerSheet> {
  static const _kBlue = Color(0xFF0284C7);

  Future<void> _pickFromGallery() async {
    Navigator.pop(context);
    final picker = ImagePicker();
    final picked = await picker.pickMultiImage(imageQuality: 85, limit: widget.remainingImages);
    if (picked.isEmpty) return;
    final files = picked.map((x) => File(x.path)).toList();
    widget.onImagesSelected(files);
  }

  Future<void> _takePhoto() async {
    Navigator.pop(context);
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.camera, imageQuality: 85);
    if (picked != null) widget.onImagesSelected([File(picked.path)]);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Center(child: Container(width: 40, height: 4,
          decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10)))),
        const SizedBox(height: 16),
        Row(children: [
          const Icon(Icons.perm_media_rounded, color: _kBlue, size: 20),
          const SizedBox(width: 8),
          const Text('Add Media', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: Color(0xFF0D1B2A))),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: _kBlue.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12)),
            child: Text('${widget.remainingImages} images left',
              style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: _kBlue))),
        ]),
        const SizedBox(height: 20),
        // Grid of options
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 2.6,
          children: [
            _MediaOption(
              icon: Icons.photo_library_rounded,
              label: 'Choose Photos',
              sublabel: 'Up to ${widget.remainingImages} images',
              color: _kBlue,
              onTap: _pickFromGallery),
            _MediaOption(
              icon: Icons.camera_alt_rounded,
              label: 'Take Photo',
              sublabel: 'Open camera',
              color: const Color(0xFF059669),
              onTap: _takePhoto),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: _kBlue.withValues(alpha: 0.05),
            borderRadius: BorderRadius.circular(14)),
          child: Row(children: [
            const Icon(Icons.auto_fix_high_rounded, color: _kBlue, size: 16),
            const SizedBox(width: 8),
            const Expanded(child: Text(
              'After selecting photos, you can crop, rotate & flip them before posting.',
              style: TextStyle(fontSize: 12, color: Color(0xFF0284C7), height: 1.4))),
          ]),
        ),
      ]),
    );
  }
}

class _MediaOption extends StatelessWidget {
  final IconData icon;
  final String label, sublabel;
  final Color color;
  final VoidCallback onTap;
  const _MediaOption({
    required this.icon, required this.label, required this.sublabel,
    required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.07),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withValues(alpha: 0.25))),
        child: Row(children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.12), shape: BoxShape.circle),
            child: Icon(icon, color: color, size: 18)),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
            Text(label, style: TextStyle(
              fontSize: 12, fontWeight: FontWeight.w800, color: color)),
            Text(sublabel, style: TextStyle(
              fontSize: 10, color: Colors.grey[600])),
          ])),
        ]),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
//  Compact Video Thumbnail — shown in feed card (tap → full post)
// ══════════════════════════════════════════════════════════════

// ══════════════════════════════════════════════════════════════

// ══════════════════════════════════════════════════════════════

// ══════════════════════════════════════════════════════════════
//  Video Edit Sheet — preview + trim selection + crop option
// ══════════════════════════════════════════════════════════════

// ══════════════════════════════════════════════════════════════
//  Video Edit Screen — Instagram-style, light UI
//  • 3-minute max (edit/trim shown)
//  • Videos under 3 min → trim screen  (all videos show edit)

// ── Helper: option tile ────────────────────────────────────────
class _OptionTile extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title, subtitle;
  final Widget trailing;
  final VoidCallback onTap;
  const _OptionTile({
    required this.icon, required this.iconColor,
    required this.title, required this.subtitle,
    required this.trailing, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFFF9FAFB),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFE5E7EB))),
        child: Row(children: [
          Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              color: iconColor.withValues(alpha: 0.12),
              shape: BoxShape.circle),
            child: Icon(icon, color: iconColor, size: 18)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: Color(0xFF111827))),
            Text(subtitle, style: TextStyle(fontSize: 11, color: Colors.grey.shade500)),
          ])),
          trailing,
        ])));
  }
}
