import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../widgets/zylo_cached_image.dart';

// ══════════════════════════════════════════════════════════════════════════════
//  Post Analytics Screen — Full dedicated analytics for post owner
//  Tracks: views (5s), clicks, reactions (who reacted), shares, comments
//  HTML posts: also tracks how many users opened the HTML app
// ══════════════════════════════════════════════════════════════════════════════

class PostAnalyticsScreen extends StatefulWidget {
  final String postId;
  final Map<String, dynamic> post;
  final bool isHtmlPost;

  const PostAnalyticsScreen({
    super.key,
    required this.postId,
    required this.post,
    this.isHtmlPost = false,
  });

  @override
  State<PostAnalyticsScreen> createState() => _PostAnalyticsScreenState();
}

class _PostAnalyticsScreenState extends State<PostAnalyticsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  static const _kPurple = Color(0xFF7C3AED);
  static const _reactionKeys = ['heart','fire','haha','wow','sad'];

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(
      length: widget.isHtmlPost ? 4 : 3, vsync: this);
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F8FC),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance
            .collection('posts').doc(widget.postId).snapshots(),
        builder: (ctx, snap) {
          final data = snap.data?.data() as Map<String, dynamic>? ?? widget.post;
          return _buildContent(data);
        },
      ),
    );
  }

  Widget _buildContent(Map<String, dynamic> data) {
    final views    = data['views']        as int? ?? 0;
    final clicks   = data['clicks']       as int? ?? 0;
    final shares   = data['shares']       as int? ?? 0;
    final comments = data['commentCount'] as int? ?? 0;
    final reposts  = data['reposts']      as int? ?? 0;
    final htmlOpens = data['htmlOpens']   as int? ?? 0;
    final createdAt = data['createdAt'] as Timestamp?;

    // Reactions
    int totalReactions = 0;
    final reactionCounts = <String, int>{};
    final reactionUids   = <String, List<String>>{};
    for (int i = 0; i < _reactionKeys.length; i++) {
      final k = _reactionKeys[i];
      final uids = (data['reactions_$k'] as List?)?.cast<String>() ?? [];
      reactionUids[k] = uids;
      reactionCounts[k] = uids.length;
      totalReactions += uids.length;
    }

    final engagementRate = views > 0
        ? ((totalReactions + comments + shares) / views * 100).toStringAsFixed(1)
        : '0.0';

    return NestedScrollView(
      headerSliverBuilder: (_, __) => [
        SliverAppBar(
          expandedHeight: 200,
          floating: false,
          pinned: true,
          backgroundColor: Colors.white,
          elevation: 0,
          leading: GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              margin: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.grey[100], shape: BoxShape.circle),
              child: const Icon(Icons.arrow_back_ios_new_rounded,
                size: 16, color: Colors.black87)),
          ),
          flexibleSpace: FlexibleSpaceBar(
            background: _buildHeader(data, views, clicks, shares,
                comments, totalReactions, engagementRate, htmlOpens, createdAt),
          ),
          bottom: TabBar(
            controller: _tabCtrl,
            labelColor: _kPurple,
            unselectedLabelColor: Colors.grey,
            indicatorColor: _kPurple,
            indicatorWeight: 3,
            labelStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12),
            tabs: [
              const Tab(text: 'Overview'),
              Tab(text: 'Reactions ($totalReactions)'),
              const Tab(text: 'Viewers'),
              if (widget.isHtmlPost) const Tab(text: 'HTML Opens'),
            ],
          ),
        ),
      ],
      body: TabBarView(
        controller: _tabCtrl,
        children: [
          _OverviewTab(
            views: views, clicks: clicks, shares: shares,
            comments: comments, reposts: reposts,
            totalReactions: totalReactions, engagementRate: engagementRate,
            htmlOpens: htmlOpens, isHtmlPost: widget.isHtmlPost,
            reactionCounts: reactionCounts),
          _ReactionsTab(
            reactionUids: reactionUids,
            reactionCounts: reactionCounts),
          _ViewersTab(postId: widget.postId),
          if (widget.isHtmlPost)
            _HtmlOpensTab(postId: widget.postId),
        ],
      ),
    );
  }

  Widget _buildHeader(
    Map<String, dynamic> data,
    int views, int clicks, int shares, int comments,
    int totalReactions, String engRate, int htmlOpens,
    Timestamp? createdAt,
  ) {
    final daysSince = createdAt != null
        ? DateTime.now().difference(createdAt.toDate()).inDays
        : 0;
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF7C3AED), Color(0xFF0284C7)],
          begin: Alignment.topLeft, end: Alignment.bottomRight),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 48, 20, 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(12)),
                child: const Icon(Icons.bar_chart_rounded,
                  color: Colors.white, size: 20)),
              const SizedBox(width: 10),
              const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Post Analytics',
                  style: TextStyle(color: Colors.white,
                    fontWeight: FontWeight.w900, fontSize: 18)),
                Text('Real-time performance insights',
                  style: TextStyle(color: Colors.white70, fontSize: 11)),
              ]),
            ]),
            const SizedBox(height: 16),
            Row(children: [
              _HeaderStat('👁️', '$views', 'Views'),
              const SizedBox(width: 12),
              _HeaderStat('❤️', '$totalReactions', 'Reacts'),
              const SizedBox(width: 12),
              _HeaderStat('💬', '$comments', 'Comments'),
              const SizedBox(width: 12),
              _HeaderStat('📊', '$engRate%', 'Engage'),
            ]),
            const SizedBox(height: 8),
            Text('Post is $daysSince day${daysSince == 1 ? '' : 's'} old',
              style: const TextStyle(color: Colors.white60, fontSize: 11)),
          ]),
        ),
      ),
    );
  }
}

// ── Small stat in header ──────────────────────────────────────────────────────
class _HeaderStat extends StatelessWidget {
  final String emoji, value, label;
  const _HeaderStat(this.emoji, this.value, this.label);
  @override
  Widget build(BuildContext context) => Expanded(
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(12)),
      child: Column(children: [
        Text(emoji, style: const TextStyle(fontSize: 14)),
        const SizedBox(height: 2),
        Text(value, style: const TextStyle(
          color: Colors.white, fontWeight: FontWeight.w900, fontSize: 14)),
        Text(label, style: const TextStyle(
          color: Colors.white70, fontSize: 9, fontWeight: FontWeight.w600)),
      ]),
    ),
  );
}

// ══════════════════════════════════════════════════════════════════════════════
//  Tab 1: Overview
// ══════════════════════════════════════════════════════════════════════════════
class _OverviewTab extends StatelessWidget {
  final int views, clicks, shares, comments, reposts, totalReactions, htmlOpens;
  final String engagementRate;
  final bool isHtmlPost;
  final Map<String, int> reactionCounts;

  static const _reactions    = ['❤️','🔥','😂','😮','😢'];
  static const _reactionKeys = ['heart','fire','haha','wow','sad'];

  const _OverviewTab({
    required this.views, required this.clicks,
    required this.shares, required this.comments, required this.reposts,
    required this.totalReactions, required this.engagementRate,
    required this.htmlOpens, required this.isHtmlPost,
    required this.reactionCounts});

  @override
  Widget build(BuildContext context) {
    final reach = views > 0
        ? ((totalReactions / views) * 100).toStringAsFixed(1)
        : '0.0';

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Stat grid
        _SectionLabel('📊 Core Stats'),
        const SizedBox(height: 10),
        GridView.count(
          crossAxisCount: 3, shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.05,
          children: [
            _StatTile(icon: Icons.visibility_rounded,   label: 'Views',    value: '$views',   color: Colors.blue),
            _StatTile(icon: Icons.touch_app_rounded,    label: 'Clicks',   value: '$clicks',  color: Colors.indigo),
            _StatTile(icon: Icons.favorite_rounded,     label: 'Reactions',value: '$totalReactions', color: Colors.red),
            _StatTile(icon: Icons.chat_bubble_rounded,  label: 'Comments', value: '$comments',color: Colors.green),
            _StatTile(icon: Icons.share_rounded,        label: 'Shares',   value: '$shares',  color: Colors.purple),
            _StatTile(icon: Icons.repeat_rounded,       label: 'Reposts',  value: '$reposts', color: Colors.orange),
          ]),

        if (isHtmlPost) ...[
          const SizedBox(height: 16),
          _SectionLabel('🌐 HTML App Stats'),
          const SizedBox(height: 10),
          _BigStatCard(
            icon: Icons.open_in_browser_rounded,
            label: 'Users Opened HTML App',
            value: '$htmlOpens',
            color: const Color(0xFFE8542A),
            subtitle: htmlOpens > 0
                ? 'That\'s ${(htmlOpens / (views > 0 ? views : 1) * 100).toStringAsFixed(1)}% of viewers opened your app'
                : 'No one has opened your HTML app yet'),
        ],

        const SizedBox(height: 16),
        _SectionLabel('📈 Performance'),
        const SizedBox(height: 10),
        _PerformanceCard(
          engagementRate: engagementRate,
          reach: reach,
          views: views,
          totalReactions: totalReactions),

        const SizedBox(height: 16),
        _SectionLabel('😀 Reaction Breakdown'),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.grey.shade100),
            boxShadow: [BoxShadow(
              color: Colors.black.withValues(alpha: 0.04), blurRadius: 8)]),
          child: Column(
            children: List.generate(_reactionKeys.length, (i) {
              final k = _reactionKeys[i];
              final count = reactionCounts[k] ?? 0;
              final pct = totalReactions > 0 ? count / totalReactions : 0.0;
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Row(children: [
                  Text(_reactions[i], style: const TextStyle(fontSize: 20)),
                  const SizedBox(width: 10),
                  Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Text(['Love','Fire','Haha','Wow','Sad'][i],
                        style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                      const Spacer(),
                      Text('$count', style: const TextStyle(
                        fontWeight: FontWeight.w900, fontSize: 13, color: Color(0xFF7C3AED))),
                    ]),
                    const SizedBox(height: 4),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: pct, minHeight: 6,
                        backgroundColor: Colors.grey[100],
                        valueColor: AlwaysStoppedAnimation(
                          [Colors.red, Colors.orange, Colors.amber,
                           Colors.blue, Colors.blueGrey][i]))),
                  ])),
                ]));
            }),
          ),
        ),
        const SizedBox(height: 80),
      ],
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);
  @override
  Widget build(BuildContext context) => Text(text,
    style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14,
      color: Color(0xFF0D1B2A)));
}

class _StatTile extends StatelessWidget {
  final IconData icon;
  final String label, value;
  final Color color;
  const _StatTile({required this.icon, required this.label,
    required this.value, required this.color});
  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      color: color.withValues(alpha: 0.07), borderRadius: BorderRadius.circular(14),
      border: Border.all(color: color.withValues(alpha: 0.15))),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Container(width: 36, height: 36,
        decoration: BoxDecoration(color: color.withValues(alpha: 0.13), shape: BoxShape.circle),
        child: Icon(icon, color: color, size: 18)),
      const SizedBox(height: 6),
      Text(value, style: TextStyle(
        fontWeight: FontWeight.w900, fontSize: 17, color: color)),
      Text(label, style: const TextStyle(
        fontSize: 9, color: Colors.grey, fontWeight: FontWeight.w600),
        textAlign: TextAlign.center),
    ]));
}

class _BigStatCard extends StatelessWidget {
  final IconData icon;
  final String label, value, subtitle;
  final Color color;
  const _BigStatCard({required this.icon, required this.label,
    required this.value, required this.subtitle, required this.color});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: color.withValues(alpha: 0.07),
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: color.withValues(alpha: 0.2))),
    child: Row(children: [
      Container(width: 52, height: 52,
        decoration: BoxDecoration(color: color.withValues(alpha: 0.15), shape: BoxShape.circle),
        child: Icon(icon, color: color, size: 26)),
      const SizedBox(width: 14),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(value, style: TextStyle(
          fontWeight: FontWeight.w900, fontSize: 28, color: color)),
        Text(label, style: const TextStyle(
          fontWeight: FontWeight.w700, fontSize: 13, color: Color(0xFF0D1B2A))),
        const SizedBox(height: 2),
        Text(subtitle, style: TextStyle(fontSize: 11, color: Colors.grey[600])),
      ])),
    ]));
}

class _PerformanceCard extends StatelessWidget {
  final String engagementRate, reach;
  final int views, totalReactions;
  const _PerformanceCard({required this.engagementRate, required this.reach,
    required this.views, required this.totalReactions});
  @override
  Widget build(BuildContext context) {
    String insight;
    if (views == 0) {
      insight = '📭 No views yet. Share your post to get started!';
    } else if (double.parse(engagementRate) > 15) {
      insight = '🚀 Excellent! Your post is performing really well.';
    } else if (double.parse(engagementRate) > 5) {
      insight = '📈 Good engagement! Keep posting consistently.';
    } else {
      insight = '💡 Post more frequently to boost your engagement.';
    }
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [const Color(0xFF7C3AED).withValues(alpha: 0.08),
                   const Color(0xFF0284C7).withValues(alpha: 0.06)]),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF7C3AED).withValues(alpha: 0.15))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          _EngStat('Engagement', '$engagementRate%', const Color(0xFF7C3AED)),
          const SizedBox(width: 12),
          _EngStat('Reaction Rate', '$reach%', Colors.red),
        ]),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Colors.white, borderRadius: BorderRadius.circular(10)),
          child: Row(children: [
            const Icon(Icons.lightbulb_outline_rounded,
              color: Color(0xFF7C3AED), size: 16),
            const SizedBox(width: 8),
            Expanded(child: Text(insight,
              style: const TextStyle(fontSize: 12, color: Color(0xFF7C3AED),
                fontWeight: FontWeight.w600))),
          ])),
      ]));
  }
}

class _EngStat extends StatelessWidget {
  final String label, value;
  final Color color;
  const _EngStat(this.label, this.value, this.color);
  @override
  Widget build(BuildContext context) => Expanded(
    child: Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(10)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(value, style: TextStyle(
          fontWeight: FontWeight.w900, fontSize: 20, color: color)),
        Text(label, style: TextStyle(
          fontSize: 11, color: color.withValues(alpha: 0.8), fontWeight: FontWeight.w600)),
      ])));
}

// ══════════════════════════════════════════════════════════════════════════════
//  Tab 2: Reactions — who reacted with what
// ══════════════════════════════════════════════════════════════════════════════
class _ReactionsTab extends StatefulWidget {
  final Map<String, List<String>> reactionUids;
  final Map<String, int> reactionCounts;
  const _ReactionsTab({
    required this.reactionUids,
    required this.reactionCounts});
  @override
  State<_ReactionsTab> createState() => _ReactionsTabState();
}

class _ReactionsTabState extends State<_ReactionsTab> {
  static const _reactions     = ['❤️','🔥','😂','😮','😢'];
  static const _reactionKeys  = ['heart','fire','haha','wow','sad'];
  static const _reactionLabels = ['Love','Fire','Haha','Wow','Sad'];
  int _selectedFilter = -1; // -1 = All

  @override
  Widget build(BuildContext context) {
    // Collect all unique uids + their reaction
    final allItems = <Map<String, String>>[];
    for (int i = 0; i < _reactionKeys.length; i++) {
      final uids = widget.reactionUids[_reactionKeys[i]] ?? [];
      for (final uid in uids) {
        allItems.add({'uid': uid, 'key': _reactionKeys[i], 'emoji': _reactions[i]});
      }
    }
    final filtered = _selectedFilter < 0
        ? allItems
        : allItems.where((m) => m['key'] == _reactionKeys[_selectedFilter]).toList();

    return Column(children: [
      // Filter chips
      SizedBox(
        height: 50,
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          scrollDirection: Axis.horizontal,
          children: [
            _FilterChip(
              label: 'All (${allItems.length})',
              selected: _selectedFilter < 0,
              onTap: () => setState(() => _selectedFilter = -1)),
            ...List.generate(_reactionKeys.length, (i) {
              final cnt = widget.reactionCounts[_reactionKeys[i]] ?? 0;
              if (cnt == 0) return const SizedBox.shrink();
              return _FilterChip(
                label: '${_reactions[i]} ${_reactionLabels[i]} ($cnt)',
                selected: _selectedFilter == i,
                onTap: () => setState(() => _selectedFilter = i));
            }),
          ],
        ),
      ),
      if (filtered.isEmpty)
        const Expanded(child: Center(
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text('😶', style: TextStyle(fontSize: 40)),
            SizedBox(height: 12),
            Text('No reactions yet', style: TextStyle(
              color: Colors.grey, fontWeight: FontWeight.w600)),
          ])))
      else
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            itemCount: filtered.length,
            itemBuilder: (_, i) => _ReactionUserTile(
              uid: filtered[i]['uid']!,
              emoji: filtered[i]['emoji']!,
              reactionLabel: _reactionLabels[
                _reactionKeys.indexOf(filtered[i]['key']!)]),
          ),
        ),
    ]);
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _FilterChip({required this.label, required this.selected, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: selected ? const Color(0xFF7C3AED) : Colors.grey[100],
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: selected ? const Color(0xFF7C3AED) : Colors.grey[200]!)),
      child: Text(label, style: TextStyle(
        fontSize: 12, fontWeight: FontWeight.w700,
        color: selected ? Colors.white : Colors.grey[700]))));
}

class _ReactionUserTile extends StatelessWidget {
  final String uid, emoji, reactionLabel;
  const _ReactionUserTile({
    required this.uid, required this.emoji, required this.reactionLabel});
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
      builder: (_, snap) {
        final u = snap.data?.data() as Map<String, dynamic>? ?? {};
        final name  = u['username'] as String? ?? 'User';
        final photo = u['photoURL'] as String? ?? '';
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.grey.shade100),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 4)]),
          child: Row(children: [
            Stack(children: [
              photo.isNotEmpty
                ? ZyloCachedImage(
                    url: photo,
                    imageBuilder: (_, ip) => CircleAvatar(radius: 22, backgroundImage: ip),
                    placeholder: (_, __) => const CircleAvatar(radius: 22,
                      backgroundColor: Color(0xFFE5E7EB)))
                : CircleAvatar(
                    radius: 22,
                    backgroundColor: const Color(0xFF7C3AED).withValues(alpha: 0.1),
                    child: Text(name.isNotEmpty ? name[0].toUpperCase() : '?',
                      style: const TextStyle(fontWeight: FontWeight.w900,
                        color: Color(0xFF7C3AED)))),
              Positioned(
                right: 0, bottom: 0,
                child: Container(
                  width: 18, height: 18,
                  decoration: BoxDecoration(
                    color: Colors.white, shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.1), blurRadius: 4)]),
                  child: Center(child: Text(emoji,
                    style: const TextStyle(fontSize: 10))))),
            ]),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('@$name', style: const TextStyle(
                fontWeight: FontWeight.w800, fontSize: 14)),
              Text('Reacted with $reactionLabel',
                style: TextStyle(fontSize: 12, color: Colors.grey[600])),
            ])),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFF7C3AED).withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(20)),
              child: Text(emoji, style: const TextStyle(fontSize: 16))),
          ]),
        );
      },
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  Tab 3: Viewers — who viewed (5s view tracked)
// ══════════════════════════════════════════════════════════════════════════════
class _ViewersTab extends StatelessWidget {
  final String postId;
  const _ViewersTab({required this.postId});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('posts').doc(postId)
          .collection('viewers')
          .orderBy('viewedAt', descending: true)
          .snapshots(),
      builder: (_, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(
            color: Color(0xFF7C3AED)));
        }
        final docs = snap.data?.docs ?? [];
        if (docs.isEmpty) {
          return const Center(
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text('👁️', style: TextStyle(fontSize: 40)),
              SizedBox(height: 12),
              Text('No 5-second views yet',
                style: TextStyle(color: Colors.grey, fontWeight: FontWeight.w600)),
              SizedBox(height: 4),
              Text('Users who view your post for 5+ seconds\nwill appear here',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey, fontSize: 12)),
            ]));
        }
        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: docs.length,
          itemBuilder: (_, i) {
            final d   = docs[i].data() as Map<String, dynamic>;
            final uid = d['uid'] as String? ?? '';
            final ts  = d['viewedAt'] as Timestamp?;
            final timeAgo = ts != null ? _timeAgo(ts.toDate()) : '';
            return _ViewerTile(uid: uid, timeAgo: timeAgo, index: i + 1);
          });
      });
  }

  String _timeAgo(DateTime dt) {
    final d = DateTime.now().difference(dt);
    if (d.inMinutes < 1) return 'just now';
    if (d.inMinutes < 60) return '${d.inMinutes}m ago';
    if (d.inHours < 24) return '${d.inHours}h ago';
    return '${d.inDays}d ago';
  }
}

class _ViewerTile extends StatelessWidget {
  final String uid, timeAgo;
  final int index;
  const _ViewerTile({required this.uid, required this.timeAgo, required this.index});
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
      builder: (_, snap) {
        final u     = snap.data?.data() as Map<String, dynamic>? ?? {};
        final name  = u['username'] as String? ?? 'User';
        final photo = u['photoURL'] as String? ?? '';
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.grey.shade100),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 4)]),
          child: Row(children: [
            Container(
              width: 24, height: 24,
              decoration: BoxDecoration(
                color: Colors.blue.withValues(alpha: 0.1), shape: BoxShape.circle),
              child: Center(child: Text('$index',
                style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900,
                  color: Colors.blue)))),
            const SizedBox(width: 10),
            photo.isNotEmpty
              ? ZyloCachedImage(
                  url: photo,
                  imageBuilder: (_, ip) => CircleAvatar(radius: 20, backgroundImage: ip),
                  placeholder: (_, __) => const CircleAvatar(radius: 20))
              : CircleAvatar(
                  radius: 20,
                  backgroundColor: Colors.blue.withValues(alpha: 0.1),
                  child: Text(name.isNotEmpty ? name[0].toUpperCase() : '?',
                    style: const TextStyle(fontWeight: FontWeight.w900, color: Colors.blue))),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('@$name', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
              Text('Viewed $timeAgo', style: TextStyle(fontSize: 11, color: Colors.grey[600])),
            ])),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: Colors.blue.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(20)),
              child: const Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.timer_outlined, size: 10, color: Colors.blue),
                SizedBox(width: 3),
                Text('5s+', style: TextStyle(fontSize: 10,
                  fontWeight: FontWeight.w700, color: Colors.blue)),
              ])),
          ]));
      });
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  Tab 4 (HTML only): HTML Opens — who opened the HTML app
// ══════════════════════════════════════════════════════════════════════════════
class _HtmlOpensTab extends StatelessWidget {
  final String postId;
  const _HtmlOpensTab({required this.postId});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('posts').doc(postId)
          .collection('htmlOpeners')
          .orderBy('openedAt', descending: true)
          .snapshots(),
      builder: (_, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(
            color: Color(0xFFE8542A)));
        }
        final docs = snap.data?.docs ?? [];
        if (docs.isEmpty) {
          return Center(
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: const Color(0xFFE8542A).withValues(alpha: 0.08),
                  shape: BoxShape.circle),
                child: const Icon(Icons.code_rounded,
                  color: Color(0xFFE8542A), size: 40)),
              const SizedBox(height: 12),
              const Text('No HTML App Opens Yet',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
              const SizedBox(height: 4),
              Text('Users who tap "Run" on your\nHTML app will appear here',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey[600], fontSize: 12)),
            ]));
        }
        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: docs.length,
          itemBuilder: (_, i) {
            final d   = docs[i].data() as Map<String, dynamic>;
            final uid = d['uid'] as String? ?? '';
            final ts  = d['openedAt'] as Timestamp?;
            final opens = d['openCount'] as int? ?? 1;
            final timeAgo = ts != null ? _timeAgo(ts.toDate()) : '';
            return _HtmlOpenerTile(uid: uid, timeAgo: timeAgo, opens: opens);
          });
      });
  }

  String _timeAgo(DateTime dt) {
    final d = DateTime.now().difference(dt);
    if (d.inMinutes < 1) return 'just now';
    if (d.inMinutes < 60) return '${d.inMinutes}m ago';
    if (d.inHours < 24) return '${d.inHours}h ago';
    return '${d.inDays}d ago';
  }
}

class _HtmlOpenerTile extends StatelessWidget {
  final String uid, timeAgo;
  final int opens;
  const _HtmlOpenerTile({required this.uid, required this.timeAgo, required this.opens});
  static const _kOrange = Color(0xFFE8542A);
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
      builder: (_, snap) {
        final u     = snap.data?.data() as Map<String, dynamic>? ?? {};
        final name  = u['username'] as String? ?? 'User';
        final photo = u['photoURL'] as String? ?? '';
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _kOrange.withValues(alpha: 0.12)),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 4)]),
          child: Row(children: [
            photo.isNotEmpty
              ? ZyloCachedImage(
                  url: photo,
                  imageBuilder: (_, ip) => CircleAvatar(radius: 22, backgroundImage: ip),
                  placeholder: (_, __) => const CircleAvatar(radius: 22))
              : CircleAvatar(
                  radius: 22,
                  backgroundColor: _kOrange.withValues(alpha: 0.1),
                  child: Text(name.isNotEmpty ? name[0].toUpperCase() : '?',
                    style: const TextStyle(fontWeight: FontWeight.w900, color: _kOrange))),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('@$name', style: const TextStyle(
                fontWeight: FontWeight.w800, fontSize: 14)),
              Text('Opened HTML App $timeAgo',
                style: TextStyle(fontSize: 11, color: Colors.grey[600])),
            ])),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: _kOrange.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(20)),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.open_in_browser_rounded,
                  size: 12, color: _kOrange),
                const SizedBox(width: 4),
                Text('${opens}x', style: const TextStyle(
                  fontSize: 12, fontWeight: FontWeight.w800, color: _kOrange)),
              ])),
          ]));
      });
  }
}
