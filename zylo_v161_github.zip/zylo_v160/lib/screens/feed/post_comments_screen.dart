import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../services/auth_service.dart';
import '../../services/notification_service.dart';
import '../profile/view_profile_screen.dart';
import '../../widgets/zylo_avatar.dart';

const _kBlue = Color(0xFF0284C7);

class PostCommentsScreen extends StatefulWidget {
  final String postId, myUid;
  final AuthService auth;
  const PostCommentsScreen({super.key, required this.postId, required this.myUid, required this.auth});
  @override State<PostCommentsScreen> createState() => _PostCommentsScreenState();
}

class _PostCommentsScreenState extends State<PostCommentsScreen> {
  final _commentCtrl = TextEditingController();
  String? _replyToId;
  String? _replyToName;
  bool _isSending = false;
  List<String> _mentionSuggestions = [];
  bool _showMentions = false;
  int _mentionStart = -1;
  final _scrollCtrl = ScrollController();

  @override void dispose() { _commentCtrl.dispose(); _scrollCtrl.dispose(); super.dispose(); }

  void _onTextChanged(String val) {
    setState(() {});
    final cursor = _commentCtrl.selection.baseOffset;
    if (cursor < 0) return;
    final before = val.substring(0, cursor);
    final match = RegExp(r'@(\w*)$').firstMatch(before);
    if (match != null) {
      _mentionStart = match.start;
      _fetchMentions(match.group(1) ?? '');
    } else {
      setState(() { _showMentions = false; _mentionSuggestions = []; });
    }
  }

  void _fetchMentions(String q) async {
    if (q.isEmpty) { setState(() => _showMentions = false); return; }
    final snap = await FirebaseFirestore.instance.collection('users')
        .where('username', isGreaterThanOrEqualTo: q)
        .where('username', isLessThanOrEqualTo: '$q\uf8ff')
        .limit(4).get();
    if (mounted) setState(() {
      _mentionSuggestions = snap.docs.map((d) => d['username'] as String).toList();
      _showMentions = _mentionSuggestions.isNotEmpty;
    });
  }

  void _applyMention(String u) {
    final text = _commentCtrl.text;
    final cursor = _commentCtrl.selection.baseOffset;
    final newText = text.substring(0, _mentionStart) + '@$u ' + text.substring(cursor);
    _commentCtrl.text = newText;
    _commentCtrl.selection = TextSelection.fromPosition(TextPosition(offset: _mentionStart + u.length + 2));
    setState(() { _showMentions = false; });
  }

  Future<void> _sendComment() async {
    final text = _commentCtrl.text.trim();
    if (text.isEmpty) return;
    setState(() => _isSending = true);
    try {
      final auth = widget.auth;
      final myName = auth.userName ?? 'user';
      final myPhoto = auth.photoURL ?? '';

      await FirebaseFirestore.instance.collection('posts').doc(widget.postId)
          .collection('comments').add({
            'authorId': widget.myUid,
            'authorName': myName,
            'authorPhoto': myPhoto,
            'text': text,
            'likes': [],
            'replyToId': _replyToId,
            'replyToName': _replyToName,
            'createdAt': FieldValue.serverTimestamp(),
          });
      // Increment comment count
      FirebaseFirestore.instance.collection('posts').doc(widget.postId)
          .update({'commentCount': FieldValue.increment(1)}).catchError((_) {});

      // Notification: post author (comment notification)
      final postDoc = await FirebaseFirestore.instance.collection('posts').doc(widget.postId).get();
      final postData = postDoc.data() as Map<String, dynamic>? ?? {};
      final postAuthorId = postData['authorId'] as String? ?? '';
      if (postAuthorId.isNotEmpty && postAuthorId != widget.myUid) {
        FirebaseFirestore.instance.collection('users').doc(postAuthorId)
            .collection('notifications').add({
          'type': _replyToId != null ? 'comment_reply' : 'post_comment',
          'text': _replyToId != null
              ? '@$myName replied to a comment on your post'
              : '@$myName commented on your post',
          'fromUid': widget.myUid,
          'fromName': myName,
          'fromPhoto': myPhoto,
          'postId': widget.postId,
          'read': false,
          'createdAt': FieldValue.serverTimestamp(),
        });
        // Push notification to post author
        NotificationService().sendCommentNotification(
          toUid: postAuthorId,
          fromName: myName,
          fromPhotoUrl: myPhoto.isNotEmpty ? myPhoto : null,
          postId: widget.postId,
          isReply: _replyToId != null,
        ).catchError((_) {});
      }

      // Notification: reply to comment author
      if (_replyToId != null) {
        final replyDoc = await FirebaseFirestore.instance.collection('posts')
            .doc(widget.postId).collection('comments').doc(_replyToId).get();
        final replyData = replyDoc.data() as Map<String, dynamic>? ?? {};
        final replyAuthorId = replyData['authorId'] as String? ?? '';
        if (replyAuthorId.isNotEmpty && replyAuthorId != widget.myUid && replyAuthorId != postAuthorId) {
          FirebaseFirestore.instance.collection('users').doc(replyAuthorId)
              .collection('notifications').add({
            'type': 'comment_reply',
            'text': '@$myName replied to your comment',
            'fromUid': widget.myUid,
            'fromName': myName,
            'fromPhoto': myPhoto,
            'postId': widget.postId,
            'read': false,
            'createdAt': FieldValue.serverTimestamp(),
          });
          // Push notification to comment author
          NotificationService().sendCommentNotification(
            toUid: replyAuthorId,
            fromName: myName,
            fromPhotoUrl: myPhoto.isNotEmpty ? myPhoto : null,
            postId: widget.postId,
            isReply: true,
          ).catchError((_) {});
        }
      }

      // Notification: @mentions
      final mentionRegex = RegExp(r'@(\w+)');
      final mentions = mentionRegex.allMatches(text).map((m) => m.group(1)!).toSet();
      for (final username in mentions) {
        final mentionSnap = await FirebaseFirestore.instance.collection('users')
            .where('username', isEqualTo: username).limit(1).get();
        if (mentionSnap.docs.isNotEmpty) {
          final mentionedUid = mentionSnap.docs.first.id;
          if (mentionedUid != widget.myUid) {
            FirebaseFirestore.instance.collection('users').doc(mentionedUid)
                .collection('notifications').add({
              'type': 'mention',
              'text': '@$myName mentioned you in a comment',
              'fromUid': widget.myUid,
              'fromName': myName,
              'fromPhoto': myPhoto,
              'postId': widget.postId,
              'read': false,
              'createdAt': FieldValue.serverTimestamp(),
            });
          }
        }
      }

      _commentCtrl.clear();
      setState(() { _replyToId = null; _replyToName = null; _isSending = false; });
      HapticFeedback.lightImpact();
    } catch (_) {
      setState(() => _isSending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: const Color(0xFFF8FAFD),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18, color: Colors.black87),
          onPressed: () => Navigator.pop(context)),
        title: const Text('Discussion', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: Colors.black87)),
        actions: [
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance.collection('posts').doc(widget.postId)
                .collection('comments').snapshots(),
            builder: (_, snap) {
              final count = snap.data?.docs.length ?? 0;
              return Padding(padding: const EdgeInsets.only(right: 16),
                child: Center(child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(color: _kBlue.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(12)),
                  child: Text('$count comments', style: const TextStyle(color: _kBlue, fontWeight: FontWeight.w700, fontSize: 12)))));
            }),
        ],
      ),
      body: SafeArea(
        child: Column(children: [
        // ── Post preview ─────────────────────────────────────────────────────
        StreamBuilder<DocumentSnapshot>(
          stream: FirebaseFirestore.instance.collection('posts').doc(widget.postId).snapshots(),
          builder: (_, snap) {
            final post = snap.data?.data() as Map<String, dynamic>? ?? {};
            final text = post['text'] as String? ?? '';
            final authorName = post['authorName'] as String? ?? '';
            if (text.isEmpty) return const SizedBox.shrink();
            return Container(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(bottom: BorderSide(color: Colors.grey.withValues(alpha: 0.1)))),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(width: 3, height: 40, margin: const EdgeInsets.only(right: 12),
                  decoration: BoxDecoration(color: _kBlue, borderRadius: BorderRadius.circular(2))),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('@$authorName', style: const TextStyle(color: _kBlue, fontWeight: FontWeight.w800, fontSize: 12)),
                  const SizedBox(height: 3),
                  Text(text.length > 120 ? '${text.substring(0, 120)}...' : text,
                    style: const TextStyle(fontSize: 13, color: Colors.black54, height: 1.4)),
                ])),
              ]),
            );
          }),

        // ── Comments ─────────────────────────────────────────────────────────
        Expanded(child: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance.collection('posts').doc(widget.postId)
              .collection('comments').orderBy('createdAt').snapshots(),
          builder: (_, snap) {
            if (snap.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator(color: _kBlue));
            }
            final docs = snap.data?.docs ?? [];
            if (docs.isEmpty) {
              return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.chat_bubble_outline, size: 52, color: Colors.grey[200]),
                const SizedBox(height: 12),
                Text('No comments yet', style: TextStyle(color: Colors.grey[400], fontWeight: FontWeight.w600, fontSize: 15)),
                const SizedBox(height: 6),
                Text('Be the first to comment!', style: TextStyle(color: Colors.grey[300], fontSize: 12)),
              ]));
            }
            return ListView.builder(
              controller: _scrollCtrl,
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 16),
              itemCount: docs.length,
              itemBuilder: (_, i) {
                final d = docs[i].data() as Map<String, dynamic>;
                return _CommentCard(
                  data: d, commentId: docs[i].id, postId: widget.postId,
                  myUid: widget.myUid, auth: widget.auth,
                  onReply: (id, name) => setState(() {
                    _replyToId = id;
                    _replyToName = name;
                    _commentCtrl.text = '@$name ';
                    _commentCtrl.selection = TextSelection.fromPosition(TextPosition(offset: _commentCtrl.text.length));
                  }),
                );
              });
          })),

        // ── Reply indicator ───────────────────────────────────────────────────
        if (_replyToName != null)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            color: _kBlue.withValues(alpha: 0.05),
            child: Row(children: [
              const Icon(Icons.reply_rounded, size: 16, color: _kBlue),
              const SizedBox(width: 6),
              Text('Replying to @$_replyToName', style: const TextStyle(color: _kBlue, fontSize: 12, fontWeight: FontWeight.w700)),
              const Spacer(),
              GestureDetector(onTap: () => setState(() { _replyToId = null; _replyToName = null; _commentCtrl.clear(); }),
                child: const Icon(Icons.close, size: 16, color: Colors.grey)),
            ]),
          ),

        // ── @mention suggestions ───────────────────────────────────────────
        if (_showMentions && _mentionSuggestions.isNotEmpty)
          Container(
            color: Colors.white,
            child: Column(children: _mentionSuggestions.map((u) => ListTile(
              dense: true,
              leading: const Icon(Icons.alternate_email, color: _kBlue, size: 16),
              title: Text('@$u', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: _kBlue)),
              onTap: () => _applyMention(u),
            )).toList()),
          ),

        // ── Input bar ─────────────────────────────────────────────────────────
        Container(
          padding: EdgeInsets.only(
            left: 12, right: 12, top: 10,
            bottom: MediaQuery.of(context).viewInsets.bottom + 12),
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border(top: BorderSide(color: Colors.grey.withValues(alpha: 0.12)))),
          child: Row(children: [
            // My avatar
            ZyloAvatar(
              photoUrl: (widget.auth.photoURL ?? '').isNotEmpty ? widget.auth.photoURL : null,
              radius: 16,
            ),
            const SizedBox(width: 10),
            Expanded(child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFFF1F5F9),
                borderRadius: BorderRadius.circular(20)),
              child: TextField(
                controller: _commentCtrl,
                onChanged: _onTextChanged,
                style: const TextStyle(fontSize: 14, color: Colors.black87),
                decoration: const InputDecoration(
                  hintText: 'Add a comment... @mention someone',
                  hintStyle: TextStyle(color: Colors.grey, fontSize: 13),
                  border: InputBorder.none, isDense: true),
                maxLines: null,
              ),
            )),
            const SizedBox(width: 10),
            _isSending
              ? const SizedBox(width: 32, height: 32, child: CircularProgressIndicator(strokeWidth: 2, color: _kBlue))
              : GestureDetector(
                  onTap: _commentCtrl.text.trim().isNotEmpty ? _sendComment : null,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 38, height: 38,
                    decoration: BoxDecoration(
                      color: _commentCtrl.text.trim().isNotEmpty ? _kBlue : Colors.grey[300],
                      shape: BoxShape.circle,
                      boxShadow: _commentCtrl.text.trim().isNotEmpty
                        ? [BoxShadow(color: _kBlue.withValues(alpha: 0.35), blurRadius: 8, offset: const Offset(0, 3))]
                        : []),
                    child: const Icon(Icons.send_rounded, color: Colors.white, size: 18))),
          ]),
        ),
        ]),
      ),
    );
  }
}

// ── Comment Card ──────────────────────────────────────────────────────────────
class _CommentCard extends StatelessWidget {
  final Map<String, dynamic> data;
  final String commentId, postId, myUid;
  final AuthService auth;
  final Function(String id, String name) onReply;

  const _CommentCard({
    required this.data, required this.commentId, required this.postId,
    required this.myUid, required this.auth, required this.onReply,
  });

  @override
  Widget build(BuildContext context) {
    final authorId = data['authorId'] as String? ?? '';
    final authorName = data['authorName'] as String? ?? 'user';
    final authorPhoto = data['authorPhoto'] as String? ?? '';
    final text = data['text'] as String? ?? '';
    final likes = (data['likes'] as List?)?.cast<String>() ?? [];
    final replyToName = data['replyToName'] as String?;
    final createdAt = data['createdAt'] as Timestamp?;
    final isLiked = likes.contains(myUid);
    final isMyComment = authorId == myUid;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Avatar — tappable to open profile
        GestureDetector(
          onTap: authorId.isNotEmpty
              ? () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => ViewProfileScreen(targetUid: authorId)))
              : null,
           child: ZyloAvatar(
             photoUrl: authorPhoto.isNotEmpty ? authorPhoto : null,
             radius: 18,
           ),
        ),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.only(
                topRight: Radius.circular(16), bottomLeft: Radius.circular(16), bottomRight: Radius.circular(16)),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 8, offset: const Offset(0, 2))]),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                GestureDetector(
                  onTap: authorId.isNotEmpty
                      ? () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => ViewProfileScreen(targetUid: authorId)))
                      : null,
                  child: Text('@$authorName', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: _kBlue)),
                ),
                const SizedBox(width: 6),
                if (isMyComment)
                  Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(color: _kBlue.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(6)),
                    child: const Text('You', style: TextStyle(color: _kBlue, fontSize: 10, fontWeight: FontWeight.w800))),
                const Spacer(),
                Text(_timeAgo(createdAt?.toDate()), style: TextStyle(fontSize: 10, color: Colors.grey[400])),
              ]),
              if (replyToName != null) ...[ const SizedBox(height: 3),
                Text('Replying to @$replyToName', style: const TextStyle(color: _kBlue, fontSize: 11, fontWeight: FontWeight.w600))],
              const SizedBox(height: 4),
              _MentionRichText(text: text),
            ]),
          ),
          // Actions
          Padding(padding: const EdgeInsets.only(top: 4, left: 4),
            child: Row(children: [
              // Like
              GestureDetector(
                onTap: () {
                  HapticFeedback.lightImpact();
                  final ref = FirebaseFirestore.instance.collection('posts').doc(postId).collection('comments').doc(commentId);
                  if (isLiked) ref.update({'likes': FieldValue.arrayRemove([myUid])});
                  else ref.update({'likes': FieldValue.arrayUnion([myUid])});
                },
                child: Row(children: [
                  Icon(isLiked ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                    size: 15, color: isLiked ? Colors.red : Colors.grey[400]),
                  const SizedBox(width: 3),
                  Text('${likes.length}', style: TextStyle(fontSize: 11, color: isLiked ? Colors.red : Colors.grey[400], fontWeight: FontWeight.w600)),
                ])),
              const SizedBox(width: 14),
              // Reply
              GestureDetector(
                onTap: () => onReply(commentId, authorName),
                child: Row(children: [
                  Icon(Icons.reply_rounded, size: 15, color: Colors.grey[400]),
                  const SizedBox(width: 3),
                  Text('Reply', style: TextStyle(fontSize: 11, color: Colors.grey[400], fontWeight: FontWeight.w600)),
                ])),
              // Delete own comment
              if (isMyComment) ...[ const SizedBox(width: 14),
                GestureDetector(
                  onTap: () => FirebaseFirestore.instance.collection('posts').doc(postId)
                      .collection('comments').doc(commentId).delete(),
                  child: Text('Delete', style: TextStyle(fontSize: 11, color: Colors.red.withValues(alpha: 0.7), fontWeight: FontWeight.w600))),
              ],
            ])),
        ])),
      ]),
    );
  }

  String _timeAgo(DateTime? dt) {
    if (dt == null) return '';
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 1) return 'now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m';
    if (diff.inHours < 24) return '${diff.inHours}h';
    return '${diff.inDays}d';
  }
}

class _MentionRichText extends StatelessWidget {
  final String text;
  const _MentionRichText({required this.text});

  @override
  Widget build(BuildContext context) {
    final spans = <TextSpan>[];
    final style = const TextStyle(fontSize: 13.5, color: Colors.black87, height: 1.4);
    final regex = RegExp(r'@(\w+)');
    int last = 0;
    for (final m in regex.allMatches(text)) {
      if (m.start > last) spans.add(TextSpan(text: text.substring(last, m.start), style: style));
      spans.add(TextSpan(text: m.group(0), style: style.copyWith(color: _kBlue, fontWeight: FontWeight.w700)));
      last = m.end;
    }
    if (last < text.length) spans.add(TextSpan(text: text.substring(last), style: style));
    return RichText(text: TextSpan(children: spans));
  }
}
