// ═══════════════════════════════════════════════════════════════════════════
// PostDeepLinkScreen — Opens a single post by ID (from chat or deep link)
// ═══════════════════════════════════════════════════════════════════════════
import 'package:cached_network_image/cached_network_image.dart';
import '../../widgets/zylo_cached_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../profile/view_profile_screen.dart';
import 'post_comments_screen.dart';
import '../../services/auth_service.dart';

class PostDeepLinkScreen extends StatefulWidget {
  final String postId;
  const PostDeepLinkScreen({super.key, required this.postId});
  @override
  State<PostDeepLinkScreen> createState() => _PostDeepLinkScreenState();
}

class _PostDeepLinkScreenState extends State<PostDeepLinkScreen> {
  static const _blue   = Color(0xFF0284C7);
  static const _bg     = Color(0xFFF8FAFD);

  Map<String, dynamic>? _post;
  String? _error;
  bool _loading = true;
  final _db    = FirebaseFirestore.instance;
  final _myUid = FirebaseAuth.instance.currentUser?.uid ?? '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      DocumentSnapshot snap = await _db.collection('posts').doc(widget.postId).get();
      if (!snap.exists) {
        snap = await _db.collection('feed').doc(widget.postId).get();
      }
      if (!snap.exists) {
        setState(() { _loading = false; _error = 'Post not found.'; });
        return;
      }
      final data = snap.data() as Map<String, dynamic>;
      data['_docId'] = snap.id;
      setState(() { _post = data; _loading = false; });
      // increment view count silently
      _db.collection('posts').doc(widget.postId).update({
        'views': FieldValue.increment(1)
      }).catchError((_) {});
    } catch (e) {
      setState(() { _loading = false; _error = e.toString(); });
    }
  }

  Future<void> _toggleLike() async {
    if (_post == null) return;
    final likedBy = List<String>.from(_post!['likedBy'] ?? []);
    final ref = _db.collection('posts').doc(widget.postId);
    if (likedBy.contains(_myUid)) {
      likedBy.remove(_myUid);
      ref.update({'likes': FieldValue.increment(-1), 'likedBy': likedBy});
    } else {
      likedBy.add(_myUid);
      ref.update({'likes': FieldValue.increment(1), 'likedBy': likedBy});
    }
    setState(() => _post!['likedBy'] = likedBy);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
        title: const Text('Post', style: TextStyle(fontWeight: FontWeight.w800, color: Colors.black87)),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black87),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _blue))
          : _error != null
              ? _buildError()
              : _buildPost(),
    );
  }

  Widget _buildError() {
    return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(Icons.broken_image_rounded, size: 64, color: Colors.grey[300]),
      const SizedBox(height: 16),
      Text(_error!, style: TextStyle(color: Colors.grey[500], fontSize: 15)),
      const SizedBox(height: 12),
      TextButton.icon(
        onPressed: () { setState(() { _loading = true; _error = null; }); _load(); },
        icon: const Icon(Icons.refresh_rounded),
        label: const Text('Retry'),
      ),
    ]));
  }

  Widget _buildPost() {
    final p          = _post!;
    final authorId   = p['authorId']   ?? p['uid'] ?? '';
    final name       = p['authorName'] ?? p['authorUsername'] ?? p['displayName'] ?? 'User';
    final photo      = p['authorPhoto'] ?? p['photoUrl'] ?? '';
    final text       = p['text']       ?? p['content'] ?? '';
    final images     = p['images']     ?? p['imageUrls'] ?? [];
    final likedBy    = List<String>.from(p['likedBy'] ?? []);
    final likes      = p['likes']      ?? likedBy.length;
    final comments   = p['commentsCount'] ?? p['comments'] ?? 0;
    final views      = p['views']      ?? 0;
    final isLiked    = likedBy.contains(_myUid);
    final ts         = p['createdAt']  as Timestamp?;
    final timeStr    = ts != null
        ? DateFormat('MMM d, y · h:mm a').format(ts.toDate()) : '';

    return SingleChildScrollView(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // ── Post card ──────────────────────────────────────────────────────
        Container(
          color: Colors.white,
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // Author row
            GestureDetector(
              onTap: () {
                if (authorId.isNotEmpty) {
                  Navigator.push(context, MaterialPageRoute(
                    builder: (_) => ViewProfileScreen(targetUid: authorId)));
                }
              },
              child: Row(children: [
                CircleAvatar(
                  radius: 22,
                  backgroundColor: _blue,
                  backgroundImage: photo.isNotEmpty ? CachedNetworkImageProvider(photo) : null,
                  child: photo.isEmpty
                      ? Text(name.isNotEmpty ? name[0].toUpperCase() : 'U',
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))
                      : null,
                ),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('@$name', style: const TextStyle(
                      fontWeight: FontWeight.w800, fontSize: 15, color: Colors.black87)),
                  if (timeStr.isNotEmpty)
                    Text(timeStr, style: TextStyle(color: Colors.grey[400], fontSize: 12)),
                ])),
              ]),
            ),
            const SizedBox(height: 14),

            // Text content
            if (text.isNotEmpty) ...[
              Text(text, style: const TextStyle(
                  fontSize: 15, height: 1.6, color: Colors.black87)),
              const SizedBox(height: 12),
            ],

            // Images
            if (images is List && images.isNotEmpty) ...[
              ...images.map((img) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: ZyloCachedImage(
                    url: img.toString(),
                    width: null,
                    fit: BoxFit.cover,
                    placeholder: (_, __) => Container(
                        height: 220, color: Colors.grey[100],
                        child: const Center(child: CircularProgressIndicator(
                            strokeWidth: 2, color: _blue))),
                    errorWidget: const SizedBox.shrink(),
                  ),
                ),
              )),
            ],

            const SizedBox(height: 8),
            const Divider(height: 1, color: Color(0xFFE5E5EA)),
            const SizedBox(height: 10),

            // Actions row
            Row(children: [
              // Like
              GestureDetector(
                onTap: _toggleLike,
                child: Row(children: [
                  Icon(
                    isLiked ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                    color: isLiked ? Colors.redAccent : Colors.grey[400],
                    size: 24,
                  ),
                  const SizedBox(width: 5),
                  Text('$likes', style: TextStyle(
                      color: isLiked ? Colors.redAccent : Colors.grey[500],
                      fontWeight: FontWeight.w600, fontSize: 14)),
                ]),
              ),
              const SizedBox(width: 20),
              // Comments
              GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => PostCommentsScreen(postId: widget.postId, myUid: _myUid, auth: AuthService()))),
                child: Row(children: [
                  Icon(Icons.chat_bubble_outline_rounded, color: Colors.grey[400], size: 22),
                  const SizedBox(width: 5),
                  Text('$comments', style: TextStyle(
                      color: Colors.grey[500], fontWeight: FontWeight.w600, fontSize: 14)),
                ]),
              ),
              const Spacer(),
              Row(children: [
                Icon(Icons.visibility_outlined, color: Colors.grey[300], size: 16),
                const SizedBox(width: 4),
                Text('$views', style: TextStyle(color: Colors.grey[400], fontSize: 12)),
              ]),
            ]),
          ]),
        ),

        const SizedBox(height: 10),

        // ── Comments preview label ─────────────────────────────────────────
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(children: [
            const Text('Comments', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
            const Spacer(),
            TextButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(
                builder: (_) => PostCommentsScreen(postId: widget.postId, myUid: _myUid, auth: AuthService()))),
              child: const Text('View all', style: TextStyle(color: _blue, fontWeight: FontWeight.w600)),
            ),
          ]),
        ),

        // ── Recent comments preview ────────────────────────────────────────
        StreamBuilder<QuerySnapshot>(
          stream: _db.collection('posts').doc(widget.postId)
              .collection('comments')
              .orderBy('createdAt', descending: true)
              .limit(3)
              .snapshots(),
          builder: (_, snap) {
            final docs = snap.data?.docs ?? [];
            if (docs.isEmpty) {
              return Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                child: Text('No comments yet. Be the first!',
                    style: TextStyle(color: Colors.grey[400], fontSize: 13)),
              );
            }
            return Column(
              children: docs.map((doc) {
                final c = doc.data() as Map<String, dynamic>;
                final cName  = c['authorName']  as String? ?? 'User';
                final cPhoto = c['authorPhoto'] as String? ?? '';
                final cText  = c['text']        as String? ?? '';
                final cTs    = c['createdAt']   as Timestamp?;
                return ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
                  leading: CircleAvatar(
                    radius: 18, backgroundColor: _blue,
                    backgroundImage: cPhoto.isNotEmpty ? CachedNetworkImageProvider(cPhoto) : null,
                    child: cPhoto.isEmpty ? Text(cName[0].toUpperCase(),
                        style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)) : null,
                  ),
                  title: Text('@$cName',
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                  subtitle: Text(cText, style: const TextStyle(fontSize: 13, color: Colors.black87)),
                  trailing: cTs != null ? Text(_timeAgo(cTs.toDate()),
                      style: TextStyle(fontSize: 10, color: Colors.grey[400])) : null,
                );
              }).toList(),
            );
          },
        ),
        const SizedBox(height: 40),
      ]),
    );
  }

  String _timeAgo(DateTime dt) {
    final d = DateTime.now().difference(dt);
    if (d.inSeconds < 60) return 'now';
    if (d.inMinutes < 60) return '${d.inMinutes}m';
    if (d.inHours < 24)   return '${d.inHours}h';
    return '${d.inDays}d';
  }
}
