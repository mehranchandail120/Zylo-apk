// ═══════════════════════════════════════════════════════════════════════════
// ZyloGuideScreen — "How Zylo Works" interactive walkthrough
// Shown to new users after registration, and accessible from Settings.
// ═══════════════════════════════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'home_screen.dart';

class ZyloGuideScreen extends StatefulWidget {
  /// If true, a "Go to Home" button shows at the end (new user flow).
  final bool isNewUser;
  const ZyloGuideScreen({super.key, this.isNewUser = true});

  @override
  State<ZyloGuideScreen> createState() => _ZyloGuideScreenState();
}

class _ZyloGuideScreenState extends State<ZyloGuideScreen>
    with TickerProviderStateMixin {
  final PageController _pc = PageController();
  int _page = 0;
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;

  // ── Guide pages data ─────────────────────────────────────────────────────
  static const _pages = [
    _GuidePage(
      bg1: Color(0xFF0A0F2E),
      bg2: Color(0xFF0C2D6B),
      accent: Color(0xFF38BDF8),
      icon: '👋',
      tag: 'Welcome',
      title: 'Welcome to Zylo',
      body: 'Zylo is a private social platform built for real connections. '
          'No AI-generated feeds, no political noise — just you and the people you actually care about.',
      features: [],
    ),
    _GuidePage(
      bg1: Color(0xFF0C1A0A),
      bg2: Color(0xFF0F3A1A),
      accent: Color(0xFF34D399),
      icon: '📱',
      tag: 'The App',
      title: 'How Zylo Works',
      body: 'Zylo has 5 core sections you can explore from the bottom navigation bar:',
      features: [
        _Feature('🏠', 'Feed', 'See posts from friends & people you follow'),
        _Feature('🔍', 'Search', 'Discover new people and explore profiles'),
        _Feature('💬', 'Chat', 'Private messaging, games & file sharing'),
        _Feature('📸', 'Stories', '24-hour disappearing moments'),
        _Feature('👤', 'Profile', 'Your posts, settings & identity'),
      ],
    ),
    _GuidePage(
      bg1: Color(0xFF1A0B2E),
      bg2: Color(0xFF2D0F5E),
      accent: Color(0xFFA78BFA),
      icon: '⭕',
      tag: 'Follow System',
      title: 'What is Following?',
      body: 'Follow people to see their posts in your Following feed. People who follow you see your posts.',
      features: [
        _Feature('🔒', 'Private Posts', 'Post for followers only — hidden from non-followers'),
        _Feature('⚡', 'Following Feed', 'Posts from people you follow appear in your feed'),
        _Feature('🔔', 'Instant Alerts', 'They get notified the moment you post'),
        _Feature('👑', 'Max 30 People', 'Exclusive — only your closest friends qualify'),
        _Feature('➕', 'How to Add', 'Go to a friend\'s profile → tap ⭕ button'),
      ],
    ),
    _GuidePage(
      bg1: Color(0xFF0A1A2E),
      bg2: Color(0xFF0F2D5E),
      accent: Color(0xFF38BDF8),
      icon: '☁️',
      tag: 'Zylo Storage',
      title: 'Unlimited Cloud Storage',
      body: 'Zylo gives you free, permanent cloud storage for all your files — tied to your account forever.',
      features: [
        _Feature('♾️', 'Unlimited', 'No storage limits — upload as much as you want'),
        _Feature('📷', 'Any File Type', 'Photos, videos, APKs, documents, archives'),
        _Feature('🔗', 'Permanent Links', 'Files never expire — accessible anytime'),
        _Feature('📱', 'App-Independent', 'Delete the app, reinstall — files still there'),
        _Feature('⚡', 'Cloudflare CDN', 'Fast global delivery via encrypted infrastructure'),
      ],
    ),
    _GuidePage(
      bg1: Color(0xFF1A0C0A),
      bg2: Color(0xFF3A1A0F),
      accent: Color(0xFFFB923C),
      icon: '💬',
      tag: 'Chat',
      title: 'Chat & More',
      body: 'Zylo Chat is more than just messaging — it\'s a full communication hub.',
      features: [
        _Feature('💌', 'Real-time Messages', 'Instant delivery with read receipts'),
        _Feature('🎮', 'In-Chat Games', 'Play Tic Tac Toe & Ludo with friends'),
        _Feature('📎', 'File Sharing', 'Send files directly via Zylo Storage'),
        _Feature('📌', 'Pin & Reply', 'Pin important messages, reply in thread'),
        _Feature('🔐', 'Chat Lock', 'Lock individual chats with fingerprint/PIN'),
      ],
    ),
    _GuidePage(
      bg1: Color(0xFF0A1A0E),
      bg2: Color(0xFF0F3322),
      accent: Color(0xFF34D399),
      icon: '🚀',
      tag: 'You\'re Ready!',
      title: 'Start Exploring Zylo',
      body: 'You\'re all set! Here are a few quick tips to get the most out of Zylo:',
      features: [
        _Feature('✅', 'Complete Your Profile', 'Add a photo and bio to get more followers'),
        _Feature('👥', 'Build Your Network', 'Follow people to stay updated with their posts'),
        _Feature('☁️', 'Upload to Storage', 'Settings → Zylo Storage to upload files'),
        _Feature('🔔', 'Enable Notifications', 'Stay on top of messages and posts'),
        _Feature('🌟', 'Follow People', 'Search and discover people you might know'),
      ],
    ),
  ];

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();
  }

  @override
  void dispose() {
    _pc.dispose();
    _fadeCtrl.dispose();
    super.dispose();
  }

  void _next() {
    if (_page < _pages.length - 1) {
      _fadeCtrl.reverse().then((_) {
        _pc.nextPage(duration: const Duration(milliseconds: 400), curve: Curves.easeInOut);
        setState(() => _page++);
        _fadeCtrl.forward();
      });
    } else {
      _finish();
    }
  }

  void _prev() {
    if (_page > 0) {
      _fadeCtrl.reverse().then((_) {
        _pc.previousPage(duration: const Duration(milliseconds: 400), curve: Curves.easeInOut);
        setState(() => _page--);
        _fadeCtrl.forward();
      });
    }
  }

  void _finish() {
    if (widget.isNewUser) {
      Navigator.pushAndRemoveUntil(context,
        MaterialPageRoute(builder: (_) => const HomeScreen()),
        (r) => false);
    } else {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final pg = _pages[_page];
    return Scaffold(
      body: AnimatedContainer(
        duration: const Duration(milliseconds: 600),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [pg.bg1, pg.bg2],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Column(children: [
            // ── Top bar ──────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: Row(children: [
                // Back or close
                if (_page > 0)
                  GestureDetector(
                    onTap: _prev,
                    child: Container(
                      width: 38, height: 38,
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.12),
                        shape: BoxShape.circle),
                      child: const Icon(Icons.arrow_back_rounded, color: Colors.white, size: 18)),
                  )
                else
                  const SizedBox(width: 38),

                // Page indicator dots
                Expanded(child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(_pages.length, (i) => AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    width: _page == i ? 20 : 6,
                    height: 6,
                    decoration: BoxDecoration(
                      color: _page == i ? pg.accent : Colors.white.withValues(alpha: 0.25),
                      borderRadius: BorderRadius.circular(3)),
                  )),
                )),

                // Skip / X
                GestureDetector(
                  onTap: _finish,
                  child: Container(
                    width: 38, height: 38,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.12),
                      shape: BoxShape.circle),
                    child: Icon(
                      _page == _pages.length - 1 ? Icons.close_rounded : Icons.skip_next_rounded,
                      color: Colors.white70, size: 18)),
                ),
              ]),
            ),

            // ── Page content ─────────────────────────────────────────────
            Expanded(
              child: PageView.builder(
                controller: _pc,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _pages.length,
                itemBuilder: (_, i) => _buildPage(_pages[i]),
              ),
            ),

            // ── Bottom button ─────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
              child: GestureDetector(
                onTap: _next,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: double.infinity,
                  height: 56,
                  decoration: BoxDecoration(
                    color: pg.accent,
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: [BoxShadow(
                      color: pg.accent.withValues(alpha: 0.4),
                      blurRadius: 20,
                      offset: const Offset(0, 6))],
                  ),
                  child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text(
                      _page == _pages.length - 1
                          ? (widget.isNewUser ? '🚀  Start Exploring' : '✅  Got It!')
                          : 'Next',
                      style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w800,
                        color: Colors.white, letterSpacing: 0.2),
                    ),
                    if (_page < _pages.length - 1) ...[ 
                      const SizedBox(width: 8),
                      const Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 18),
                    ],
                  ]),
                ),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _buildPage(_GuidePage pg) {
    return FadeTransition(
      opacity: _fadeAnim,
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Tag chip
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
            decoration: BoxDecoration(
              color: pg.accent.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: pg.accent.withValues(alpha: 0.4)),
            ),
            child: Text(pg.tag,
              style: TextStyle(color: pg.accent, fontSize: 12, fontWeight: FontWeight.w700,
                  letterSpacing: 0.5)),
          ),
          const SizedBox(height: 20),

          // Big icon
          Text(pg.icon, style: const TextStyle(fontSize: 56)),
          const SizedBox(height: 16),

          // Title
          Text(pg.title,
            style: const TextStyle(
              fontSize: 28, fontWeight: FontWeight.w900,
              color: Colors.white, height: 1.15, letterSpacing: -0.5)),
          const SizedBox(height: 14),

          // Body
          Text(pg.body,
            style: TextStyle(fontSize: 15, color: Colors.white.withValues(alpha: 0.75), height: 1.6)),

          // Features
          if (pg.features.isNotEmpty) ...[ 
            const SizedBox(height: 24),
            ...pg.features.map((f) => _featureTile(f, pg.accent)),
          ],

          const SizedBox(height: 16),
        ]),
      ),
    );
  }

  Widget _featureTile(_Feature f, Color accent) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          width: 40, height: 40,
          decoration: BoxDecoration(
            color: accent.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: accent.withValues(alpha: 0.2)),
          ),
          child: Center(child: Text(f.emoji, style: const TextStyle(fontSize: 18))),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(f.title,
            style: const TextStyle(
              color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14)),
          const SizedBox(height: 2),
          Text(f.desc,
            style: TextStyle(color: Colors.white.withValues(alpha: 0.55), fontSize: 12, height: 1.4)),
        ])),
      ]),
    );
  }
}

// ── Data models ───────────────────────────────────────────────────────────

class _GuidePage {
  final Color bg1, bg2, accent;
  final String icon, tag, title, body;
  final List<_Feature> features;
  const _GuidePage({
    required this.bg1, required this.bg2, required this.accent,
    required this.icon, required this.tag, required this.title,
    required this.body, required this.features,
  });
}

class _Feature {
  final String emoji, title, desc;
  const _Feature(this.emoji, this.title, this.desc);
}
