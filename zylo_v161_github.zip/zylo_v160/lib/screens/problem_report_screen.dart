import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ProblemReportScreen extends StatefulWidget {
  const ProblemReportScreen({super.key});
  @override
  State<ProblemReportScreen> createState() => _ProblemReportScreenState();
}

class _ProblemReportScreenState extends State<ProblemReportScreen>
    with SingleTickerProviderStateMixin {
  static const _blue = Color(0xFF0284C7);
  static const _bg   = Color(0xFFF2F2F7);

  late TabController _tab;
  final _descCtrl = TextEditingController();
  String _selectedCategory = 'Bug / Crash';
  bool _submitting = false;
  bool _submitted  = false;

  // My past reports
  final _uid = FirebaseAuth.instance.currentUser?.uid ?? '';

  final _categories = [
    ('Bug / Crash',        Icons.bug_report_outlined,      Color(0xFFEF4444)),
    ('Feature Request',    Icons.lightbulb_outline,         Color(0xFFF59E0B)),
    ('Account Problem',    Icons.person_outline,            Color(0xFF8B5CF6)),
    ('Chat Issue',         Icons.chat_bubble_outline,       Color(0xFF0284C7)),
    ('Media / Upload',     Icons.cloud_upload_outlined,     Color(0xFF10B981)),
    ('Notification',       Icons.notifications_none_rounded,Color(0xFFEC4899)),
    ('Performance',        Icons.speed_rounded,             Color(0xFF06B6D4)),
    ('Other',              Icons.more_horiz_rounded,        Colors.grey),
  ];

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tab.dispose();
    _descCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_descCtrl.text.trim().isEmpty) {
      _snack('Please describe the problem', Colors.red);
      return;
    }
    setState(() => _submitting = true);
    try {
      await FirebaseFirestore.instance.collection('problemReports').add({
        'uid':         _uid,
        'category':    _selectedCategory,
        'description': _descCtrl.text.trim(),
        'timestamp':   FieldValue.serverTimestamp(),
        'status':      'pending',
        'resolved':    false,
      });
      _descCtrl.clear();
      setState(() { _submitting = false; _submitted = true; });
      await Future.delayed(const Duration(seconds: 2));
      if (mounted) setState(() => _submitted = false);
      _tab.animateTo(1); // switch to My Reports tab
    } catch (e) {
      if (mounted) {
        setState(() => _submitting = false);
        _snack('Failed: $e', Colors.red);
      }
    }
  }

  void _snack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        title: const Text('Report a Problem',
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black87)),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black87),
          onPressed: () => Navigator.pop(context),
        ),
        bottom: TabBar(
          controller: _tab,
          labelColor: _blue,
          unselectedLabelColor: Colors.grey,
          indicatorColor: _blue,
          indicatorSize: TabBarIndicatorSize.label,
          tabs: const [
            Tab(text: 'New Report'),
            Tab(text: 'My Reports'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          _buildNewReport(),
          _buildMyReports(),
        ],
      ),
    );
  }

  Widget _buildNewReport() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SizedBox(height: 4),

        // Header card
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF0284C7), Color(0xFF0369A1)],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.flag_rounded, color: Colors.white, size: 24),
            ),
            const SizedBox(width: 14),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Tell us what\'s wrong',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
              SizedBox(height: 3),
              Text('We read every report and fix issues quickly.',
                  style: TextStyle(color: Colors.white70, fontSize: 12)),
            ])),
          ]),
        ),

        const SizedBox(height: 20),
        const Text('CATEGORY', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
            color: Colors.grey, letterSpacing: 0.8)),
        const SizedBox(height: 10),

        // Category grid
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4, mainAxisSpacing: 10, crossAxisSpacing: 10,
            childAspectRatio: 0.85,
          ),
          itemCount: _categories.length,
          itemBuilder: (_, i) {
            final cat = _categories[i];
            final selected = _selectedCategory == cat.$1;
            return GestureDetector(
              onTap: () => setState(() => _selectedCategory = cat.$1),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                decoration: BoxDecoration(
                  color: selected ? cat.$3.withValues(alpha: 0.12) : Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: selected ? cat.$3 : const Color(0xFFE5E5EA),
                    width: selected ? 2 : 1,
                  ),
                  boxShadow: selected
                      ? [BoxShadow(color: cat.$3.withValues(alpha: 0.2), blurRadius: 8)]
                      : [],
                ),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(cat.$2, color: selected ? cat.$3 : Colors.grey, size: 22),
                  const SizedBox(height: 6),
                  Text(cat.$1,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                      color: selected ? cat.$3 : Colors.black54,
                    ),
                  ),
                ]),
              ),
            );
          },
        ),

        const SizedBox(height: 20),
        const Text('DESCRIPTION', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
            color: Colors.grey, letterSpacing: 0.8)),
        const SizedBox(height: 10),

        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFE5E5EA)),
          ),
          child: TextField(
            controller: _descCtrl,
            maxLines: 6,
            maxLength: 500,
            decoration: InputDecoration(
              hintText: 'Describe the problem in detail...\n\nE.g. "When I open the chat screen, the app crashes immediately."',
              hintStyle: TextStyle(color: Colors.grey[400], fontSize: 13, height: 1.5),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.all(16),
              counterStyle: const TextStyle(fontSize: 11, color: Colors.grey),
            ),
          ),
        ),

        const SizedBox(height: 20),

        // Success animation
        if (_submitted)
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFF10B981).withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFF10B981).withValues(alpha: 0.4)),
            ),
            child: const Row(children: [
              Icon(Icons.check_circle_rounded, color: Color(0xFF10B981), size: 20),
              SizedBox(width: 10),
              Expanded(child: Text('Report submitted! We\'ll look into it.',
                  style: TextStyle(color: Color(0xFF10B981), fontWeight: FontWeight.w600, fontSize: 13))),
            ]),
          ),

        const SizedBox(height: 12),

        // Submit button
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            icon: _submitting
                ? const SizedBox(width: 18, height: 18,
                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : const Icon(Icons.send_rounded, size: 18, color: Colors.white),
            label: Text(_submitting ? 'Submitting...' : 'Submit Report',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15)),
            onPressed: _submitting ? null : _submit,
            style: ElevatedButton.styleFrom(
              backgroundColor: _blue,
              disabledBackgroundColor: _blue.withValues(alpha: 0.6),
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              elevation: 0,
            ),
          ),
        ),

        const SizedBox(height: 32),
      ]),
    );
  }

  Widget _buildMyReports() {
    if (_uid.isEmpty) {
      return const Center(child: Text('Not logged in', style: TextStyle(color: Colors.grey)));
    }
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('problemReports')
          .where('uid', isEqualTo: _uid)
          .orderBy('timestamp', descending: true)
          .snapshots(),
      builder: (_, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(color: _blue));
        }
        // Fallback without orderBy if index missing
        if (snap.hasError) {
          return StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('problemReports')
                .where('uid', isEqualTo: _uid)
                .snapshots(),
            builder: (_, snap2) {
              if (!snap2.hasData) return const Center(child: CircularProgressIndicator(color: _blue));
              final docs = snap2.data!.docs;
              if (docs.isEmpty) return _emptyReports();
              return _reportList(docs);
            },
          );
        }
        final docs = snap.data?.docs ?? [];
        if (docs.isEmpty) return _emptyReports();
        return _reportList(docs);
      },
    );
  }

  Widget _emptyReports() {
    return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.grey[100],
          shape: BoxShape.circle,
        ),
        child: Icon(Icons.flag_outlined, size: 48, color: Colors.grey[400]),
      ),
      const SizedBox(height: 16),
      Text('No reports yet', style: TextStyle(color: Colors.grey[500], fontSize: 15,
          fontWeight: FontWeight.w600)),
      const SizedBox(height: 6),
      Text('Submit your first report from the\nNew Report tab.',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.grey[400], fontSize: 13)),
    ]));
  }

  Widget _reportList(List<QueryDocumentSnapshot> docs) {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
      itemCount: docs.length,
      itemBuilder: (_, i) {
        final r = docs[i].data() as Map<String, dynamic>;
        final category    = r['category'] as String? ?? 'Other';
        final description = r['description'] as String? ?? '';
        final resolved    = r['resolved'] == true;
        final status      = r['status'] as String? ?? 'pending';
        final ts          = r['timestamp'] as Timestamp?;
        final adminNote   = r['adminNote'] as String?;

        // find category color/icon
        final catData = _categories.firstWhere((c) => c.$1 == category,
            orElse: () => _categories.last);

        final statusColor = resolved ? const Color(0xFF10B981)
            : status == 'in_review' ? const Color(0xFFF59E0B)
            : const Color(0xFFEF4444);
        final statusLabel = resolved ? 'Resolved'
            : status == 'in_review' ? 'In Review'
            : 'Pending';
        final statusIcon  = resolved ? Icons.check_circle_rounded
            : status == 'in_review' ? Icons.hourglass_top_rounded
            : Icons.schedule_rounded;

        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFE5E5EA)),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 6)],
          ),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // Top row
              Row(children: [
                Container(
                  padding: const EdgeInsets.all(7),
                  decoration: BoxDecoration(
                    color: catData.$3.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(catData.$2, color: catData.$3, size: 16),
                ),
                const SizedBox(width: 10),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(category, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                  if (ts != null)
                    Text(_timeAgo(ts.toDate()),
                        style: const TextStyle(color: Colors.grey, fontSize: 11)),
                ])),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: statusColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(statusIcon, size: 12, color: statusColor),
                    const SizedBox(width: 4),
                    Text(statusLabel,
                        style: TextStyle(color: statusColor, fontSize: 11,
                            fontWeight: FontWeight.w700)),
                  ]),
                ),
              ]),
              const SizedBox(height: 10),
              const Divider(height: 1, color: Color(0xFFE5E5EA)),
              const SizedBox(height: 10),
              Text(description,
                  maxLines: 3, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.black87, fontSize: 13, height: 1.4)),
              if (adminNote != null && adminNote.isNotEmpty) ...[
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0284C7).withValues(alpha: 0.06),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: const Color(0xFF0284C7).withValues(alpha: 0.2)),
                  ),
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Icon(Icons.admin_panel_settings_outlined,
                        size: 14, color: Color(0xFF0284C7)),
                    const SizedBox(width: 8),
                    Expanded(child: Text(adminNote,
                        style: const TextStyle(color: Color(0xFF0284C7), fontSize: 12,
                            fontWeight: FontWeight.w500))),
                  ]),
                ),
              ],
            ]),
          ),
        );
      },
    );
  }

  String _timeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inSeconds < 60) return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24)   return '${diff.inHours}h ago';
    if (diff.inDays < 7)     return '${diff.inDays}d ago';
    return '${dt.day}/${dt.month}/${dt.year}';
  }
}
