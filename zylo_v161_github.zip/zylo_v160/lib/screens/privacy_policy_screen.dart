import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'auth/register_screen.dart';

// ══════════════════════════════════════════════════════════════════════════════
// PrivacyPolicyScreen
// fromSettings: true  → no accept footer, just read-only scroll
// fromSettings: false → show accept + continue button (registration flow)
// ══════════════════════════════════════════════════════════════════════════════
class PrivacyPolicyScreen extends StatefulWidget {
  final bool fromSettings;
  const PrivacyPolicyScreen({super.key, this.fromSettings = false});

  @override
  State<PrivacyPolicyScreen> createState() => _PrivacyPolicyScreenState();
}

class _PrivacyPolicyScreenState extends State<PrivacyPolicyScreen> {
  bool _accepted = false;
  final ScrollController _scrollCtrl = ScrollController();
  bool _scrolledToBottom = false;

  @override
  void initState() {
    super.initState();
    _scrollCtrl.addListener(() {
      if (_scrollCtrl.position.pixels >=
          _scrollCtrl.position.maxScrollExtent - 40) {
        if (!_scrolledToBottom) setState(() => _scrolledToBottom = true);
      }
    });
  }

  @override
  void dispose() {
    _scrollCtrl.dispose();
    super.dispose();
  }

  static const _blue = Color(0xFF0284C7);
  static const _kBg = Color(0xFF0A0A0A);
  static const _kCard = Color(0xFF1A1A1A);
  static const _kText = Color(0xFFE8E8E8);
  static const _kSub = Color(0xFF888888);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      body: SafeArea(
        child: Column(children: [
          _buildHeader(),
          Expanded(
            child: SingleChildScrollView(
              controller: _scrollCtrl,
              padding: const EdgeInsets.all(20),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                _lastUpdated(),
                _section('1. Introduction', [
                  'Welcome to zylo.pages ("App", "we", "our", or "us"), a social communication platform developed and maintained by Mehran Chandail. By creating an account or using zylo.pages, you agree to these Terms of Service and our Privacy Policy.',
                  'zylo.pages is designed for users aged 13 and above. By registering, you confirm that you meet this age requirement or have parental consent.',
                ]),
                _section('2. Information We Collect', [
                  'We collect information you provide directly: username, email address, phone number, profile photo, bio, and gender. This information is required to create and maintain your account.',
                  'We also collect usage data including messages (stored securely), posts, stories, likes, comments, follows, and interaction history. Location data is collected only when you use location-specific features.',
                  'We collect device information such as device type, operating system, app version, and push notification tokens to provide core app functionality.',
                ]),
                _section('3. How We Use Your Information', [
                  'Your information is used to: operate and improve the App, authenticate your identity, send you notifications about activity on your account, provide customer support, detect and prevent fraud or abuse, and comply with legal obligations.',
                  'We do not sell your personal information to third parties. We do not use your data for advertising purposes.',
                ]),
                _section('4. Data Storage & Security', [
                  'Your data is stored securely using Google Firebase (Firestore & Firebase Storage) with encryption in transit and at rest. Profile photos and media files are stored using Cloudinary CDN.',
                  'While we take reasonable security measures, no system is 100% secure. You are responsible for keeping your account credentials confidential.',
                ]),
                _section('5. User Content & Conduct', [
                  'You retain ownership of content you post. By posting content, you grant zylo.pages a non-exclusive, royalty-free license to display that content within the App.',
                  'You agree NOT to: post illegal, harmful, hateful, or sexually explicit content; harass or bully other users; impersonate others; distribute spam or malware; engage in unauthorized commercial activity; or attempt to reverse-engineer the App.',
                  'We reserve the right to remove any content that violates these terms and to suspend or permanently ban accounts that engage in prohibited conduct.',
                ]),
                _section('6. Admin Rights & Moderation', [
                  'zylo.pages administrators have the authority to: review reported content, suspend or delete posts, temporarily or permanently ban user accounts, place the App in maintenance mode, push app updates, add official announcements, and grant or revoke verified badges.',
                  'Admin actions are taken in good faith to maintain a safe community. Banned users may appeal by contacting support.',
                ]),
                _section('7. Followers & Social Features', [
                  'When you follow another user, your username and profile photo become visible to them. Your follower and following counts are publicly visible on your profile.',
                  'Mutual follows allow users to chat directly. Private accounts require approval before followers can see your posts.',
                ]),
                _section('8. Messages & Chat', [
                  'Private messages are stored in Firebase and are accessible only to the sender and recipient. We do not read private messages except when required by law or to investigate a valid abuse report.',
                  'Disappearing messages, once expired, are automatically deleted from our servers. Chat lock features are device-local and cannot be recovered if forgotten.',
                ]),
                _section('8A. End-to-End Encryption & Telegram Security', [
                  'All media files, APKs, videos, photos, and large attachments shared on zylo.pages are transmitted and stored using Telegram\'s infrastructure, which employs end-to-end encryption (E2EE) based on the MTProto 2.0 protocol.',
                  'File transfers use AES-256 encryption in combination with RSA-2048 and Diffie-Hellman key exchange. No plaintext file data is stored on zylo.pages servers.',
                  'Our Cloudflare Worker API acts solely as a relay/proxy — it does not store, inspect, or cache your file contents.',
                  'Voice messages, location shares, and real-time chat data are protected in transit using TLS 1.3 encryption over all network connections.',
                ]),
                _section('9. Third-Party Services', [
                  'We use the following third-party services: Google Firebase (database, auth, storage), Cloudinary (media hosting), ZegoCloud (voice/video calls), JioSaavn proxy (music in stories). Each service has its own privacy policy.',
                ]),
                _section('10. Data Deletion & Account Termination', [
                  'You may request deletion of your account and associated data at any time from Settings > Account > Delete Account. Upon deletion, your profile, posts, and messages will be permanently removed within 30 days.',
                  'We may retain certain data as required by law for up to 90 days after account deletion.',
                ]),
                _section('11. Cookies & Tracking', [
                  'The mobile App does not use cookies. We use Firebase Analytics to understand aggregate usage patterns. You can opt out of analytics through your device privacy settings.',
                ]),
                _section('12. Children\'s Privacy', [
                  'zylo.pages is not intended for children under 13. If we become aware that a child under 13 has provided personal information without parental consent, we will delete that information immediately.',
                ]),
                _section('13. Changes to This Policy', [
                  'We may update this Privacy Policy periodically. Major changes will be notified via an in-app announcement. Continued use of zylo.pages after changes constitutes acceptance of the updated policy.',
                ]),
                _section('14. Contact Us', [
                  'For privacy concerns, data requests, or policy questions, contact: support@zylopages.app',
                  'For abuse reports or admin issues, use the in-app "Report a Problem" feature in Settings.',
                ]),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0284C7).withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _blue.withValues(alpha: 0.2)),
                  ),
                  child: const Text(
                    'Made with ❤️ by Mehran Chandail\nzylo.pages — Connect. Explore. Securely.',
                    style: TextStyle(
                        color: Color(0xFF60A5FA),
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        height: 1.5),
                    textAlign: TextAlign.center,
                  ),
                ),
                const SizedBox(height: 40),
              ]),
            ),
          ),

          // ── Footer: only shown in registration flow, NOT from settings ──
          if (!widget.fromSettings) _buildAcceptFooter(),
        ]),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
      decoration: BoxDecoration(
        color: _kCard,
        border:
            Border(bottom: BorderSide(color: Colors.white.withValues(alpha: 0.06))),
      ),
      child: Column(children: [
        Row(children: [
          // Back button
          if (widget.fromSettings)
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 36, height: 36,
                margin: const EdgeInsets.only(right: 12),
                decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.08),
                    shape: BoxShape.circle),
                child: const Icon(Icons.arrow_back_ios_new_rounded,
                    color: Colors.white54, size: 16),
              ),
            ),
          Container(
            width: 42, height: 42,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [Color(0xFF0284C7), Color(0xFF0EA5E9)]),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.shield_rounded, color: Colors.white, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
            const Text('zylo.pages',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -0.5)),
            Text('Privacy Policy & Terms of Service',
                style: TextStyle(
                    color: _kSub, fontSize: 11, fontWeight: FontWeight.w500)),
          ])),
        ]),
        // Show info banner only in registration flow
        if (!widget.fromSettings) ...[
          const SizedBox(height: 12),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFF0284C7).withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _blue.withValues(alpha: 0.25)),
            ),
            child: Row(children: [
              const Icon(Icons.info_outline, color: _blue, size: 14),
              const SizedBox(width: 8),
              const Expanded(
                  child: Text(
                'Please read and scroll through the full policy before accepting.',
                style: TextStyle(
                    color: _blue, fontSize: 11, fontWeight: FontWeight.w500),
              )),
            ]),
          ),
        ],
      ]),
    );
  }

  Widget _buildAcceptFooter() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
      decoration: BoxDecoration(
        color: _kCard,
        border: Border(top: BorderSide(color: Colors.white.withValues(alpha: 0.06))),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.4),
              blurRadius: 20,
              offset: const Offset(0, -8))
        ],
      ),
      child: Column(children: [
        GestureDetector(
          onTap: () {
            if (!_scrolledToBottom) {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: const Text(
                    'Please scroll and read the full policy first.'),
                backgroundColor: Colors.orange[700],
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ));
              return;
            }
            setState(() => _accepted = !_accepted);
          },
          child: Row(children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 22, height: 22,
              decoration: BoxDecoration(
                color: _accepted ? _blue : Colors.transparent,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(
                    color: _accepted ? _blue : const Color(0xFF444444),
                    width: 2),
              ),
              child: _accepted
                  ? const Icon(Icons.check, color: Colors.white, size: 14)
                  : null,
            ),
            const SizedBox(width: 12),
            const Expanded(
                child: Text(
              'I have read and agree to the Privacy Policy and Terms of Service.',
              style: TextStyle(
                  color: Color(0xFFCCCCCC), fontSize: 13, height: 1.4),
            )),
          ]),
        ),
        const SizedBox(height: 14),
        SizedBox(
          width: double.infinity, height: 52,
          child: ElevatedButton(
            onPressed: _accepted
                ? () async {
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.setBool('privacy_accepted', true);
                    if (context.mounted) {
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const RegisterScreen()));
                    }
                  }
                : null,
            style: ElevatedButton.styleFrom(
              backgroundColor:
                  _accepted ? _blue : const Color(0xFF2A2A2A),
              foregroundColor: Colors.white,
              disabledBackgroundColor: const Color(0xFF2A2A2A),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              elevation: _accepted ? 4 : 0,
            ),
            child: Text(
              _accepted ? 'Accept & Create Account' : 'Read Policy to Continue',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 15,
                color: _accepted
                    ? Colors.white
                    : const Color(0xFF555555),
              ),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _lastUpdated() {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: _kCard,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.white.withValues(alpha: 0.05)),
      ),
      child: Row(children: [
        const Icon(Icons.calendar_today_outlined, color: _kSub, size: 14),
        const SizedBox(width: 8),
        Text('Last updated: April 2026 • Version 1.5.0',
            style: TextStyle(color: _kSub, fontSize: 12)),
      ]),
    );
  }

  Widget _section(String title, List<String> points) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 22),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding:
              const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: const Color(0xFF0284C7).withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(title,
              style: const TextStyle(
                  color: Color(0xFF60A5FA),
                  fontWeight: FontWeight.w800,
                  fontSize: 13)),
        ),
        ...points.map((p) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Container(
                    margin: const EdgeInsets.only(top: 6, right: 10),
                    width: 4, height: 4,
                    decoration: const BoxDecoration(
                        color: Color(0xFF0284C7),
                        shape: BoxShape.circle)),
                Expanded(
                    child: Text(p,
                        style: const TextStyle(
                            color: _kText,
                            fontSize: 13,
                            height: 1.55))),
              ]),
            )),
      ]),
    );
  }
}
