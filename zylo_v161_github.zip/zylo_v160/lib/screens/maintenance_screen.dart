import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:url_launcher/url_launcher.dart';

class MaintenanceScreen extends StatelessWidget {
  final String message;
  final String apkUrl;
  const MaintenanceScreen({super.key, required this.message, this.apkUrl = ''});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: SafeArea(
        child: StreamBuilder<DocumentSnapshot>(
          stream: FirebaseFirestore.instance.collection('appConfig').doc('main').snapshots(),
          builder: (context, snap) {
            final d = snap.data?.data() as Map<String, dynamic>? ?? {};
            final isStillMaintenance = d['maintenanceMode'] == true;
            final msg   = (d['maintenanceMessage'] as String?)?.isNotEmpty == true
                ? d['maintenanceMessage'] as String
                : message;
            final apk   = d['apkDownloadUrl'] as String? ?? apkUrl;

            return Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  // Animated icon
                  Container(
                    width: 96, height: 96,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF0284C7), Color(0xFF38BDF8)],
                        begin: Alignment.topLeft, end: Alignment.bottomRight),
                      borderRadius: BorderRadius.circular(28),
                      boxShadow: [BoxShadow(color: const Color(0xFF0284C7).withValues(alpha: 0.35), blurRadius: 30, offset: const Offset(0, 10))],
                    ),
                    child: const Icon(Icons.construction_rounded, color: Colors.white, size: 48),
                  ),
                  const SizedBox(height: 28),
                  const Text('Under Maintenance', style: TextStyle(
                    color: Colors.white, fontSize: 26, fontWeight: FontWeight.w900, letterSpacing: -0.5)),
                  const SizedBox(height: 12),
                  Text(msg, style: const TextStyle(color: Colors.white60, fontSize: 14, height: 1.6), textAlign: TextAlign.center),
                  const SizedBox(height: 36),

                  // Pulse indicator
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Container(width: 8, height: 8, decoration: const BoxDecoration(color: Color(0xFF10B981), shape: BoxShape.circle)),
                    const SizedBox(width: 8),
                    const Text('We\'ll be back soon', style: TextStyle(color: Color(0xFF10B981), fontSize: 13, fontWeight: FontWeight.w700)),
                  ]),

                  if (apk.isNotEmpty) ...[
                    const SizedBox(height: 28),
                    SizedBox(width: double.infinity, child: ElevatedButton.icon(
                      onPressed: () => launchUrl(Uri.parse(apk), mode: LaunchMode.externalApplication),
                      icon: const Icon(Icons.download_rounded, color: Colors.white),
                      label: const Text('Download Latest APK', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF0284C7),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                    )),
                  ],

                  const SizedBox(height: 48),
                  const Text('zylo.pages', style: TextStyle(color: Colors.white24, fontSize: 13, fontWeight: FontWeight.w800, letterSpacing: 1)),
                  const SizedBox(height: 4),
                  const Text('Made by Mehran Chandail', style: TextStyle(color: Colors.white24, fontSize: 11)),
                ]),
              ),
            );
          },
        ),
      ),
    );
  }
}
