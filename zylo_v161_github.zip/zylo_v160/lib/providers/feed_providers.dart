// lib/providers/feed_providers.dart
// ─────────────────────────────────────────────────────────────────────────────
// Zylo v121 — Riverpod providers for global feed state, pagination,
// and profile caching. Replaces scattered setState + StreamBuilder patterns.
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:async';
import 'dart:isolate';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/cache_service.dart';

// ══════════════════════════════════════════════════════════════
//  1. BACKGROUND ISOLATE — JSON / privacy filtering off main thread
// ══════════════════════════════════════════════════════════════

/// Message passed into the isolate
class _IsolateMsg {
  final SendPort replyPort;
  final List<Map<String, dynamic>> rawPosts;
  final String myUid;
  const _IsolateMsg(this.replyPort, this.rawPosts, this.myUid);
}

/// Runs in a background isolate — filters/sorts posts without blocking UI.
void _filterPostsIsolate(_IsolateMsg msg) {
  final now = DateTime.now();
  final result = <Map<String, dynamic>>[];
  for (final p in msg.rawPosts) {
    final authorId = p['authorId'] as String? ?? '';
    final vis = p['visibility'] as String? ?? 'public';
    // Skip private posts from others
    if ((vis == 'private') && authorId != msg.myUid) continue;
    // Skip scheduled posts from others that haven't fired yet
    if (p['isScheduled'] == true && authorId != msg.myUid) {
      final ms = p['scheduledAt'];
      if (ms is int) {
        final dt = DateTime.fromMillisecondsSinceEpoch(ms);
        if (dt.isAfter(now)) continue;
      }
    }
    result.add(p);
  }
  // Sort descending by createdAt
  result.sort((a, b) {
    final aMs = a['createdAt'] as int? ?? 0;
    final bMs = b['createdAt'] as int? ?? 0;
    return bMs.compareTo(aMs);
  });
  msg.replyPort.send(result);
}

/// Runs post filtering in a background isolate; returns filtered list.
Future<List<Map<String, dynamic>>> filterPostsInBackground(
    List<Map<String, dynamic>> raw, String myUid) async {
  final rp = ReceivePort();
  await Isolate.spawn(
      _filterPostsIsolate, _IsolateMsg(rp.sendPort, raw, myUid));
  final result = await rp.first as List<dynamic>;
  rp.close();
  return result.cast<Map<String, dynamic>>();
}

// ══════════════════════════════════════════════════════════════
//  2. CURRENT USER UID PROVIDER
// ══════════════════════════════════════════════════════════════

final currentUidProvider = StateProvider<String>((ref) => '');

// ══════════════════════════════════════════════════════════════
//  3. FEED PAGE STATE
// ══════════════════════════════════════════════════════════════

class FeedPageState {
  final List<String> postIds;
  final List<String> pinnedIds;
  final Map<String, Map<String, dynamic>> postData;
  final bool loading;
  final bool hasMore;
  final bool firstLoad;
  final DocumentSnapshot? lastDoc;

  const FeedPageState({
    this.postIds = const [],
    this.pinnedIds = const [],
    this.postData = const {},
    this.loading = false,
    this.hasMore = true,
    this.firstLoad = true,
    this.lastDoc,
  });

  FeedPageState copyWith({
    List<String>? postIds,
    List<String>? pinnedIds,
    Map<String, Map<String, dynamic>>? postData,
    bool? loading,
    bool? hasMore,
    bool? firstLoad,
    DocumentSnapshot? lastDoc,
    bool clearLastDoc = false,
  }) =>
      FeedPageState(
        postIds: postIds ?? this.postIds,
        pinnedIds: pinnedIds ?? this.pinnedIds,
        postData: postData ?? this.postData,
        loading: loading ?? this.loading,
        hasMore: hasMore ?? this.hasMore,
        firstLoad: firstLoad ?? this.firstLoad,
        lastDoc: clearLastDoc ? null : lastDoc ?? this.lastDoc,
      );
}

// ══════════════════════════════════════════════════════════════
//  4. GLOBAL FEED NOTIFIER (Riverpod StateNotifier)
// ══════════════════════════════════════════════════════════════

class GlobalFeedNotifier extends StateNotifier<FeedPageState> {
  GlobalFeedNotifier(this._myUid) : super(const FeedPageState()) {
    _init();
  }

  static const int _pageSize = 15;
  final String _myUid;
  final Map<String, StreamSubscription> _subs = {};
  StreamSubscription? _pinnedSub;
  Timer? _autoRefreshTimer;

  void _init() {
    _listenPinnedPosts();
    loadMore();
    _autoRefreshTimer = Timer.periodic(const Duration(minutes: 10), (_) => refresh());
  }

  @override
  void dispose() {
    _autoRefreshTimer?.cancel();
    _pinnedSub?.cancel();
    for (final s in _subs.values) s.cancel();
    super.dispose();
  }

  void _listenPinnedPosts() {
    _pinnedSub = FirebaseFirestore.instance
        .collection('posts')
        .where('isPinned', isEqualTo: true)
        .snapshots()
        .listen((snap) {
      if (!mounted) return;
      final newPinned = <String>[];
      final updatedData = Map<String, Map<String, dynamic>>.from(state.postData);
      for (final doc in snap.docs) {
        final id = doc.id;
        newPinned.add(id);
        final data = Map<String, dynamic>.from(doc.data());
        data['_docId'] = id;
        updatedData[id] = data;
        _subscribePost(id);
      }
      state = state.copyWith(pinnedIds: newPinned, postData: updatedData);
    });
  }

  void _subscribePost(String postId) {
    if (_subs.containsKey(postId)) return;
    _subs[postId] = FirebaseFirestore.instance
        .collection('posts')
        .doc(postId)
        .snapshots()
        .listen((snap) {
      if (!mounted) return;
      if (!snap.exists) {
        final newIds = List<String>.from(state.postIds)..remove(postId);
        final newData = Map<String, Map<String, dynamic>>.from(state.postData)
          ..remove(postId);
        state = state.copyWith(postIds: newIds, postData: newData);
        return;
      }
      final data = snap.data() as Map<String, dynamic>;
      data['_docId'] = postId;
      final newData = Map<String, Map<String, dynamic>>.from(state.postData);
      newData[postId] = data;
      state = state.copyWith(postData: newData);
    });
  }

  Future<void> loadMore() async {
    if (state.loading || !state.hasMore) return;
    state = state.copyWith(loading: true);
    try {
      Query q = FirebaseFirestore.instance
          .collection('posts')
          .orderBy('createdAt', descending: true)
          .limit(_pageSize);
      if (state.lastDoc != null) q = q.startAfterDocument(state.lastDoc!);
      final snap = await q.get();
      if (snap.docs.isEmpty) {
        state = state.copyWith(hasMore: false, loading: false, firstLoad: false);
        return;
      }

      // Convert to plain maps (Timestamp → int) for isolate
      final rawPosts = snap.docs.map((doc) {
        final d = Map<String, dynamic>.from(doc.data() as Map<String, dynamic>);
        d['_docId'] = doc.id;
        // Convert Timestamps for isolate transfer
        final createdAt = d['createdAt'];
        if (createdAt is Timestamp) d['createdAt'] = createdAt.millisecondsSinceEpoch;
        final schedAt = d['scheduledAt'];
        if (schedAt is Timestamp) d['scheduledAt'] = schedAt.millisecondsSinceEpoch;
        return d;
      }).toList();

      // Filter in background isolate
      final filtered = await filterPostsInBackground(rawPosts, _myUid);

      final newIds = List<String>.from(state.postIds);
      final newData = Map<String, Map<String, dynamic>>.from(state.postData);

      for (final p in filtered) {
        final id = p['_docId'] as String;
        if (!newIds.contains(id)) {
          final vis = p['visibility'] as String? ?? 'public';
          if ((vis == 'inner') && (p['authorId'] as String? ?? '') != _myUid) continue;
          newIds.add(id);
          newData[id] = p;
          _subscribePost(id);
        }
      }

      // Cache first page
      if (newIds.length <= _pageSize) {
        final toCache = newIds.map((id) {
          final m = Map<String, dynamic>.from(newData[id] ?? {});
          return m;
        }).toList();
        CacheService.cacheFeedPosts(_myUid, toCache);
      }

      state = state.copyWith(
        postIds: newIds,
        postData: newData,
        lastDoc: snap.docs.last,
        hasMore: snap.docs.length == _pageSize,
        loading: false,
        firstLoad: false,
      );
    } catch (_) {
      state = state.copyWith(loading: false, firstLoad: false);
    }
  }

  Future<void> refresh() async {
    for (final s in _subs.values) s.cancel();
    _subs.clear();
    state = FeedPageState(); // reset
    _listenPinnedPosts();
    await loadMore();
  }

  /// Called when a new post is uploaded — prepend to feed without full refresh
  void prependPost(String postId, Map<String, dynamic> data) {
    if (!mounted) return;
    final newIds = [postId, ...state.postIds];
    final newData = Map<String, Map<String, dynamic>>.from(state.postData);
    data['_docId'] = postId;
    newData[postId] = data;
    _subscribePost(postId);
    state = state.copyWith(postIds: newIds, postData: newData);
  }
}

final globalFeedProvider =
    StateNotifierProvider.family<GlobalFeedNotifier, FeedPageState, String>(
  (ref, myUid) => GlobalFeedNotifier(myUid),
);

// ══════════════════════════════════════════════════════════════
//  5. PROFILE CACHE PROVIDER
// ══════════════════════════════════════════════════════════════

/// Per-uid profile data, streamed from Firestore with Hive cache fallback.
final profileProvider =
    StreamProvider.family<Map<String, dynamic>, String>((ref, uid) {
  if (uid.isEmpty) return Stream.value({});

  // Immediately emit stale cache
  final stale = CacheService.getStaleProfile(uid);

  return FirebaseFirestore.instance
      .collection('users')
      .doc(uid)
      .snapshots()
      .map((snap) {
    final data = snap.data() ?? stale ?? {};
    // Update cache asynchronously
    if (snap.exists) CacheService.cacheProfile(uid, data);
    return data;
  }).asBroadcastStream();
});

// ══════════════════════════════════════════════════════════════
//  6. INNER-CIRCLE / FOLLOW CHECKS — cached per session
// ══════════════════════════════════════════════════════════════

// ── Session-level caches (cleared on app restart) ────────────────────────────
final _followCache  = <String, bool>{};
final _savedCache   = <String, bool>{};

/// Returns true if myUid follows targetUid — session-cached to avoid N+1.
final isFollowingProvider =
    FutureProvider.family<bool, ({String myUid, String targetUid})>(
  (ref, args) async {
    if (args.myUid.isEmpty || args.targetUid.isEmpty) return false;
    if (args.myUid == args.targetUid) return false;
    final cacheKey = '${args.myUid}_${args.targetUid}';
    if (_followCache.containsKey(cacheKey)) return _followCache[cacheKey]!;
    final snap = await FirebaseFirestore.instance
        .collection('users')
        .doc(args.myUid)
        .collection('following')
        .doc(args.targetUid)
        .get();
    _followCache['${args.myUid}_${args.targetUid}'] = snap.exists;
    return snap.exists;
  },
);

/// Returns true if myUid is in targetUid's followers.
final isInInnerCircleProvider =
    FutureProvider.family<bool, ({String myUid, String targetUid})>(
  (ref, args) async {
    if (args.myUid.isEmpty || args.targetUid.isEmpty) return false;
    final cacheKey = 'inner_${args.myUid}_${args.targetUid}';
    if (_followCache.containsKey(cacheKey)) return _followCache[cacheKey]!;
    final snap = await FirebaseFirestore.instance
        .collection('users')
        .doc(args.targetUid)
        .collection('followers')
        .doc(args.myUid)
        .get();
    _followCache[cacheKey] = snap.exists;
    return snap.exists;
  },
);

// ══════════════════════════════════════════════════════════════
//  7. SAVED POST PROVIDER
// ══════════════════════════════════════════════════════════════

final savedPostProvider =
    FutureProvider.family<bool, ({String myUid, String postId})>(
  (ref, args) async {
    if (args.myUid.isEmpty || args.postId.isEmpty) return false;
    final cacheKey = 'saved_${args.myUid}_${args.postId}';
    if (_savedCache.containsKey(cacheKey)) return _savedCache[cacheKey]!;
    final snap = await FirebaseFirestore.instance
        .collection('users')
        .doc(args.myUid)
        .collection('savedPosts')
        .doc(args.postId)
        .get();
    _savedCache[cacheKey] = snap.exists;
    return snap.exists;
  },
);

// ══════════════════════════════════════════════════════════════
//  8. FOLLOWING FEED — paginated, batched
// ══════════════════════════════════════════════════════════════

class FollowingFeedState {
  final List<Map<String, dynamic>> posts;
  final bool loading;
  final bool hasMore;
  final DocumentSnapshot? lastDoc;

  const FollowingFeedState({
    this.posts = const [],
    this.loading = false,
    this.hasMore = true,
    this.lastDoc,
  });

  FollowingFeedState copyWith({
    List<Map<String, dynamic>>? posts,
    bool? loading,
    bool? hasMore,
    DocumentSnapshot? lastDoc,
    bool clearLastDoc = false,
  }) =>
      FollowingFeedState(
        posts: posts ?? this.posts,
        loading: loading ?? this.loading,
        hasMore: hasMore ?? this.hasMore,
        lastDoc: clearLastDoc ? null : lastDoc ?? this.lastDoc,
      );
}

class FollowingFeedNotifier extends StateNotifier<FollowingFeedState> {
  FollowingFeedNotifier(this._myUid) : super(const FollowingFeedState()) {
    _loadFollowingAndFetch();
  }

  static const int _pageSize = 15;
  final String _myUid;
  List<String> _followingUids = [];

  Future<void> _loadFollowingAndFetch() async {
    if (_myUid.isEmpty) return;
    try {
      final snap = await FirebaseFirestore.instance
          .collection('users')
          .doc(_myUid)
          .collection('following')
          .get();
      _followingUids = snap.docs.map((d) => d.id).toList();
    } catch (_) {}
    await loadMore();
  }

  Future<void> loadMore() async {
    if (state.loading || !state.hasMore) return;
    if (_followingUids.isEmpty) {
      state = state.copyWith(hasMore: false, loading: false);
      return;
    }
    state = state.copyWith(loading: true);
    try {
      // Firestore whereIn max 10
      final chunk = _followingUids.take(10).toList();
      Query q = FirebaseFirestore.instance
          .collection('posts')
          .where('authorId', whereIn: chunk)
          .orderBy('createdAt', descending: true)
          .limit(_pageSize);
      if (state.lastDoc != null) q = q.startAfterDocument(state.lastDoc!);
      final snap = await q.get();
      final newPosts = List<Map<String, dynamic>>.from(state.posts);
      for (final doc in snap.docs) {
        final d = Map<String, dynamic>.from(doc.data() as Map<String, dynamic>);
        d['_docId'] = doc.id;
        newPosts.add(d);
      }
      state = state.copyWith(
        posts: newPosts,
        lastDoc: snap.docs.isNotEmpty ? snap.docs.last : state.lastDoc,
        hasMore: snap.docs.length == _pageSize,
        loading: false,
      );
    } catch (_) {
      state = state.copyWith(loading: false, hasMore: false);
    }
  }

  Future<void> refresh() async {
    state = const FollowingFeedState();
    _followingUids = [];
    await _loadFollowingAndFetch();
  }
}

final followingFeedProvider =
    StateNotifierProvider.family<FollowingFeedNotifier, FollowingFeedState, String>(
  (ref, myUid) => FollowingFeedNotifier(myUid),
);

// ══════════════════════════════════════════════════════════════
//  9. IS ADMIN PROVIDER
// ══════════════════════════════════════════════════════════════

final isAdminProvider = FutureProvider.family<bool, String>((ref, uid) async {
  if (uid.isEmpty) return false;
  final snap =
      await FirebaseFirestore.instance.collection('users').doc(uid).get();
  final v = snap.data()?['isAdmin']; return v == true || v == 'true';
});
