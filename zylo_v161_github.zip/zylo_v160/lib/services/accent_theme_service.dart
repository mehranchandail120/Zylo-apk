import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Preset accent colors for Zylo.
class ZyloAccent {
  final String name;
  final Color color;
  final IconData icon;
  const ZyloAccent({required this.name, required this.color, required this.icon});
}

const List<ZyloAccent> kZyloAccents = [
  ZyloAccent(name: 'Sky Blue',    color: Color(0xFF0284C7), icon: Icons.water_drop_rounded),      // default
  ZyloAccent(name: 'Violet',      color: Color(0xFF7C3AED), icon: Icons.auto_awesome_rounded),
  ZyloAccent(name: 'Rose',        color: Color(0xFFE11D48), icon: Icons.favorite_rounded),
  ZyloAccent(name: 'Emerald',     color: Color(0xFF059669), icon: Icons.eco_rounded),
  ZyloAccent(name: 'Amber',       color: Color(0xFFD97706), icon: Icons.wb_sunny_rounded),
  ZyloAccent(name: 'Indigo',      color: Color(0xFF4338CA), icon: Icons.nights_stay_rounded),
  ZyloAccent(name: 'Pink',        color: Color(0xFFDB2777), icon: Icons.local_florist_rounded),
  ZyloAccent(name: 'Teal',        color: Color(0xFF0D9488), icon: Icons.waves_rounded),
  ZyloAccent(name: 'Orange',      color: Color(0xFFEA580C), icon: Icons.local_fire_department_rounded),
  ZyloAccent(name: 'Slate',       color: Color(0xFF475569), icon: Icons.cloud_rounded),
];

class AccentThemeService extends ChangeNotifier {
  static const _prefKey = 'zylo_accent_color';
  static const Color _defaultColor = Color(0xFF0284C7);

  Color _accent = _defaultColor;
  Color get accent => _accent;

  AccentThemeService() {
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final value = prefs.getInt(_prefKey);
    if (value != null) {
      _accent = Color(value);
      notifyListeners();
    }
  }

  Future<void> setAccent(Color color) async {
    _accent = color;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_prefKey, color.value);
  }

  /// Returns the light ThemeData with the current accent applied.
  ThemeData lightTheme(ThemeData base) => base.copyWith(
    primaryColor: _accent,
    colorScheme: base.colorScheme.copyWith(
      primary: _accent,
      secondary: _accent,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: _accent,
        foregroundColor: Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        padding: const EdgeInsets.symmetric(vertical: 14),
        minimumSize: const Size(double.infinity, 48),
        textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 0.4),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: _accent,
        side: BorderSide(color: _accent, width: 1.5),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        padding: const EdgeInsets.symmetric(vertical: 14),
        minimumSize: const Size(double.infinity, 48),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(foregroundColor: _accent),
    ),
    tabBarTheme: base.tabBarTheme.copyWith(
      indicatorColor: _accent,
      labelColor: _accent,
    ),
    checkboxTheme: base.checkboxTheme.copyWith(
      fillColor: WidgetStateProperty.resolveWith((s) =>
          s.contains(WidgetState.selected) ? _accent : null),
    ),
    switchTheme: base.switchTheme.copyWith(
      thumbColor: WidgetStateProperty.resolveWith((s) =>
          s.contains(WidgetState.selected) ? _accent : null),
      trackColor: WidgetStateProperty.resolveWith((s) =>
          s.contains(WidgetState.selected) ? _accent.withValues(alpha: 0.4) : null),
    ),
    inputDecorationTheme: base.inputDecorationTheme.copyWith(
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: _accent, width: 1.5),
      ),
    ),
    progressIndicatorTheme: ProgressIndicatorThemeData(color: _accent),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: _accent,
      foregroundColor: Colors.white,
    ),
  );

  /// Returns the dark ThemeData with the current accent applied.
  ThemeData darkTheme(ThemeData base) => base.copyWith(
    primaryColor: _accent,
    colorScheme: base.colorScheme.copyWith(
      primary: _accent,
      secondary: _accent,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: _accent,
        foregroundColor: Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        padding: const EdgeInsets.symmetric(vertical: 14),
        minimumSize: const Size(double.infinity, 48),
        textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 0.4),
      ),
    ),
    tabBarTheme: base.tabBarTheme.copyWith(
      indicatorColor: _accent,
      labelColor: _accent,
    ),
    switchTheme: base.switchTheme.copyWith(
      thumbColor: WidgetStateProperty.resolveWith((s) =>
          s.contains(WidgetState.selected) ? _accent : null),
      trackColor: WidgetStateProperty.resolveWith((s) =>
          s.contains(WidgetState.selected) ? _accent.withValues(alpha: 0.4) : null),
    ),
    progressIndicatorTheme: ProgressIndicatorThemeData(color: _accent),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: _accent,
      foregroundColor: Colors.white,
    ),
  );
}
