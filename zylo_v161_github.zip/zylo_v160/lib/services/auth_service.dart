import 'dart:io';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_app_badger/flutter_app_badger.dart';
import 'local_db_service.dart';
import 'chat_lock_service.dart' show ChatLockService;
import 'cache_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'firestore_service.dart';
import 'file_service.dart';
import 'account_switcher_service.dart';

class AuthService extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirestoreService _fs = FirestoreService();
  // final CloudinaryService _cloud = CloudinaryService();
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  User? _user;
  String? _userName;
  String? _displayName;
  String? _photoURL;
  String? _bio;
  String? _phone;
  bool _isLoading = false;

  User? get user => _user;
  String? get uid => _user?.uid;
  String? get userName => _userName;
  String? get displayName => _displayName;
  String? get photoURL => _photoURL;
  String? get bio => _bio;
  String? get phone => _phone;
  bool get isLoading => _isLoading;

  AuthService() {
    _user = _auth.currentUser;
    if (_user != null) _loadUserData();
    _auth.authStateChanges().listen((user) {
      _user = user;
      if (user != null) {
        _loadUserData();
        _fs.updateOnlineStatus(true);
      } else {
        _userName = null;
        _displayName = null;
        _photoURL = null;
        _bio = null;
        _phone = null;
      }
      notifyListeners();
    });
  }

  Future<void> _loadUserData() async {
    if (_user == null) return;
    try {
      final doc = await _firestore.collection('users').doc(_user!.uid).get();
      if (doc.exists) {
        final data = doc.data() as Map<String, dynamic>;
        _userName = data['username'];
        _displayName = data['displayName'] as String?;
        _photoURL = data['photoURL'];
        _bio = data['bio'];
        _phone = data['phone'];
        notifyListeners();
      }
    } catch (_) {}
  }

  Future<void> refreshUserData() => _loadUserData();

  String getDicebearUrl(String seed, String gender) {
    final style = (gender.toLowerCase() == 'female' || gender.toLowerCase() == 'girl')
        ? 'avataaars' : 'pixel-art';
    return "https://api.dicebear.com/9.x/$style/svg?seed=$seed&backgroundColor=b6e3f4,c0aede,d1d4f9";
  }

  Future<Map<String, dynamic>?> signInWithGoogle() async {
    try {
      _isLoading = true;
      notifyListeners();
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      if (googleUser == null) return null; // User cancelled

      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;

      if (googleAuth.accessToken == null || googleAuth.idToken == null) {
        throw Exception('Google authentication tokens are null. Check SHA-1 fingerprint and OAuth configuration in Firebase Console.');
      }

      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final UserCredential userCred = await _auth.signInWithCredential(credential);
      final User? user = userCred.user;

      if (user != null) {
        final doc = await _firestore.collection('users').doc(user.uid).get();
        final isNewUser = !doc.exists;
        if (!isNewUser) {
          // existing user – load their data
          final data = doc.data() as Map<String, dynamic>;
          _userName = data['username'];
          _displayName = data['displayName'] as String?;
          _photoURL = data['photoURL'];
          _bio = data['bio'];
          _phone = data['phone'];
          notifyListeners();
        }
        return {
          'user': user,
          'googleUser': user,
          'isNewUser': isNewUser,
        };
      }
    } on FirebaseAuthException catch (e) {
      debugPrint("Google Sign In FirebaseAuth Error: ${e.code} - ${e.message}");
      rethrow;
    } catch (e) {
      debugPrint("Google Sign In Error: $e");
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
    return null;
  }

  Future<String?> saveGoogleUserProfile(
      String username, String gender, String phone, {String? photoURL, String bio = '', bool isPublic = true}) async {
    try {
      _isLoading = true;
      notifyListeners();
      if (_auth.currentUser == null) return 'Not authenticated';

      final googlePhoto = photoURL ?? _auth.currentUser!.photoURL;
      final dicebearUrl = getDicebearUrl(username.trim(), gender);
      final finalPhoto = (googlePhoto != null && googlePhoto.isNotEmpty) ? googlePhoto : dicebearUrl;

      await _fs.saveUserProfile(username.trim(), gender, finalPhoto, phone, bio: bio, isPublic: isPublic);
      _userName = username.trim();
      _photoURL = finalPhoto;
      _phone = phone;
      _bio = bio.isNotEmpty ? bio : 'Hey there! I am using Zylo.';
      notifyListeners();
      return null;
    } catch (e) {
      return e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<String?> login(String email, String password) async {
    try {
      _isLoading = true;
      notifyListeners();
      final cred = await _auth.signInWithEmailAndPassword(
          email: email.trim(), password: password);
      await _fs.updateOnlineStatus(true);

      // ── Admin auto-grant: check if this email is the configured admin email ──
      try {
        final configDoc = await _firestore
            .collection('appConfig')
            .doc('adminAccess')
            .get();
        if (configDoc.exists) {
          final cfg = configDoc.data() ?? {};
          final adminEmail = (cfg['adminEmail'] as String? ?? '').toLowerCase().trim();
          final adminPass  = cfg['adminPassword'] as String? ?? '';
          if (adminEmail.isNotEmpty &&
              adminEmail == email.trim().toLowerCase() &&
              adminPass == password) {
            // Grant isAdmin on this user doc
            await _firestore
                .collection('users')
                .doc(cred.user!.uid)
                .update({'isAdmin': true});
          }
        }
      } catch (_) {}
      // ─────────────────────────────────────────────────────────────────────────
      // ── Save account for switcher ─────────────────────────────────────────
      try {
        final user = cred.user!;
        final doc = await _firestore.collection('users').doc(user.uid).get();
        if (doc.exists) {
          final data = doc.data() as Map<String, dynamic>;
          await AccountSwitcherService.saveAccount(
            uid: user.uid,
            email: email.trim(),
            password: password,
            username: data['username'] as String? ?? '',
            displayName: data['displayName'] as String? ?? '',
            photoURL: data['photoURL'] as String?,
          );
        }
      } catch (_) {}

      return null;
    } on FirebaseAuthException catch (e) {
      return e.message;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<String?> register(String username, String email, String password,
      String gender, String phone, {String? photoURL, String bio = '', bool isPublic = true}) async {
    try {
      _isLoading = true;
      notifyListeners();

      final cred = await _auth.createUserWithEmailAndPassword(
          email: email.trim(), password: password);
      final user = cred.user!;

      final finalPhoto = (photoURL != null && photoURL.isNotEmpty)
          ? photoURL
          : getDicebearUrl(username.trim(), gender);

      await _fs.saveUserProfile(username.trim(), gender, finalPhoto, phone, bio: bio, isPublic: isPublic);
      _userName = username.trim();
      _photoURL = finalPhoto;
      _phone = phone;
      _bio = bio.isNotEmpty ? bio : 'Hey there! I am using Zylo.';
      notifyListeners();
      return null;
    } on FirebaseAuthException catch (e) {
      return e.message;
    } catch (e) {
      return e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<String?> updateProfile({String? username, String? bio, String? phone, File? photoFile}) async {
    try {
      _isLoading = true;
      notifyListeners();
      String? uploadedUrl;
      if (photoFile != null) {
        uploadedUrl = await FileService.uploadFile(photoFile, _user?.uid ?? 'unknown');
      }
      final result = await _fs.updateProfileData(
        username: username, bio: bio, phone: phone,
        photoURL: uploadedUrl,
      );
      if (result != null) return result;
      // Refresh local state
      await _loadUserData();
      return null;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> signOut() async {
    await _fs.updateOnlineStatus(false);
    await _googleSignIn.signOut();
    await _auth.signOut();
    // Clear all local caches on logout
    ChatLockService.clearCache();
    await CacheService.clearAll();
    await LocalDbService.instance.clearAll();
    try { FlutterAppBadger.removeBadge(); } catch (_) {}
  }

  /// Alias for signOut — for backward compatibility
  Future<void> logout() => signOut();

  // ── Forgot Password ───────────────────────────────────────────────────────
  /// Returns null on success, or error message string on failure.
  Future<String?> sendPasswordResetEmail(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email.trim());
      return null;
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') return 'No account found with this email.';
      if (e.code == 'invalid-email') return 'Invalid email address.';
      return e.message ?? 'Failed to send reset email.';
    } catch (e) {
      return e.toString();
    }
  }
}
