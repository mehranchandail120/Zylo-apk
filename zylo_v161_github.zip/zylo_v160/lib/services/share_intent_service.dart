// ═══════════════════════════════════════════════════════════════════════════
// ShareIntentService — Handles incoming Android Share intents
// Fixes blank screen: stores pending intent until HomeScreen registers callback
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:receive_sharing_intent/receive_sharing_intent.dart';

class ShareIntentService {
  ShareIntentService._();
  static final ShareIntentService instance = ShareIntentService._();

  StreamSubscription<List<SharedMediaFile>>? _mediaSub;
  bool _initialized = false;

  // Pending intents (arrived before HomeScreen was ready)
  List<SharedMediaFile>? _pendingMedia;
  String? _pendingText;

  // ── Callbacks — when set, flush pending immediately ──────────────────────
  void Function(List<SharedMediaFile> files)? _onMediaShared;
  void Function(String text)? _onTextShared;

  set onMediaShared(void Function(List<SharedMediaFile>)? cb) {
    _onMediaShared = cb;
    if (cb != null && _pendingMedia != null) {
      final pending = _pendingMedia!;
      _pendingMedia = null;
      Future.microtask(() => cb(pending));
    }
  }

  set onTextShared(void Function(String)? cb) {
    _onTextShared = cb;
    if (cb != null && _pendingText != null) {
      final pending = _pendingText!;
      _pendingText = null;
      Future.microtask(() => cb(pending));
    }
  }

  Future<void> init() async {
    if (_initialized) return;
    _initialized = true;

    // ── Initial intent (app was CLOSED when share happened) ────────────────
    // Delay slightly so plugin initializes
    await Future.delayed(const Duration(milliseconds: 300));
    final initialMedia = await ReceiveSharingIntent.instance.getInitialMedia();
    if (initialMedia.isNotEmpty) {
      _dispatch(initialMedia);
    }

    // ── Stream (app is OPEN when share happens) ────────────────────────────
    _mediaSub = ReceiveSharingIntent.instance.getMediaStream().listen(_dispatch);
  }

  void _dispatch(List<SharedMediaFile> files) {
    if (files.isEmpty) return;

    final textItems  = files.where((f) => f.type == SharedMediaType.text).toList();
    final mediaItems = files.where((f) => f.type != SharedMediaType.text).toList();

    if (textItems.isNotEmpty) {
      final text = textItems.map((f) => f.path).join('\n');
      if (_onTextShared != null) {
        _onTextShared!(text);
      } else {
        _pendingText = text; // store until callback registered
      }
    }

    if (mediaItems.isNotEmpty) {
      if (_onMediaShared != null) {
        _onMediaShared!(mediaItems);
      } else {
        _pendingMedia = mediaItems; // store until callback registered
      }
    }
  }

  void reset() {
    _pendingMedia = null;
    _pendingText  = null;
    ReceiveSharingIntent.instance.reset();
  }

  void dispose() {
    _mediaSub?.cancel();
    _initialized = false;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SharedMediaInfo — normalized wrapper used by the sheet UI
// ─────────────────────────────────────────────────────────────────────────────
class SharedMediaInfo {
  final List<SharedMediaFile> files;
  final String? text;

  const SharedMediaInfo({this.files = const [], this.text});

  bool get hasFiles => files.isNotEmpty;
  bool get hasText  => text != null && text!.isNotEmpty;
  bool get isEmpty  => !hasFiles && !hasText;

  String get label {
    if (hasText && !hasFiles) return 'Text';
    if (files.length == 1) {
      switch (files.first.type) {
        case SharedMediaType.image: return 'Photo';
        case SharedMediaType.video: return 'Video';
        default: return 'File';
      }
    }
    return '${files.length} items';
  }

  IconData get icon {
    if (hasText && !hasFiles) return Icons.text_fields_rounded;
    if (files.isEmpty) return Icons.attach_file_rounded;
    switch (files.first.type) {
      case SharedMediaType.image: return Icons.image_rounded;
      case SharedMediaType.video: return Icons.videocam_rounded;
      default: return Icons.insert_drive_file_rounded;
    }
  }
}
