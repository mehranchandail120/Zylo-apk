import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// One-time migration: converts old friends subcollection → followers/following
class MigrationService {
  static final _db = FirebaseFirestore.instance;

  static Future<void> runIfNeeded(String myUid) async {
    if (myUid.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    final key   = 'friends_migrated_$myUid';
    if (prefs.getBool(key) == true) return; // already done

    try {
      final friendsSnap = await _db
          .collection('users')
          .doc(myUid)
          .collection('friends')
          .where('status', isEqualTo: 'friends')
          .get();

      if (friendsSnap.docs.isEmpty) {
        await prefs.setBool(key, true);
        return;
      }

      final batch = _db.batch();
      for (final doc in friendsSnap.docs) {
        final friendUid = doc.id;
        // myUid follows friendUid
        batch.set(
          _db.collection('users').doc(myUid).collection('following').doc(friendUid),
          {'followedAt': doc.data()['createdAt'] ?? FieldValue.serverTimestamp()},
          SetOptions(merge: true));
        // friendUid is a follower of myUid
        batch.set(
          _db.collection('users').doc(myUid).collection('followers').doc(friendUid),
          {'followedAt': doc.data()['createdAt'] ?? FieldValue.serverTimestamp()},
          SetOptions(merge: true));
      }
      await batch.commit();
      await prefs.setBool(key, true);
    } catch (e) {
      // silent fail — will retry next launch
    }
  }
}
