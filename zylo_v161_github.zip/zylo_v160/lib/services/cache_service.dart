import 'package:flutter/painting.dart';
// lib/services/cache_service.dart
// ─────────────────────────────────────────────────────────────────────────────
// Zylo local cache using Hive.
// Provides instant reads from local storage, with Firebase as the live source.
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:convert';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart';

class CacheService {
  // ── Box names ───────────────────────────────────────────────────────────────
  static const _boxMessages  = 'zylo_messages';
  static const _boxChats     = 'zylo_chats';
  static const _boxFeed      = 'zylo_feed';
  static const _boxProfiles  = 'zylo_profiles';
  static const _boxMeta      = 'zylo_meta';

  // ── TTL (time-to-live) constants ────────────────────────────────────────────
  static const Duration _profileTTL = Duration(hours: 24);  // was 6h
  static const Duration _feedTTL    = Duration(hours: 2);   // was 1h
  static const Duration _chatsTTL   = Duration(hours: 1);   // was 30min
  static const Duration _msgTTL     = Duration(hours: 24);  // was 12h

  static bool _initialized = false;

  // ── Init ────────────────────────────────────────────────────────────────────
  static Future<void> init() async {
    if (_initialized) return;
    final dir = await getApplicationDocumentsDirectory();
    await Hive.initFlutter(dir.path);
    await Future.wait([
      Hive.openBox(_boxMessages),
      Hive.openBox(_boxChats),
      Hive.openBox(_boxFeed),
      Hive.openBox(_boxProfiles),
      Hive.openBox(_boxMeta),
    ]);
    _initialized = true;
  }

  // ── Internal helpers ────────────────────────────────────────────────────────
  static Box _box(String name) => Hive.box(name);

  static bool _isExpired(String metaKey, Duration ttl) {
    final raw = _box(_boxMeta).get(metaKey);
    if (raw == null) return true;
    final saved = DateTime.fromMillisecondsSinceEpoch(raw as int);
    return DateTime.now().difference(saved) > ttl;
  }

  static void _stamp(String metaKey) {
    _box(_boxMeta).put(metaKey, DateTime.now().millisecondsSinceEpoch);
  }

  // ── PROFILE CACHE ───────────────────────────────────────────────────────────

  static Future<void> cacheProfile(String uid, Map<String, dynamic> data) async {
    await _box(_boxProfiles).put(uid, jsonEncode(data));
    _stamp('profile_$uid');
  }

  static Map<String, dynamic>? getCachedProfile(String uid) {
    final raw = _box(_boxProfiles).get(uid);
    if (raw == null) return null;
    if (_isExpired('profile_$uid', _profileTTL)) return null;
    try {
      return Map<String, dynamic>.from(jsonDecode(raw as String));
    } catch (_) {
      return null;
    }
  }

  /// Returns stale profile even if expired — useful for offline fallback.
  static Map<String, dynamic>? getStaleProfile(String uid) {
    final raw = _box(_boxProfiles).get(uid);
    if (raw == null) return null;
    try {
      return Map<String, dynamic>.from(jsonDecode(raw as String));
    } catch (_) {
      return null;
    }
  }

  // ── CHAT LIST CACHE ─────────────────────────────────────────────────────────

  static Future<void> cacheChats(String uid, List<Map<String, dynamic>> chats) async {
    await _box(_boxChats).put(uid, jsonEncode(chats));
    _stamp('chats_$uid');
  }

  static List<Map<String, dynamic>>? getCachedChats(String uid) {
    final raw = _box(_boxChats).get(uid);
    if (raw == null) return null;
    try {
      final decoded = jsonDecode(raw as String) as List;
      return decoded.map((e) => Map<String, dynamic>.from(e)).toList();
    } catch (_) {
      return null;
    }
  }

  static List<Map<String, dynamic>>? getStaleCachedChats(String uid) =>
      getCachedChats(uid); // chats are always useful offline

  // ── MESSAGES CACHE ──────────────────────────────────────────────────────────

  static String _msgKey(String myUid, String otherUid) {
    final ids = [myUid, otherUid]..sort();
    return '${ids[0]}_${ids[1]}';
  }

  static Future<void> cacheMessages(
    String myUid,
    String otherUid,
    List<Map<String, dynamic>> messages,
  ) async {
    final key = _msgKey(myUid, otherUid);
    // Only cache the last 100 messages to keep storage light
    final trimmed = messages.length > 100 ? messages.sublist(0, 100) : messages;
    await _box(_boxMessages).put(key, jsonEncode(trimmed));
    _stamp('msg_$key');
  }

  static List<Map<String, dynamic>>? getCachedMessages(String myUid, String otherUid) {
    final key = _msgKey(myUid, otherUid);
    final raw = _box(_boxMessages).get(key);
    if (raw == null) return null;
    try {
      final decoded = jsonDecode(raw as String) as List;
      return decoded.map((e) => Map<String, dynamic>.from(e)).toList();
    } catch (_) {
      return null;
    }
  }

  static List<Map<String, dynamic>>? getStaleCachedMessages(
          String myUid, String otherUid) =>
      getCachedMessages(myUid, otherUid);

  // ── FEED CACHE ──────────────────────────────────────────────────────────────

  static Future<void> cacheFeedPosts(
      String uid, List<Map<String, dynamic>> posts) async {
    final trimmed = posts.length > 60 ? posts.sublist(0, 60) : posts;
    await _box(_boxFeed).put(uid, jsonEncode(trimmed));
    _stamp('feed_$uid');
  }

  static List<Map<String, dynamic>>? getCachedFeedPosts(String uid) {
    final raw = _box(_boxFeed).get(uid);
    if (raw == null) return null;
    try {
      final decoded = jsonDecode(raw as String) as List;
      return decoded.map((e) => Map<String, dynamic>.from(e)).toList();
    } catch (_) {
      return null;
    }
  }

  static List<Map<String, dynamic>>? getStaleFeedPosts(String uid) =>
      getCachedFeedPosts(uid);

  // ── CLEAR ───────────────────────────────────────────────────────────────────

  static Future<void> clearAll() async {
    await Future.wait([
      _box(_boxMessages).clear(),
      _box(_boxChats).clear(),
      _box(_boxFeed).clear(),
      _box(_boxProfiles).clear(),
      _box(_boxMeta).clear(),
    ]);
  }

  static Future<void> clearForUser(String uid) async {
    await _box(_boxChats).delete(uid);
    await _box(_boxFeed).delete(uid);
    await _box(_boxProfiles).delete(uid);
    await _box(_boxMeta).delete('chats_$uid');
    await _box(_boxMeta).delete('feed_$uid');
    await _box(_boxMeta).delete('profile_$uid');
  }

  // ── Storage size (debug helper) ─────────────────────────────────────────────
  static int get totalEntries =>
      _box(_boxMessages).length +
      _box(_boxChats).length +
      _box(_boxFeed).length +
      _box(_boxProfiles).length;

  // ── Image cache config ────────────────────────────────────────────────────
  // Call once from main() after CacheService.init()
  // Limits Flutter's CachedNetworkImage memory + disk usage
  static void configureImageCache() {
    PaintingBinding.instance.imageCache.maximumSizeBytes = 150 * 1024 * 1024; // 150 MB RAM
    PaintingBinding.instance.imageCache.maximumSize = 600; // max 600 images in memory
  }

}
