import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:google_mlkit_translation/google_mlkit_translation.dart';
import 'package:google_mlkit_language_id/google_mlkit_language_id.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

/// On-device ML Kit translation service.
///
/// TWO modes:
///  1. INCOMING  — translate received messages into user's chosen language
///  2. OUTGOING  — auto-translate what user types before sending
///
/// HINGLISH SPECIAL HANDLING:
///  ML Kit cannot detect Hinglish (Roman-script Hindi+English mix).
///  When Hinglish is detected, Zylo AI (Supabase) is used for translation.
///  All other languages use on-device ML Kit as usual.
class TranslationService extends ChangeNotifier {
  // ── Prefs keys ─────────────────────────────────────────────────────────────
  static const _inLangKey    = 'chat_translate_lang';
  static const _inEnabledKey = 'chat_translate_enabled';
  static const _outLangKey    = 'chat_translate_out_lang';
  static const _outEnabledKey = 'chat_translate_out_enabled';

  // ── Zylo AI endpoint (for Hinglish) ───────────────────────────────────────
  static const String _aiUrl = 'https://intubotixevlfxxgyiup.supabase.co/functions/v1/ai-chat';

  // ── Language maps ──────────────────────────────────────────────────────────
  static const Map<String, String> supportedLanguages = {
    'en': 'English',
    'ar': 'Arabic',
    'zh': 'Chinese (Simplified)',
    'fr': 'French',
    'de': 'German',
    'hi': 'Hindi',
    'id': 'Indonesian',
    'it': 'Italian',
    'ja': 'Japanese',
    'ko': 'Korean',
    'fa': 'Persian',
    'pt': 'Portuguese',
    'ru': 'Russian',
    'es': 'Spanish',
    'tr': 'Turkish',
    'ur': 'Urdu',
  };

  static const Map<String, TranslateLanguage> _langMap = {
    'en': TranslateLanguage.english,
    'ar': TranslateLanguage.arabic,
    'zh': TranslateLanguage.chinese,
    'fr': TranslateLanguage.french,
    'de': TranslateLanguage.german,
    'hi': TranslateLanguage.hindi,
    'id': TranslateLanguage.indonesian,
    'it': TranslateLanguage.italian,
    'ja': TranslateLanguage.japanese,
    'ko': TranslateLanguage.korean,
    'fa': TranslateLanguage.persian,
    'pt': TranslateLanguage.portuguese,
    'ru': TranslateLanguage.russian,
    'es': TranslateLanguage.spanish,
    'tr': TranslateLanguage.turkish,
    'ur': TranslateLanguage.urdu,
  };

  // ── Common Hinglish words (Roman-script Hindi/Urdu) ───────────────────────
  // These words appear in Hinglish but NOT in normal English text.
  // Used to detect Hinglish input so we can route to AI instead of ML Kit.
  static const Set<String> _hinglishWords = {
    'aaj', 'kal', 'kya', 'kaise', 'kaisa', 'kaisi', 'kyun', 'kyunki',
    'nahi', 'nahin', 'nai', 'haan', 'ha', 'hai', 'hain', 'tha', 'thi',
    'ho', 'hoga', 'hogi', 'hoge', 'kar', 'karo', 'karna', 'karta',
    'karti', 'karte', 'kiya', 'ki', 'ke', 'ka', 'ko', 'se', 'mein',
    'main', 'mai', 'tum', 'aap', 'woh', 'wo', 'yeh', 'ye', 'yahan',
    'wahan', 'ab', 'abhi', 'phir', 'fir', 'bhi', 'bhai', 'didi', 'yaar',
    'yrr', 'yr', 'mere', 'mera', 'meri', 'tera', 'teri', 'tere',
    'uska', 'uski', 'unka', 'unki', 'unke', 'humara', 'humari', 'humare',
    'bahut', 'bohot', 'boht', 'thoda', 'thodi', 'accha', 'achha', 'acha',
    'sahi', 'galat', 'bilkul', 'zaroor', 'zarur', 'plz', 'pls',
    'baat', 'kaam', 'din', 'raat', 'subah', 'sham', 'ghar', 'bahar',
    'andar', 'upar', 'neeche', 'aage', 'peeche', 'dost', 'pyaar', 'pyar',
    'dil', 'zindagi', 'duniya', 'log', 'aadmi', 'aurat', 'baccha',
    'chal', 'chalo', 'chalna', 'aa', 'aao', 'aana', 'ja', 'jao', 'jana',
    'dekh', 'dekho', 'dekhna', 'sun', 'suno', 'sunna', 'bol', 'bolo',
    'bolna', 'laga', 'lagi', 'lage', 'lagta', 'lagti', 'lagey', 'raha',
    'rahi', 'rahe', 'wala', 'wali', 'wale', 'waala', 'waali', 'waale',
    'matlab', 'matlb', 'mtlb', 'samjha', 'samjhi', 'samajh', 'pata',
    'patha', 'malum', 'kuch', 'koi', 'sab', 'sabko', 'sabse',
    'sirf', 'bas', 'par', 'lekin', 'magar', 'aur', 'ya', 'toh',
    'warna', 'isliye', 'agar', 'jab', 'tab', 'jaise', 'tarah',
    'itna', 'utna', 'kitna', 'kaafi', 'thak', 'thaka', 'thaki',
    'tang', 'pareshaan', 'khush', 'dukhi', 'gussa',
    'hasna', 'rona', 'khaana', 'peena', 'sona', 'uthna', 'bethna',
    'milna', 'milte', 'milege', 'bhej', 'bhejo', 'bhejna', 'lena',
    'dena', 'rakho', 'rakh', 'apna', 'apni', 'apne',
    'khud', 'khudse', 'zyada', 'jyada', 'kam', 'ekdum',
    'pakka', 'pukka', 'pakki', 'sach', 'jhooth', 'jooth', 'yaad',
    'bhool', 'socha', 'socho', 'sochna', 'hua', 'hui', 'hue',
    'kr', 'krna', 'krdo', 'hoja', 'aaja', 'btao', 'bta',
    'batao', 'batana', 'btana', 'dekha', 'dekhi',
    'allah', 'khuda', 'inshallah', 'mashallah', 'alhamdulillah',
    'subhanallah', 'jazakallah', 'shukar', 'shukria', 'shukran',
    'mehrbani', 'shukriya', 'khair', 'theek',
  };

  // ── Internals ──────────────────────────────────────────────────────────────
  final LanguageIdentifier _langId = LanguageIdentifier(confidenceThreshold: 0.5);
  final OnDeviceTranslatorModelManager _modelManager = OnDeviceTranslatorModelManager();
  final Map<String, OnDeviceTranslator> _translators = {};
  final Map<String, String> _cache = {};

  // ── Incoming state ─────────────────────────────────────────────────────────
  String _inLang   = 'en';
  bool   _inEnabled = false;

  // ── Outgoing state ─────────────────────────────────────────────────────────
  String _outLang    = 'en';
  bool   _outEnabled = false;

  // ── Getters ────────────────────────────────────────────────────────────────
  String get inLang        => _inLang;
  String get inLangName    => supportedLanguages[_inLang]    ?? _inLang;
  bool   get inEnabled     => _inEnabled;

  String get outLang       => _outLang;
  String get outLangName   => supportedLanguages[_outLang]   ?? _outLang;
  bool   get outEnabled    => _outEnabled;

  // Legacy alias used by existing code
  String get targetLang     => _inLang;
  String get targetLangName => inLangName;
  bool   get isEnabled      => _inEnabled;

  bool   _isDownloadingModel = false;
  String? _downloadError;
  bool   get isDownloadingModel => _isDownloadingModel;
  String? get downloadError    => _downloadError;

  // ── Init ───────────────────────────────────────────────────────────────────
  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _inLang     = prefs.getString(_inLangKey)    ?? 'en';
    _inEnabled  = prefs.getBool(_inEnabledKey)   ?? false;
    _outLang    = prefs.getString(_outLangKey)   ?? 'en';
    _outEnabled = prefs.getBool(_outEnabledKey)  ?? false;
    notifyListeners();
  }

  // ── Setters ────────────────────────────────────────────────────────────────
  Future<void> setIncomingLanguage(String tag) async {
    if (_inLang == tag) return;
    _inLang = tag;
    _clearInCache();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_inLangKey, tag);
    notifyListeners();
  }

  Future<void> setIncomingEnabled(bool v) async {
    _inEnabled = v;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_inEnabledKey, v);
    notifyListeners();
  }

  Future<void> setOutgoingLanguage(String tag) async {
    if (_outLang == tag) return;
    _outLang = tag;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_outLangKey, tag);
    notifyListeners();
  }

  Future<void> setOutgoingEnabled(bool v) async {
    _outEnabled = v;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_outEnabledKey, v);
    notifyListeners();
  }

  // Legacy compat
  Future<void> setTargetLanguage(String tag) => setIncomingLanguage(tag);
  Future<void> setEnabled(bool v)            => setIncomingEnabled(v);

  void _clearInCache() {
    _cache.clear();
  }

  // ── Model download with user permission ───────────────────────────────────
  /// Called when user enables translation or changes language.
  /// Shows a dialog explaining model download, then downloads if user agrees.
  /// Returns true if model is ready (already downloaded OR user accepted + download succeeded).
  Future<bool> ensureModelReady(
    String tag, {
    required Future<bool> Function(String langName, double modelSizeMb) askUserPermission,
    void Function(double progress)? onProgress,
  }) async {
    final alreadyDownloaded = await isModelDownloaded(tag);
    if (alreadyDownloaded) return true;

    final langName = supportedLanguages[tag] ?? tag;
    // Each ML Kit translation model is roughly 30 MB
    const modelSizeMb = 30.0;

    final allowed = await askUserPermission(langName, modelSizeMb);
    if (!allowed) return false;

    return downloadModel(tag, onProgress: onProgress);
  }

  // ── Model management ───────────────────────────────────────────────────────
  Future<bool> isModelDownloaded(String tag) async {
    final lang = _langMap[tag];
    if (lang == null) return false;
    try { return await _modelManager.isModelDownloaded(lang.bcpCode); }
    catch (_) { return false; }
  }

  Future<bool> downloadModel(String tag, {void Function(double)? onProgress}) async {
    final lang = _langMap[tag];
    if (lang == null) return false;
    _isDownloadingModel = true;
    _downloadError = null;
    notifyListeners();
    try {
      onProgress?.call(0.1);
      final ok = await _modelManager.downloadModel(lang.bcpCode, isWifiRequired: false);
      onProgress?.call(1.0);
      _isDownloadingModel = false;
      notifyListeners();
      return ok;
    } catch (e) {
      _isDownloadingModel = false;
      _downloadError = e.toString();
      notifyListeners();
      return false;
    }
  }

  // ── Hinglish Detection ────────────────────────────────────────────────────
  /// Detects if the given text is Hinglish (Roman-script Hindi/Urdu mixed with English).
  /// ML Kit cannot identify Hinglish as a language, so we use a word-match heuristic.
  ///
  /// Logic:
  ///  1. Text must use Latin/Roman script (no Devanagari/Arabic chars → pure Hindi/Urdu)
  ///  2. At least [minHinglishWords] words from [_hinglishWords] must appear
  ///  3. Minimum word count to avoid false positives on short text
  bool isHinglish(String text) {
    if (text.trim().isEmpty) return false;

    // If text contains Devanagari (Hindi script) or Arabic (Urdu script) → NOT Hinglish
    final hasDevanagari = RegExp(r'[\u0900-\u097F]').hasMatch(text);
    final hasArabic     = RegExp(r'[\u0600-\u06FF]').hasMatch(text);
    if (hasDevanagari || hasArabic) return false;

    // Tokenise to lowercase words (strip punctuation)
    final words = text.toLowerCase()
        .replaceAll(RegExp(r"[^a-z\s]"), ' ')
        .split(RegExp(r'\s+'))
        .where((w) => w.length > 1)
        .toList();

    if (words.length < 2) return false; // too short to judge

    // Count how many words are known Hinglish words
    int hinglishCount = 0;
    for (final w in words) {
      if (_hinglishWords.contains(w)) hinglishCount++;
    }

    // Threshold: at least 1 Hinglish word in short texts, or ≥20% in longer texts
    final threshold = words.length <= 4 ? 1 : (words.length * 0.2).ceil();
    return hinglishCount >= threshold;
  }

  // ── Language detection (ML Kit) ────────────────────────────────────────────
  Future<String?> detectLanguage(String text) async {
    if (text.trim().isEmpty) return null;
    try {
      final tag = await _langId.identifyLanguage(text);
      return tag == 'und' ? null : tag;
    } catch (_) { return null; }
  }

  // ── AI Translation via Zylo AI (for Hinglish) ────────────────────────────
  /// Sends text to Zylo AI with a strict translation instruction.
  /// Returns only the translated text, no commentary.
  Future<String?> _translateViaAI(String text, String targetLangName) async {
    final cacheKey = 'ai|$targetLangName|$text';
    if (_cache.containsKey(cacheKey)) return _cache[cacheKey];

    try {
      final prompt =
          'Translate the following Hinglish text (Roman-script Hindi/Urdu mixed with English) '
          'to $targetLangName. '
          'Return ONLY the translated text. No explanation, no quotes, no extra words.\n\n'
          'Text: $text';

      final response = await http.post(
        Uri.parse(_aiUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'message': prompt,
          'session_id': 'hinglish_translate_${DateTime.now().millisecondsSinceEpoch}',
          'custom_instruction':
              'You are a precise translation engine. '
              'Always respond with ONLY the translated text. '
              'Never add explanations, quotes, or commentary.',
        }),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        // Zylo AI returns { reply: "..." }
        final translated = (data['reply'] ?? data['message'] ?? data['text'] ?? '').toString().trim();
        if (translated.isNotEmpty) {
          _cache[cacheKey] = translated;
          return translated;
        }
      }
    } catch (_) {
      // Fall through — return null so caller can skip translation
    }
    return null;
  }

  // ── Incoming translation (received messages) ───────────────────────────────
  /// Auto-detects source language, translates to [_inLang].
  /// If Hinglish detected → uses Zylo AI.
  /// Otherwise → uses on-device ML Kit.
  /// Returns null if same language, disabled, or fails.
  /// Returns [TranslationResult.modelNotDownloaded] sentinel if model needs download.
  Future<String?> translate(String text) async {
    if (!_inEnabled || text.trim().isEmpty) return null;
    try {
      // ── Hinglish check first (ML Kit can't detect it) ──────────────────
      if (isHinglish(text)) {
        final tgtName = supportedLanguages[_inLang] ?? _inLang;
        // Don't translate if target is Hindi/Urdu (Hinglish is close enough)
        if (_inLang == 'hi' || _inLang == 'ur') return null;
        return await _translateViaAI(text, tgtName);
      }

      // ── Normal ML Kit path ─────────────────────────────────────────────
      final modelReady = await isModelDownloaded(_inLang);
      if (!modelReady) return TranslationResult.modelNotDownloaded;
      final srcTag = await detectLanguage(text);
      if (srcTag == null) return null;
      final normSrc = srcTag.split('-').first.toLowerCase();
      if (normSrc == _inLang) return null;
      return await _doTranslate(text, normSrc, _inLang);
    } catch (_) { return null; }
  }

  // ── Outgoing translation (sent messages) ───────────────────────────────────
  /// Auto-detects source language, translates to [_outLang].
  /// If Hinglish detected → uses Zylo AI.
  /// Otherwise → uses on-device ML Kit.
  /// Returns null if disabled, same language, or fails.
  /// Returns [TranslationResult.modelNotDownloaded] sentinel if model needs download.
  Future<String?> translateOutgoing(String text) async {
    if (!_outEnabled || text.trim().isEmpty) return null;
    try {
      // ── Hinglish check first ───────────────────────────────────────────
      if (isHinglish(text)) {
        final tgtName = supportedLanguages[_outLang] ?? _outLang;
        // If target is Hindi/Urdu, Hinglish is already close — skip
        if (_outLang == 'hi' || _outLang == 'ur') return null;
        return await _translateViaAI(text, tgtName);
      }

      // ── Normal ML Kit path ─────────────────────────────────────────────
      final modelReady = await isModelDownloaded(_outLang);
      if (!modelReady) return TranslationResult.modelNotDownloaded;
      final srcTag = await detectLanguage(text);
      if (srcTag == null) return null;
      final normSrc = srcTag.split('-').first.toLowerCase();
      if (normSrc == _outLang) return null;
      return await _doTranslate(text, normSrc, _outLang);
    } catch (_) { return null; }
  }

  Future<String?> _doTranslate(String text, String src, String tgt) async {
    final srcEnum = _langMap[src];
    final tgtEnum = _langMap[tgt];
    if (srcEnum == null || tgtEnum == null) return null;
    final cacheKey = '$src|$tgt|$text';
    if (_cache.containsKey(cacheKey)) return _cache[cacheKey];
    final translator = _getOrCreate(srcEnum, tgtEnum);
    final result = await translator.translateText(text);
    _cache[cacheKey] = result;
    return result;
  }

  OnDeviceTranslator _getOrCreate(TranslateLanguage src, TranslateLanguage tgt) {
    final key = '${src.bcpCode}_${tgt.bcpCode}';
    return _translators[key] ??= OnDeviceTranslator(sourceLanguage: src, targetLanguage: tgt);
  }

  @override
  void dispose() {
    _langId.close();
    for (final t in _translators.values) t.close();
    super.dispose();
  }
}

/// Sentinel values returned by [TranslationService.translate] /
/// [TranslationService.translateOutgoing] so callers can distinguish
/// "model not yet downloaded" from a real translation failure (null).
///
/// Usage:
/// ```dart
/// final result = await translationService.translate(text);
/// if (result == TranslationResult.modelNotDownloaded) {
///   // Show download dialog to user
/// } else if (result != null) {
///   // Show translated text
/// }
/// ```
abstract final class TranslationResult {
  /// Returned when the ML Kit model for the selected language has not been
  /// downloaded yet. The caller should prompt the user to download it via
  /// [TranslationService.ensureModelReady].
  static const String modelNotDownloaded = '__model_not_downloaded__';
}
