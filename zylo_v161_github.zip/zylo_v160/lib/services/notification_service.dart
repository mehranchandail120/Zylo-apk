import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class NotificationService {
  static const String _backendUrl =
      'https://zylo-notify.vercel.app/api/notify';

  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String? get _myUidSafe => _auth.currentUser?.uid;
  String get _myUid => _auth.currentUser!.uid;

  // ── Save OneSignal Player ID for this user ──────────────────────────────────
  Future<void> savePlayerId(String playerId) async {
    await _db.collection('users').doc(_myUid).update({
      'oneSignalPlayerId': playerId,
    });
  }

  // ── Get my own photo URL from Firestore ─────────────────────────────────────
  Future<String?> _getMyPhotoUrl() async {
    final doc = await _db.collection('users').doc(_myUid).get();
    return doc.data()?['photoURL'] as String?;
  }

  // ── Send push + save to Firestore notifications ─────────────────────────────
  // ── Mute helpers (per-user chat mute stored in Firestore) ──────────────────
  /// Returns true if [toUid] has muted chat with [fromUid] (i.e. _myUid).
  Future<bool> isMutedBy(String toUid) async {
    try {
      final doc = await _db
          .collection('users').doc(toUid)
          .collection('mutedChats').doc(_myUid)
          .get();
      return doc.exists;
    } catch (_) { return false; }
  }

  /// Mute chat with [otherUid] for current user.
  Future<void> muteChat(String otherUid) =>
      _db.collection('users').doc(_myUid)
          .collection('mutedChats').doc(otherUid)
          .set({'mutedAt': FieldValue.serverTimestamp()});

  /// Unmute chat with [otherUid] for current user.
  Future<void> unmuteChat(String otherUid) =>
      _db.collection('users').doc(_myUid)
          .collection('mutedChats').doc(otherUid)
          .delete();

  /// Stream: is chat with [otherUid] muted?
  Stream<bool> mutedStream(String otherUid) =>
      _db.collection('users').doc(_myUid)
          .collection('mutedChats').doc(otherUid)
          .snapshots()
          .map((d) => d.exists);
  // ───────────────────────────────────────────────────────────────────────────

  Future<void> sendMessageNotification({
    required String toUid,
    required String fromName,
    required String messageText,
    required String chatId,
    String? mediaType,
  }) async {
    // Build rich emoji preview — WhatsApp style
    String preview;
    final mediaIcons = {
      'image': '📷 Photo',
      'video': '🎥 Video',
      'audio': '🎤 Voice message',
      'document': '📄 Document',
      'gif': '🎭 GIF',
      'sticker': '🏷️ Sticker',
      'contact': '👤 Contact',
      'location': '📍 Location',
    };

    if (mediaType != null && mediaIcons.containsKey(mediaType)) {
      // Media message: show icon + optional caption
      final icon = mediaIcons[mediaType]!;
      if (messageText.isNotEmpty &&
          !['Photo', 'Video', 'Audio', 'Document'].contains(messageText)) {
        preview = '$icon — ${messageText.length > 40 ? messageText.substring(0, 40) + '...' : messageText}';
      } else {
        preview = icon;
      }
    } else if (messageText.startsWith('http')) {
      preview = '🔗 Link';
    } else if (messageText.isEmpty) {
      preview = '💬 Message';
    } else {
      preview = messageText.length > 80
          ? '${messageText.substring(0, 80)}...'
          : messageText;
    }

    // Check if receiver muted this chat — skip in-app + push both
    final muted = await isMutedBy(toUid);
    if (muted) return;

    // Get my photo once, reuse for both in-app and push
    final myPhotoUrl = await _getMyPhotoUrl();

    // 1. Save to Firestore (in-app bell)
    await _db.collection('users').doc(toUid).collection('notifications').add({
      'type': 'message',
      'text': '@$fromName sent you a message',
      'preview': preview,
      'fromUid': _myUid,
      'fromName': fromName,
      'fromPhoto': myPhotoUrl ?? '',
      'chatId': chatId,
      'mediaType': mediaType,
      'read': false,
      'createdAt': FieldValue.serverTimestamp(),
    });

    // 2. Get receiver's player ID
    final userDoc = await _db.collection('users').doc(toUid).get();

    final playerId = userDoc.data() != null
        ? (userDoc.data() as Map<String, dynamic>)['oneSignalPlayerId'] as String?
        : null;
    if (playerId == null || playerId.isEmpty) return;

    // 3. Send push via Vercel backend
    try {
      await http.post(
        Uri.parse(_backendUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'playerIds': [playerId],
          'title': fromName,
          'message': preview,
          'senderPhotoUrl': myPhotoUrl,
          'data': {
            'type': 'message',
            'chatId': chatId,
            'fromUid': _myUid,
            'fromName': fromName,
          },
        }),
      );
    } catch (_) {
      // Silent fail — in-app notification saved anyway
    }
  }

  // ── Follow Notification ───────────────────────────────────────────────────
  /// Call this right after followUser() succeeds.
  Future<void> sendFollowNotification({
    required String toUid,
    required String fromName,
  }) async {
    if (_myUidSafe == null || _myUidSafe == toUid) return;

    // 1. Save in-app notification
    final myPhoto = await _getMyPhotoUrl();
    await _db.collection('users').doc(toUid).collection('notifications').add({
      'type':      'follow',
      'text':      '@$fromName started following you',
      'fromUid':   _myUid,
      'fromName':  fromName,
      'fromPhoto': myPhoto ?? '',
      'read':      false,
      'createdAt': FieldValue.serverTimestamp(),
    });

    // 2. Push notification
    final userDoc   = await _db.collection('users').doc(toUid).get();
    final myPhoto2  = myPhoto; // reuse already fetched
    final playerId  = userDoc.data() != null
        ? (userDoc.data() as Map<String, dynamic>)['oneSignalPlayerId'] as String?
        : null;
    if (playerId == null || playerId.isEmpty) return;

    try {
      await http.post(
        Uri.parse(_backendUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'playerIds':      [playerId],
          'title':          fromName,
          'message':        'started following you',
          'senderPhotoUrl': myPhoto2,
          'data': {
            'type':    'follow',
            'fromUid': _myUid,
          },
        }),
      ).timeout(
        const Duration(seconds: 5),
        onTimeout: () => http.Response('timeout', 408),
      );
    } catch (_) {}
  }

  // ── Feed Notification: notify Following when user posts ─────────────────
  /// Call this after a new post is created.
  /// Reads the author's Following list, gets their player IDs,
  /// and sends a push + saves an in-app notification for each member.
  Future<void> sendFeedNotification({
    required String authorName,
    required String? authorPhotoUrl,
    required String postText,
    required String postId,
    required String visibility, // 'public' or 'inner'
  }) async {
    try {
      // Build preview text
      final preview = postText.trim().isNotEmpty
          ? (postText.length > 70 ? '${postText.substring(0, 70)}...' : postText)
          : '📷 Shared a new post';

      // Get followers UIDs (people who follow me get notified)
      final circleSnap = await _db
          .collection('users').doc(_myUid).collection('followers')
          .get();
      if (circleSnap.docs.isEmpty) return;

      final memberUids = circleSnap.docs.map((d) => d.id).toList();

      // Batch: get all member docs (player IDs + mute status) in chunks of 30
      final List<String> playerIds = [];
      final batch = _db.batch();

      // Process in chunks of 10 (Firestore whereIn limit safe)
      for (int i = 0; i < memberUids.length; i += 10) {
        final chunk = memberUids.sublist(i, i + 10 > memberUids.length ? memberUids.length : i + 10);
        final usersSnap = await _db.collection('users')
            .where(FieldPath.documentId, whereIn: chunk)
            .get();

        for (final userDoc in usersSnap.docs) {
          final uid = userDoc.id;
          final data = userDoc.data();

          // Skip if user muted this author
          final muteDoc = await _db
              .collection('users').doc(uid)
              .collection('mutedFeeds').doc(_myUid)
              .get();
          if (muteDoc.exists) continue;

          // Save in-app notification
          final notifRef = _db
              .collection('users').doc(uid)
              .collection('notifications').doc();
          batch.set(notifRef, {
            'type': 'feed_post',
            'text': '@$authorName posted something new',
            'preview': preview,
            'fromUid': _myUid,
            'fromName': authorName,
            'fromPhoto': authorPhotoUrl ?? '',
            'postId': postId,
            'visibility': visibility,
            'read': false,
            'createdAt': FieldValue.serverTimestamp(),
          });

          // Collect player ID for push
          final pid = data['oneSignalPlayerId'] as String?;
          if (pid != null && pid.isNotEmpty) playerIds.add(pid);
        }
      }

      // Commit all in-app notifications at once
      await batch.commit();

      // Send push to all player IDs in one call
      if (playerIds.isEmpty) return;
      await http.post(
        Uri.parse(_backendUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'playerIds': playerIds,
          'title': authorName,
          'message': preview,
          'senderPhotoUrl': authorPhotoUrl,
          'data': {
            'type': 'feed_post',
            'postId': postId,
            'fromUid': _myUid,
            'fromName': authorName,
          },
        }),
      );
    } catch (_) {
      // Silent fail
    }
  }

  // ── Mute/unmute feed posts from a user ─────────────────────────────────────
  Future<void> muteFeedFrom(String authorUid) => _db
      .collection('users').doc(_myUid)
      .collection('mutedFeeds').doc(authorUid)
      .set({'mutedAt': FieldValue.serverTimestamp()});

  Future<void> unmuteFeedFrom(String authorUid) => _db
      .collection('users').doc(_myUid)
      .collection('mutedFeeds').doc(authorUid)
      .delete();

  Stream<bool> feedMutedStream(String authorUid) => _db
      .collection('users').doc(_myUid)
      .collection('mutedFeeds').doc(authorUid)
      .snapshots().map((d) => d.exists);


  Future<void> markAsRead(String notifId) async {
    await _db
        .collection('users')
        .doc(_myUid)
        .collection('notifications')
        .doc(notifId)
        .update({'read': true});
  }

  // ── Mark all notifications as read ─────────────────────────────────────────
  Future<void> markAllAsRead() async {
    final batch = _db.batch();
    final snaps = await _db
        .collection('users')
        .doc(_myUid)
        .collection('notifications')
        .where('read', isEqualTo: false)
        .get();
    for (final doc in snaps.docs) {
      batch.update(doc.reference, {'read': true});
    }
    await batch.commit();
  }

  // ── Stream of unread count ──────────────────────────────────────────────────
  Stream<int> unreadCountStream() {
    return _db
        .collection('users')
        .doc(_myUid)
        .collection('notifications')
        .where('read', isEqualTo: false)
        .snapshots()
        .map((snap) => snap.docs.length);
  }

  // ── Stream of all notifications ─────────────────────────────────────────────
  Stream<QuerySnapshot> notificationsStream() {
    return _db
        .collection('users')
        .doc(_myUid)
        .collection('notifications')
        .orderBy('createdAt', descending: true)
        .limit(50)
        .snapshots();
  }

  // ── Quick Reply from notification ───────────────────────────────────────────
  Future<void> quickReply({
    required String toUid,
    required String toName,
    required String replyText,
  }) async {
    if (replyText.trim().isEmpty) return;

    final ids = [_myUid, toUid]..sort();
    final chatId = '${ids[0]}_${ids[1]}';

    await _db.collection('chats').doc(chatId).collection('messages').add({
      'senderId': _myUid,
      'text': replyText.trim(),
      'mediaType': 'text',
      'isRead': false,
      'timestamp': FieldValue.serverTimestamp(),
    });

    await _db.collection('chats').doc(chatId).update({
      'lastMsg': replyText.trim(),
      'lastMsgTime': FieldValue.serverTimestamp(),
      'unreadCount.$toUid': FieldValue.increment(1),
    });

    final myDoc = await _db.collection('users').doc(_myUid).get();
    final myName = myDoc.data()?['username'] as String? ?? 'Someone';

    await sendMessageNotification(
      toUid: toUid,
      fromName: myName,
      messageText: replyText.trim(),
      chatId: chatId,
    );
  }

  // ── Upload / Download Notifications ───────────────────────────────────────

  /// Call karo jab file upload complete ho
  static Future<void> sendUploadCompleteNotification({
    required String fileName,
    required String fileSize,
    bool isSuccess = true,
  }) async {
    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) return;

      final db = FirebaseFirestore.instance;

      // Get my own player ID
      final myDoc = await db.collection('users').doc(uid).get();
      final playerId = myDoc.data()?['oneSignalPlayerId'] as String?;
      if (playerId == null || playerId.isEmpty) return;

      final title = isSuccess ? '✅ Upload Complete' : '❌ Upload Failed';
      final message = isSuccess
          ? '$fileName ($fileSize) uploaded successfully'
          : '$fileName could not be uploaded. Tap to retry.';

      // Save in-app notification
      await db.collection('users').doc(uid).collection('notifications').add({
        'type': 'upload_complete',
        'text': title,
        'preview': message,
        'fileName': fileName,
        'isSuccess': isSuccess,
        'read': false,
        'createdAt': FieldValue.serverTimestamp(),
      });

      // Send push notification to self
      await http.post(
        Uri.parse(_backendUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'playerIds': [playerId],
          'title': title,
          'message': message,
          'data': {
            'type': 'upload_complete',
            'fileName': fileName,
            'isSuccess': isSuccess,
          },
        }),
      );
    } catch (e) {
      debugPrint('[NotificationService] Upload notif error: $e');
    }
  }

  /// Call karo jab file download complete ho
  static Future<void> sendDownloadCompleteNotification({
    required String fileName,
    bool isSuccess = true,
  }) async {
    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) return;

      final db = FirebaseFirestore.instance;
      final myDoc = await db.collection('users').doc(uid).get();
      final playerId = myDoc.data()?['oneSignalPlayerId'] as String?;
      if (playerId == null || playerId.isEmpty) return;

      final title = isSuccess ? '⬇️ Download Complete' : '❌ Download Failed';
      final message = isSuccess
          ? '$fileName saved to your device'
          : '$fileName could not be downloaded';

      // Save in-app notification
      await db.collection('users').doc(uid).collection('notifications').add({
        'type': 'download_complete',
        'text': title,
        'preview': message,
        'fileName': fileName,
        'isSuccess': isSuccess,
        'read': false,
        'createdAt': FieldValue.serverTimestamp(),
      });

      // Push notification
      await http.post(
        Uri.parse(_backendUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'playerIds': [playerId],
          'title': title,
          'message': message,
          'data': {
            'type': 'download_complete',
            'fileName': fileName,
            'isSuccess': isSuccess,
          },
        }),
      );
    } catch (e) {
      debugPrint('[NotificationService] Download notif error: $e');
    }
  }

  /// Backup complete notification
  static Future<void> sendBackupCompleteNotification({
    required bool isSuccess,
    required bool isRestore,
    String? detail,
  }) async {
    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) return;

      final db = FirebaseFirestore.instance;
      final myDoc = await db.collection('users').doc(uid).get();
      final playerId = myDoc.data()?['oneSignalPlayerId'] as String?;
      if (playerId == null || playerId.isEmpty) return;

      final title = isSuccess
          ? (isRestore ? '✅ Restore Complete' : '✅ Backup Complete')
          : (isRestore ? '❌ Restore Failed' : '❌ Backup Failed');

      final message = detail ??
          (isSuccess
              ? (isRestore ? 'Your data has been restored from Google Drive' : 'Your chats are backed up to Google Drive')
              : 'Something went wrong. Tap to retry.');

      await db.collection('users').doc(uid).collection('notifications').add({
        'type': isRestore ? 'restore_complete' : 'backup_complete',
        'text': title,
        'preview': message,
        'isSuccess': isSuccess,
        'read': false,
        'createdAt': FieldValue.serverTimestamp(),
      });

      await http.post(
        Uri.parse(_backendUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'playerIds': [playerId],
          'title': title,
          'message': message,
          'data': {'type': isRestore ? 'restore_complete' : 'backup_complete'},
        }),
      );
    } catch (e) {
      debugPrint('[NotificationService] Backup notif error: $e');
    }
  }

  /// Format file size
  static String formatFileSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }

  // ── Post Like / Reaction Push Notification ───────────────────────────────
  /// Push only — in-app notification already written in feed_screen.
  Future<void> sendLikeNotification({
    required String toUid,
    required String fromName,
    String? fromPhotoUrl,
    required String postId,
    String emoji = '❤️',
  }) async {
    if (_myUidSafe == null || _myUidSafe == toUid) return;
    final userDoc  = await _db.collection('users').doc(toUid).get();
    final playerId = userDoc.data()?['oneSignalPlayerId'] as String?;
    if (playerId == null || playerId.isEmpty) return;
    try {
      await http.post(
        Uri.parse(_backendUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'playerIds':      [playerId],
          'title':          fromName,
          'message':        'reacted $emoji to your post',
          'senderPhotoUrl': fromPhotoUrl,
          'data': {
            'type':    'post_like',
            'postId':  postId,
            'fromUid': _myUid,
          },
        }),
      ).timeout(const Duration(seconds: 5), onTimeout: () => http.Response('timeout', 408));
    } catch (_) {}
  }

  // ── Comment / Reply Push Notification ────────────────────────────────────
  /// Push only — in-app notification is already written by post_comments_screen.
  Future<void> sendCommentNotification({
    required String toUid,
    required String fromName,
    String? fromPhotoUrl,
    required String postId,
    required bool isReply,
  }) async {
    if (_myUidSafe == null || _myUidSafe == toUid) return;
    final userDoc  = await _db.collection('users').doc(toUid).get();
    final playerId = userDoc.data()?['oneSignalPlayerId'] as String?;
    if (playerId == null || playerId.isEmpty) return;
    final message  = isReply ? 'replied to your comment 💬' : 'commented on your post 💬';
    try {
      await http.post(
        Uri.parse(_backendUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'playerIds':      [playerId],
          'title':          fromName,
          'message':        message,
          'senderPhotoUrl': fromPhotoUrl,
          'data': {
            'type':    isReply ? 'comment_reply' : 'post_comment',
            'postId':  postId,
            'fromUid': _myUid,
          },
        }),
      ).timeout(const Duration(seconds: 5), onTimeout: () => http.Response('timeout', 408));
    } catch (_) {}
  }

  // ── Post Saved Notification ───────────────────────────────────────────────
  /// Call karo jab koi tera post save kare.
  Future<void> sendPostSavedNotification({
    required String toUid,
    required String postId,
    required String fromName,
    String? fromPhotoUrl,
  }) async {
    if (_myUidSafe == null || _myUidSafe == toUid) return;
    final myPhoto = fromPhotoUrl ?? await _getMyPhotoUrl();

    // 1. In-app notification
    await _db.collection('users').doc(toUid).collection('notifications').add({
      'type':      'post_saved',
      'text':      '@$fromName saved your post',
      'fromUid':   _myUid,
      'fromName':  fromName,
      'fromPhoto': myPhoto ?? '',
      'postId':    postId,
      'read':      false,
      'createdAt': FieldValue.serverTimestamp(),
    });

    // 2. Push notification
    final userDoc  = await _db.collection('users').doc(toUid).get();
    final playerId = userDoc.data()?['oneSignalPlayerId'] as String?;
    if (playerId == null || playerId.isEmpty) return;
    try {
      await http.post(
        Uri.parse(_backendUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'playerIds':      [playerId],
          'title':          fromName,
          'message':        'saved your post 🔖',
          'senderPhotoUrl': myPhoto,
          'data': {
            'type':    'post_saved',
            'postId':  postId,
            'fromUid': _myUid,
          },
        }),
      ).timeout(const Duration(seconds: 5), onTimeout: () => http.Response('timeout', 408));
    } catch (_) {}
  }

  // ── Post Mention Notification ─────────────────────────────────────────────
  /// Call karo jab koi post text mein @username tag kare.
  Future<void> sendPostMentionNotification({
    required String toUid,
    required String postId,
    required String fromName,
    String? fromPhotoUrl,
  }) async {
    if (_myUidSafe == null || _myUidSafe == toUid) return;
    final myPhoto = fromPhotoUrl ?? await _getMyPhotoUrl();

    // Dedupe: agar 1 ghante mein same post mention already hai to skip
    final recent = await _db
        .collection('users').doc(toUid).collection('notifications')
        .where('type',    isEqualTo: 'post_mention')
        .where('postId',  isEqualTo: postId)
        .where('fromUid', isEqualTo: _myUid)
        .limit(1).get();
    if (recent.docs.isNotEmpty) return;

    // 1. In-app notification
    await _db.collection('users').doc(toUid).collection('notifications').add({
      'type':      'post_mention',
      'text':      '@$fromName mentioned you in a post',
      'fromUid':   _myUid,
      'fromName':  fromName,
      'fromPhoto': myPhoto ?? '',
      'postId':    postId,
      'read':      false,
      'createdAt': FieldValue.serverTimestamp(),
    });

    // 2. Push notification
    final userDoc  = await _db.collection('users').doc(toUid).get();
    final playerId = userDoc.data()?['oneSignalPlayerId'] as String?;
    if (playerId == null || playerId.isEmpty) return;
    try {
      await http.post(
        Uri.parse(_backendUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'playerIds':      [playerId],
          'title':          fromName,
          'message':        'mentioned you in a post @$fromName',
          'senderPhotoUrl': myPhoto,
          'data': {
            'type':    'post_mention',
            'postId':  postId,
            'fromUid': _myUid,
          },
        }),
      ).timeout(const Duration(seconds: 5), onTimeout: () => http.Response('timeout', 408));
    } catch (_) {}
  }

  // ── Profile View Milestone Notification ───────────────────────────────────
  /// Milestones: 10, 50, 100, 500, 1000, 5000 views
  /// Call karo jab koi profile view kare — profile owner ko notify karo milestone par.
  static const List<int> _viewMilestones = [10, 50, 100, 500, 1000, 5000];

  Future<void> checkAndSendProfileViewMilestone({
    required String profileOwnerUid,
  }) async {
    if (_myUidSafe == null) return;
    try {
      final userRef = _db.collection('users').doc(profileOwnerUid);

      // Atomically increment view count
      await userRef.update({
        'profileViewCount': FieldValue.increment(1),
      });

      final userDoc  = await userRef.get();
      final data     = userDoc.data() as Map<String, dynamic>? ?? {};
      final newCount = (data['profileViewCount'] as int?) ?? 0;
      final lastMilestoneNotif = (data['lastProfileMilestoneNotif'] as int?) ?? 0;

      // Check if we crossed a new milestone
      int? hitMilestone;
      for (final m in _viewMilestones.reversed) {
        if (newCount >= m && lastMilestoneNotif < m) {
          hitMilestone = m;
          break;
        }
      }
      if (hitMilestone == null) return;

      // Save milestone so we don't re-notify
      await userRef.update({'lastProfileMilestoneNotif': hitMilestone});

      final emoji = hitMilestone >= 1000 ? '🏆' : hitMilestone >= 500 ? '🌟' : hitMilestone >= 100 ? '🎉' : '👀';

      // 1. In-app notification (to the profile owner themselves)
      await userRef.collection('notifications').add({
        'type':      'profile_milestone',
        'text':      '$emoji Your profile hit $hitMilestone views!',
        'fromUid':   profileOwnerUid, // self-notification
        'fromName':  data['username'] ?? '',
        'fromPhoto': data['photoURL'] ?? '',
        'milestone': hitMilestone,
        'read':      false,
        'createdAt': FieldValue.serverTimestamp(),
      });

      // 2. Push notification to owner
      final playerId = data['oneSignalPlayerId'] as String?;
      if (playerId == null || playerId.isEmpty) return;
      await http.post(
        Uri.parse(_backendUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'playerIds': [playerId],
          'title':     '$emoji Profile Milestone!',
          'message':   'Your profile just reached $hitMilestone views 🎉',
          'data': {
            'type':      'profile_milestone',
            'milestone': hitMilestone,
          },
        }),
      ).timeout(const Duration(seconds: 5), onTimeout: () => http.Response('timeout', 408));
    } catch (e) {
      debugPrint('[NotifService] Profile milestone error: $e');
    }
  }

}
