import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'cloudflare_service.dart';

// ══════════════════════════════════════════════════════════════════════════════
// FileService — Smart upload router
//
// ROUTING LOGIC:
//   • Images  → Cloudinary (compressed, CDN URL)
//   • Videos  → Cloudinary (video resource_type, CDN URL)
//   • Others  → Cloudflare Worker → Telegram CDN
//
// URL always saved to Firestore — NO Supabase.
// ══════════════════════════════════════════════════════════════════════════════
class FileService {

  // ── Cloudinary ─────────────────────────────────────────────────────────────
  static const String _cloudName    = 'dflusu2q8';
  static const String _uploadPreset = 'hfdmti3y';

  // ── Supported extensions ───────────────────────────────────────────────────
  static const List<String> _imageExts = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
  static const List<String> _videoExts = ['mp4', 'avi', 'mkv', 'mov', 'webm', '3gp'];
  static const List<String> _audioExts = ['mp3', 'wav', 'aac', 'flac', 'm4a', 'ogg'];

  static const Duration _uploadTimeout = Duration(minutes: 20);

  static Future<void> init() async {}

  // ── Image compression ──────────────────────────────────────────────────────
  static const int _maxWidth  = 1280;
  static const int _maxHeight = 1280;
  static const int _quality   = 82;

  static Future<File> compressImage(File file) async {
    final ext = p.extension(file.path).toLowerCase().replaceAll('.', '');
    if (!_imageExts.contains(ext) || ext == 'gif') return file;
    try {
      final dir     = await getTemporaryDirectory();
      final outPath = p.join(dir.path, 'zylo_cmp_${DateTime.now().millisecondsSinceEpoch}.$ext');
      final fmt     = ext == 'png' ? CompressFormat.png : CompressFormat.jpeg;
      final Uint8List? result = await FlutterImageCompress.compressWithFile(
        file.absolute.path,
        minWidth: _maxWidth, minHeight: _maxHeight,
        quality: _quality, format: fmt,
      );
      if (result == null) return file;
      final compressed = await File(outPath).writeAsBytes(result);
      if (await compressed.length() < await file.length()) return compressed;
      return file;
    } catch (e) {
      debugPrint('[FileService] compress error: $e');
      return file;
    }
  }

  // ── Main upload entry point ────────────────────────────────────────────────
  static Future<String> uploadFile(
    File file,
    String userId, {
    void Function(double progress)? onProgress,
  }) async {
    if (!await file.exists()) throw Exception('File not found: ${file.path}');

    final ext = p.extension(file.path).toLowerCase().replaceAll('.', '');

    // ── IMAGES → Cloudinary ──────────────────────────────────────────────────
    if (_imageExts.contains(ext)) {
      final toUpload = await compressImage(file);
      try {
        final url = await _uploadToCloudinary(
          toUpload, resourceType: 'image', onProgress: onProgress);
        debugPrint('[FileService] Cloudinary image OK: $url');
        return url;
      } catch (e) {
        debugPrint('[FileService] Cloudinary image failed → Cloudflare fallback: $e');
      }
    }

    // ── VIDEOS → Cloudinary (resource_type: video) ───────────────────────────
    if (_videoExts.contains(ext)) {
      try {
        final url = await _uploadToCloudinary(
          file, resourceType: 'video', onProgress: onProgress);
        debugPrint('[FileService] Cloudinary video OK: $url');
        return url;
      } catch (e) {
        throw Exception('Video upload failed: $e');
      }
    }

    // ── AUDIO → Cloudinary ───────────────────────────────────────────────────
    if (_audioExts.contains(ext)) {
      try {
        final url = await _uploadToCloudinary(
          file, resourceType: 'video', onProgress: onProgress);
        debugPrint('[FileService] Cloudinary audio OK: $url');
        return url;
      } catch (e) {
        debugPrint('[FileService] Cloudinary audio failed → Cloudflare: $e');
      }
    }

    // ── OTHERS → Cloudflare Worker → Telegram CDN ────────────────────────────
    try {
      final result = await CloudflareService.uploadFile(file, onProgress: onProgress);
      // Cloudflare returns UploadResult with fileId (Telegram file_id)
      // Build a proxy URL via the worker
      const workerUrl = 'https://zylo-files.mehranchandailyt.workers.dev';
      final url = '$workerUrl/file/${result.fileId}';
      debugPrint('[FileService] Cloudflare other OK: $url');
      return url;
    } catch (e) {
      throw Exception('Upload failed for $ext: $e');
    }
  }

  // ── Cloudinary upload — images AND videos ─────────────────────────────────
  static Future<String> _uploadToCloudinary(
    File file, {
    required String resourceType, // 'image' | 'video' | 'raw'
    void Function(double)? onProgress,
  }) async {
    final uri = Uri.parse(
      'https://api.cloudinary.com/v1_1/$_cloudName/$resourceType/upload');

    final req = http.MultipartRequest('POST', uri)
      ..fields['upload_preset'] = _uploadPreset
      ..fields['resource_type'] = resourceType;

    final bytes = await file.readAsBytes();
    final filename = p.basename(file.path);

    // Content-type for video
    String? contentType;
    final ext = p.extension(file.path).toLowerCase().replaceAll('.', '');
    if (resourceType == 'video') {
      const videoMimes = {
        'mp4': 'video/mp4', 'mov': 'video/quicktime',
        'avi': 'video/x-msvideo', 'mkv': 'video/x-matroska',
        'webm': 'video/webm', '3gp': 'video/3gpp',
        'mp3': 'audio/mpeg', 'aac': 'audio/aac',
        'wav': 'audio/wav', 'm4a': 'audio/mp4',
        'flac': 'audio/flac', 'ogg': 'audio/ogg',
      };
      contentType = videoMimes[ext];
    }

    req.files.add(http.MultipartFile.fromBytes(
      'file', bytes,
      filename: filename,
      contentType: contentType != null
          ? http.MediaType.parse(contentType)
          : null,
    ));

    // Progress tracking via stream
    onProgress?.call(0.05);
    final stream = req.send().timeout(_uploadTimeout);

    int uploaded = 0;
    final total  = bytes.length;

    final response = await stream;
    final body     = await response.stream.toBytes();

    onProgress?.call(0.95);

    if (response.statusCode != 200) {
      throw Exception(
        'Cloudinary $resourceType upload failed ${response.statusCode}: ${utf8.decode(body)}');
    }

    final json = jsonDecode(utf8.decode(body)) as Map<String, dynamic>;
    final url  = json['secure_url'] as String? ?? json['url'] as String?;
    if (url == null || url.isEmpty) {
      throw Exception('Cloudinary returned no URL: $json');
    }

    onProgress?.call(1.0);
    return url;
  }

  // ── Convenience: upload from bytes (for in-memory data) ───────────────────
  static Future<String> uploadBytes(
    Uint8List bytes,
    String filename,
    String userId, {
    void Function(double)? onProgress,
  }) async {
    final dir  = await getTemporaryDirectory();
    final temp = File(p.join(dir.path, filename));
    await temp.writeAsBytes(bytes);
    try {
      return await uploadFile(temp, userId, onProgress: onProgress);
    } finally {
      try { await temp.delete(); } catch (_) {}
    }
  }
}
