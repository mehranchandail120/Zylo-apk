// ═══════════════════════════════════════════════════════════════════════════
// DeepLinkService
// Handles: zylo://zylo/profile/USERNAME  →  ViewProfileScreen(targetUid)
//          zylo://zylo/post/POST_ID      →  PostDeepLinkScreen(postId)
//          https://zyloo.pages.dev/u/USERNAME
//          https://zyloo.pages.dev/p/POST_ID
//
// pubspec.yaml mein add karo:  app_links: ^6.3.2
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'package:app_links/app_links.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../screens/profile/view_profile_screen.dart';
import '../screens/feed/post_deep_link_screen.dart';

class DeepLinkService {
  DeepLinkService._();
  static final DeepLinkService instance = DeepLinkService._();

  final _appLinks = AppLinks();
  StreamSubscription<Uri>? _sub;

  Future<void> init(GlobalKey<NavigatorState> navigatorKey) async {
    // Cold start
    try {
      final uri = await _appLinks.getInitialLink();
      if (uri != null) {
        Future.delayed(const Duration(milliseconds: 600), () {
          _handleUri(uri, navigatorKey);
        });
      }
    } catch (_) {}

    // Hot start
    _sub = _appLinks.uriLinkStream.listen((uri) {
      _handleUri(uri, navigatorKey);
    });
  }

  void dispose() => _sub?.cancel();

  void _handleUri(Uri uri, GlobalKey<NavigatorState> navigatorKey) {
    if (FirebaseAuth.instance.currentUser != null) {
      _navigate(uri, navigatorKey);
      return;
    }
    late StreamSubscription<User?> sub;
    sub = FirebaseAuth.instance.authStateChanges().listen((user) {
      if (user != null) {
        sub.cancel();
        Future.delayed(const Duration(milliseconds: 400), () {
          _navigate(uri, navigatorKey);
        });
      }
    });
  }

  Future<void> _navigate(Uri uri, GlobalKey<NavigatorState> navigatorKey) async {
    final nav = navigatorKey.currentState;
    if (nav == null) return;

    debugPrint('[DeepLink] $uri');

    if (_isProfile(uri)) {
      final username = _segment(uri, 1);
      if (username.isEmpty) return;
      final uid = await _usernameToUid(username);
      if (uid == null) return;
      nav.push(MaterialPageRoute(
        builder: (_) => ViewProfileScreen(targetUid: uid),
      ));
      return;
    }

    if (_isPost(uri)) {
      final postId = _segment(uri, 1);
      if (postId.isEmpty) return;
      nav.push(MaterialPageRoute(
        builder: (_) => PostDeepLinkScreen(postId: postId),
      ));
    }
  }

  bool _isProfile(Uri uri) {
    if (uri.scheme == 'zylo') {
      return uri.pathSegments.isNotEmpty && uri.pathSegments[0] == 'profile';
    }
    return uri.host == 'zyloo.pages.dev' &&
        uri.pathSegments.isNotEmpty && uri.pathSegments[0] == 'u';
  }

  bool _isPost(Uri uri) {
    if (uri.scheme == 'zylo') {
      return uri.pathSegments.isNotEmpty && uri.pathSegments[0] == 'post';
    }
    return uri.host == 'zyloo.pages.dev' &&
        uri.pathSegments.isNotEmpty && uri.pathSegments[0] == 'p';
  }

  String _segment(Uri uri, int index) {
    if (uri.pathSegments.length > index) return uri.pathSegments[index];
    return '';
  }

  Future<String?> _usernameToUid(String username) async {
    try {
      final snap = await FirebaseFirestore.instance
          .collection('users')
          .where('username', isEqualTo: username.toLowerCase().trim())
          .limit(1)
          .get();
      if (snap.docs.isEmpty) return null;
      return snap.docs.first.id;
    } catch (e) {
      debugPrint('[DeepLink] Firestore error: $e');
      return null;
    }
  }
}
