import 'dart:convert';
import 'package:http/http.dart' as http;

class AiChatService {
  static const String _apiUrl = 'https://intubotixevlfxxgyiup.supabase.co/functions/v1/ai-chat';

  static Future<Map<String, dynamic>> sendMessage({
    required String message,
    required String sessionId,
    String? customInstruction,
  }) async {
    final response = await http.post(
      Uri.parse(_apiUrl),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'message': message,
        'session_id': sessionId,
        if (customInstruction != null)
          'custom_instruction': customInstruction,
      }),
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else if (response.statusCode == 429) {
      throw Exception('Rate limit! Try again later.');
    } else if (response.statusCode == 402) {
      throw Exception('Daily limit reached.');
    } else {
      throw Exception('Error: ${response.statusCode}');
    }
  }
}
