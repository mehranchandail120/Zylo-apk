// lib/services/local_db_service.dart
// ─────────────────────────────────────────────────────────────────────────────
// Zylo Local SQLite Database — WhatsApp-style local message store
//
// Architecture:
//   • Messages SQLite mein save hote hain — Firestore sirf delivery ke liye
//   • Chat room open hone par SQLite se instant load (zero network wait)
//   • Firestore stream background mein sync karta hai SQLite ko
//   • Unread counts + last messages bhi SQLite mein cached hain
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:async';
import 'dart:convert';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class LocalDbService {
  LocalDbService._();
  static final LocalDbService instance = LocalDbService._();

  Database? _db;
  bool _initialized = false;

  // ── Schema version — bump this if you change tables ─────────────────────
  static const int _schemaVersion = 2;

  // ── Init ─────────────────────────────────────────────────────────────────
  Future<void> init() async {
    if (_initialized) return;
    final dir = await getApplicationDocumentsDirectory();
    final path = join(dir.path, 'zylo_local.db');
    _db = await openDatabase(
      path,
      version: _schemaVersion,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
    _initialized = true;
  }

  Database get db {
    assert(_initialized, 'LocalDbService.init() call karo pehle');
    return _db!;
  }

  Future<void> _onCreate(Database db, int version) async {
    // ── Messages table ───────────────────────────────────────────────────
    await db.execute('''
      CREATE TABLE messages (
        local_id      TEXT PRIMARY KEY,
        chat_id       TEXT NOT NULL,
        sender_id     TEXT NOT NULL,
        text          TEXT,
        media_type    TEXT NOT NULL DEFAULT 'text',
        image_url     TEXT,
        video_url     TEXT,
        audio_url     TEXT,
        doc_url       TEXT,
        doc_name      TEXT,
        reply_to      TEXT,
        extra_data    TEXT,
        is_read       INTEGER NOT NULL DEFAULT 0,
        is_pinned     INTEGER NOT NULL DEFAULT 0,
        is_deleted    INTEGER NOT NULL DEFAULT 0,
        reactions     TEXT,
        timestamp_ms  INTEGER NOT NULL,
        synced        INTEGER NOT NULL DEFAULT 0,
        firestore_id  TEXT
      )
    ''');

    // ── Chats summary table (unread + last message) ───────────────────────
    await db.execute('''
      CREATE TABLE chats (
        chat_id         TEXT PRIMARY KEY,
        my_uid          TEXT NOT NULL,
        other_uid       TEXT NOT NULL,
        last_msg        TEXT,
        last_msg_time   INTEGER,
        unread_count    INTEGER NOT NULL DEFAULT 0,
        updated_at      INTEGER NOT NULL
      )
    ''');

    // ── Indexes for performance ───────────────────────────────────────────
    await db.execute('CREATE INDEX idx_messages_chat ON messages(chat_id, timestamp_ms DESC)');
    await db.execute('CREATE INDEX idx_messages_sync ON messages(synced, chat_id)');
    await db.execute('CREATE INDEX idx_chats_uid ON chats(my_uid)');
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    // v1 → v2: Following system removed — drop table + index (now handled by Firestore only)
    if (oldVersion < 2) {
      try { await db.execute('DROP INDEX IF EXISTS idx_following_uid'); } catch (_) {}
      try { await db.execute('DROP TABLE IF EXISTS following'); } catch (_) {}
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // MESSAGES
  // ══════════════════════════════════════════════════════════════════════════

  /// Chat ID banana
  static String chatId(String uid1, String uid2) {
    final ids = [uid1, uid2]..sort();
    return '${ids[0]}_${ids[1]}';
  }

  /// Message save karo locally (optimistic insert)
  Future<void> insertMessage({
    required String localId,
    required String myUid,
    required String otherUid,
    required String senderId,
    String? text,
    String mediaType = 'text',
    String? imageUrl,
    String? videoUrl,
    String? audioUrl,
    String? docUrl,
    String? docName,
    Map<String, dynamic>? replyTo,
    Map<String, dynamic>? extraData,
    bool synced = false,
    String? firestoreId,
    DateTime? timestamp,
  }) async {
    final cid = chatId(myUid, otherUid);
    final tsMs = (timestamp ?? DateTime.now()).millisecondsSinceEpoch;
    await db.insert(
      'messages',
      {
        'local_id':     localId,
        'chat_id':      cid,
        'sender_id':    senderId,
        'text':         text,
        'media_type':   mediaType,
        'image_url':    imageUrl,
        'video_url':    videoUrl,
        'audio_url':    audioUrl,
        'doc_url':      docUrl,
        'doc_name':     docName,
        'reply_to':     replyTo != null ? jsonEncode(replyTo) : null,
        'extra_data':   extraData != null ? jsonEncode(extraData) : null,
        'is_read':      0,
        'is_pinned':    0,
        'is_deleted':   0,
        'timestamp_ms': tsMs,
        'synced':       synced ? 1 : 0,
        'firestore_id': firestoreId,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  /// Firestore ID update karo jab message deliver ho jaye
  Future<void> markSynced(String localId, String firestoreId) async {
    await db.update(
      'messages',
      {'synced': 1, 'firestore_id': firestoreId},
      where: 'local_id = ?',
      whereArgs: [localId],
    );
  }

  /// Firestore se aya message save karo (bulk upsert)
  Future<void> upsertFirestoreMessages({
    required String myUid,
    required String otherUid,
    required List<Map<String, dynamic>> fsMessages,
  }) async {
    final cid = chatId(myUid, otherUid);
    final batch = db.batch();
    for (final m in fsMessages) {
      final tsMs = m['timestamp_ms'] as int? ??
          (m['timestamp'] is DateTime
              ? (m['timestamp'] as DateTime).millisecondsSinceEpoch
              : DateTime.now().millisecondsSinceEpoch);

      batch.insert(
        'messages',
        {
          'local_id':     m['firestoreId'] ?? m['id'] ?? m['_docId'] ?? '',
          'chat_id':      cid,
          'sender_id':    m['senderId'] ?? m['sender_id'] ?? '',
          'text':         m['text'],
          'media_type':   m['mediaType'] ?? m['media_type'] ?? 'text',
          'image_url':    m['imageUrl'] ?? m['image_url'],
          'video_url':    m['videoUrl'] ?? m['video_url'],
          'audio_url':    m['audioUrl'] ?? m['audioPath'] ?? m['audio_url'],
          'doc_url':      m['docUrl'] ?? m['docPath'] ?? m['doc_url'],
          'doc_name':     m['docName'] ?? m['doc_name'],
          'reply_to':     m['replyTo'] != null ? jsonEncode(m['replyTo']) : null,
          'extra_data':   null,
          'is_read':      (m['isRead'] == true || m['is_read'] == 1) ? 1 : 0,
          'is_pinned':    (m['isPinned'] == true || m['is_pinned'] == 1) ? 1 : 0,
          'is_deleted':   0,
          'reactions':    m['reactions'] != null ? jsonEncode(m['reactions']) : null,
          'timestamp_ms': tsMs,
          'synced':       1,
          'firestore_id': m['firestoreId'] ?? m['id'] ?? m['_docId'],
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }
    await batch.commit(noResult: true);
  }

  /// Messages load karo SQLite se (instant, no network)
  Future<List<Map<String, dynamic>>> loadMessages({
    required String myUid,
    required String otherUid,
    int limit = 50,
    int offset = 0,
  }) async {
    final cid = chatId(myUid, otherUid);
    final rows = await db.query(
      'messages',
      where: 'chat_id = ? AND is_deleted = 0',
      whereArgs: [cid],
      orderBy: 'timestamp_ms DESC',
      limit: limit,
      offset: offset,
    );
    return rows.map(_rowToMessage).toList();
  }

  /// Older messages for pagination
  Future<List<Map<String, dynamic>>> loadOlderMessages({
    required String myUid,
    required String otherUid,
    required int beforeTimestampMs,
    int limit = 30,
  }) async {
    final cid = chatId(myUid, otherUid);
    final rows = await db.query(
      'messages',
      where: 'chat_id = ? AND is_deleted = 0 AND timestamp_ms < ?',
      whereArgs: [cid, beforeTimestampMs],
      orderBy: 'timestamp_ms DESC',
      limit: limit,
    );
    return rows.map(_rowToMessage).toList();
  }

  /// Convert DB row to message map (same format as chat room uses)
  Map<String, dynamic> _rowToMessage(Map<String, dynamic> row) {
    Map<String, dynamic>? replyTo;
    if (row['reply_to'] != null) {
      try { replyTo = Map<String, dynamic>.from(jsonDecode(row['reply_to'] as String)); } catch (_) {}
    }
    Map<String, dynamic> reactions = {};
    if (row['reactions'] != null) {
      try { reactions = Map<String, dynamic>.from(jsonDecode(row['reactions'] as String)); } catch (_) {}
    }
    Map<String, dynamic>? extraData;
    if (row['extra_data'] != null) {
      try { extraData = Map<String, dynamic>.from(jsonDecode(row['extra_data'] as String)); } catch (_) {}
    }
    return {
      'id':          row['local_id'],
      'firestoreId': row['firestore_id'],
      'senderId':    row['sender_id'],
      'text':        (row['text'] as String?)?.isNotEmpty == true ? row['text'] : null,
      'mediaType':   row['media_type'] ?? 'text',
      'imageUrl':    row['image_url'],
      'videoUrl':    row['video_url'],
      'audioPath':   row['audio_url'],
      'docPath':     row['doc_url'],
      'docName':     row['doc_name'],
      'replyTo':     replyTo,
      'reactions':   reactions,
      'isRead':      row['is_read'] == 1,
      'isPinned':    row['is_pinned'] == 1,
      'isLiked':     false,
      'timestamp':   DateTime.fromMillisecondsSinceEpoch(row['timestamp_ms'] as int),
      'synced':      row['synced'] == 1,
      if (extraData != null) ...extraData,
    };
  }

  /// Message delete karo (soft delete)
  Future<void> deleteMessage(String localId) async {
    await db.update('messages', {'is_deleted': 1},
        where: 'local_id = ?', whereArgs: [localId]);
  }

  /// Update reaction
  Future<void> updateReactions(String localId, Map<String, dynamic> reactions) async {
    await db.update('messages', {'reactions': jsonEncode(reactions)},
        where: 'local_id = ?', whereArgs: [localId]);
  }

  /// Update pinned state
  Future<void> updatePinned(String localId, bool pinned) async {
    await db.update('messages', {'is_pinned': pinned ? 1 : 0},
        where: 'local_id = ?', whereArgs: [localId]);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // CHATS SUMMARY (unread + last message)
  // ══════════════════════════════════════════════════════════════════════════

  Future<void> upsertChatSummary({
    required String myUid,
    required String otherUid,
    String? lastMsg,
    int? lastMsgTimeMs,
    int? unreadCount,
  }) async {
    final cid = chatId(myUid, otherUid);
    final existing = await db.query('chats',
        where: 'chat_id = ?', whereArgs: [cid], limit: 1);

    if (existing.isEmpty) {
      await db.insert('chats', {
        'chat_id':       cid,
        'my_uid':        myUid,
        'other_uid':     otherUid,
        'last_msg':      lastMsg,
        'last_msg_time': lastMsgTimeMs,
        'unread_count':  unreadCount ?? 0,
        'updated_at':    DateTime.now().millisecondsSinceEpoch,
      });
    } else {
      final updates = <String, dynamic>{
        'updated_at': DateTime.now().millisecondsSinceEpoch,
      };
      if (lastMsg != null) updates['last_msg'] = lastMsg;
      if (lastMsgTimeMs != null) updates['last_msg_time'] = lastMsgTimeMs;
      if (unreadCount != null) updates['unread_count'] = unreadCount;
      await db.update('chats', updates,
          where: 'chat_id = ?', whereArgs: [cid]);
    }
  }

  Future<Map<String, dynamic>?> getChatSummary(String myUid, String otherUid) async {
    final cid = chatId(myUid, otherUid);
    final rows = await db.query('chats',
        where: 'chat_id = ?', whereArgs: [cid], limit: 1);
    return rows.isNotEmpty ? rows.first : null;
  }

  /// All chat summaries for a user (chat list)
  Future<List<Map<String, dynamic>>> getAllChatSummaries(String myUid) async {
    return db.query('chats',
        where: 'my_uid = ?',
        whereArgs: [myUid],
        orderBy: 'last_msg_time DESC');
  }

  /// Mark chat as read (unread = 0)
  Future<void> markChatRead(String myUid, String otherUid) async {
    final cid = chatId(myUid, otherUid);
    await db.update('chats', {'unread_count': 0},
        where: 'chat_id = ?', whereArgs: [cid]);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // FOLLOWING
  // ══════════════════════════════════════════════════════════════════════════


  // ══════════════════════════════════════════════════════════════════════════
  // UTILITY
  // ══════════════════════════════════════════════════════════════════════════

  Future<void> clearMessagesForChat(String myUid, String otherUid) async {
    final cid = chatId(myUid, otherUid);
    await db.delete('messages', where: 'chat_id = ?', whereArgs: [cid]);
    await db.delete('chats', where: 'chat_id = ?', whereArgs: [cid]);
  }

  Future<void> clearAll() async {
    await db.delete('messages');
    await db.delete('chats');
  }
}
