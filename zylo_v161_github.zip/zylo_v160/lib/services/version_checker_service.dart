import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:open_filex/open_filex.dart';
import 'package:permission_handler/permission_handler.dart';

/// ─────────────────────────────────────────────────────────────────────────────
///  VersionCheckerService
///
///  Admin Firestore mein yeh document rakhega:
///    Collection: app_config
///    Document:   version
///    Fields:
///      latestVersion  : "1.9.0"          (String)
///      apkUrl         : "https://..."    (String — direct APK download link)
///      releaseNotes   : "Bug fixes..."   (String, optional)
///      forceUpdate    : false            (bool, optional)
///
///  Call karo:
///    VersionCheckerService.check(context, currentVersion: '1.5.0');
/// ─────────────────────────────────────────────────────────────────────────────
class VersionCheckerService {
  static const _collection = 'app_config';
  static const _document   = 'version';

  /// Check karo aur update dialog dikhao agar update available hai
  static Future<void> check(
    BuildContext context, {
    required String currentVersion,
    bool silent = false, // true = no "up to date" toast
  }) async {
    try {
      final doc = await FirebaseFirestore.instance
          .collection(_collection)
          .doc(_document)
          .get();

      if (!doc.exists) return;

      final data          = doc.data()!;
      final latestVersion = data['latestVersion'] as String? ?? '';
      final apkUrl        = data['apkUrl']        as String? ?? '';
      final releaseNotes  = data['releaseNotes']  as String? ?? '';
      final forceUpdate   = data['forceUpdate']   as bool?   ?? false;

      if (latestVersion.isEmpty || apkUrl.isEmpty) return;

      final hasUpdate = _isNewer(latestVersion, currentVersion);

      if (!hasUpdate) {
        if (!silent && context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('✅ App is up to date!'),
              behavior: SnackBarBehavior.floating,
              backgroundColor: Color(0xFF059669),
            ),
          );
        }
        return;
      }

      if (context.mounted) {
        _showUpdateDialog(
          context,
          latestVersion: latestVersion,
          apkUrl: apkUrl,
          releaseNotes: releaseNotes,
          forceUpdate: forceUpdate,
          currentVersion: currentVersion,
        );
      }
    } catch (e) {
      debugPrint('[VersionChecker] Error: $e');
    }
  }

  /// Compare versions — "1.9.0" > "1.5.0" → true
  static bool _isNewer(String latest, String current) {
    try {
      final l = latest.split('.').map(int.parse).toList();
      final c = current.split('.').map(int.parse).toList();
      for (int i = 0; i < 3; i++) {
        final lv = i < l.length ? l[i] : 0;
        final cv = i < c.length ? c[i] : 0;
        if (lv > cv) return true;
        if (lv < cv) return false;
      }
      return false;
    } catch (_) {
      return false;
    }
  }

  static void _showUpdateDialog(
    BuildContext context, {
    required String latestVersion,
    required String apkUrl,
    required String releaseNotes,
    required bool forceUpdate,
    required String currentVersion,
  }) {
    showDialog(
      context: context,
      barrierDismissible: !forceUpdate,
      builder: (_) => _UpdateDialog(
        latestVersion: latestVersion,
        apkUrl: apkUrl,
        releaseNotes: releaseNotes,
        forceUpdate: forceUpdate,
        currentVersion: currentVersion,
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Update Dialog Widget
// ─────────────────────────────────────────────────────────────────────────────
class _UpdateDialog extends StatefulWidget {
  final String latestVersion, apkUrl, releaseNotes, currentVersion;
  final bool forceUpdate;

  const _UpdateDialog({
    required this.latestVersion,
    required this.apkUrl,
    required this.releaseNotes,
    required this.forceUpdate,
    required this.currentVersion,
  });

  @override
  State<_UpdateDialog> createState() => _UpdateDialogState();
}

class _UpdateDialogState extends State<_UpdateDialog> {
  _DownloadState _state = _DownloadState.idle;
  double _progress = 0;
  String _statusText = '';
  String? _error;

  static const _blue   = Color(0xFF0284C7);
  static const _purple = Color(0xFF7C3AED);

  Future<void> _startDownload() async {
    // 1. Unknown sources permission check
    if (Platform.isAndroid) {
      final status = await Permission.requestInstallPackages.status;
      if (!status.isGranted) {
        final result = await Permission.requestInstallPackages.request();
        if (!result.isGranted) {
          if (mounted) {
            setState(() {
              _error = 'Please enable "Install unknown apps" permission and try again.';
              _state = _DownloadState.error;
            });
          }
          // Open settings so user can enable it
          await openAppSettings();
          return;
        }
      }
    }

    setState(() {
      _state      = _DownloadState.downloading;
      _progress   = 0;
      _statusText = 'Connecting...';
      _error      = null;
    });

    try {
      // 2. Temp dir mein save karo
      final tempDir  = await getTemporaryDirectory();
      final apkFile  = File('${tempDir.path}/zylo_update_${widget.latestVersion}.apk');

      // 3. HTTP request with progress
      final request  = http.Request('GET', Uri.parse(widget.apkUrl));
      final response = await request.send().timeout(const Duration(minutes: 10));

      final total    = response.contentLength ?? 0;
      int received   = 0;

      final sink = apkFile.openWrite();
      await for (final chunk in response.stream) {
        sink.add(chunk);
        received += chunk.length;
        if (total > 0 && mounted) {
          setState(() {
            _progress   = received / total;
            _statusText = '${_fmtBytes(received)} / ${_fmtBytes(total)}';
          });
        }
      }
      await sink.flush();
      await sink.close();

      if (!mounted) return;
      setState(() {
        _state      = _DownloadState.installing;
        _statusText = 'Installing...';
        _progress   = 1.0;
      });

      // 4. Install APK
      await OpenFilex.open(apkFile.path);

    } catch (e) {
      if (mounted) {
        setState(() {
          _state = _DownloadState.error;
          _error = 'Download failed. Please check your connection and try again.';
        });
        debugPrint('[VersionChecker] Download error: $e');
      }
    }
  }

  String _fmtBytes(int bytes) {
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !widget.forceUpdate && _state == _DownloadState.idle,
      child: Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Icon
              Container(
                width: 72, height: 72,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [_blue, _purple],
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Icon(Icons.system_update_alt_rounded,
                    color: Colors.white, size: 36),
              ),
              const SizedBox(height: 16),

              // Title
              const Text('Update Available! 🚀',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800,
                    color: Colors.black87)),
              const SizedBox(height: 6),

              // Version info
              Text(
                'v${widget.currentVersion}  →  v${widget.latestVersion}',
                style: TextStyle(fontSize: 13, color: Colors.grey[600],
                    fontWeight: FontWeight.w600),
              ),

              // Release notes
              if (widget.releaseNotes.isNotEmpty) ...[
                const SizedBox(height: 14),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Text(widget.releaseNotes,
                    style: TextStyle(fontSize: 12, color: Colors.grey[700],
                        height: 1.5)),
                ),
              ],

              const SizedBox(height: 20),

              // ── Idle state ─────────────────────────────────────────────
              if (_state == _DownloadState.idle) ...[
                _PrimaryButton(
                  label: 'Download & Install',
                  icon: Icons.download_rounded,
                  onTap: _startDownload,
                ),
                if (!widget.forceUpdate) ...[
                  const SizedBox(height: 10),
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: Text('Later',
                      style: TextStyle(color: Colors.grey[500], fontSize: 13)),
                  ),
                ],
              ],

              // ── Downloading ────────────────────────────────────────────
              if (_state == _DownloadState.downloading) ...[
                _ProgressSection(progress: _progress, statusText: _statusText),
              ],

              // ── Installing ─────────────────────────────────────────────
              if (_state == _DownloadState.installing) ...[
                const CircularProgressIndicator(color: _blue, strokeWidth: 3),
                const SizedBox(height: 12),
                const Text('Installing update...',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600,
                      color: Colors.black87)),
                const SizedBox(height: 6),
                Text('Accept the install prompt to continue.',
                  style: TextStyle(fontSize: 11, color: Colors.grey[500]),
                  textAlign: TextAlign.center),
              ],

              // ── Error ──────────────────────────────────────────────────
              if (_state == _DownloadState.error && _error != null) ...[
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.red.shade50,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.red.shade200),
                  ),
                  child: Text(_error!,
                    style: const TextStyle(fontSize: 12, color: Colors.red),
                    textAlign: TextAlign.center),
                ),
                const SizedBox(height: 12),
                _PrimaryButton(
                  label: 'Retry',
                  icon: Icons.refresh_rounded,
                  onTap: _startDownload,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Helper Widgets
// ─────────────────────────────────────────────────────────────────────────────

class _ProgressSection extends StatelessWidget {
  final double progress;
  final String statusText;
  const _ProgressSection({required this.progress, required this.statusText});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Stack(
          alignment: Alignment.center,
          children: [
            SizedBox(
              width: 80, height: 80,
              child: CircularProgressIndicator(
                value: progress,
                strokeWidth: 7,
                backgroundColor: Colors.grey.shade200,
                color: const Color(0xFF0284C7),
              ),
            ),
            Text(
              '${(progress * 100).toStringAsFixed(0)}%',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800,
                  color: Color(0xFF0284C7)),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Text(statusText,
          style: TextStyle(fontSize: 12, color: Colors.grey[500])),
        const SizedBox(height: 4),
        const Text('Do not close the app',
          style: TextStyle(fontSize: 11, color: Colors.grey,
              fontStyle: FontStyle.italic)),
      ],
    );
  }
}

class _PrimaryButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  const _PrimaryButton({
    required this.label, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 18),
        label: Text(label,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF0284C7),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14)),
          elevation: 0,
        ),
      ),
    );
  }
}

enum _DownloadState { idle, downloading, installing, error }
