import 'package:cloud_firestore/cloud_firestore.dart';
import 'local_db_service.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String get _myUid => _auth.currentUser!.uid;
  String get myUid => _myUid;

  Future<void> saveUserProfile(String username, String gender, String photoURL, String phone, {String bio = '', bool isPublic = true}) async {
    await _db.collection('users').doc(_myUid).set({
      'uid': _myUid,
      'username': username.toLowerCase().trim(),
      'email': _auth.currentUser!.email,
      'gender': gender,
      'photoURL': photoURL,
      'phone': phone,
      'bio': bio.isNotEmpty ? bio : 'Hey there! I am using Zylo.',
      'isPublic': isPublic,
      'isOnline': true,
      'usernameChangeCount': 0,
      'lastUsernameChangeMonth': DateTime.now().month,
      'lastSeen': FieldValue.serverTimestamp(),
      'createdAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<bool> isUsernameTaken(String username) async {
    final query = await _db.collection('users')
        .where('username', isEqualTo: username.toLowerCase().trim())
        .get();
    return query.docs.any((d) => d.id != _myUid);
  }

  Future<String?> updateProfileData({String? name, String? bio, String? phone, String? username, String? photoURL}) async {
    try {
      final userDoc = await _db.collection('users').doc(_myUid).get();
      final data = userDoc.data()!;

      Map<String, dynamic> updates = {
        if (bio != null) 'bio': bio,
        if (phone != null) 'phone': phone,
        if (name != null) 'displayName': name,
        if (photoURL != null) 'photoURL': photoURL,
      };

      if (username != null && username.toLowerCase() != data['username']) {
        int count = data['usernameChangeCount'] ?? 0;
        int lastMonth = data['lastUsernameChangeMonth'] ?? 0;
        int currentMonth = DateTime.now().month;

        if (lastMonth != currentMonth) count = 0;
        if (count >= 5) return "You can only change username 5 times a month.";

        bool taken = await isUsernameTaken(username);
        if (taken) return "Username already taken.";

        updates['username'] = username.toLowerCase().trim();
        updates['usernameChangeCount'] = count + 1;
        updates['lastUsernameChangeMonth'] = currentMonth;
      }

      await _db.collection('users').doc(_myUid).update(updates);
      return null;
    } catch (e) {
      return e.toString();
    }
  }

  Future<void> updateOnlineStatus(bool isOnline) async {
    try {
      await _db.collection('users').doc(_myUid).update({
        'isOnline': isOnline,
        'lastSeen': FieldValue.serverTimestamp(),
      });
    } catch (_) {}
  }

  Stream<QuerySnapshot> getChats() {
    return _db.collection('chats')
        .where('participants', arrayContains: _myUid)
        .orderBy('lastMsgTime', descending: true)
        .snapshots();
  }

  // ── Paginated messages — first 30, then load more ──────────────────────
  static const int _msgPageSize = 30;

  Stream<QuerySnapshot> getMessages(String otherUid) {
    final ids = [_myUid, otherUid]..sort();
    final cid = '${ids[0]}_${ids[1]}';
    return _db
        .collection('chats')
        .doc(cid)
        .collection('messages')
        .orderBy('timestamp', descending: true)
        .limit(_msgPageSize)
        .snapshots();
  }

  /// Load older messages before [lastDoc] (for pagination)
  Future<QuerySnapshot> loadMoreMessages(
      String otherUid, DocumentSnapshot lastDoc) {
    final ids = [_myUid, otherUid]..sort();
    final cid = '${ids[0]}_${ids[1]}';
    return _db
        .collection('chats')
        .doc(cid)
        .collection('messages')
        .orderBy('timestamp', descending: true)
        .startAfterDocument(lastDoc)
        .limit(_msgPageSize)
        .get();
  }

  Future<void> ensureChatExists(String otherUid, String name, String photo) async {
    final ids = [_myUid, otherUid]..sort();
    final cid = '${ids[0]}_${ids[1]}';
    // Get my own data to fill in my name/photo
    final myDoc = await _db.collection('users').doc(_myUid).get();
    final myData = myDoc.data() as Map<String, dynamic>? ?? {};
    final myName = myData['username'] ?? '';
    final myPhoto = myData['photoURL'] ?? '';
    await _db.collection('chats').doc(cid).set({
      'participants': ids,
      'participantNames': {_myUid: myName, otherUid: name},
      'participantPhotos': {_myUid: myPhoto, otherUid: photo},
      'lastMsgTime': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<void> sendMessage({
    required String otherUid,
    String? text,
    String? imageUrl,
    String? videoUrl,
    String? audioUrl,
    String? docUrl,
    String? docName,
    String mediaType = 'text',
    Map<String, dynamic>? replyTo,
    Map<String, dynamic>? extraData,
  }) async {
    final ids = [_myUid, otherUid]..sort();
    final cid = '${ids[0]}_${ids[1]}';

    final msgData = <String, dynamic>{
      'senderId': _myUid,
      'text': text ?? '',
      'imageUrl': imageUrl,
      'videoUrl': videoUrl,
      'audioUrl': audioUrl,
      'docUrl': docUrl,
      'docName': docName,
      'mediaType': mediaType,
      'isRead': false,
      'timestamp': FieldValue.serverTimestamp(),
    };
    if (replyTo != null) msgData['replyTo'] = replyTo;
    if (extraData != null) msgData.addAll(extraData);

    await _db.collection('chats').doc(cid).collection('messages').add(msgData);

    // Track media uploads for profile media tab
    if (imageUrl != null && imageUrl.isNotEmpty) {
      _db.collection('users').doc(_myUid).collection('mediaUploads').add({
        'url': imageUrl, 'type': 'image', 'uploadedAt': FieldValue.serverTimestamp(),
      }).catchError((_) {});
    }
    if (videoUrl != null && videoUrl.isNotEmpty) {
      _db.collection('users').doc(_myUid).collection('mediaUploads').add({
        'url': videoUrl, 'type': 'video', 'uploadedAt': FieldValue.serverTimestamp(),
      }).catchError((_) {});
    }
    // Track extra imageUrls from multi-photo send
    if (extraData != null && extraData['imageUrls'] is List) {
      for (final u in (extraData['imageUrls'] as List)) {
        _db.collection('users').doc(_myUid).collection('mediaUploads').add({
          'url': u, 'type': 'image', 'uploadedAt': FieldValue.serverTimestamp(),
        }).catchError((_) {});
      }
    }

    final preview = text?.isNotEmpty == true
        ? text!
        : imageUrl != null
            ? '📷 Photo'
            : videoUrl != null
                ? '🎥 Video'
                : audioUrl != null
                    ? '🎵 Audio'
                    : '📄 Document';

    await _db.collection('chats').doc(cid).set({
      'lastMsg': preview,
      'lastMsgTime': FieldValue.serverTimestamp(),
      'unreadCount.$otherUid': FieldValue.increment(1),
      'participants': [_myUid, otherUid],
    }, SetOptions(merge: true));
  }

  Future<void> markAsRead(String otherUid) async {
    final ids = [_myUid, otherUid]..sort();
    final cid = '${ids[0]}_${ids[1]}';
    try {
      await _db.collection('chats').doc(cid).update({
        'unreadCount.$_myUid': 0,
      });
      // Also mark messages as read
      final unread = await _db.collection('chats').doc(cid)
          .collection('messages')
          .where('senderId', isEqualTo: otherUid)
          .where('isRead', isEqualTo: false)
          .get();
      final batch = _db.batch();
      for (final doc in unread.docs) {
        batch.update(doc.reference, {'isRead': true});
      }
      await batch.commit();
    } catch (_) {}
  }

  // Delete for Me only (soft delete)
  Future<void> deleteMessage(String otherUid, String messageId) async {
    final ids = [_myUid, otherUid]..sort();
    final cid = '${ids[0]}_${ids[1]}';
    try {
      await _db
          .collection('chats')
          .doc(cid)
          .collection('messages')
          .doc(messageId)
          .update({'deletedFor': FieldValue.arrayUnion([_myUid])});
    } catch (_) {}
  }

  // Delete for Everyone (hard delete — removes document)
  Future<void> deleteMessageForEveryone(String otherUid, String messageId) async {
    final ids = [_myUid, otherUid]..sort();
    final cid = '${ids[0]}_${ids[1]}';
    try {
      await _db
          .collection('chats')
          .doc(cid)
          .collection('messages')
          .doc(messageId)
          .update({
            'deletedForEveryone': true,
            'text': '',
            'imageUrl': FieldValue.delete(),
            'fileUrl': FieldValue.delete(),
            'videoUrl': FieldValue.delete(),
            'deletedAt': FieldValue.serverTimestamp(),
          });
    } catch (_) {}
  }

  // Delete selected for Everyone (batch)
  Future<void> deleteSelectedMessagesForEveryone(String otherUid, List<String> messageIds) async {
    final ids = [_myUid, otherUid]..sort();
    final cid = '${ids[0]}_${ids[1]}';
    try {
      final batch = _db.batch();
      for (final msgId in messageIds) {
        batch.update(_db
            .collection('chats')
            .doc(cid)
            .collection('messages')
            .doc(msgId), {
          'deletedForEveryone': true,
          'text': '',
          'imageUrl': FieldValue.delete(),
          'fileUrl': FieldValue.delete(),
          'videoUrl': FieldValue.delete(),
          'deletedAt': FieldValue.serverTimestamp(),
        });
      }
      await batch.commit();
    } catch (_) {}
  }

  Future<void> togglePinMessage(String otherUid, String messageId, bool pin) async {
    final ids = [_myUid, otherUid]..sort();
    final cid = '${ids[0]}_${ids[1]}';
    try {
      await _db
          .collection('chats')
          .doc(cid)
          .collection('messages')
          .doc(messageId)
          .update({
            'isPinned': pin,
            if (pin) 'pinnedBy': _myUid,
            if (pin) 'pinnedAt': FieldValue.serverTimestamp(),
          });
    } catch (_) {}
  }

  Future<void> deleteSelectedMessages(String otherUid, List<String> messageIds) async {
    final ids = [_myUid, otherUid]..sort();
    final cid = '${ids[0]}_${ids[1]}';
    try {
      final batch = _db.batch();
      for (final msgId in messageIds) {
        batch.update(_db
            .collection('chats')
            .doc(cid)
            .collection('messages')
            .doc(msgId), {'deletedFor': FieldValue.arrayUnion([_myUid])});
      }
      await batch.commit();
    } catch (_) {}
  }

  Future<void> clearChat(String otherUid) async {
    final ids = [_myUid, otherUid]..sort();
    final cid = '${ids[0]}_${ids[1]}';
    // Soft delete — mark all messages as deleted for current user only
    const chunkSize = 400;
    while (true) {
      final snap = await _db.collection('chats').doc(cid)
          .collection('messages').limit(chunkSize).get();
      if (snap.docs.isEmpty) break;
      final batch = _db.batch();
      for (final doc in snap.docs) {
        batch.update(doc.reference, {
          'deletedFor': FieldValue.arrayUnion([_myUid]),
        });
      }
      await batch.commit();
      if (snap.docs.length < chunkSize) break;
    }
    // Reset lastMsg in chat doc for this user
    await _db.collection('chats').doc(cid).update({
      'lastMsg': '',
      'lastMsgTime': FieldValue.serverTimestamp(),
    }).catchError((_) {});
  }

  /// Clear chat for BOTH sides (hard delete all messages)
  Future<void> clearChatBothSides(String otherUid) async {
    final ids = [_myUid, otherUid]..sort();
    final cid = '${ids[0]}_${ids[1]}';
    const chunkSize = 400;
    while (true) {
      final snap = await _db.collection('chats').doc(cid)
          .collection('messages').limit(chunkSize).get();
      if (snap.docs.isEmpty) break;
      final batch = _db.batch();
      for (final doc in snap.docs) {
        batch.delete(doc.reference);
      }
      await batch.commit();
      if (snap.docs.length < chunkSize) break;
    }
    await _db.collection('chats').doc(cid).update({
      'lastMsg': '',
      'lastMsgTime': FieldValue.serverTimestamp(),
      'unreadCount': {},
    }).catchError((_) {});
  }

  Stream<QuerySnapshot> searchUsers(String query) {
    return _db
        .collection('users')
        .where('username', isGreaterThanOrEqualTo: query)
        .where('username', isLessThanOrEqualTo: '$query\uf8ff')
        .limit(20)
        .snapshots();
  }

  // Stories
  Future<void> postStory(String mediaUrl, String type, {
    String? caption,
    int? durationSec,
    String? musicTitle,
    String? musicArtist,
    String? bgColor,
    String? pollQuestion,
    List<String>? pollOptions,
  }) async {
    final myDoc = await _db.collection('users').doc(_myUid).get();
    final myData = myDoc.data() as Map<String, dynamic>? ?? {};
    final doc = await _db.collection('stories').add({
      'uid': _myUid,
      'username': myData['username'] ?? '',
      'photoURL': myData['photoURL'] ?? '',
      'mediaUrl': mediaUrl,
      'type': type, // 'image', 'text', 'poll', 'music'
      'text': caption ?? '',
      'viewers': [],
      'views': {},
      'durationSec': (durationSec ?? 7).clamp(1, 60),
      if (bgColor != null) 'bgColor': bgColor,
      if (musicTitle != null) 'musicTitle': musicTitle,
      if (musicArtist != null) 'musicArtist': musicArtist,
      if (pollQuestion != null) 'pollQuestion': pollQuestion,
      if (pollOptions != null) 'pollOptions': pollOptions,
      if (pollOptions != null) 'pollVotes': {},
      'timestamp': FieldValue.serverTimestamp(),
      'expiresAt': Timestamp.fromDate(DateTime.now().add(const Duration(hours: 24))),
    });
    await doc.update({'storyId': doc.id});
  }

  Future<void> postPollStory({
    required String question,
    required List<String> options,
    String? bgColor,
  }) => postStory('', 'poll',
      caption: question,
      pollQuestion: question,
      pollOptions: options,
      bgColor: bgColor,
      durationSec: 10);

  Stream<QuerySnapshot> getStories() {
    final cutoff = Timestamp.fromDate(DateTime.now().subtract(const Duration(hours: 24)));
    return _db.collection('stories')
        .where('timestamp', isGreaterThan: cutoff)
        .orderBy('timestamp', descending: true)
        .snapshots();
  }

  Future<void> viewStory(String storyId) async {
    try {
      await _db.collection('stories').doc(storyId).update({
        'viewers': FieldValue.arrayUnion([_myUid]),
      });
    } catch (_) {}
  }

  // Friends count — realtime from subcollection
  Stream<int> friendsCountStream() {
    return _db
        .collection('users')
        .doc(_myUid)
        .collection('friends')
        .where('status', isEqualTo: 'friends')
        .snapshots()
        .map((snap) => snap.docs.length);
  }

  // Friends count for any user — realtime
  Stream<int> friendsCountStreamFor(String uid) {
    return _db
        .collection('users')
        .doc(uid)
        .collection('friends')
        .where('status', isEqualTo: 'friends')
        .snapshots()
        .map((snap) => snap.docs.length);
  }

  // Stream of friend user-data maps for current user (for share sheet etc.)
  Stream<List<Map<String, dynamic>>> myFriendsStream() {
    return _db
        .collection('users')
        .doc(_myUid)
        .collection('friends')
        .where('status', isEqualTo: 'friends')
        .snapshots()
        .asyncMap((snap) async {
      final List<Map<String, dynamic>> result = [];
      for (final doc in snap.docs) {
        try {
          final userDoc = await _db.collection('users').doc(doc.id).get();
          if (userDoc.exists) {
            result.add({'uid': doc.id, ...userDoc.data() as Map<String, dynamic>});
          }
        } catch (_) {}
      }
      return result;
    });
  }

  // Location
  Future<void> updateLocationSharingEnabled(bool enabled) async {
    try {
      await _db.collection('users').doc(_myUid).update({'locationSharingEnabled': enabled});
    } catch (_) {}
  }

  // ── Typing Indicator ─────────────────────────────────────────────────────────
  Future<void> setTyping(String otherUid, bool isTyping) async {
    final ids = [_myUid, otherUid]..sort();
    final cid = '${ids[0]}_${ids[1]}';
    try {
      await _db.collection('chats').doc(cid).update({
        'typing.$_myUid': isTyping,
        'typingAt.$_myUid': FieldValue.serverTimestamp(),
      });
    } catch (_) {}
  }

  Stream<bool> isOtherTyping(String otherUid) {
    final ids = [_myUid, otherUid]..sort();
    final cid = '${ids[0]}_${ids[1]}';
    return _db.collection('chats').doc(cid).snapshots().map((snap) {
      final data = snap.data() as Map<String, dynamic>? ?? {};
      final typing = data['typing'] as Map<String, dynamic>? ?? {};
      final typingAt = data['typingAt'] as Map<String, dynamic>? ?? {};
      final isTyping = typing[otherUid] == true;
      // Expire typing indicator after 5 seconds
      if (isTyping && typingAt[otherUid] != null) {
        final ts = (typingAt[otherUid] as Timestamp).toDate();
        if (DateTime.now().difference(ts).inSeconds > 5) return false;
      }
      return isTyping;
    });
  }

  // ── Profile Views ────────────────────────────────────────────────────────────
  Future<void> recordProfileView(String profileUid) async {
    if (profileUid == _myUid) return;
    try {
      await _db.collection('users').doc(profileUid).update({
        'profileViews': FieldValue.increment(1),
        'profileViewers': FieldValue.arrayUnion([_myUid]),
        'profileViewedAt.$_myUid': FieldValue.serverTimestamp(),
      });
    } catch (_) {}
  }

  Stream<Map<String, dynamic>> profileViewsStream(String uid) {
    return _db.collection('users').doc(uid).snapshots().map((snap) {
      final data = snap.data() as Map<String, dynamic>? ?? {};
      return {
        'count': data['profileViews'] ?? 0,
        'viewers': (data['profileViewers'] as List?)?.cast<String>() ?? [],
      };
    });
  }

  // ── Story Reply → sends a message with storyReply metadata ──────────────────
  Future<void> sendStoryReply({
    required String otherUid,
    required String replyText,
    required String storyId,
    required String storyMediaUrl,
    required String storyType,
  }) async {
    final ids = [_myUid, otherUid]..sort();
    final cid = '${ids[0]}_${ids[1]}';
    final msgData = <String, dynamic>{
      'senderId': _myUid,
      'text': replyText,
      'mediaType': 'text',
      'isRead': false,
      'timestamp': FieldValue.serverTimestamp(),
      'storyReply': {
        'storyId': storyId,
        'storyMediaUrl': storyMediaUrl,
        'storyType': storyType,
      },
    };
    await _db.collection('chats').doc(cid).collection('messages').add(msgData);
    await _db.collection('chats').doc(cid).set({
      'participants': ids,
      'lastMsg': '↩️ Replied to your story',
      'lastMsgTime': FieldValue.serverTimestamp(),
      'unreadCount.$otherUid': FieldValue.increment(1),
    }, SetOptions(merge: true));
  }

  // ── Contact Card ─────────────────────────────────────────────────────────────
  Future<void> sendContactCard({
    required String otherUid,
    required String contactUid,
    required String contactName,
    required String contactPhoto,
    required String contactUsername,
  }) async {
    await sendMessage(
      otherUid: otherUid,
      mediaType: 'contact_card',
      text: '👤 $contactName',
    );
    // Also store extra contact card data by updating the last message doc
    final ids = [_myUid, otherUid]..sort();
    final cid = '${ids[0]}_${ids[1]}';
    // Get the message we just sent and update it with contact fields
    final msgs = await _db
        .collection('chats')
        .doc(cid)
        .collection('messages')
        .orderBy('timestamp', descending: true)
        .limit(1)
        .get();
    if (msgs.docs.isNotEmpty) {
      await msgs.docs.first.reference.update({
        'contactUid': contactUid,
        'contactName': contactName,
        'contactPhoto': contactPhoto,
        'contactUsername': contactUsername,
      });
    }
  }

  // ── Block / Unblock ───────────────────────────────────────────────────────────
  Future<void> blockUser(String otherUid) async {
    await _db.collection('users').doc(_myUid).update({
      'blockedUsers': FieldValue.arrayUnion([otherUid]),
    });
  }

  Future<void> unblockUser(String otherUid) async {
    await _db.collection('users').doc(_myUid).update({
      'blockedUsers': FieldValue.arrayRemove([otherUid]),
    });
  }

  Stream<bool> isUserBlocked(String otherUid) {
    return _db.collection('users').doc(_myUid).snapshots().map((snap) {
      final data = snap.data() as Map<String, dynamic>? ?? {};
      final blocked = (data['blockedUsers'] as List<dynamic>? ?? []).cast<String>();
      return blocked.contains(otherUid);
    });
  }

  Stream<bool> amIBlockedBy(String otherUid) {
    return _db.collection('users').doc(otherUid).snapshots().map((snap) {
      final data = snap.data() as Map<String, dynamic>? ?? {};
      final blocked = (data['blockedUsers'] as List<dynamic>? ?? []).cast<String>();
      return blocked.contains(_myUid);
    });
  }

  // ── Reaction detail — fetch usernames for UIDs ───────────────────────────────
  Future<Map<String, String>> fetchUsernames(List<String> uids) async {
    if (uids.isEmpty) return {};
    final result = <String, String>{};
    final chunks = <List<String>>[];
    for (var i = 0; i < uids.length; i += 10) {
      chunks.add(uids.sublist(i, i + 10 > uids.length ? uids.length : i + 10));
    }
    for (final chunk in chunks) {
      final snap = await _db
          .collection('users')
          .where(FieldPath.documentId, whereIn: chunk)
          .get();
      for (final d in snap.docs) {
        final data = d.data();
        result[d.id] = data['username'] ?? 'User';
      }
    }
    return result;
  }

  // ── Remove Friend ────────────────────────────────────────────────────────────
  Future<void> removeFriend(String otherUid) async {
    final batch = _db.batch();
    batch.delete(_db.collection('users').doc(_myUid).collection('friends').doc(otherUid));
    batch.delete(_db.collection('users').doc(otherUid).collection('friends').doc(_myUid));
    await batch.commit();
  }

  // ══════════════════════════════════════════════════════════════════════════
  // ── Follow System ───────────────────────────────────────────────────────
  // ══════════════════════════════════════════════════════════════════════════
  // Follow System
  // following: users/{myUid}/following/{otherUid} { followedAt }
  // followers: users/{otherUid}/followers/{myUid} { followedAt }
  // ══════════════════════════════════════════════════════════════════════════

  // Session-level cache
  static final Map<String, bool> _followingCache = {};

  static void clearFollowCache() {
    _followingCache.clear();
  }

  /// Follow a user (writes to my following + their followers)
  Future<void> followUser(String otherUid) async {
    if (_auth.currentUser == null) return;
    // Step 1: Write subcollection docs (these are allowed by rules)
    final batch = _db.batch();
    final ts = {'followedAt': FieldValue.serverTimestamp()};
    batch.set(
      _db.collection('users').doc(_myUid).collection('following').doc(otherUid), ts);
    batch.set(
      _db.collection('users').doc(otherUid).collection('followers').doc(_myUid), ts);
    await batch.commit();

    // Step 2: Update counts separately — non-critical, ignore errors
    try {
      await _db.collection('users').doc(_myUid).update(
          {'followingCount': FieldValue.increment(1)});
    } catch (_) {}
    try {
      await _db.collection('users').doc(otherUid).update(
          {'followersCount': FieldValue.increment(1)});
    } catch (_) {
      // Will be recalculated from subcollection count — non-critical
    }
    _followingCache[otherUid] = true;
  }

  /// Unfollow a user
  Future<void> unfollowUser(String otherUid) async {
    if (_auth.currentUser == null) return;
    // Step 1: Delete subcollection docs
    final batch = _db.batch();
    batch.delete(_db.collection('users').doc(_myUid).collection('following').doc(otherUid));
    batch.delete(_db.collection('users').doc(otherUid).collection('followers').doc(_myUid));
    await batch.commit();

    // Step 2: Update counts separately — non-critical
    try {
      await _db.collection('users').doc(_myUid).update(
          {'followingCount': FieldValue.increment(-1)});
    } catch (_) {}
    try {
      await _db.collection('users').doc(otherUid).update(
          {'followersCount': FieldValue.increment(-1)});
    } catch (_) {
      // Non-critical — count shown from subcollection stream
    }
    _followingCache[otherUid] = false;
  }

  /// Check if I follow someone (live stream)
  Stream<bool> isFollowingStream(String otherUid) {
    return _db
        .collection('users').doc(_myUid).collection('following').doc(otherUid)
        .snapshots()
        .map((snap) {
          _followingCache[otherUid] = snap.exists;
          return snap.exists;
        });
  }

  /// One-shot check — uses cache
  Future<bool> isFollowingOnce(String otherUid) async {
    if (_followingCache.containsKey(otherUid)) return _followingCache[otherUid]!;
    try {
      final snap = await _db
          .collection('users').doc(_myUid).collection('following').doc(otherUid).get();
      _followingCache[otherUid] = snap.exists;
      return snap.exists;
    } catch (_) { return false; }
  }

  /// Check if someone follows me (am I followed by them)
  Future<bool> isFollowedByOnce(String otherUid) async {
    try {
      final snap = await _db
          .collection('users').doc(_myUid).collection('followers').doc(otherUid).get();
      return snap.exists;
    } catch (_) { return false; }
  }

  /// Live list of UIDs I follow
  Stream<List<String>> myFollowingStream() {
    return _db
        .collection('users').doc(_myUid).collection('following')
        .orderBy('followedAt', descending: false)
        .snapshots()
        .map((snap) => snap.docs.map((d) => d.id).toList());
  }

  /// Live list of following with full user data
  Stream<List<Map<String, dynamic>>> myFollowingWithDataStream() {
    return _db
        .collection('users').doc(_myUid).collection('following')
        .orderBy('followedAt', descending: false)
        .snapshots()
        .asyncMap((snap) async {
          if (snap.docs.isEmpty) return <Map<String, dynamic>>[];
          final uids = snap.docs.map((d) => d.id).toList();
          // Batch in chunks of 30
          final List<Map<String, dynamic>> result = [];
          for (int i = 0; i < uids.length; i += 30) {
            final chunk = uids.sublist(i, i + 30 > uids.length ? uids.length : i + 30);
            final usersSnap = await _db.collection('users')
                .where(FieldPath.documentId, whereIn: chunk).get();
            final userMap = {for (final d in usersSnap.docs) d.id: d.data()};
            for (final d in snap.docs.where((x) => chunk.contains(x.id))) {
              final u = userMap[d.id] ?? {};
              result.add({
                'uid':         d.id,
                'username':    u['username'] ?? '',
                'photoURL':    u['photoURL'] ?? '',
                'followedAt':  d.data()['followedAt'],
              });
            }
          }
          return result;
        });
  }

  /// Following count (live)
  Stream<int> followingCountStream() {
    return _db
        .collection('users').doc(_myUid).collection('following')
        .snapshots()
        .map((snap) => snap.docs.length);
  }

  /// Followers count for any user (live)
  Stream<int> followersCountStream(String uid) {
    return _db
        .collection('users').doc(uid).collection('followers')
        .snapshots()
        .map((snap) => snap.docs.length);
  }

  /// Live list of my followers with full user data
  Stream<List<Map<String, dynamic>>> myFollowersWithDataStream() {
    return _db
        .collection('users').doc(_myUid).collection('followers')
        .orderBy('followedAt', descending: true)
        .snapshots()
        .asyncMap((snap) async {
          if (snap.docs.isEmpty) return <Map<String, dynamic>>[];
          final uids = snap.docs.map((d) => d.id).toList();
          final List<Map<String, dynamic>> result = [];
          for (int i = 0; i < uids.length; i += 30) {
            final chunk = uids.sublist(i, i + 30 > uids.length ? uids.length : i + 30);
            final usersSnap = await _db.collection('users')
                .where(FieldPath.documentId, whereIn: chunk).get();
            final userMap = {for (final d in usersSnap.docs) d.id: d.data()};
            for (final d in snap.docs.where((x) => chunk.contains(x.id))) {
              final u = userMap[d.id] ?? {};
              result.add({
                'uid':        d.id,
                'username':   u['username'] ?? '',
                'photoURL':   u['photoURL'] ?? '',
                'followedAt': d.data()['followedAt'],
              });
            }
          }
          return result;
        });
  }

  // ── Backwards compat aliases (feed uses amIInTheirInnerCircle) ────────────
  Future<bool> amIInTheirInnerCircle(String authorUid) => isFollowingOnce(authorUid);
  Future<bool> isInMyInnerCircleOnce(String otherUid) => isFollowingOnce(otherUid);
  Stream<bool> isInMyInnerCircle(String otherUid) => isFollowingStream(otherUid);
  Future<String?> addToInnerCircle(String otherUid) async {
    try {
      await followUser(otherUid);
      return null;
    } on FirebaseException catch (e) {
      if (e.code == 'permission-denied') {
        // Try just writing own subcollection (fallback)
        try {
          final ts = {'followedAt': FieldValue.serverTimestamp()};
          await _db.collection('users').doc(_myUid).collection('following').doc(otherUid).set(ts);
          await _db.collection('users').doc(otherUid).collection('followers').doc(_myUid).set(ts);
          _followingCache[otherUid] = true;
          return null;
        } catch (_) {}
      }
      return 'Could not follow. Try again.';
    } catch (_) {
      return 'Could not follow. Try again.';
    }
  }

  // ═══════════════════════════════════════════════════════════
  //  Saved Messages
  // ═══════════════════════════════════════════════════════════

  /// Save a message to the current user's savedMessages subcollection.
  Future<void> saveMessage(Map<String, dynamic> msg, String chatPartnerName) async {
    if (_myUid == null) return;
    final docId = msg['firestoreId'] as String? ?? msg['id'] as String? ?? DateTime.now().millisecondsSinceEpoch.toString();
    await _db.collection('users').doc(_myUid).collection('savedMessages').doc(docId).set({
      'firestoreId': docId,
      'chatPartnerName': chatPartnerName,
      'chatPartnerId': msg['senderId'] ?? '',
      'text': msg['text'],
      'imageUrl': msg['imageUrl'],
      'videoUrl': msg['videoUrl'],
      'audioPath': msg['audioPath'],
      'docPath': msg['docPath'],
      'docName': msg['docName'],
      'isMe': msg['isMe'],
      'mediaType': msg['mediaType'],
      'savedAt': FieldValue.serverTimestamp(),
      'originalTimestamp': msg['timestamp'] != null
          ? Timestamp.fromDate(msg['timestamp'] as DateTime)
          : null,
    });
  }

  /// Unsave a message.
  Future<void> unsaveMessage(String firestoreId) async {
    if (_myUid == null) return;
    await _db.collection('users').doc(_myUid).collection('savedMessages').doc(firestoreId).delete();
  }

  /// Check if a message is saved.
  Future<bool> isMessageSaved(String firestoreId) async {
    if (_myUid == null) return false;
    final doc = await _db.collection('users').doc(_myUid).collection('savedMessages').doc(firestoreId).get();
    return doc.exists;
  }

  /// Stream of saved messages, newest first.
  Stream<List<Map<String, dynamic>>> savedMessagesStream() {
    if (_myUid == null) return const Stream.empty();
    return _db
        .collection('users')
        .doc(_myUid)
        .collection('savedMessages')
        .orderBy('savedAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) {
              final data = Map<String, dynamic>.from(d.data());
              data['firestoreId'] = d.id;
              // Convert Timestamp back to DateTime
              final ts = data['originalTimestamp'];
              if (ts is Timestamp) data['timestamp'] = ts.toDate();
              return data;
            }).toList());
  }

  Future<void> removeFromInnerCircle(String otherUid) => unfollowUser(otherUid);
  Stream<List<Map<String, dynamic>>> myInnerCircleWithDataStream() => myFollowingWithDataStream();
  Stream<int> innerCircleCountStream() => followingCountStream();
  static const int innerCircleMax = 999999;
  static void _clearCircleCache() => clearFollowCache();
}
