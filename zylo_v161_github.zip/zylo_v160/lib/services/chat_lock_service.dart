import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';

/// ChatLockService with in-memory cache.
///
/// FlutterSecureStorage karta hai encrypted disk I/O on every read —
/// isliye isLocked() ko bar bar call karna (e.g. chat list mein har tile)
/// lag create karta hai. Ab:
///   - _lockMemCache → lock state memory mein rehta hai
///   - _bioCache     → canUseBiometrics() sirf ek baar check hota hai
///   - setLock / removeLock dono disk + memory update karte hain
///   - preloadAll() → app start / chat list open hone par sab keys ek read mein load

class ChatLockService {
  static const _storage = FlutterSecureStorage();
  static final _localAuth = LocalAuthentication();

  // ── In-memory caches ─────────────────────────────────────────────────────
  static final Map<String, bool> _lockMemCache = {};
  static bool? _bioCache;              // null = not checked yet

  static String _lockKey(String chatId) => 'chat_lock_$chatId';
  static String _pinKey(String chatId)  => 'chat_pin_$chatId';

  // ── Preload all lock states in ONE disk read ──────────────────────────────
  /// Call this once when ChatListScreen opens.
  /// Reads ALL keys from secure storage, populates _lockMemCache.
  static Future<void> preloadAll() async {
    try {
      final all = await _storage.readAll();
      _lockMemCache.clear();
      all.forEach((key, value) {
        if (key.startsWith('chat_lock_')) {
          final chatId = key.substring('chat_lock_'.length);
          _lockMemCache[chatId] = value == 'true';
        }
      });
    } catch (_) {
      // Silent — old cache remains valid
    }
  }

  // ── isLocked: memory-first, disk fallback ────────────────────────────────
  static Future<bool> isLocked(String chatId) async {
    if (_lockMemCache.containsKey(chatId)) {
      return _lockMemCache[chatId]!;
    }
    // Cache miss — read from disk once and store
    try {
      final val = await _storage.read(key: _lockKey(chatId));
      final result = val == 'true';
      _lockMemCache[chatId] = result;
      return result;
    } catch (_) {
      return false;
    }
  }

  /// Synchronous read — returns null if not in cache yet (no disk I/O).
  /// Use this in ListView itemBuilder to avoid any async gap.
  static bool? isLockedSync(String chatId) => _lockMemCache[chatId];

  // ── setLock: update both memory + disk ───────────────────────────────────
  static Future<void> setLock(String chatId, bool locked) async {
    _lockMemCache[chatId] = locked;   // memory-first for instant UI
    await _storage.write(key: _lockKey(chatId), value: locked ? 'true' : 'false');
  }

  // ── removeLock: clear both memory + disk ────────────────────────────────
  static Future<void> removeLock(String chatId) async {
    _lockMemCache.remove(chatId);
    await _storage.delete(key: _lockKey(chatId));
    await _storage.delete(key: _pinKey(chatId));
  }

  // ── PIN helpers (no caching needed — only called on lock/unlock flows) ───
  static Future<void> setPin(String chatId, String pin) async {
    await _storage.write(key: _pinKey(chatId), value: pin);
  }

  static Future<String?> getPin(String chatId) async {
    return _storage.read(key: _pinKey(chatId));
  }

  // ── Biometrics: cache after first check ──────────────────────────────────
  static Future<bool> canUseBiometrics() async {
    if (_bioCache != null) return _bioCache!;
    try {
      _bioCache = await _localAuth.canCheckBiometrics ||
                  await _localAuth.isDeviceSupported();
      return _bioCache!;
    } catch (_) {
      _bioCache = false;
      return false;
    }
  }

  static Future<bool> authenticateBiometric() async {
    try {
      return await _localAuth.authenticate(
        localizedReason: 'Unlock this chat',
        options: const AuthenticationOptions(
          biometricOnly: false,
          useErrorDialogs: true,
          stickyAuth: true,
        ),
      );
    } on PlatformException catch (_) {
      return false;
    }
  }

  /// Call when user logs out — clear all in-memory state
  static void clearCache() {
    _lockMemCache.clear();
    _bioCache = null;
  }
}
