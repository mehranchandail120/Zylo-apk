import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Stores up to [maxAccounts] saved accounts locally.
/// Credentials (email+password) → flutter_secure_storage (encrypted).
/// Display info (uid, username, displayName, photoURL) → shared_preferences.
class AccountSwitcherService {
  static const int maxAccounts = 3;
  static const String _prefKey  = 'zylo_saved_accounts';       // JSON list of display info
  static const String _secPrefix = 'zylo_acc_cred_';           // prefix for secure entries

  static final _sec = FlutterSecureStorage(
    aOptions: const AndroidOptions(encryptedSharedPreferences: true),
  );

  // ─── Models ───────────────────────────────────────────────────────────────

  static List<SavedAccount> _fromPrefs(List<dynamic> raw) =>
      raw.map((e) => SavedAccount.fromJson(Map<String, dynamic>.from(e as Map))).toList();

  // ─── Read ─────────────────────────────────────────────────────────────────

  static Future<List<SavedAccount>> loadAccounts() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_prefKey);
    if (raw == null) return [];
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return _fromPrefs(list);
    } catch (_) {
      return [];
    }
  }

  static Future<_Creds?> loadCreds(String uid) async {
    final raw = await _sec.read(key: '$_secPrefix$uid');
    if (raw == null) return null;
    try {
      final m = jsonDecode(raw) as Map<String, dynamic>;
      return _Creds(email: m['email'] as String, password: m['password'] as String);
    } catch (_) {
      return null;
    }
  }

  // ─── Write ────────────────────────────────────────────────────────────────

  /// Call after successful login to persist this account.
  static Future<void> saveAccount({
    required String uid,
    required String email,
    required String password,
    required String username,
    required String displayName,
    required String? photoURL,
  }) async {
    final accounts = await loadAccounts();

    // Remove existing entry for this uid
    accounts.removeWhere((a) => a.uid == uid);

    // Add at front
    accounts.insert(0, SavedAccount(
      uid: uid,
      username: username,
      displayName: displayName,
      photoURL: photoURL,
    ));

    // Enforce limit
    final trimmed = accounts.take(maxAccounts).toList();

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefKey, jsonEncode(trimmed.map((a) => a.toJson()).toList()));

    // Save creds securely
    await _sec.write(
      key: '$_secPrefix$uid',
      value: jsonEncode({'email': email, 'password': password}),
    );
  }

  /// Update display info for an existing account (called after profile edit).
  static Future<void> updateDisplayInfo({
    required String uid,
    String? username,
    String? displayName,
    String? photoURL,
  }) async {
    final accounts = await loadAccounts();
    final idx = accounts.indexWhere((a) => a.uid == uid);
    if (idx == -1) return;
    accounts[idx] = accounts[idx].copyWith(
      username: username,
      displayName: displayName,
      photoURL: photoURL,
    );
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefKey, jsonEncode(accounts.map((a) => a.toJson()).toList()));
  }

  /// Remove a saved account (e.g. user explicitly removes it).
  static Future<void> removeAccount(String uid) async {
    final accounts = await loadAccounts();
    accounts.removeWhere((a) => a.uid == uid);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefKey, jsonEncode(accounts.map((a) => a.toJson()).toList()));
    await _sec.delete(key: '$_secPrefix$uid');
  }

  /// Clear all saved accounts.
  static Future<void> clearAll() async {
    final accounts = await loadAccounts();
    for (final a in accounts) {
      await _sec.delete(key: '$_secPrefix${a.uid}');
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_prefKey);
  }
}

// ─── Data classes ─────────────────────────────────────────────────────────────

class SavedAccount {
  final String uid;
  final String username;
  final String displayName;
  final String? photoURL;

  const SavedAccount({
    required this.uid,
    required this.username,
    required this.displayName,
    this.photoURL,
  });

  factory SavedAccount.fromJson(Map<String, dynamic> m) => SavedAccount(
    uid: m['uid'] as String,
    username: m['username'] as String,
    displayName: m['displayName'] as String,
    photoURL: m['photoURL'] as String?,
  );

  Map<String, dynamic> toJson() => {
    'uid': uid,
    'username': username,
    'displayName': displayName,
    if (photoURL != null) 'photoURL': photoURL,
  };

  SavedAccount copyWith({String? username, String? displayName, String? photoURL}) =>
      SavedAccount(
        uid: uid,
        username: username ?? this.username,
        displayName: displayName ?? this.displayName,
        photoURL: photoURL ?? this.photoURL,
      );
}

class _Creds {
  final String email;
  final String password;
  const _Creds({required this.email, required this.password});
}
