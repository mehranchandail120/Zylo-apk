import 'package:firebase_remote_config/firebase_remote_config.dart';
import 'package:flutter/foundation.dart';

/// Firebase Remote Config Service for Zylo
/// 
/// Usage:
///   await RemoteConfigService.instance.init();
///   final val = RemoteConfigService.instance.getString('my_key');
///
/// In Firebase Console → Remote Config, add keys like:
///   maintenance_mode        (bool)   → false
///   force_update_version    (string) → "1.3.9"
///   chat_list_page_size     (int)    → 30
///   banner_message          (string) → ""
///   feature_feed_enabled    (bool)   → true
///   feature_ai_chat_enabled (bool)   → true

class RemoteConfigService {
  RemoteConfigService._();
  static final RemoteConfigService instance = RemoteConfigService._();

  late final FirebaseRemoteConfig _rc;
  bool _initialized = false;

  // ── Default values — app works even if fetch fails ──────────────────────
  static const Map<String, dynamic> _defaults = {
    'maintenance_mode': false,
    'force_update_version': '',
    'min_supported_version': '',
    'chat_list_page_size': 30,
    'banner_message': '',
    'banner_color': '#0284C7',
    'feature_feed_enabled': true,
    'feature_ai_chat_enabled': true,
    'feature_voice_messages_enabled': true,
    'feature_video_messages_enabled': true,
    'max_file_upload_mb': 50,
    'welcome_message': '',
    'giphy_api_key': 'maiw24f5nnLL5WPtZGuJ2H63YWnziuzQjt8', // override in Firebase Console
  };

  /// Call once in main() after Firebase.initializeApp()
  Future<void> init() async {
    if (_initialized) return;
    try {
      _rc = FirebaseRemoteConfig.instance;

      await _rc.setConfigSettings(RemoteConfigSettings(
        fetchTimeout: const Duration(seconds: 10),
        minimumFetchInterval: kDebugMode
            ? const Duration(minutes: 0)   // instant refresh in dev
            : const Duration(hours: 1),    // 1hr cache in production
      ));

      await _rc.setDefaults(_defaults);
      await _rc.fetchAndActivate();
      _initialized = true;

      debugPrint('[RemoteConfig] Initialized — last fetch: ${_rc.lastFetchTime}');
    } catch (e) {
      // Never crash — defaults are already set above
      debugPrint('[RemoteConfig] Init failed (using defaults): $e');
      _initialized = true;
    }
  }

  /// Fetch fresh values in background (call on app resume if needed)
  Future<void> refresh() async {
    try {
      await _rc.fetchAndActivate();
    } catch (e) {
      debugPrint('[RemoteConfig] Refresh failed: $e');
    }
  }

  // ── Typed getters ────────────────────────────────────────────────────────

  bool getBool(String key) {
    try { return _rc.getBool(key); }
    catch (_) { return _defaults[key] as bool? ?? false; }
  }

  String getString(String key) {
    try { return _rc.getString(key); }
    catch (_) { return _defaults[key] as String? ?? ''; }
  }

  int getInt(String key) {
    try { return _rc.getInt(key); }
    catch (_) { return _defaults[key] as int? ?? 0; }
  }

  double getDouble(String key) {
    try { return _rc.getDouble(key); }
    catch (_) { return _defaults[key] as double? ?? 0.0; }
  }

  // ── Convenience shortcuts for common Zylo keys ──────────────────────────

  bool get isMaintenanceMode => getBool('maintenance_mode');
  String get forceUpdateVersion => getString('force_update_version');
  String get minSupportedVersion => getString('min_supported_version');
  int get chatListPageSize => getInt('chat_list_page_size');
  String get bannerMessage => getString('banner_message');
  String get bannerColor => getString('banner_color');
  bool get isFeedEnabled => getBool('feature_feed_enabled');
  bool get isAiChatEnabled => getBool('feature_ai_chat_enabled');
  bool get isVoiceMessagesEnabled => getBool('feature_voice_messages_enabled');
  bool get isVideoMessagesEnabled => getBool('feature_video_messages_enabled');
  String get giphyApiKey => getString('giphy_api_key');
  int get maxFileUploadMb => getInt('max_file_upload_mb');
  String get welcomeMessage => getString('welcome_message');
}
