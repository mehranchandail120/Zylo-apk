// ═══════════════════════════════════════════════════════════════════════════
// CloudflareService  —  Upload to Cloudflare Worker & Download via Telegram
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'notification_service.dart';
import 'package:firebase_auth/firebase_auth.dart';

class UploadResult {
  final String fileId;
  final String fileName;
  final String status;
  final int fileSize;
  const UploadResult({
    required this.fileId,
    required this.fileName,
    required this.status,
    this.fileSize = 0,
  });
  factory UploadResult.fromJson(Map<String, dynamic> json) => UploadResult(
    fileId:   json['file_id']   ?? '',
    fileName: json['file_name'] ?? '',
    status:   (json['ok'] == true) ? 'success' : (json['status'] ?? 'unknown'),
    fileSize: json['file_size'] ?? 0,
  );
  bool get isSuccess => status == 'success' || fileId.isNotEmpty;
}

class DownloadedFile {
  final File file;
  final String fileName;
  const DownloadedFile({required this.file, required this.fileName});
}

class CloudflareService {
  static const String _workerUrl = 'https://zylo-files.mehranchandailyt.workers.dev';

  // ── Telegram config ──────────────────────────────────────────────────────
  static const String _tgPart1 = '8605648071';
  static const String _tgPart2 = ':AAEJO3egJEDL2lz_KIEi2zKaWJ0InsTwrxQ';
  static const String _tgPart3 = '';
  static String get _tgToken => '$_tgPart1$_tgPart2$_tgPart3';
  // ignore: library_private_types_in_public_api
  static String get tgToken => _tgToken;

  static const String _prefsKeyUploads = 'zylo_cf_uploads';

  // FIX 1: Add upload/download timeouts
  static const Duration _uploadTimeout   = Duration(minutes: 10);
  static const Duration _downloadTimeout = Duration(minutes: 10);
  static const Duration _apiTimeout      = Duration(seconds: 15);

  // ─────────────────────────────────────────────────────────────────────────
  // UPLOAD
  // ─────────────────────────────────────────────────────────────────────────

  /// Upload [file] to the Cloudflare Worker → stored on Telegram.
  /// [onProgress] receives 0.0–1.0 upload progress (real streaming progress).
  /// Returns an [UploadResult] on success, throws on failure.
  static Future<UploadResult> uploadFile(
    File file, {
    void Function(double progress)? onProgress,
  }) async {
    // FIX 2: File existence check before upload
    if (!await file.exists()) {
      throw Exception('File not found: ${file.path}');
    }

    final fileName = p.basename(file.path);
    final body = await _sendMultipart(file, fileName, onProgress);
    onProgress?.call(1.0);

    final Map<String, dynamic> json;
    try {
      json = jsonDecode(body) as Map<String, dynamic>;
    } catch (_) {
      throw Exception('Invalid server response: $body');
    }

    final result = UploadResult.fromJson(json);

    // FIX 3: Save file size in history too
    final resultWithSize = UploadResult(
      fileId:   result.fileId,
      fileName: result.fileName,
      status:   result.status,
      fileSize: await file.length(),
    );

    if (resultWithSize.isSuccess) {
      await _saveUpload(resultWithSize);
      // Send upload complete notification (works even if app is in background)
      await NotificationService.sendUploadCompleteNotification(
        fileName: resultWithSize.fileName,
        fileSize: NotificationService.formatFileSize(resultWithSize.fileSize),
        isSuccess: true,
      );
    } else {
      await NotificationService.sendUploadCompleteNotification(
        fileName: fileName,
        fileSize: '',
        isSuccess: false,
      );
      throw Exception('Upload failed: status=${result.status}');
    }
    return resultWithSize;
  }

  static Future<String> _sendMultipart(
    File file,
    String fileName,
    void Function(double)? onProgress,
  ) async {
    final uri        = Uri.parse('$_workerUrl/upload');
    final totalBytes = await file.length();
    final request    = http.MultipartRequest('POST', uri);

    int sent = 0;
    final trackedStream = file.openRead().map((chunk) {
      sent += chunk.length;
      if (totalBytes > 0) {
        onProgress?.call((sent / totalBytes).clamp(0.0, 0.95));
      }
      return chunk;
    });

    request.files.add(http.MultipartFile(
      'file',
      trackedStream,
      totalBytes,
      filename: fileName,
    ));

    // FIX 1: Timeout on send
    final streamed = await request.send().timeout(_uploadTimeout);
    final body = await streamed.stream.bytesToString();

    if (streamed.statusCode != 200) {
      throw Exception('Upload failed (${streamed.statusCode}): $body');
    }
    return body;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // DOWNLOAD via Telegram getFile
  // ─────────────────────────────────────────────────────────────────────────

  /// Download file using [fileId] (Telegram file_id) via Telegram Bot API.
  /// [onProgress] receives 0.0–1.0 progress, or -1 if size unknown.
  static Future<DownloadedFile> downloadFile(
    String fileId,
    String fileName, {
    void Function(double progress)? onProgress,
  }) async {
    if (fileId.trim().isEmpty) throw Exception('File ID cannot be empty');

    // Step 1: Resolve file_path from Telegram
    final getFileUri = Uri.parse(
      'https://api.telegram.org/bot$_tgToken/getFile?file_id=$fileId',
    );

    // FIX 4: Timeout on Telegram API call
    final metaResp = await http.get(getFileUri).timeout(_apiTimeout);
    if (metaResp.statusCode != 200) {
      throw Exception('Telegram getFile failed (${metaResp.statusCode})');
    }

    final meta = jsonDecode(metaResp.body) as Map<String, dynamic>;
    if (meta['ok'] != true) {
      throw Exception('Telegram error: ${meta['description'] ?? 'unknown'}');
    }

    final result   = meta['result'] as Map<String, dynamic>;
    final filePath = result['file_path'] as String;
    final fileSize = (result['file_size'] as int?) ?? 0;

    // FIX 5: Auto-detect extension from Telegram file_path if fileName has none
    String saveName = fileName.trim().isEmpty ? 'zylo_download' : fileName;
    if (p.extension(saveName).isEmpty && p.extension(filePath).isNotEmpty) {
      saveName = '$saveName${p.extension(filePath)}';
    }

    // Step 2: Download from Telegram CDN
    final downloadUri = Uri.parse(
      'https://api.telegram.org/file/bot$_tgToken/$filePath',
    );

    final httpClient = HttpClient();
    httpClient.connectionTimeout = _downloadTimeout;

    final req      = await httpClient.getUrl(downloadUri);
    final response = await req.close();

    if (response.statusCode != 200) {
      httpClient.close();
      throw Exception('Download failed (${response.statusCode})');
    }

    // Save to device
    final saveDir  = await _getDownloadDir();
    final savePath = p.join(saveDir.path, _sanitizeFileName(saveName));
    final outFile  = File(savePath);
    final sink     = outFile.openWrite();

    int received = 0;
    await for (final chunk in response) {
      sink.add(chunk);
      received += chunk.length;
      if (fileSize > 0) {
        onProgress?.call((received / fileSize).clamp(0.0, 1.0));
      } else {
        onProgress?.call(-1); // indeterminate
      }
    }
    await sink.close();
    httpClient.close();
    onProgress?.call(1.0);

    // Send download complete notification
    await NotificationService.sendDownloadCompleteNotification(
      fileName: saveName,
      isSuccess: true,
    );

    return DownloadedFile(file: outFile, fileName: saveName);
  }

  // ─────────────────────────────────────────────────────────────────────────
  // LOCAL STORAGE — save/load upload history
  // ─────────────────────────────────────────────────────────────────────────

  // ── Cloud upload history (Firestore — works across all devices) ───────────
  static String? get _uid => FirebaseAuth.instance.currentUser?.uid;

  static Future<void> _saveUpload(UploadResult result) async {
    final uid = _uid;
    if (uid == null) return;

    final entry = {
      'file_id':     result.fileId,
      'file_name':   result.fileName,
      'file_size':   result.fileSize,
      'uploaded_at': DateTime.now().toIso8601String(),
    };

    // ── 1. Always save to SharedPrefs first (offline cache, always reliable) ──
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('zylo_cf_uploads');
      final List<dynamic> list = raw != null ? jsonDecode(raw) : [];
      list.removeWhere((e) => (e as Map)['file_id'] == result.fileId);
      list.insert(0, entry);
      if (list.length > 200) list.removeRange(200, list.length);
      await prefs.setString('zylo_cf_uploads', jsonEncode(list));
    } catch (e) {
      debugPrint('[CloudflareService] SharedPrefs save error: $e');
    }

    // ── 2. Also try Firestore (best-effort, failure is non-blocking) ──────────
    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .collection('uploadHistory')
          .doc(result.fileId)
          .set(entry);
    } catch (e) {
      debugPrint('[CloudflareService] Firestore save error (non-fatal): $e');
    }
  }

  static Future<List<Map<String, dynamic>>> getSavedUploads() async {
    final uid = _uid;
    if (uid != null) {
      try {
        final snap = await FirebaseFirestore.instance
            .collection('users').doc(uid).collection('uploadHistory')
            .orderBy('uploaded_at', descending: true).limit(200).get();
        if (snap.docs.isNotEmpty) {
          return snap.docs.map((d) => Map<String, dynamic>.from(d.data())).toList();
        }
      } catch (_) {}
    }
    // Fallback to local cache
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('zylo_cf_uploads');
    if (raw == null) return [];
    try { return (jsonDecode(raw) as List).cast<Map<String, dynamic>>(); } catch (_) { return []; }
  }

  static Future<void> clearSavedUploads() async {
    final uid = _uid;
    if (uid != null) {
      try {
        final snap = await FirebaseFirestore.instance
            .collection('users').doc(uid).collection('uploadHistory').get();
        for (final doc in snap.docs) await doc.reference.delete();
      } catch (_) {}
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('zylo_cf_uploads');
  }

  static Future<void> deleteUpload(String fileId) async {
    final uid = _uid;
    if (uid != null) {
      try {
        await FirebaseFirestore.instance
            .collection('users').doc(uid).collection('uploadHistory').doc(fileId).delete();
      } catch (_) {}
    }
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('zylo_cf_uploads');
    if (raw == null) return;
    final list = (jsonDecode(raw) as List).cast<Map<String, dynamic>>();
    list.removeWhere((e) => e['file_id'] == fileId);
    await prefs.setString('zylo_cf_uploads', jsonEncode(list));
  }


  // ─────────────────────────────────────────────────────────────────────────
  // HELPERS
  // ─────────────────────────────────────────────────────────────────────────

  static Future<Directory> _getDownloadDir() async {
    if (Platform.isAndroid) {
      final sdkInt = await _getAndroidSdkInt();
      if (sdkInt <= 29) {
        // Android 9 and below — request legacy storage permission
        final status = await Permission.storage.request();
        if (status.isGranted) {
          final dl = Directory('/storage/emulated/0/Download/zylo');
          if (!(await dl.exists())) await dl.create(recursive: true);
          return dl;
        }
      } else {
        // Android 10+ — app-scoped external Downloads (no permission needed)
        final extDirs = await getExternalStorageDirectories(
          type: StorageDirectory.downloads,
        );
        if (extDirs != null && extDirs.isNotEmpty) {
          final dir = Directory('${extDirs.first.path}/zylo');
          if (!(await dir.exists())) await dir.create(recursive: true);
          return dir;
        }
      }
      // Fallback — app documents dir, always works
      final docs = await getApplicationDocumentsDirectory();
      final dir  = Directory('${docs.path}/zylo_downloads');
      if (!(await dir.exists())) await dir.create(recursive: true);
      return dir;
    }
    // iOS
    final docs = await getApplicationDocumentsDirectory();
    final dir  = Directory('${docs.path}/zylo_downloads');
    if (!(await dir.exists())) await dir.create(recursive: true);
    return dir;
  }

  static Future<int> _getAndroidSdkInt() async {
    try {
      final info = await DeviceInfoPlugin().androidInfo;
      return info.version.sdkInt;
    } catch (_) {
      return 30; // assume modern Android if unknown
    }
  }

  static String _sanitizeFileName(String name) {
    return name.replaceAll(RegExp(r'[<>:"/\\|?*]'), '_');
  }

  static String buildDirectUrl(String filePath) {
    return 'https://api.telegram.org/file/bot$_tgToken/$filePath';
  }

  static String getFileEmoji(String fileName) {
    final ext = p.extension(fileName).toLowerCase();
    switch (ext) {
      case '.jpg': case '.jpeg': case '.png': case '.gif': case '.webp':
        return '🖼️';
      case '.mp4': case '.avi': case '.mkv': case '.mov':
        return '🎬';
      case '.mp3': case '.wav': case '.aac': case '.m4a': case '.ogg':
        return '🎵';
      case '.apk':  return '📦';
      case '.pdf':  return '📄';
      case '.doc': case '.docx': return '📝';
      case '.xls': case '.xlsx': return '📊';
      case '.ppt': case '.pptx': return '📊';
      case '.zip': case '.rar': case '.7z': return '🗜️';
      case '.txt':  return '📃';
      default:      return '📁';
    }
  }

  static String formatFileSize(int bytes) {
    if (bytes <= 0)              return 'Unknown size';
    if (bytes < 1024)            return '$bytes B';
    if (bytes < 1024 * 1024)    return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }
}
