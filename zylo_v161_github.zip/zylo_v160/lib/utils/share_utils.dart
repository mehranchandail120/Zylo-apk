// ═══════════════════════════════════════════════════════════════════════════
// ZyloShareUtils — Profile & Post link generator + share
//
// Usage:
//   ZyloShareUtils.shareProfile(username: 'mehran', displayName: 'Mehran');
//   ZyloShareUtils.sharePost(postId: 'abc123', authorName: 'Mehran', text: 'Hello!');
//   ZyloShareUtils.copyProfileLink(context, 'mehran');
//   ZyloShareUtils.copyPostLink(context, 'abc123');
// ═══════════════════════════════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

class ZyloShareUtils {
  ZyloShareUtils._();

  static const String _base = 'https://zyloo.pages.dev';

  static String profileLink(String username) =>
      '$_base/u/${username.toLowerCase().trim()}';

  static String postLink(String postId) => '$_base/p/$postId';

  static Future<void> shareProfile({
    required String username,
    String? displayName,
  }) async {
    final link = profileLink(username);
    final name = (displayName?.isNotEmpty == true) ? displayName! : username;
    await Share.share('👤 $name is on Zylo!\n$link', subject: '$name on Zylo');
  }

  static Future<void> sharePost({
    required String postId,
    required String authorName,
    String text = '',
  }) async {
    final link    = postLink(postId);
    final preview = text.length > 100 ? '${text.substring(0, 100)}...' : text;
    final body    = preview.isNotEmpty
        ? '📋 $authorName on Zylo:\n"$preview"\n\n$link'
        : '📋 Post by $authorName on Zylo\n$link';
    await Share.share(body, subject: '$authorName on Zylo');
  }

  static Future<void> copyProfileLink(BuildContext context, String username) async {
    await Clipboard.setData(ClipboardData(text: profileLink(username)));
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Profile link copied!'),
        backgroundColor: Color(0xFF8B5CF6),
        behavior: SnackBarBehavior.floating,
      ));
    }
  }

  static Future<void> copyPostLink(BuildContext context, String postId) async {
    await Clipboard.setData(ClipboardData(text: postLink(postId)));
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Post link copied!'),
        backgroundColor: Color(0xFF8B5CF6),
        behavior: SnackBarBehavior.floating,
      ));
    }
  }
}
