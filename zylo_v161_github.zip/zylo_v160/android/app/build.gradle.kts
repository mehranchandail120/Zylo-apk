plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.zylopages.app"
    compileSdk = 36
    ndkVersion = "27.0.12077973"

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_17.toString()
    }

    defaultConfig {
        applicationId = "com.zylopages.app"
        minSdk = 23
        targetSdk = 35
        versionCode = flutter.versionCode
        versionName = flutter.versionName
        multiDexEnabled = true
    }

    signingConfigs {
        create("release") {
            keyAlias = "zylo-key"
            keyPassword = "zylo@2026"
            storeFile = file("zylo-release.jks")
            storePassword = "zylo@2026"
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android.txt"),  // non-optimize safer for Flutter
                "proguard-rules.pro"
            )
        }
    }

    // ── Disable lint checks that cause Java heap OOM on release builds ─────────
    lint {
        abortOnError = false
        checkReleaseBuilds = false   // <-- this skips lintVitalAnalyzeRelease entirely
        disable += setOf(
            "InvalidPackage",
            "GradleDependency",
            "OldTargetApi"
        )
    }

    splits {
        abi {
            isEnable = true
            reset()
            include("arm64-v8a", "armeabi-v7a")
            isUniversalApk = true
        }
    }

    // ── Packaging options to avoid duplicate file conflicts ───────────────────
    packaging {
        resources {
            excludes += setOf(
                "META-INF/LICENSE",
                "META-INF/LICENSE.txt",
                "META-INF/NOTICE",
                "META-INF/NOTICE.txt",
                "META-INF/*.kotlin_module"
            )
        }
    }
}

flutter {
    source = "../.."
}


// ── ML Kit: Exclude ALL bundled models from APK — saves ~60-70MB ────────────
// Models download on-demand via OnDeviceTranslatorModelManager when user selects a language.
// Without these excludes, ML Kit bundles every language model into the APK at build time.
configurations.all {
    resolutionStrategy {
        // Force unbundled (thin) variants — download models on demand
        force("com.google.mlkit:translate:17.0.3")
        force("com.google.mlkit:language-id:17.0.6")
    }
    // Translation models — exclude bundled variants
    exclude(group = "com.google.mlkit", module = "translate-bundled")
    exclude(group = "com.google.android.gms", module = "play-services-mlkit-translate-bundled")
    // Language identification models — exclude bundled variants
    exclude(group = "com.google.mlkit", module = "language-id-bundled")
    exclude(group = "com.google.android.gms", module = "play-services-mlkit-language-id-bundled")
}

dependencies {
    implementation("androidx.multidex:multidex:2.0.1")
    implementation("com.google.android.gms:play-services-tasks:18.2.0")
    
    // Kotlin Coroutines for async operations in NotificationActionReceiver
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.8.0")
    
    // Firebase dependencies for native Kotlin code
    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    implementation("com.google.firebase:firebase-common-ktx")
    implementation("com.google.firebase:firebase-auth-ktx")
    implementation("com.google.firebase:firebase-firestore-ktx")

    // OneSignal dependency for native Kotlin code
    implementation("com.onesignal:OneSignal:[5.0.0, 5.99.99]")
}
