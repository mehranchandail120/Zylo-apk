package com.zylopages.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput
import com.onesignal.notifications.INotificationReceivedEvent
import com.onesignal.notifications.INotificationServiceExtension

class ZyloNotificationExtender : INotificationServiceExtension {

    override fun onNotificationReceived(event: INotificationReceivedEvent) {
        val notif = event.notification
        val data = notif.additionalData ?: run {
            event.preventDefault() // suppress default for safety
            return
        }
        val type = data.optString("type")
        if (type != "message") {
            // For non-message types, let OneSignal show default
            return
        }

        val context = event.context
        val chatId = data.optString("chatId")
        val fromUid = data.optString("fromUid")
        val fromName = data.optString("fromName", "User")
        val androidNotifId = notif.androidNotificationId

        // Suppress OneSignal default — we show our own with actions
        event.preventDefault()

        // Show our custom notification with Reply + Mark as Read
        showActionNotification(
            context = context,
            notifId = androidNotifId,
            title = notif.title ?: fromName,
            body = notif.body ?: "",
            chatId = chatId,
            fromUid = fromUid,
            fromName = fromName,
            bigIconUrl = data.optString("senderPhotoUrl", "")
        )
    }

    private fun showActionNotification(
        context: Context,
        notifId: Int,
        title: String,
        body: String,
        chatId: String,
        fromUid: String,
        fromName: String,
        bigIconUrl: String
    ) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "zylo_messages"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Messages",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                enableVibration(true)
                enableLights(true)
            }
            nm.createNotificationChannel(channel)
        }

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        else PendingIntent.FLAG_UPDATE_CURRENT

        // ── REPLY action ──────────────────────────────────────────────────────
        val remoteInput = RemoteInput.Builder(NotificationActionReceiver.KEY_REPLY_TEXT)
            .setLabel("Reply…")
            .build()

        val replyIntent = Intent(context, NotificationActionReceiver::class.java).apply {
            action = NotificationActionReceiver.ACTION_REPLY
            putExtra(NotificationActionReceiver.EXTRA_FROM_UID, fromUid)
            putExtra(NotificationActionReceiver.EXTRA_FROM_NAME, fromName)
            putExtra(NotificationActionReceiver.EXTRA_CHAT_ID, chatId)
            putExtra(NotificationActionReceiver.EXTRA_ANDROID_NOTIF_ID, notifId)
        }
        val replyPi = PendingIntent.getBroadcast(context, notifId * 10 + 1, replyIntent, flags)
        val replyAction = NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_revert, "Reply", replyPi
        ).addRemoteInput(remoteInput).build()

        // ── MARK AS READ action ───────────────────────────────────────────────
        val markReadIntent = Intent(context, NotificationActionReceiver::class.java).apply {
            action = NotificationActionReceiver.ACTION_MARK_READ
            putExtra(NotificationActionReceiver.EXTRA_FROM_UID, fromUid)
            putExtra(NotificationActionReceiver.EXTRA_CHAT_ID, chatId)
            putExtra(NotificationActionReceiver.EXTRA_ANDROID_NOTIF_ID, notifId)
        }
        val markReadPi = PendingIntent.getBroadcast(context, notifId * 10 + 2, markReadIntent, flags)
        val markReadAction = NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_agenda, "Mark as Read", markReadPi
        ).build()

        // ── TAP → open app ────────────────────────────────────────────────────
        // Note: MainActivity is usually in the root package of the project
        val tapIntent = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("type", "message")
            putExtra("fromUid", fromUid)
            putExtra("fromName", fromName)
        }
        val tapPi = PendingIntent.getActivity(context, notifId, tapIntent, flags)

        // ── Build notification ────────────────────────────────────────────────
        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(tapPi)
            .addAction(replyAction)
            .addAction(markReadAction)
            .setGroup("zylo_messages")

        nm.notify(notifId, builder.build())
    }
}
