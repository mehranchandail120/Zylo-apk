package com.zylopages.app

import android.app.NotificationManager
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.DocumentSnapshot
import com.google.android.gms.tasks.Tasks
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class NotificationActionReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_REPLY = "com.zylopages.app.ACTION_REPLY"
        const val ACTION_MARK_READ = "com.zylopages.app.ACTION_MARK_READ"
        const val KEY_REPLY_TEXT = "key_reply_text"
        const val EXTRA_NOTIF_ID = "notif_id"
        const val EXTRA_FROM_UID = "from_uid"
        const val EXTRA_FROM_NAME = "from_name"
        const val EXTRA_CHAT_ID = "chat_id"
        const val EXTRA_ANDROID_NOTIF_ID = "android_notif_id"
        const val BACKEND_URL = "https://zylo-notify.vercel.app/api/notify"
    }

    override fun onReceive(context: Context, intent: Intent) {
        FirebaseApp.initializeApp(context)
        val db = FirebaseFirestore.getInstance()
        val auth = FirebaseAuth.getInstance()
        val myUid = auth.currentUser?.uid ?: return

        val fromUid = intent.getStringExtra(EXTRA_FROM_UID) ?: return
        val fromName = intent.getStringExtra(EXTRA_FROM_NAME) ?: "User"
        val chatId = intent.getStringExtra(EXTRA_CHAT_ID) ?: return
        val androidNotifId = intent.getIntExtra(EXTRA_ANDROID_NOTIF_ID, -1)

        when (intent.action) {

            // ── REPLY ─────────────────────────────────────────────────────────
            ACTION_REPLY -> {
                val remoteInput = RemoteInput.getResultsFromIntent(intent)
                val replyText = remoteInput?.getCharSequence(KEY_REPLY_TEXT)
                    ?.toString()?.trim() ?: return

                // Dismiss notification
                if (androidNotifId != -1) {
                    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE)
                            as NotificationManager
                    nm.cancel(androidNotifId)
                }

                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        // 1. Save message to Firestore
                        db.collection("chats").document(chatId)
                            .collection("messages")
                            .add(mapOf(
                                "senderId" to myUid,
                                "text" to replyText,
                                "mediaType" to "text",
                                "isRead" to false,
                                "timestamp" to FieldValue.serverTimestamp()
                            ))

                        // 2. Update chat preview
                        db.collection("chats").document(chatId)
                            .update(mapOf(
                                "lastMsg" to replyText,
                                "lastMsgTime" to FieldValue.serverTimestamp(),
                                "unreadCount.$fromUid" to FieldValue.increment(1)
                            ))

                        // 3. Save in-app notification for receiver
                        db.collection("users").document(fromUid)
                            .collection("notifications")
                            .add(mapOf(
                                "type" to "message",
                                "text" to "@$fromName sent you a message",
                                "preview" to replyText,
                                "fromUid" to myUid,
                                "fromName" to fromName,
                                "chatId" to chatId,
                                "read" to false,
                                "createdAt" to FieldValue.serverTimestamp()
                            ))

                        // 4. Get receiver's OneSignal player ID + my photo
                        val receiverDocTask = db.collection("users").document(fromUid).get()
                        val myDocTask = db.collection("users").document(myUid).get()

                        // Wait for both
                        val receiverData: DocumentSnapshot = Tasks.await(receiverDocTask)
                        val myData: DocumentSnapshot = Tasks.await(myDocTask)

                        val playerId = receiverData.getString("oneSignalPlayerId") ?: return@launch
                        val myName = myData.getString("username") ?: "Someone"
                        val myPhoto = myData.getString("photoURL")

                        // 5. Send push via backend
                        sendPush(
                            playerId = playerId,
                            title = myName,
                            message = replyText,
                            photoUrl = myPhoto,
                            chatId = chatId,
                            fromUid = myUid,
                            fromName = myName
                        )

                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }

            // ── MARK AS READ ──────────────────────────────────────────────────
            ACTION_MARK_READ -> {
                // Dismiss notification
                if (androidNotifId != -1) {
                    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE)
                            as NotificationManager
                    nm.cancel(androidNotifId)
                }

                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        // Mark all unread notifications from this chat as read
                        val snapsTask = db.collection("users").document(myUid)
                            .collection("notifications")
                            .whereEqualTo("read", false)
                            .whereEqualTo("chatId", chatId)
                            .get()

                        val snaps: QuerySnapshot = Tasks.await(snapsTask)
                        val batch = db.batch()
                        for (doc in snaps.documents) {
                            batch.update(doc.reference, "read", true)
                        }
                        batch.commit()

                        // Also mark messages as read
                        val msgsTask = db.collection("chats").document(chatId)
                            .collection("messages")
                            .whereEqualTo("isRead", false)
                            .get()

                        val msgs: QuerySnapshot = Tasks.await(msgsTask)
                        val batch2 = db.batch()
                        for (doc in msgs.documents) {
                            if (doc.getString("senderId") != myUid) {
                                batch2.update(doc.reference, "isRead", true)
                            }
                        }
                        batch2.commit()

                        // Clear unread count
                        db.collection("chats").document(chatId)
                            .update("unreadCount.$myUid", 0)

                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }

    private fun sendPush(
        playerId: String,
        title: String,
        message: String,
        photoUrl: String?,
        chatId: String,
        fromUid: String,
        fromName: String
    ) {
        try {
            val url = URL(BACKEND_URL)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true

            val body = JSONObject().apply {
                put("playerIds", org.json.JSONArray().put(playerId))
                put("title", title)
                put("message", message)
                if (photoUrl != null) put("senderPhotoUrl", photoUrl)
                put("data", JSONObject().apply {
                    put("type", "message")
                    put("chatId", chatId)
                    put("fromUid", fromUid)
                    put("fromName", fromName)
                })
            }

            OutputStreamWriter(conn.outputStream).use { it.write(body.toString()) }
            conn.responseCode // trigger request
            conn.disconnect()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
