allprojects {
    repositories {
        google()
        mavenCentral()
    }
    // Force minimum Kotlin Gradle plugin version across ALL subprojects.
    // Prevents old plugins (like screenshot_callback 2.0.0) from pulling in
    // kotlin-gradle-plugin < 1.5.20 which breaks AGP 7.4+.
    configurations.all {
        resolutionStrategy.eachDependency {
            if (requested.group == "org.jetbrains.kotlin") {
                useVersion("1.9.10")
                because("AGP requires Kotlin Gradle plugin >= 1.5.20; force a modern version")
            }
        }
    }
}

// ── Patch all subprojects: namespace + compileSdk + JVM 17 ──
// Fixes flutter_app_badger 1.5.0 and any other older plugin with similar issues
subprojects {
    afterEvaluate {
        if (project.hasProperty("android")) {
            val androidExt = project.extensions.findByName("android")

            // Fix 1: AGP 8+ requires explicit namespace; older plugins omit it
            if (androidExt is com.android.build.gradle.LibraryExtension) {
                if (androidExt.namespace == null) {
                    androidExt.namespace = project.group.toString()
                }
            }

            if (androidExt is com.android.build.gradle.BaseExtension) {
                // Fix 2: Force compileSdk 34 on plugins that set a too-low value
                // (flutter_app_badger has compileSdkVersion < 30, breaking Java 9+ compile)
                val current = androidExt.compileSdkVersion
                    ?.removePrefix("android-")?.toIntOrNull() ?: 0
                if (current < 34) {
                    androidExt.compileSdkVersion(34)
                }

                // Fix 3: Force JVM 17 (fixes receive_sharing_intent JVM mismatch)
                androidExt.compileOptions {
                    sourceCompatibility = JavaVersion.VERSION_17
                    targetCompatibility = JavaVersion.VERSION_17
                }
            }

            tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile>().configureEach {
                kotlinOptions { jvmTarget = "17" }
            }
        }
    }
}

val newBuildDir: Directory = rootProject.layout.buildDirectory.dir("../../build").get()
rootProject.layout.buildDirectory.value(newBuildDir)

subprojects {
    val newSubprojectBuildDir: Directory = newBuildDir.dir(project.name)
    project.layout.buildDirectory.value(newSubprojectBuildDir)
}
subprojects {
    project.evaluationDependsOn(":app")
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
