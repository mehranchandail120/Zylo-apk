// ── Zylo Push Notification Backend ──────────────────────────────────────────
// Deploy karo: Vercel → https://zylo-notify.vercel.app/api/notify
// Env vars set karo Vercel dashboard mein:
//   ONESIGNAL_APP_ID     → OneSignal App ID
//   ONESIGNAL_REST_KEY   → OneSignal REST API Key

export default async function handler(req, res) {
  // CORS — Flutter app se aane wale requests allow karo
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { playerIds, title, message, senderPhotoUrl, data } = req.body ?? {};

  if (!playerIds || !Array.isArray(playerIds) || playerIds.length === 0) {
    return res.status(400).json({ error: 'playerIds required' });
  }

  const APP_ID  = process.env.ONESIGNAL_APP_ID;
  const API_KEY = process.env.ONESIGNAL_REST_KEY;

  if (!APP_ID || !API_KEY) {
    console.error('[Zylo] Missing env vars: ONESIGNAL_APP_ID or ONESIGNAL_REST_KEY');
    return res.status(500).json({ error: 'Server misconfigured' });
  }

  // Build OneSignal payload
  const payload = {
    app_id:              APP_ID,
    include_player_ids:  playerIds,
    headings:            { en: title    ?? 'Zylo' },
    contents:            { en: message  ?? '' },
    data:                data ?? {},
    // Android channel
    android_channel_id:  'zylo_messages',
    // Priority
    priority:            10,
    // iOS badge increment
    ios_badgeType:       'Increase',
    ios_badgeCount:      1,
  };

  // Large icon (sender photo)
  if (senderPhotoUrl) {
    payload.large_icon   = senderPhotoUrl; // Android
    payload.ios_attachments = { id1: senderPhotoUrl }; // iOS
  }

  try {
    const response = await fetch('https://onesignal.com/api/v1/notifications', {
      method:  'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': `Basic ${API_KEY}`,
      },
      body: JSON.stringify(payload),
    });

    const result = await response.json();

    if (!response.ok) {
      console.error('[Zylo] OneSignal error:', result);
      return res.status(response.status).json({ error: result });
    }

    console.log(`[Zylo] Sent to ${playerIds.length} device(s) | recipients: ${result.recipients}`);
    return res.status(200).json({ success: true, recipients: result.recipients, id: result.id });

  } catch (err) {
    console.error('[Zylo] Network error:', err.message);
    return res.status(500).json({ error: 'Failed to reach OneSignal' });
  }
}
