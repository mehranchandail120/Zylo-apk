# Zylo Notify Backend

## Deploy Steps

### 1. Vercel pe deploy karo
```bash
# Vercel CLI install
npm i -g vercel

# Is folder mein jaao
cd zylo_vercel_backend

# Deploy
vercel --prod
```

### 2. Environment Variables set karo
Vercel Dashboard → Project → Settings → Environment Variables:

| Variable | Value |
|---|---|
| `ONESIGNAL_APP_ID` | OneSignal dashboard → Settings → Keys & IDs → App ID |
| `ONESIGNAL_REST_KEY` | OneSignal dashboard → Settings → Keys & IDs → REST API Key |

### 3. OneSignal REST API Key kahan milega?
1. onesignal.com → apna app open karo
2. Settings → Keys & IDs
3. **REST API Key** copy karo (ye "API Key" nahi, "REST API Key" hai)
4. **App ID** bhi copy karo

### 4. Test karo
```bash
curl -X POST https://zylo-notify.vercel.app/api/notify \
  -H "Content-Type: application/json" \
  -d '{
    "playerIds": ["APNA_PLAYER_ID_YAHAN"],
    "title": "Test",
    "message": "Zylo notification working hai!"
  }'
```

Expected response:
```json
{"success": true, "recipients": 1, "id": "..."}
```

## Common Errors

| Error | Fix |
|---|---|
| `Host not in allowlist` | REST API Key galat hai — regenerate karo OneSignal se |
| `Missing app` | App ID galat hai |
| `recipients: 0` | Player ID invalid/expired — user ne app reinstall kiya hoga |
| `500 Server misconfigured` | Env vars set nahi kiye Vercel mein |
